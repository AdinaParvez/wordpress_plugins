jQuery(document).ready(function($){
    const vars = window.aceeducation_vars || {};
    const $bubble = $('#chatbot-bubble');
    const $window = $('#chatbot-window');
    const $close = $('#chatbot-close');
    const $send = $('#chatbot-send');
    const $input = $('#chatbot-input');
    const $messages = $('#chatbot-messages');
    const $suggests = $('#chatbot-suggests');
    const $saveLeadArea = $('#chatbot-save-lead');

    function appendBot(text){
        if(!text) return;
        $messages.append(`<div class="chatbot-msg-bot">${escapeHtml(text)}</div>`);
        scrollBottom();
    }

    function appendUser(text){
        $messages.append(`<div class="chatbot-msg-user">${escapeHtml(text)}</div>`);
        scrollBottom();
    }

    function scrollBottom(){ 
        $messages.scrollTop($messages[0].scrollHeight); 
    }

    function showTyping(){
        $messages.append(`<div class="chatbot-msg-bot" id="chatbot-typing">Typing...</div>`);
        scrollBottom();
    }

    function removeTyping(){ $('#chatbot-typing').remove(); }

    // Open/Close chat
    $bubble.on('click', function(){
        $window.removeClass('ace-hidden').attr('aria-hidden','false');
        if ($messages.children().length === 0) {
            appendBot(vars.greeting || 'Hello! How can I help?');
        }
    });

    $close.on('click', function(){ 
        $window.addClass('ace-hidden').attr('aria-hidden','true'); 
    });

    // Auto-popup after delay
    const delay = parseInt(vars.popup_delay_ms || 3000, 10);
    if(!sessionStorage.getItem('acebot_shown')){
        setTimeout(function(){ $bubble.click(); }, delay);
        sessionStorage.setItem('acebot_shown','yes');
    }

    // Quick suggestion buttons
    $suggests.on('click', '.suggest-btn', function(){
        const text = $(this).text();
        $input.val(text);
        sendMessage();
    });

    // Send message
    $send.on('click', sendMessage);
    $input.on('keypress', function(e){ 
        if(e.which === 13) sendMessage(); 
    });

    function sendMessage(){
        const text = $input.val().trim();
        if(!text) return;
        appendUser(text);
        $input.val('');
        showTyping();

        $.post(vars.ajax_url, {
            action: 'aceeducation_ai',
            nonce: vars.nonce,
            message: text
        }, function(res){
            removeTyping();
            if(res && res.success){
                appendBot(res.data.reply);
            } else {
                appendBot(res && res.data && res.data.msg ? res.data.msg : 'Sorry, something went wrong.');
            }
        }, 'json').fail(function(){
            removeTyping();
            appendBot('Network error. Please try again.');
        });
    }

    // Show save area with ctrl+shift+s (testing)
    $(document).on('keydown', function(e){
        if(e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 's') {
            $saveLeadArea.removeClass('ace-hidden');
        }
    });

    // Save lead
    $(document).on('click', '#lead-save-btn', function(){
        const name = $('#lead-name').val().trim();
        const email = $('#lead-email').val().trim();
        const message = $('#lead-message').val().trim();

        if(!name || !email) {
            alert('Please add name & email.');
            return;
        }

        $.post(vars.ajax_url, {
            action: 'aceeducation_save_lead',
            nonce: vars.nonce,
            name: name,
            email: email,
            message: message
        }, function(res){
            if(res && res.success){
                alert('Lead saved successfully.');
                $saveLeadArea.addClass('ace-hidden');
            } else {
                alert(res && res.data && res.data.msg ? res.data.msg : 'Could not save lead.');
            }
        }, 'json').fail(function(){
            alert('Network error.');
        });
    });

    // Util: escape HTML
    function escapeHtml(text) {
        return $('<div>').text(text).html();
    }
});
