<?php
/**
 * Plugin Name: ACEEducation Chatbot (Multi-AI)
 * Description: AI Chatbot integrated with multiple AI APIs - Gemini, OpenAI, Claude, Groq
 * Version: 2.0
 * Author: Adina Pervaiz
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* -----------------------
  Activation: create table
------------------------*/
register_activation_hook( __FILE__, 'aceeducation_activate' );
function aceeducation_activate() {
    global $wpdb;
    $table = $wpdb->prefix . 'aceeducation_leads';
    $charset = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        name varchar(191) DEFAULT '' NOT NULL,
        email varchar(191) DEFAULT '' NOT NULL,
        message text,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}

/* -------------------------------
   Admin Settings Page - MULTI-API
---------------------------------*/
add_action('admin_menu', 'aceeducation_admin_menu');
function aceeducation_admin_menu() {
    add_menu_page(
        'AceBot Settings',
        'AceBot',
        'manage_options',
        'acebot-settings',
        'aceeducation_settings_page',
        'dashicons-format-chat',
        100
    );
}

add_action('admin_init', 'aceeducation_register_settings');
function aceeducation_register_settings() {
    // AI Provider
    register_setting('acebot_options', 'acebot_ai_provider');
    
    // Gemini
    register_setting('acebot_options', 'acebot_gemini_key');
    register_setting('acebot_options', 'acebot_gemini_model');
    
    // OpenAI
    register_setting('acebot_options', 'acebot_openai_key');
    register_setting('acebot_options', 'acebot_openai_model');
    
    // Claude
    register_setting('acebot_options', 'acebot_claude_key');
    register_setting('acebot_options', 'acebot_claude_model');
    
    // Groq
    register_setting('acebot_options', 'acebot_groq_key');
    register_setting('acebot_options', 'acebot_groq_model');
    
    // Common
    register_setting('acebot_options', 'acebot_greeting');
    register_setting('acebot_options', 'acebot_popup_delay');
}

function aceeducation_settings_page() {
    ?>
    <div class="wrap">
        <h1>AceBot Settings - Multi AI</h1>
        <form method="post" action="options.php">
            <?php settings_fields('acebot_options'); ?>
            <table class="form-table">
                <tr>
                    <th>AI Provider</th>
                    <td>
                        <select name="acebot_ai_provider" id="ai_provider">
                            <?php
                            $current_provider = get_option('acebot_ai_provider', 'openai');
                            $providers = array(
                                'openai' => 'OpenAI ChatGPT (Recommended)',
                                'groq' => 'Groq (Fast & Free)',
                                'gemini' => 'Google Gemini',
                                'claude' => 'Anthropic Claude'
                            );
                            foreach ($providers as $value => $label) {
                                $selected = ($current_provider === $value) ? 'selected' : '';
                                echo "<option value='$value' $selected>$label</option>";
                            }
                            ?>
                        </select>
                        <p class="description">Choose which AI service to use</p>
                    </td>
                </tr>
                
                <!-- OpenAI Settings -->
                <tr class="provider-settings openai-settings">
                    <th>OpenAI API Key</th>
                    <td>
                        <input type="text" name="acebot_openai_key" value="<?php echo esc_attr(get_option('acebot_openai_key')); ?>" size="50" placeholder="sk-...">
                        <p class="description">Get from <a href="https://platform.openai.com/api-keys" target="_blank">OpenAI Platform</a> - $5 free credit for new users</p>
                    </td>
                </tr>
                <tr class="provider-settings openai-settings">
                    <th>OpenAI Model</th>
                    <td>
                        <select name="acebot_openai_model">
                            <?php
                            $current_model = get_option('acebot_openai_model', 'gpt-3.5-turbo');
                            $models = array(
                                'gpt-3.5-turbo' => 'GPT-3.5 Turbo (Fast & Cheap)',
                                'gpt-4' => 'GPT-4 (Most Powerful)',
                                'gpt-4-turbo-preview' => 'GPT-4 Turbo (Recommended)'
                            );
                            foreach ($models as $value => $label) {
                                $selected = ($current_model === $value) ? 'selected' : '';
                                echo "<option value='$value' $selected>$label</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                
                <!-- Groq Settings -->
                <tr class="provider-settings groq-settings" style="display:none;">
                    <th>Groq API Key</th>
                    <td>
                        <input type="text" name="acebot_groq_key" value="<?php echo esc_attr(get_option('acebot_groq_key')); ?>" size="50" placeholder="gsk_...">
                        <p class="description">Get from <a href="https://console.groq.com/keys" target="_blank">Groq Console</a> - Free tier available</p>
                    </td>
                </tr>
                <tr class="provider-settings groq-settings" style="display:none;">
                    <th>Groq Model</th>
                    <td>
                        <select name="acebot_groq_model">
                            <?php
                            $current_model = get_option('acebot_groq_model', 'llama2-70b-4096');
                            $models = array(
                                'llama2-70b-4096' => 'Llama2 70B (Recommended)',
                                'mixtral-8x7b-32768' => 'Mixtral 8x7B',
                                'gemma-7b-it' => 'Gemma 7B'
                            );
                            foreach ($models as $value => $label) {
                                $selected = ($current_model === $value) ? 'selected' : '';
                                echo "<option value='$value' $selected>$label</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                
                <!-- Gemini Settings -->
                <tr class="provider-settings gemini-settings" style="display:none;">
                    <th>Gemini API Key</th>
                    <td>
                        <input type="text" name="acebot_gemini_key" value="<?php echo esc_attr(get_option('acebot_gemini_key')); ?>" size="50" placeholder="AIza...">
                        <p class="description">Get from <a href="https://aistudio.google.com/app/apikey" target="_blank">Google AI Studio</a></p>
                    </td>
                </tr>
                <tr class="provider-settings gemini-settings" style="display:none;">
                    <th>Gemini Model</th>
                    <td>
                        <select name="acebot_gemini_model">
                            <?php
                            $current_model = get_option('acebot_gemini_model', 'gemini-pro');
                            $models = array(
                                'gemini-pro' => 'Gemini Pro (Recommended)',
                                'gemini-1.0-pro' => 'Gemini 1.0 Pro'
                            );
                            foreach ($models as $value => $label) {
                                $selected = ($current_model === $value) ? 'selected' : '';
                                echo "<option value='$value' $selected>$label</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                
                <!-- Claude Settings -->
                <tr class="provider-settings claude-settings" style="display:none;">
                    <th>Claude API Key</th>
                    <td>
                        <input type="text" name="acebot_claude_key" value="<?php echo esc_attr(get_option('acebot_claude_key')); ?>" size="50" placeholder="sk-ant-...">
                        <p class="description">Get from <a href="https://console.anthropic.com/" target="_blank">Anthropic Console</a></p>
                    </td>
                </tr>
                <tr class="provider-settings claude-settings" style="display:none;">
                    <th>Claude Model</th>
                    <td>
                        <select name="acebot_claude_model">
                            <?php
                            $current_model = get_option('acebot_claude_model', 'claude-3-haiku-20240307');
                            $models = array(
                                'claude-3-haiku-20240307' => 'Claude 3 Haiku (Fastest)',
                                'claude-3-sonnet-20240229' => 'Claude 3 Sonnet (Balanced)',
                                'claude-3-opus-20240229' => 'Claude 3 Opus (Most Powerful)'
                            );
                            foreach ($models as $value => $label) {
                                $selected = ($current_model === $value) ? 'selected' : '';
                                echo "<option value='$value' $selected>$label</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                
                <!-- Common Settings -->
                <tr>
                    <th>Greeting Message</th>
                    <td>
                        <input type="text" name="acebot_greeting" value="<?php echo esc_attr(get_option('acebot_greeting', "Hello! I'm AceBot — how can I help you today?")); ?>" size="70">
                        <p class="description">This message will show when the chat opens</p>
                    </td>
                </tr>
                <tr>
                    <th>Popup Delay (ms)</th>
                    <td>
                        <input type="number" name="acebot_popup_delay" value="<?php echo esc_attr(get_option('acebot_popup_delay', 3000)); ?>" size="10">
                        <p class="description">How long to wait before showing the chat popup (1000ms = 1 second)</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Settings'); ?>
        </form>
        
        <script>
        jQuery(document).ready(function($) {
            function toggleProviderSettings() {
                $('.provider-settings').hide();
                var provider = $('#ai_provider').val();
                $('.' + provider + '-settings').show();
            }
            
            $('#ai_provider').change(toggleProviderSettings);
            toggleProviderSettings(); // Run on page load
        });
        </script>

        <hr>
        
        <h2>Test API Connection</h2>
        <div style="background: #f9f9f9; padding: 15px; border-radius: 5px; margin-bottom: 15px;">
            <p><strong>Recommended Setup Steps:</strong></p>
            <ol>
                <li>Get an API key from your preferred provider (OpenAI recommended for beginners)</li>
                <li>Select the provider and enter your API key above</li>
                <li>Save settings</li>
                <li>Test the connection using the button below</li>
            </ol>
        </div>
        
        <button type="button" class="button button-primary" onclick="testAIAPI()">Test API Connection</button>
        <div id="api-test-result" style="margin-top: 10px; min-height: 50px; padding: 10px;"></div>
        
        <script>
        function testAIAPI() {
            var resultDiv = document.getElementById('api-test-result');
            resultDiv.innerHTML = '<div style="color: blue; background: #f0f5ff; padding: 15px; border-radius: 4px;">🔄 Testing API connection to selected provider...</div>';
            
            jQuery.post(ajaxurl, {
                action: 'aceeducation_test_api',
                nonce: '<?php echo wp_create_nonce('aceeducation_test_nonce'); ?>'
            }, function(response) {
                if (response.success) {
                    resultDiv.innerHTML = '<div style="color: green; background: #f0fff0; padding: 15px; border-radius: 4px; border: 1px solid #00ff00;">✅ <strong>Success!</strong> ' + response.data.msg + '</div>';
                } else {
                    resultDiv.innerHTML = '<div style="color: red; background: #fff0f0; padding: 15px; border-radius: 4px; border: 1px solid #ff0000;">❌ <strong>Error:</strong> ' + response.data.msg + '</div>';
                }
            }).fail(function(xhr, status, error) {
                resultDiv.innerHTML = '<div style="color: red; background: #fff0f0; padding: 15px; border-radius: 4px;">❌ <strong>AJAX Request Failed:</strong> ' + error + '</div>';
            });
        }
        </script>
        
        <div style="margin-top: 30px; padding: 20px; background: #f0f8ff; border-left: 4px solid #0073aa; border-radius: 4px;">
            <h3 style="margin-top: 0;">🚀 Quick Start Guide</h3>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 15px;">
                <div style="background: white; padding: 15px; border-radius: 4px;">
                    <h4>1. OpenAI ChatGPT (Recommended)</h4>
                    <ul>
                        <li><strong>Best for:</strong> Beginners, reliability</li>
                        <li><strong>Cost:</strong> $5 free credit + pay-as-you-go</li>
                        <li><strong>Speed:</strong> Fast</li>
                        <li><a href="https://platform.openai.com/api-keys" target="_blank">Get API Key →</a></li>
                    </ul>
                </div>
                
                <div style="background: white; padding: 15px; border-radius: 4px;">
                    <h4>2. Groq (Free Tier)</h4>
                    <ul>
                        <li><strong>Best for:</strong> Speed, free usage</li>
                        <li><strong>Cost:</strong> Free tier available</li>
                        <li><strong>Speed:</strong> Very fast</li>
                        <li><a href="https://console.groq.com/keys" target="_blank">Get API Key →</a></li>
                    </ul>
                </div>
                
                <div style="background: white; padding: 15px; border-radius: 4px;">
                    <h4>3. Google Gemini</h4>
                    <ul>
                        <li><strong>Best for:</strong> Google ecosystem</li>
                        <li><strong>Cost:</strong> Free with limits</li>
                        <li><strong>Speed:</strong> Medium</li>
                        <li><a href="https://aistudio.google.com/app/apikey" target="_blank">Get API Key →</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <?php
}

/* -------------------------------
   TEST API CONNECTION (Admin)
---------------------------------*/
add_action('wp_ajax_aceeducation_test_api', 'aceeducation_test_api');
function aceeducation_test_api() {
    check_ajax_referer('aceeducation_test_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('msg' => 'Permission denied'));
    }
    
    $provider = get_option('acebot_ai_provider', 'openai');
    
    // Get API key and model based on provider
    switch($provider) {
        case 'openai':
            $api_key = get_option('acebot_openai_key', '');
            $model = get_option('acebot_openai_model', 'gpt-3.5-turbo');
            if (empty($api_key)) {
                wp_send_json_error(array('msg' => 'OpenAI API key not configured'));
            }
            break;
            
        case 'groq':
            $api_key = get_option('acebot_groq_key', '');
            $model = get_option('acebot_groq_model', 'llama2-70b-4096');
            if (empty($api_key)) {
                wp_send_json_error(array('msg' => 'Groq API key not configured'));
            }
            break;
            
        case 'gemini':
            $api_key = get_option('acebot_gemini_key', '');
            $model = get_option('acebot_gemini_model', 'gemini-pro');
            if (empty($api_key)) {
                wp_send_json_error(array('msg' => 'Gemini API key not configured'));
            }
            break;
            
        case 'claude':
            $api_key = get_option('acebot_claude_key', '');
            $model = get_option('acebot_claude_model', 'claude-3-haiku-20240307');
            if (empty($api_key)) {
                wp_send_json_error(array('msg' => 'Claude API key not configured'));
            }
            break;
            
        default:
            wp_send_json_error(array('msg' => 'Unknown AI provider'));
    }
    
    // Test the API
    $test_result = aceeducation_call_ai_api($provider, $api_key, $model, "Hello! Please respond with just 'OK' if you can read this.");
    
    if ($test_result['success']) {
        wp_send_json_success(array('msg' => "✅ {$provider} API is working! Response: '" . $test_result['reply'] . "'"));
    } else {
        wp_send_json_error(array('msg' => $test_result['error']));
    }
}

/* -------------------------------
   MULTI-API AI FUNCTIONS
---------------------------------*/
function aceeducation_call_ai_api($provider, $api_key, $model, $user_message) {
    $system_prompt = "You are AceBot, a helpful, friendly assistant for " . get_bloginfo('name') . ". Keep responses concise and helpful. Respond directly to the user's message.";
    
    switch($provider) {
        case 'openai':
            return aceeducation_call_openai($api_key, $model, $system_prompt, $user_message);
        case 'groq':
            return aceeducation_call_groq($api_key, $model, $system_prompt, $user_message);
        case 'claude':
            return aceeducation_call_claude($api_key, $model, $system_prompt, $user_message);
        case 'gemini':
            return aceeducation_call_gemini($api_key, $model, $system_prompt, $user_message);
        default:
            return array('success' => false, 'error' => 'Unknown AI provider');
    }
}

function aceeducation_call_openai($api_key, $model, $system_prompt, $user_message) {
    $url = "https://api.openai.com/v1/chat/completions";
    
    $payload = array(
        "model" => $model,
        "messages" => array(
            array("role" => "system", "content" => $system_prompt),
            array("role" => "user", "content" => $user_message)
        ),
        "max_tokens" => 500,
        "temperature" => 0.7
    );
    
    $args = array(
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key
        ),
        'body' => wp_json_encode($payload),
        'timeout' => 20
    );
    
    $response = wp_remote_post($url, $args);
    
    if (is_wp_error($response)) {
        return array('success' => false, 'error' => 'Network error: ' . $response->get_error_message());
    }
    
    $response_code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);
    
    if ($response_code !== 200) {
        $error_msg = isset($body['error']['message']) ? $body['error']['message'] : 'Unknown error';
        return array('success' => false, 'error' => 'OpenAI API Error: ' . $error_msg);
    }
    
    if (isset($body['choices'][0]['message']['content'])) {
        return array('success' => true, 'reply' => trim($body['choices'][0]['message']['content']));
    }
    
    return array('success' => false, 'error' => 'Unexpected response format from OpenAI');
}

function aceeducation_call_groq($api_key, $model, $system_prompt, $user_message) {
    $url = "https://api.groq.com/openai/v1/chat/completions";
    
    $payload = array(
        "model" => $model,
        "messages" => array(
            array("role" => "system", "content" => $system_prompt),
            array("role" => "user", "content" => $user_message)
        ),
        "max_tokens" => 500,
        "temperature" => 0.7
    );
    
    $args = array(
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key
        ),
        'body' => wp_json_encode($payload),
        'timeout' => 20
    );
    
    $response = wp_remote_post($url, $args);
    
    if (is_wp_error($response)) {
        return array('success' => false, 'error' => 'Network error: ' . $response->get_error_message());
    }
    
    $response_code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);
    
    if ($response_code !== 200) {
        $error_msg = isset($body['error']['message']) ? $body['error']['message'] : 'Unknown error';
        return array('success' => false, 'error' => 'Groq API Error: ' . $error_msg);
    }
    
    if (isset($body['choices'][0]['message']['content'])) {
        return array('success' => true, 'reply' => trim($body['choices'][0]['message']['content']));
    }
    
    return array('success' => false, 'error' => 'Unexpected response format from Groq');
}

function aceeducation_call_claude($api_key, $model, $system_prompt, $user_message) {
    $url = "https://api.anthropic.com/v1/messages";
    
    $payload = array(
        "model" => $model,
        "max_tokens" => 500,
        "temperature" => 0.7,
        "system" => $system_prompt,
        "messages" => array(
            array("role" => "user", "content" => $user_message)
        )
    );
    
    $args = array(
        'headers' => array(
            'Content-Type' => 'application/json',
            'x-api-key' => $api_key,
            'anthropic-version' => '2023-06-01'
        ),
        'body' => wp_json_encode($payload),
        'timeout' => 20
    );
    
    $response = wp_remote_post($url, $args);
    
    if (is_wp_error($response)) {
        return array('success' => false, 'error' => 'Network error: ' . $response->get_error_message());
    }
    
    $response_code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);
    
    if ($response_code !== 200) {
        $error_msg = isset($body['error']['message']) ? $body['error']['message'] : 'Unknown error';
        return array('success' => false, 'error' => 'Claude API Error: ' . $error_msg);
    }
    
    if (isset($body['content'][0]['text'])) {
        return array('success' => true, 'reply' => trim($body['content'][0]['text']));
    }
    
    return array('success' => false, 'error' => 'Unexpected response format from Claude');
}

function aceeducation_call_gemini($api_key, $model, $system_prompt, $user_message) {
    $url = "https://generativelanguage.googleapis.com/v1/models/{$model}:generateContent?key=" . urlencode($api_key);

    $payload = array(
        "contents" => array(
            array(
                "parts" => array(
                    array("text" => $system_prompt . "\n\nUser: " . $user_message . "\nAssistant:")
                )
            )
        ),
        "generationConfig" => array(
            "temperature" => 0.7,
            "maxOutputTokens" => 500
        )
    );

    $args = array(
        'headers' => array('Content-Type' => 'application/json'),
        'body' => wp_json_encode($payload),
        'timeout' => 20
    );

    $response = wp_remote_post($url, $args);

    if (is_wp_error($response)) {
        return array('success' => false, 'error' => 'Network error: ' . $response->get_error_message());
    }

    $response_code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);
    
    if ($response_code !== 200) {
        if (isset($body['error']['message'])) {
            return array('success' => false, 'error' => 'Gemini API Error: ' . $body['error']['message']);
        }
        return array('success' => false, 'error' => "HTTP Error $response_code");
    }

    if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
        return array('success' => true, 'reply' => trim($body['candidates'][0]['content']['parts'][0]['text']));
    }

    return array('success' => false, 'error' => 'Unexpected response format from Gemini');
}

/* -------------------------------
   Enqueue CSS & JS (frontend)
---------------------------------*/
function aceeducation_assets() {
    wp_enqueue_style( 'aceeducation-style', plugin_dir_url( __FILE__ ) . 'assets/css/style.css' );
    wp_enqueue_script( 'aceeducation-js', plugin_dir_url( __FILE__ ) . 'assets/js/chat.js', array('jquery'), null, true );

    wp_localize_script( 'aceeducation-js', 'aceeducation_vars', array(
        'ajax_url'       => admin_url( 'admin-ajax.php' ),
        'nonce'          => wp_create_nonce( 'aceeducation_nonce' ),
        'greeting'       => get_option('acebot_greeting', "Hello! I'm AceBot — how can I help you today?"),
        'popup_delay_ms' => get_option('acebot_popup_delay', 3000),
        'site_name'      => get_bloginfo('name'),
    ) );
}
add_action( 'wp_enqueue_scripts', 'aceeducation_assets' );

/* -------------------------------
   Output HTML (chat bubble + window)
---------------------------------*/
function aceeducation_html() {
    include plugin_dir_path( __FILE__ ) . 'chatbot-window.php';
}
add_action( 'wp_footer', 'aceeducation_html' );

/* -------------------------------
   AJAX handler: AI reply (Multi-API)
---------------------------------*/
add_action( 'wp_ajax_aceeducation_ai', 'aceeducation_ai_response' );
add_action( 'wp_ajax_nopriv_aceeducation_ai', 'aceeducation_ai_response' );

function aceeducation_ai_response() {
    check_ajax_referer( 'aceeducation_nonce', 'nonce' );

    $user_msg = isset($_POST['message']) ? sanitize_text_field( wp_unslash($_POST['message']) ) : '';
    if ( empty( $user_msg ) ) {
        wp_send_json_error( array( 'msg' => 'Empty message.' ) );
    }

    $provider = get_option('acebot_ai_provider', 'openai');
    
    // Get API key and model based on provider
    switch($provider) {
        case 'openai':
            $api_key = get_option('acebot_openai_key', '');
            $model = get_option('acebot_openai_model', 'gpt-3.5-turbo');
            break;
        case 'groq':
            $api_key = get_option('acebot_groq_key', '');
            $model = get_option('acebot_groq_model', 'llama2-70b-4096');
            break;
        case 'gemini':
            $api_key = get_option('acebot_gemini_key', '');
            $model = get_option('acebot_gemini_model', 'gemini-pro');
            break;
        case 'claude':
            $api_key = get_option('acebot_claude_key', '');
            $model = get_option('acebot_claude_model', 'claude-3-haiku-20240307');
            break;
        default:
            wp_send_json_error( array( 'msg' => 'AI provider not configured.' ) );
    }

    if ( empty($api_key) ) {
        wp_send_json_error( array( 'msg' => 'API key not configured for ' . $provider . '.' ) );
    }

    $api_result = aceeducation_call_ai_api($provider, $api_key, $model, $user_msg);
    
    if ($api_result['success']) {
        wp_send_json_success( array( 
            'reply' => $api_result['reply'],
            'provider' => $provider
        ) );
    } else {
        wp_send_json_error( array(
            'msg' => "I'm having trouble connecting right now. Please try again later. Error: " . $api_result['error']
        ));
    }
}

/* -------------------------------
   AJAX handler: Save lead
---------------------------------*/
add_action( 'wp_ajax_aceeducation_save_lead', 'aceeducation_save_lead' );
add_action( 'wp_ajax_nopriv_aceeducation_save_lead', 'aceeducation_save_lead' );

function aceeducation_save_lead() {
    check_ajax_referer( 'aceeducation_nonce', 'nonce' );

    global $wpdb;
    $table = $wpdb->prefix . 'aceeducation_leads';

    $name    = isset($_POST['name']) ? sanitize_text_field( wp_unslash($_POST['name']) ) : '';
    $email   = isset($_POST['email']) ? sanitize_email( wp_unslash($_POST['email']) ) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field( wp_unslash($_POST['message']) ) : '';

    $inserted = $wpdb->insert(
        $table,
        array(
            'name'       => $name,
            'email'      => $email,
            'message'    => $message,
            'created_at' => current_time( 'mysql', 1 ),
        ),
        array( '%s', '%s', '%s', '%s' )
    );

    if ( $inserted ) {
        wp_send_json_success( array( 'msg' => 'Lead saved' ) );
    } else {
        wp_send_json_error( array( 'msg' => 'Could not save lead' ) );
    }
}