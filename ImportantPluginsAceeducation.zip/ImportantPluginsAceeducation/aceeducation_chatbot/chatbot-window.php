<?php
// This file is output in the footer to display the chat UI.
?>
<div id="acechat-root">
    <!-- Chat Bubble -->
    <div id="chatbot-bubble" title="Chat with Alex">
        <img src="https://i.pravatar.cc/150?img=3" alt="Alex" id="ace-bot-avatar">
        <span id="ace-bubble-text">Chat</span>
    </div>

    <!-- Chat Window -->
    <div id="chatbot-window" class="ace-hidden" aria-hidden="true">
        <div class="ace-header">
            <div class="ace-title"><strong>Alex</strong><small> — Ask me anything</small></div>
            <div class="ace-actions">
                <button id="chatbot-close" title="Close">×</button>
            </div>
        </div>

        <div id="chatbot-messages" role="log" aria-live="polite"></div>

        <div id="chatbot-suggests" class="ace-suggests">
            <button class="suggest-btn">Pricing</button>
            <button class="suggest-btn">Courses</button>
            <button class="suggest-btn">Contact</button>
        </div>

        <div class="ace-input-area">
            <input type="text" id="chatbot-input" placeholder="Type your message..." aria-label="Type your message">
            <button id="chatbot-send">Send</button>
        </div>

        <div id="chatbot-save-lead" class="ace-hidden">
            <h4>Save your details</h4>
            <input type="text" id="lead-name" placeholder="Your name">
            <input type="email" id="lead-email" placeholder="Email">
            <textarea id="lead-message" placeholder="Message (optional)"></textarea>
            <button id="lead-save-btn">Save & Notify</button>
        </div>
    </div>
</div>
