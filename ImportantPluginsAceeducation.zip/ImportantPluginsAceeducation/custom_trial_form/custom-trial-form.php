<?php
/*
Plugin Name: Custom Trial Form
Description: A responsive trial form that sends email and saves to database.
Version: 2.1
Author: Adina Pervaiz
*/

// Create database table on plugin activation
register_activation_hook(__FILE__, 'cef_trial_create_table');
function cef_trial_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'trial_form_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        full_name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        phone varchar(50) NOT NULL,
        message text NOT NULL,
        email_sent tinyint(1) DEFAULT 0,
        submitted_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Extend nonce lifetime to 7 days
add_filter('nonce_life', 'cef_trial_extend_nonce_lifetime');
function cef_trial_extend_nonce_lifetime() {
    return 7 * DAY_IN_SECONDS; // 7 days
}

// Add admin menu to view submissions
add_action('admin_menu', 'cef_trial_add_admin_menu');
function cef_trial_add_admin_menu() {
    add_menu_page(
        'Trial Form Submissions',
        'Trial Forms',
        'manage_options',
        'trial-form-submissions',
        'cef_trial_display_submissions',
        'dashicons-welcome-learn-more',
        31
    );
}

// Display submissions in admin
function cef_trial_display_submissions() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'trial_form_submissions';
    
    // Handle delete action
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $wpdb->delete($table_name, ['id' => $id]);
        echo '<div class="notice notice-success"><p>Submission deleted successfully.</p></div>';
    }
    
    // Handle export action
    if (isset($_GET['action']) && $_GET['action'] === 'export') {
        cef_trial_export_to_csv();
        exit;
    }
    
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC");
    
    ?>
    <div class="wrap">
        <h1>Trial Form Submissions</h1>
        <p>
            <a href="<?php echo admin_url('admin.php?page=trial-form-submissions&action=export'); ?>" class="button button-primary">Export to CSV</a>
        </p>
        
        <?php if (empty($submissions)): ?>
            <p>No submissions found.</p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Full Name</th>                   
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Email Sent</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $submission): ?>
                        <tr>
                            <td><?php echo $submission->id; ?></td>
                            <td><?php echo esc_html($submission->full_name); ?></td>
                            <td><?php echo esc_html($submission->email); ?></td>
                            <td><?php echo esc_html($submission->phone); ?></td>
                            <td><?php echo $submission->email_sent ? '✓ Yes' : '✗ No'; ?></td>
                            <td><?php echo date('M j, Y g:i a', strtotime($submission->submitted_at)); ?></td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=trial-form-submissions&action=view&id=' . $submission->id); ?>" class="button button-small">View</a>
                                <a href="<?php echo admin_url('admin.php?page=trial-form-submissions&action=delete&id=' . $submission->id); ?>" class="button button-small" onclick="return confirm('Are you sure you want to delete this submission?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
        <?php
        // Display full details if viewing a specific submission
        if (isset($_GET['action']) && $_GET['action'] === 'view' && isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $submission = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
            
            if ($submission) {
                ?>
                <div style="margin-top: 30px; padding: 20px; background: #fff; border: 1px solid #ccc;">
                    <h2>Submission Details - #<?php echo $submission->id; ?></h2>
                    <table class="form-table">
                        <tr><th>Full Name:</th><td><?php echo esc_html($submission->full_name); ?></td></tr>
                        <tr><th>Email:</th><td><?php echo esc_html($submission->email); ?></td></tr>
                        <tr><th>Phone:</th><td><?php echo esc_html($submission->phone); ?></td></tr>
                        <tr><th>Message:</th><td><?php echo nl2br(esc_html($submission->message)); ?></td></tr>
                        <tr><th>Email Sent:</th><td><?php echo $submission->email_sent ? 'Yes' : 'No'; ?></td></tr>
                        <tr><th>Submitted:</th><td><?php echo date('F j, Y, g:i a', strtotime($submission->submitted_at)); ?></td></tr>
                    </table>
                    <p><a href="<?php echo admin_url('admin.php?page=trial-form-submissions'); ?>" class="button">Back to List</a></p>
                </div>
                <?php
            }
        }
        ?>
    </div>
    <?php
}

// Export submissions to CSV
function cef_trial_export_to_csv(){
    global $wpdb;

    // Clear any previous output to avoid header errors
    if (ob_get_length()) ob_clean();

    $table_name = $wpdb->prefix . 'trial_form_submissions';
    $submissions = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    // If no records found, stop
    if (empty($submissions)) {
        wp_die(__('No data available to export.', 'cef'));
    }

    // Set headers for CSV file download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=trial_form_submissions-' . date('Y-m-d') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Open output stream
    $output = fopen('php://output', 'w');

    // Add UTF-8 BOM (for Excel compatibility)
    fputs($output, "\xEF\xBB\xBF");

    // Output CSV header (column names)
    fputcsv($output, array_keys($submissions[0]));

    // Output CSV rows
    foreach ($submissions as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
    exit;
}

// Shortcode to display the form
function cef_trial_form_shortcode() {
    ob_start(); ?>
    
<style>
    .cef-form-wrapper {
        max-width: 100%;
        margin: 0 auto;
        padding: 20px 0;
        background: #fff;
        font-family: Arial, sans-serif;
    }
    .cef-form-wrapper form {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }
    .cef-form-wrapper p {
        margin: 0;
    }
    .cef-form-wrapper label {
        font-weight: 600;
        font-size: 14px;
        display: block;
        margin-bottom: 6px;
        color: #333;
    }
    .cef-form-wrapper input[type="text"],
    .cef-form-wrapper input[type="tel"],
    .cef-form-wrapper input[type="email"],
    .cef-form-wrapper textarea {
        width: 100%;
        padding: 12px 15px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        background: #fff;
        box-sizing: border-box;
    }
    .cef-form-wrapper textarea {
        resize: vertical;
        min-height: 120px;
    }
    .cef-form-wrapper input[type="submit"] {
        background-color: #f9b000;
        width: 100%;
        color: #000;
        border: none;
        padding: 14px;
        cursor: pointer;
        border-radius: 4px;
        font-size: 16px;
        font-weight: bold;
        transition: background 0.3s ease;
    }
    .cef-form-wrapper input[type="submit"]:hover {
        background-color: #005177;
        color: #fff;
    }
    .cef-success-message {
        background: #d4edda;
        color: #155724;
        padding: 15px;
        border: 1px solid #c3e6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }
    .cef-error-message {
        background: #f8d7da;
        color: #721c24;
        padding: 15px;
        border: 1px solid #f5c6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }
    
    @media (max-width: 768px) {
        .cef-form-wrapper input,
        .cef-form-wrapper textarea {
            font-size: 16px;
        }
        .cef-form-wrapper input[type="submit"] {
            font-size: 18px;
            padding: 16px;
        }
    }
</style>

<div class="cef-form-wrapper">
    <?php
    // Display success or error messages
    if (isset($_GET['form_status'])) {
        if ($_GET['form_status'] === 'success') {
            echo '<div class="cef-success-message">✓ Thank you! Your inquiry has been submitted successfully.</div>';
        } elseif ($_GET['form_status'] === 'error') {
            echo '<div class="cef-error-message">⚠ There was an error submitting your form. Please try again.</div>';
        }
    }
    ?>
    
    <form method="post" action="">
        <?php wp_nonce_field('cef_trial_form_action', 'cef_trial_form_nonce'); ?>
       
        <p>
            <input type="text" placeholder="Name" name="full_name" required>
        </p>
        
        <p>
            <input type="email" placeholder="Email" name="email" required>
        </p>
        
        <p>
            <input type="tel" placeholder="Your Phone" name="phone" required>
        </p>
           
        <p>
            <textarea name="message" placeholder="Your Message" rows="5" required></textarea>
        </p>
        
        <p>
            <input type="submit" name="cef_trial_submit" value="Submit">
        </p>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Auto-hide success/error messages after 10 seconds
            const successMsg = document.querySelector('.cef-success-message');
            const errorMsg = document.querySelector('.cef-error-message');
            
            if (successMsg || errorMsg) {
                setTimeout(function() {
                    const msg = successMsg || errorMsg;
                    msg.style.transition = 'opacity 0.5s ease';
                    msg.style.opacity = '0';
                    
                    setTimeout(function() {
                        msg.remove();
                        const url = new URL(window.location);
                        url.searchParams.delete('form_status');
                        window.history.replaceState({}, document.title, url);
                    }, 500);
                }, 10000);
            }
        });
    </script>
</div>

<?php
    return ob_get_clean();
}
add_shortcode('custom_trial_form', 'cef_trial_form_shortcode');

// Handle form submission
add_action('init', 'cef_trial_handle_form');

function cef_trial_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cef_trial_submit'])) {

        // Verify nonce
        if (!isset($_POST['cef_trial_form_nonce']) || !wp_verify_nonce($_POST['cef_trial_form_nonce'], 'cef_trial_form_action')) {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
            exit;
        }

        // Sanitize and prepare data
        $data = [
            'full_name' => sanitize_text_field($_POST['full_name']),
            'email' => sanitize_email($_POST['email']),
            'phone' => sanitize_text_field($_POST['phone']),
            'message' => sanitize_textarea_field($_POST['message']),
        ];

        // Email recipients
        $to = ['info@acelanguagecentre.edu.my', 'acekl2018@gmail.com']; 
        $subject = 'New Free Trial Request';

        // Create HTML email body
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #f9b000;">New Free Trial Request</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%;">';
        
        $email_fields = [
            "Full Name" => $data['full_name'],
            "Email" => $data['email'],
            "Phone" => $data['phone'],
            "Message" => $data['message'],
        ];
        
        foreach ($email_fields as $label => $value) {
            $message .= '<tr style="border-bottom: 1px solid #ddd;">';
            $message .= '<td style="padding: 10px; font-weight: bold; width: 200px;">' . $label . ':</td>';
            $message .= '<td style="padding: 10px;">' . nl2br($value) . '</td>';
            $message .= '</tr>';
        }
        
        $message .= '</table>';
        $message .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
        $message .= '</body></html>';

        // Email headers
        $headers = [
            'From: ACE Language Centre Malaysia <info@acelanguagecentre.edu.my>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . $data['email']
        ];

        // Send email
        $mail_sent = wp_mail($to, $subject, $message, $headers);

        // Save to database (always save, mark if email was sent)
        global $wpdb;
        $table_name = $wpdb->prefix . 'trial_form_submissions';
        
        $data['email_sent'] = $mail_sent ? 1 : 0;
        
        $inserted = $wpdb->insert($table_name, $data);

        // Redirect with success message (form is saved regardless of email status)
        if ($inserted) {
            wp_redirect(add_query_arg('form_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
        }
        exit;
    }
}
?>