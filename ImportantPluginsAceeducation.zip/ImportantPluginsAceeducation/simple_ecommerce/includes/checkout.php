<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Stripe Checkout Button Shortcode
 * Usage: [stripe_checkout amount="10"]
 */
function simple_ecommerce_stripe_button( $atts ) {
    $atts = shortcode_atts( array(
        'amount' => '10.00', // default amount
    ), $atts, 'stripe_checkout' );

    ob_start(); ?>
    <form action="" method="POST" class="stripe-checkout-form">
        <input type="hidden" name="amount" value="<?php echo esc_attr($atts['amount']); ?>">
        <button type="submit" name="simple_ecommerce_stripe_pay">
            Pay with Stripe ($<?php echo esc_html($atts['amount']); ?>)
        </button>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode( 'stripe_checkout', 'simple_ecommerce_stripe_button' );


/**
 * PayPal Checkout Button Shortcode
 * Usage: [paypal_checkout amount="10"]
 */
function simple_ecommerce_paypal_button( $atts ) {
    $atts = shortcode_atts( array(
        'amount' => '10.00',
    ), $atts, 'paypal_checkout' );

    $paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr"; // Sandbox (change to live URL later)
    $business_email = "info@acelanguagecentre.my"; // Replace with real PayPal business email

    ob_start(); ?>
    <form action="<?php echo esc_url( $paypal_url ); ?>" method="post">
        <input type="hidden" name="business" value="<?php echo esc_attr( $business_email ); ?>">
        <input type="hidden" name="cmd" value="_xclick">
        <input type="hidden" name="amount" value="<?php echo esc_attr( $atts['amount'] ); ?>">
        <input type="hidden" name="currency_code" value="USD">
        <input type="hidden" name="item_name" value="Sample Product">
        <button type="submit">Pay with PayPal ($<?php echo esc_html($atts['amount']); ?>)</button>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode( 'paypal_checkout', 'simple_ecommerce_paypal_button' );
