<?php
// Start session
function my_ecom_start_session() {
    if (!session_id()) {
        session_start();
    }
}
add_action('init', 'my_ecom_start_session');

// Add to Cart
function my_ecom_add_to_cart() {
    $product_id = intval($_POST['product_id']);
    $_SESSION['my_cart'][] = $product_id;
    wp_send_json_success('Product added to cart');
}
add_action('wp_ajax_add_to_cart', 'my_ecom_add_to_cart');
add_action('wp_ajax_nopriv_add_to_cart', 'my_ecom_add_to_cart');

// Display Cart (shortcode)
function my_ecom_show_cart() {
    $cart_items = $_SESSION['my_cart'] ?? [];
    $output = "<h2>Your Cart</h2><ul>";
    foreach ($cart_items as $id) {
        $output .= "<li>" . get_the_title($id) . "</li>";
    }
    $output .= "</ul>";
    return $output;
}
add_shortcode('my_cart', 'my_ecom_show_cart');
