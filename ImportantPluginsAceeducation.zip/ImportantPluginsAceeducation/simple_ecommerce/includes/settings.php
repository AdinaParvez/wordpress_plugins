<?php
// Add settings page
function my_ecom_add_settings_page() {
    add_options_page(
        'My E-Commerce Settings',
        'My E-Commerce',
        'manage_options',
        'my-ecom-settings',
        'my_ecom_render_settings_page'
    );
}
add_action('admin_menu', 'my_ecom_add_settings_page');

// Render settings page
function my_ecom_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>My E-Commerce Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('my_ecom_settings_group');
            do_settings_sections('my-ecom-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register settings
function my_ecom_register_settings() {
    register_setting('my_ecom_settings_group', 'my_ecom_paypal_email');
    register_setting('my_ecom_settings_group', 'my_ecom_stripe_key');

    add_settings_section('my_ecom_section', 'Payment Settings', null, 'my-ecom-settings');

    add_settings_field('paypal_email', 'PayPal Email', 'my_ecom_paypal_field', 'my-ecom-settings', 'my_ecom_section');
    add_settings_field('stripe_key', 'Stripe Secret Key', 'my_ecom_stripe_field', 'my-ecom-settings', 'my_ecom_section');
}
add_action('admin_init', 'my_ecom_register_settings');

// Fields
function my_ecom_paypal_field() {
    $value = get_option('my_ecom_paypal_email', '');
    echo '<input type="email" name="my_ecom_paypal_email" value="' . esc_attr($value) . '" style="width: 300px;">';
}

function my_ecom_stripe_field() {
    $value = get_option('my_ecom_stripe_key', '');
    echo '<input type="text" name="my_ecom_stripe_key" value="' . esc_attr($value) . '" style="width: 300px;">';
}
