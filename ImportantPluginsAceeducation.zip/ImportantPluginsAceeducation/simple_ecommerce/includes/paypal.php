<?php
function my_ecom_process_paypal($cart_items, $name, $email) {
    $paypal_email = get_option('my_ecom_paypal_email');
    $return_url = home_url('/thank-you');
    $cancel_url = home_url('/checkout');

    // Assume all products are $10 for demo
    $amount = count($cart_items) * 10;

    // Redirect to PayPal
    $paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_xclick".
        "&business=" . urlencode($paypal_email).
        "&item_name=" . urlencode("Order from $name").
        "&amount=" . urlencode($amount).
        "&currency_code=USD".
        "&return=" . urlencode($return_url).
        "&cancel_return=" . urlencode($cancel_url);

    wp_redirect($paypal_url);
    exit;
}
