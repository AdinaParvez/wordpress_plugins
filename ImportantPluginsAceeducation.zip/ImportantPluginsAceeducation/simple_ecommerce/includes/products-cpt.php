<?php
// Register "Product" Custom Post Type
function my_ecom_register_product_cpt() {
    $labels = array(
        'name' => 'Products',
        'singular_name' => 'Product'
    );
    $args = array(
        'public' => true,
        'label' => 'Products',
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-cart'
    );
    register_post_type('my_product', $args);
}
add_action('init', 'my_ecom_register_product_cpt');
