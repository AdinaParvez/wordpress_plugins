<?php
require 'vendor/autoload.php'; // Install stripe-php via Composer

function my_ecom_process_stripe($cart_items, $name, $email) {
    $stripe_secret = get_option('my_ecom_stripe_key');
    \Stripe\Stripe::setApiKey($stripe_secret);

    $amount = count($cart_items) * 1000; // $10 each, in cents

    $session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'usd',
                'product_data' => [
                    'name' => "Order from $name",
                ],
                'unit_amount' => $amount,
            ],
            'quantity' => 1,
        ]],
        'mode' => 'payment',
        'success_url' => home_url('/thank-you'),
        'cancel_url' => home_url('/checkout'),
        'customer_email' => $email,
    ]);

    wp_redirect($session->url);
    exit;
}
