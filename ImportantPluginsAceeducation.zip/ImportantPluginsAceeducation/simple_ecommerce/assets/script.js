jQuery(document).ready(function($){

    // Stripe Checkout
    $('#se-payment-form').on('submit', function(e){
        e.preventDefault();

        var productName = $('input[name="product_name"]').val();
        var amount = $('input[name="amount"]').val();

        if(!productName || !amount){
            alert('Please fill in all fields.');
            return;
        }

        $(this).find('button').attr('disabled', true).text('Redirecting...');

        $.post(se_ajax.ajax_url, {
            action: 'se_stripe_checkout',
            product_name: productName,
            amount: amount
        }, function(response){
            if(response.success){
                var stripe = Stripe('pk_test_51S2mlLRFWVtBL14VuYgQ4kCIzvFOD0cHqJNLf9ZjEgP7nHML4RvsYVhwrnO5UkmDEmkkXOV5TvSlQwi5qiii1XMj00j4x9FCkA');
                stripe.redirectToCheckout({ sessionId: response.data.id });
            } else {
                alert('Error: ' + response.data);
                $('#se-payment-form button').attr('disabled', false).text('Pay with Stripe');
            }
        });

    });

    // PayPal Buttons
    paypal.Buttons({
        createOrder: function(data, actions){
            var amount = $('input[name="amount"]').val();
            if(!amount) amount = '0.01'; // default if empty
            return actions.order.create({
                purchase_units: [{
                    amount: { value: amount }
                }]
            });
        },
        onApprove: function(data, actions){
            return actions.order.capture().then(function(details){
                alert('PayPal Payment Successful! Transaction completed by ' + details.payer.name.given_name);
            });
        }
    }).render('#paypal-button-container');

});
