<?php
/*
Plugin Name: Simple Ecommerce
Description: Fully functional simple e-commerce plugin with Stripe & PayPal checkout.
Version: 1.1
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

// Composer Autoload for Stripe
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require __DIR__ . '/vendor/autoload.php';
}

// Enqueue CSS & JS
function se_enqueue_assets() {
    wp_enqueue_style('se-style', plugin_dir_url(__FILE__) . 'assets/style.css');
    wp_enqueue_script('se-script', plugin_dir_url(__FILE__) . 'assets/script.js', array('jquery'), '1.0', true);
    wp_localize_script('se-script', 'se_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php')
    ));
}
add_action('wp_enqueue_scripts', 'se_enqueue_assets');

// Shortcode [simple_checkout]
function se_checkout_shortcode() {
    // ✅ Get course and price from URL inside the function
    $course_name = isset($_GET['course']) ? sanitize_text_field($_GET['course']) : '';
    $course_price = isset($_GET['price']) ? floatval($_GET['price']) : '';
    ob_start(); ?>
    <div class="se-checkout-form">
        <h2>Simple Checkout</h2>
        <form id="se-payment-form">
            <label>Course Name</label>
           <input type="text" name="product_name" value="<?php echo esc_attr($course_name); ?>" readonly required>
            
            <label>Amount (USD)</label>
            <input type="number" name="amount" value="<?php echo esc_attr($course_price); ?>" step="0.01" readonly required>
            
            <button type="submit">Pay with Stripe</button>
        </form>
        <hr>
        <div id="paypal-button-container"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('simple_checkout', 'se_checkout_shortcode');

// Stripe Checkout Session AJAX
add_action('wp_ajax_se_stripe_checkout', 'se_stripe_checkout');
add_action('wp_ajax_nopriv_se_stripe_checkout', 'se_stripe_checkout');

function se_stripe_checkout() {
    if (!isset($_POST['amount']) || !isset($_POST['product_name'])) {
        wp_send_json_error('Missing fields');
    }

    \Stripe\Stripe::setApiKey('sk_test_51S2mlLRFWVtBL14VQQtPA6XU7dzmJ6TxKJscoiMkymyQE3pOKLMeMlAyeuXtc7nSQBKqYJr2J0QnEC5wwQMYvIDs008GVMWmka');

    try {
        $session = \Stripe\Checkout\Session::create([
            'payment_method_types' => ['card'],
            'line_items' => [[
                'price_data' => [
                    'currency' => 'usd',
                    'product_data' => [
                        'name' => sanitize_text_field($_POST['product_name']),
                    ],
                    'unit_amount' => intval($_POST['amount'] * 100),
                ],
                'quantity' => 1,
            ]],
            'mode' => 'payment',
            'success_url' => site_url('?payment=success'),
            'cancel_url' => site_url('?payment=cancel'),
        ]);

        wp_send_json_success(['id' => $session->id]);
    } catch (Exception $e) {
        wp_send_json_error($e->getMessage());
    }
}

// PayPal SDK Script
add_action('wp_footer', function() { ?>
<script src="https://www.paypal.com/sdk/js?client-id=Afqn1d7_8dOFP-WFpJ7KDo7l1d3c_NWr4Wtg05JfSVOsT46l8GYzBg3RyipbgMBiabYFLoHDlOUOKtGa&currency=USD"></script>
<?php });
