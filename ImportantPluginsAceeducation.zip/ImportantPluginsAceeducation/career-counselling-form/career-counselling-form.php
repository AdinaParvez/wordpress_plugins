<?php
/*
Plugin Name: Career Counselling Form
Description: A responsive career counselling form that sends email and saves to database.
Version: 1.0
Author: Adina Pervaiz
*/

// Create database table on plugin activation
register_activation_hook(__FILE__, 'cef_career_create_table');
function cef_career_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'career_counselling_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        full_name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        phone varchar(50) NOT NULL,
        education_level varchar(100) NOT NULL,
        area_of_interest varchar(255) NOT NULL,
        message text NOT NULL,
        terms varchar(50) NOT NULL,
        email_sent tinyint(1) DEFAULT 0,
        submitted_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Add admin menu to view submissions
add_action('admin_menu', 'cef_career_add_admin_menu');
function cef_career_add_admin_menu() {
    add_menu_page(
        'Career Counselling Submissions',
        'Career Counselling',
        'manage_options',
        'career-counselling-submissions',
        'cef_career_display_submissions',
        'dashicons-businessperson',
        32
    );
}

// Display submissions in admin
function cef_career_display_submissions() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'career_counselling_submissions';
    
    // Handle delete action
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $wpdb->delete($table_name, ['id' => $id]);
        echo '<div class="notice notice-success"><p>Submission deleted successfully.</p></div>';
    }
    
    // Handle export action
    if (isset($_GET['action']) && $_GET['action'] === 'export') {
        cef_career_export_to_csv();
        exit;
    }
    
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC");
    
    ?>
    <div class="wrap">
        <h1>Career Counselling Submissions</h1>
        <p>
            <a href="<?php echo admin_url('admin.php?page=career-counselling-submissions&action=export'); ?>" class="button button-primary">Export to CSV</a>
        </p>
        
        <?php if (empty($submissions)): ?>
            <p>No submissions found.</p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Education Level</th>
                        <th>Interest</th>
                        <th>Email Sent</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $submission): ?>
                        <tr>
                            <td><?php echo $submission->id; ?></td>
                            <td><?php echo esc_html($submission->full_name); ?></td>
                            <td><?php echo esc_html($submission->email); ?></td>
                            <td><?php echo esc_html($submission->phone); ?></td>
                            <td><?php echo esc_html($submission->education_level); ?></td>
                            <td><?php echo esc_html($submission->area_of_interest); ?></td>
                            <td><?php echo $submission->email_sent ? '✓ Yes' : '✗ No'; ?></td>
                            <td><?php echo date('M j, Y g:i a', strtotime($submission->submitted_at)); ?></td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=career-counselling-submissions&action=view&id=' . $submission->id); ?>" class="button button-small">View</a>
                                <a href="<?php echo admin_url('admin.php?page=career-counselling-submissions&action=delete&id=' . $submission->id); ?>" class="button button-small" onclick="return confirm('Are you sure you want to delete this submission?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
        <?php
        // Display full details if viewing a specific submission
        if (isset($_GET['action']) && $_GET['action'] === 'view' && isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $submission = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
            
            if ($submission) {
                ?>
                <div style="margin-top: 30px; padding: 20px; background: #fff; border: 1px solid #ccc;">
                    <h2>Submission Details - #<?php echo $submission->id; ?></h2>
                    <table class="form-table">
                        <tr><th>Full Name:</th><td><?php echo esc_html($submission->full_name); ?></td></tr>
                        <tr><th>Email:</th><td><?php echo esc_html($submission->email); ?></td></tr>
                        <tr><th>Phone:</th><td><?php echo esc_html($submission->phone); ?></td></tr>
                        <tr><th>Education Level:</th><td><?php echo esc_html($submission->education_level); ?></td></tr>
                        <tr><th>Area of Interest:</th><td><?php echo esc_html($submission->area_of_interest); ?></td></tr>
                        <tr><th>Message:</th><td><?php echo nl2br(esc_html($submission->message)); ?></td></tr>
                        <tr><th>Terms Agreed:</th><td><?php echo esc_html($submission->terms); ?></td></tr>
                        <tr><th>Email Sent:</th><td><?php echo $submission->email_sent ? 'Yes' : 'No'; ?></td></tr>
                        <tr><th>Submitted:</th><td><?php echo date('F j, Y, g:i a', strtotime($submission->submitted_at)); ?></td></tr>
                    </table>
                    <p><a href="<?php echo admin_url('admin.php?page=career-counselling-submissions'); ?>" class="button">Back to List</a></p>
                </div>
                <?php
            }
        }
        ?>
    </div>
    <?php
}

// Export CSV Function
function cef_career_export_to_csv() {
    global $wpdb;

    if (ob_get_length()) ob_clean();

    $table_name = $wpdb->prefix . 'career_counselling_submissions';
    $submissions = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    if (empty($submissions)) {
        wp_die(__('No data available to export.', 'cef'));
    }

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=career-counselling-submissions-' . date('Y-m-d') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');
    fputs($output, "\xEF\xBB\xBF");
    fputcsv($output, array_keys($submissions[0]));

    foreach ($submissions as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
    exit;
}

// Shortcode to display form
function cef_career_form_shortcode() {
    ob_start(); ?>
    
<style>
    .cef-career-wrapper {
        max-width: 800px;
        margin: 0 auto;
        padding: 40px 20px;
        background: #fff;
        font-family: Arial, sans-serif;
    }

    .cef-career-wrapper h2 {
        text-align: center;
        color: #005177;
        margin-bottom: 10px;
        font-size: 32px;
    }

    .cef-career-wrapper .subtitle {
        text-align: center;
        color: #666;
        margin-bottom: 30px;
        font-size: 16px;
    }

    .cef-career-wrapper form {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .cef-career-wrapper p {
        margin: 0;
    }

    .cef-career-wrapper label {
        font-weight: 600;
        font-size: 14px;
        display: block;
        margin-bottom: 6px;
        color: #333;
    }

    .cef-career-wrapper input[type="text"],
    .cef-career-wrapper input[type="tel"],
    .cef-career-wrapper input[type="email"],
    .cef-career-wrapper textarea,
    .cef-career-wrapper select {
        width: 100%;
        padding: 12px 15px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        background: #fff;
        box-sizing: border-box;
        transition: border-color 0.3s ease;
    }

    .cef-career-wrapper input:focus,
    .cef-career-wrapper select:focus,
    .cef-career-wrapper textarea:focus {
        outline: none;
        border-color: #f9b000;
    }

    .cef-career-wrapper input[type="submit"] {
        background-color: #f9b000;
        width: 100%;
        color: #000;
        border: none;
        padding: 14px;
        cursor: pointer;
        border-radius: 4px;
        font-size: 16px;
        font-weight: bold;
        transition: background 0.3s ease;
    }

    .cef-career-wrapper input[type="submit"]:hover {
        background-color: #005177;
        color: #fff;
    }

    .cef-career-wrapper label input[type="checkbox"] {
        display: inline-block;
        width: auto;
        margin-right: 8px;
    }

    .cef-career-success-message {
        background: #d4edda;
        color: #155724;
        padding: 15px;
        border: 1px solid #c3e6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }

    .cef-career-error-message {
        background: #f8d7da;
        color: #721c24;
        padding: 15px;
        border: 1px solid #f5c6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }

    @media (max-width: 768px) {
        .cef-career-wrapper {
            padding: 30px 15px;
        }

        .cef-career-wrapper h2 {
            font-size: 26px;
        }

        .cef-career-wrapper input,
        .cef-career-wrapper select,
        .cef-career-wrapper textarea {
            font-size: 16px;
        }

        .cef-career-wrapper input[type="submit"] {
            font-size: 18px;
            padding: 16px;
        }
    }
</style>

<div class="cef-career-wrapper">
    <h2>Your future starts here - discover the path that's right for you</h2>
    <p class="subtitle">Take the first step towards your dream career</p>
    
    <?php
    // Display success or error messages
    if (isset($_GET['form_status'])) {
        if ($_GET['form_status'] === 'success') {
            echo '<div class="cef-career-success-message">✓ Thank you! Your inquiry has been submitted successfully. We will contact you soon.</div>';
        } elseif ($_GET['form_status'] === 'error') {
            echo '<div class="cef-career-error-message">⚠ There was an error submitting your form. Please try again.</div>';
        } elseif ($_GET['form_status'] === 'terms_error') {
            echo '<div class="cef-career-error-message">⚠ You must agree to the Terms & Conditions.</div>';
        }
    }
    ?>
    
    <form method="post" action="">
        <?php wp_nonce_field('cef_career_form_action', 'cef_career_form_nonce'); ?>
        
        <p>
            <label>Full Name *</label>
            <input type="text" placeholder="Enter your full name" name="full_name" required>
        </p>
        
        <p>
            <label>Email Address *</label>
            <input type="email" placeholder="Enter your email address" name="email" required>
        </p>
        
        <p>
            <label>Phone Number *</label>
            <input type="tel" placeholder="Enter your phone number" name="phone" required>
        </p>
        
        <p>
            <label>Current Education Level *</label>
            <select name="education_level" required>
                <option value="">Please Choose</option>
                <option value="High School Student">High School Student</option>
                <option value="High School Graduate">High School Graduate</option>
                <option value="Undergraduate">Undergraduate</option>
                <option value="Graduate">Graduate</option>
                <option value="Working Professional">Working Professional</option>
                <option value="Other">Other</option>
            </select>
        </p>
        
        <p>
            <label>Area of Interest *</label>
            <input type="text" placeholder="e.g., Engineering, Medicine, Business, Arts" name="area_of_interest" required>
        </p>
        
        <p>
            <label>Tell us about your career goals *</label>
            <textarea name="message" rows="5" placeholder="Share your aspirations, concerns, or questions about your career path..." required></textarea>
        </p>
        
        <p>
            <label>
                <input type="checkbox" name="terms" value="Agreed" required>
                I agree to the Terms & Conditions of World Best Services Malaysia Sdn Bhd (ACE Education)
            </label>
        </p>
        
        <p>
            <input type="submit" name="cef_career_submit" value="Submit Inquiry">
        </p>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Auto-hide success/error messages after 10 seconds
            const successMsg = document.querySelector('.cef-career-success-message');
            const errorMsg = document.querySelector('.cef-career-error-message');
            
            if (successMsg || errorMsg) {
                setTimeout(function() {
                    const msg = successMsg || errorMsg;
                    msg.style.transition = 'opacity 0.5s ease';
                    msg.style.opacity = '0';
                    
                    setTimeout(function() {
                        msg.remove();
                        const url = new URL(window.location);
                        url.searchParams.delete('form_status');
                        window.history.replaceState({}, document.title, url);
                    }, 500);
                }, 10000);
            }
        });
    </script>
</div>

<?php
    return ob_get_clean();
}
add_shortcode('career_counselling_form', 'cef_career_form_shortcode');

// Handle form submission early
add_action('init', 'cef_handle_career_form');

function cef_handle_career_form() {
    if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cef_career_submit'])) {
        
        // Nonce Check
        if (!isset($_POST['cef_career_form_nonce']) || !wp_verify_nonce($_POST['cef_career_form_nonce'], 'cef_career_form_action')) {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
            exit;
        }
        
        if(empty($_POST['terms'])) {
            wp_redirect(add_query_arg('form_status', 'terms_error', wp_get_referer()));
            exit;
        }

        // Sanitize and prepare data
        $data = [
            'full_name' => sanitize_text_field($_POST['full_name']),
            'email' => sanitize_email($_POST['email']),
            'phone' => sanitize_text_field($_POST['phone']),
            'education_level' => sanitize_text_field($_POST['education_level']),
            'area_of_interest' => sanitize_text_field($_POST['area_of_interest']),
            'message' => sanitize_textarea_field($_POST['message']),
            'terms' => sanitize_text_field($_POST['terms']),
        ];

        // Email recipients
        $to = ['info@aceeducation.com.my', 'acekl2018@gmail.com'];
        $subject = 'New Career Counselling Inquiry';

        // Create HTML email body
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #f9b000;">New Career Counselling Inquiry</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%;">';
        
        $email_fields = [
            "Full Name" => $data['full_name'],
            "Email" => $data['email'],
            "Phone" => $data['phone'],
            "Education Level" => $data['education_level'],
            "Area of Interest" => $data['area_of_interest'],
            "Career Goals/Message" => nl2br($data['message']),
            "Terms & Conditions" => $data['terms'],
        ];
        
        foreach ($email_fields as $label => $value) {
            $message .= '<tr style="border-bottom: 1px solid #ddd;">';
            $message .= '<td style="padding: 10px; font-weight: bold; width: 200px;">' . $label . ':</td>';
            $message .= '<td style="padding: 10px;">' . $value . '</td>';
            $message .= '</tr>';
        }
        
        $message .= '</table>';
        $message .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
        $message .= '</body></html>';

        // Email headers
        $headers = [
            'From: ACE Education Malaysia <info@aceeducation.com.my>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . $data['email']
        ];

        // Send email
        $mail_sent = wp_mail($to, $subject, $message, $headers);

        // Save to database
        global $wpdb;
        $table_name = $wpdb->prefix . 'career_counselling_submissions';
        
        $data['email_sent'] = $mail_sent ? 1 : 0;
        
        $inserted = $wpdb->insert($table_name, $data);

        // Redirect with success message
        if ($inserted) {
            wp_redirect(add_query_arg('form_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
        }
        exit;
    }
}
?>