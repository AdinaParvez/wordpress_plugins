<?php
/*
Plugin Name: ACEEducation Popup Form (Simple Anti-Spam)
Description: Popup form with simple but effective anti-spam protection - no external services needed
Version: 3.0
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

register_activation_hook(__FILE__, 'ace_popup_create_table');

function ace_popup_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ace_popup_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        whatsapp varchar(50) NOT NULL,
        iam varchar(50) NOT NULL,
        subject varchar(255) NOT NULL,
        grade varchar(100) NOT NULL,
        curriculum varchar(100) NOT NULL,
        terms_accepted tinyint(1) DEFAULT 1,
        submitted_at datetime DEFAULT CURRENT_TIMESTAMP,
        ip_address varchar(100) DEFAULT '',
        is_spam tinyint(1) DEFAULT 0,
        spam_reason varchar(255) DEFAULT '',
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

add_action('wp_footer', 'ace_popup_form');
function ace_popup_form() {
    if (is_admin() || is_404()) {
        return;
    }
    ?>
    <style>
        #ace-popup-overlay {
            opacity: 0;
            visibility: hidden;
            position: fixed;
            inset: 0;
            background: rgba(0, 45, 98, 0.9);
            z-index: 9999;
            transition: opacity 0.3s ease, visibility 0.3s ease;
        }

        #ace-popup-overlay.ace-show {
            opacity: 1;
            visibility: visible;
        }

        #ace-popup {
            background: #ffffff;
            color: #002D62;
            padding: 25px;
            border-radius: 15px;
            max-width: 400px;
            width: 90%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            box-shadow: 0 10px 25px rgba(0, 45, 98, 0.3);
            text-align: center;
            border: 2px solid #002D62;
        }

        #ace-popup h2 {
            margin-bottom: 15px;
            color: #002D62;
        }

        #ace-popup form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        #ace-popup input,
        #ace-popup select {
            padding: 10px;
            border: 1px solid #002D62;
            border-radius: 8px;
            font-size: 15px;
            color: #002D62;
            background: #f8f8f8;
        }

        #ace-popup input:focus,
        #ace-popup select:focus {
            background: #ffffff;
            border-color: #002D62;
            outline: none;
        }

        .ace-submit-btn {
            background: #dcb225;
            color: #002D62;
            font-weight: bold;
            border: none;
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: background 0.3s ease;
        }

        .ace-submit-btn:hover:not(:disabled) {
            background: #002D62;
            color: #ffffff;
        }

        .ace-submit-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        #ace-popup-close {
            position: absolute;
            top: 8px;
            right: 12px;
            background: transparent;
            color: #002D62;
            font-size: 24px;
            border: none;
            cursor: pointer;
            transition: transform 0.2s ease;
        }

        #ace-popup-close:hover {
            transform: scale(1.2);
            color: #dcb225;
        }

        #ace-popup label {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 10px 0;
            text-align: left;
            color: #002D62;
        }

        #ace-popup label span {
            font-size: 13px;
        }

        /* HONEYPOT: Hidden field that bots will fill but humans won't see */
        .ace-hp-field {
            position: absolute !important;
            left: -9999px !important;
            width: 1px !important;
            height: 1px !important;
            opacity: 0 !important;
            pointer-events: none !important;
        }

        .ace-math-question {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #f0f8ff;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #dcb225;
        }

        .ace-math-question label {
            margin: 0;
            font-weight: bold;
            color: #002D62;
        }

        .ace-math-question input {
            width: 60px;
            text-align: center;
            margin: 0;
        }

        .ace-success-message {
            background: #28a745;
            color: #ffffff;
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
        }

        .ace-error-message {
            background: #dc3545;
            color: #ffffff;
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
        }

        @media (max-width: 600px) {
            #ace-popup {
                width: 95%;
                padding: 20px;
            }
        }
    </style>

    <div id="ace-popup-overlay">
        <div id="ace-popup">
            <button id="ace-popup-close" aria-label="Close popup">&times;</button>
            <h2>🎓 Enquire Now!</h2>
            
            <?php
            if (isset($_GET['ace_popup_status'])) {
                $status = sanitize_text_field($_GET['ace_popup_status']);
                if ($status === 'success') {
                    echo '<div class="ace-success-message">✅ Thank you! Your inquiry has been submitted.</div>';
                } elseif ($status === 'error') {
                    echo '<div class="ace-error-message">❌ Something went wrong. Please try again.</div>';
                } elseif ($status === 'spam') {
                    echo '<div class="ace-error-message">🚫 Your submission looks suspicious. Please try again or contact us directly.</div>';
                } elseif ($status === 'rate_limit') {
                    echo '<div class="ace-error-message">⏱️ You\'ve submitted too many forms recently. Please wait 1 hour.</div>';
                } elseif ($status === 'math_wrong') {
                    echo '<div class="ace-error-message">❌ Math answer is incorrect. Please try again.</div>';
                } elseif ($status === 'terms_error') {
                    echo '<div class="ace-error-message">⚠️ You must agree to the Terms & Conditions.</div>';
                }
            }
            ?>

            <form id="ace-popup-form" method="post" action="">
                <?php wp_nonce_field('ace_popup_form_action', 'ace_popup_form_nonce'); ?>
                
                <!-- HONEYPOT: Invisible to humans, but bots will fill it -->
                <input type="text" name="website_url" class="ace-hp-field" tabindex="-1" autocomplete="off" aria-hidden="true">
                <input type="email" name="confirm_email" class="ace-hp-field" tabindex="-1" autocomplete="off" aria-hidden="true">
                
                <!-- Hidden timestamp to detect bots that submit too fast -->
                <input type="hidden" name="form_timestamp" id="form-timestamp" value="">
                
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input type="text" name="whatsapp" placeholder="WhatsApp Number" required>
                
                <select name="iam" required>
                    <option value="">I am...</option>
                    <option value="Student">A Student</option>
                    <option value="Parent">A Parent</option>
                    <option value="Other">Other</option>
                </select>
                
                <input type="text" name="subject" placeholder="Subject(s)" required>
                <input type="text" name="grade" placeholder="Grade" required>
                <input type="text" name="curriculum" placeholder="Curriculum" required>
                
                <!-- Simple Math Question (Stops most bots) -->
                <div class="ace-math-question">
                    <label>🧮 What is <?php $num1 = rand(1,5); $num2 = rand(1,5); echo "$num1 + $num2"; ?>?</label>
                    <input type="number" name="math_answer" required>
                    <input type="hidden" name="math_correct" value="<?php echo $num1 + $num2; ?>">
                </div>
                
                <label>
                    <input type="checkbox" name="terms" value="1" required>
                    <span>I agree to the Terms & Conditions</span>
                </label>
                
                <button type="submit" name="ace_popup_submit" class="ace-submit-btn">Submit</button>
            </form>
        </div>
    </div>

    <script>
        (function() {
            const overlay = document.getElementById('ace-popup-overlay');
            const closeBtn = document.getElementById('ace-popup-close');
            const form = document.getElementById('ace-popup-form');
            const submitBtn = form.querySelector('.ace-submit-btn');
            
            // Record when form was shown (for time-based spam detection)
            document.getElementById('form-timestamp').value = Date.now();
            
            // Show popup after 3 seconds
            setTimeout(function() {
                if (!sessionStorage.getItem('acePopupClosed')) {
                    overlay.classList.add('ace-show');
                }
            }, 3000);
            
            // Close popup handlers
            overlay.addEventListener('click', function(e) {
                if (e.target === overlay) {
                    overlay.classList.remove('ace-show');
                    sessionStorage.setItem('acePopupClosed', 'true');
                }
            });
            
            closeBtn.addEventListener('click', function() {
                overlay.classList.remove('ace-show');
                sessionStorage.setItem('acePopupClosed', 'true');
            });
            
            // Disable submit button while submitting
            form.addEventListener('submit', function() {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Submitting...';
            });
            
            // Show popup if there's a status message
            <?php if (isset($_GET['ace_popup_status'])): ?>
                overlay.classList.add('ace-show');
                sessionStorage.removeItem('acePopupClosed');
            <?php endif; ?>
        })();
    </script>
    <?php
}

// SPAM PROTECTION HANDLER
add_action('init', 'ace_popup_handle_form');
function ace_popup_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ace_popup_submit'])) {

        // ===== SECURITY CHECK =====
        if (!isset($_POST['ace_popup_form_nonce']) || !wp_verify_nonce($_POST['ace_popup_form_nonce'], 'ace_popup_form_action')) {
            wp_safe_redirect(add_query_arg('ace_popup_status', 'error', wp_get_referer()));
            exit;
        }

        $spam_detected = false;
        $spam_reason = '';

        // ===== SPAM CHECK #1: HONEYPOT TRAP =====
        // If these hidden fields are filled, it's a bot
        if (!empty($_POST['website_url']) || !empty($_POST['confirm_email'])) {
            $spam_detected = true;
            $spam_reason = 'Honeypot filled';
            error_log('ACE SPAM: Honeypot trap triggered');
        }

        // ===== SPAM CHECK #2: TIME-BASED CHECK =====
        // Bots submit forms in less than 3 seconds
        $form_timestamp = isset($_POST['form_timestamp']) ? intval($_POST['form_timestamp']) : 0;
        $time_spent = (microtime(true) * 1000) - $form_timestamp;
        
        if ($time_spent < 3000 && $form_timestamp > 0) { // Less than 3 seconds
            $spam_detected = true;
            $spam_reason = 'Submitted too fast (' . round($time_spent/1000, 1) . 's)';
            error_log('ACE SPAM: Form submitted too fast - ' . $time_spent . 'ms');
        }

        // ===== SPAM CHECK #3: MATH QUESTION =====
        $math_answer = isset($_POST['math_answer']) ? intval($_POST['math_answer']) : 0;
        $math_correct = isset($_POST['math_correct']) ? intval($_POST['math_correct']) : 0;
        
        if ($math_answer !== $math_correct) {
            wp_safe_redirect(add_query_arg('ace_popup_status', 'math_wrong', wp_get_referer()));
            exit;
        }

        // ===== SPAM CHECK #4: RATE LIMITING =====
        // Max 3 submissions per hour from same IP
        $user_ip = $_SERVER['REMOTE_ADDR'];
        $rate_key = 'ace_submit_' . md5($user_ip);
        $submit_count = get_transient($rate_key);
        
        if ($submit_count && $submit_count >= 3) {
            $spam_detected = true;
            $spam_reason = 'Rate limit exceeded';
            error_log('ACE SPAM: Rate limit exceeded for IP ' . $user_ip);
            wp_safe_redirect(add_query_arg('ace_popup_status', 'rate_limit', wp_get_referer()));
            exit;
        }

        // ===== SPAM CHECK #5: DISPOSABLE EMAIL DETECTION =====
        $disposable_domains = [
            'tempmail.com', 'guerrillamail.com', '10minutemail.com', 'mailinator.com',
            'throwaway.email', 'fakeinbox.com', 'trashmail.com', 'temp-mail.org',
            'getnada.com', 'maildrop.cc', 'yopmail.com', 'sharklasers.com'
        ];
        
        $email = sanitize_email($_POST['email']);
        $email_domain = substr(strrchr($email, "@"), 1);
        
        if (in_array(strtolower($email_domain), $disposable_domains)) {
            $spam_detected = true;
            $spam_reason = 'Disposable email: ' . $email_domain;
            error_log('ACE SPAM: Disposable email detected - ' . $email);
        }

        // ===== SPAM CHECK #6: SUSPICIOUS CONTENT =====
        $spam_keywords = [
            'viagra', 'casino', 'lottery', 'crypto', 'bitcoin', 'click here', 
            'buy now', 'weight loss', 'make money', 'free money', 'loan',
            'seo service', 'backlink', 'ranking', 'investment opportunity'
        ];
        
        $content_to_check = strtolower(
            $_POST['name'] . ' ' . 
            $_POST['email'] . ' ' . 
            $_POST['subject'] . ' ' . 
            $_POST['curriculum'] . ' ' .
            $_POST['whatsapp']
        );
        
        foreach ($spam_keywords as $keyword) {
            if (strpos($content_to_check, $keyword) !== false) {
                $spam_detected = true;
                $spam_reason = 'Spam keyword: ' . $keyword;
                error_log('ACE SPAM: Spam keyword detected - ' . $keyword);
                break;
            }
        }

        // ===== SPAM CHECK #7: DUPLICATE SUBMISSION =====
        global $wpdb;
        $table_name = $wpdb->prefix . 'ace_popup_submissions';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name) {
            $recent_duplicate = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name 
                WHERE email = %s 
                AND submitted_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)",
                $email
            ));
            
            if ($recent_duplicate > 0) {
                $spam_detected = true;
                $spam_reason = 'Duplicate submission within 1 hour';
                error_log('ACE SPAM: Duplicate submission - ' . $email);
            }
        }

        // Terms check
        if (empty($_POST['terms'])) {
            wp_safe_redirect(add_query_arg('ace_popup_status', 'terms_error', wp_get_referer()));
            exit;
        }

        // Sanitize all inputs
        $name       = sanitize_text_field($_POST['name']);
        $whatsapp   = sanitize_text_field($_POST['whatsapp']);
        $iam        = sanitize_text_field($_POST['iam']);
        $subject_f  = sanitize_text_field($_POST['subject']);
        $grade      = sanitize_text_field($_POST['grade']);
        $curriculum = sanitize_text_field($_POST['curriculum']);

        // Update rate limiter
        $new_count = $submit_count ? $submit_count + 1 : 1;
        set_transient($rate_key, $new_count, HOUR_IN_SECONDS);

        // Save to database (even spam, for review)
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            ace_popup_create_table();
        }
        
        $db_saved = $wpdb->insert(
            $table_name,
            [
                'name' => $name,
                'email' => $email,
                'whatsapp' => $whatsapp,
                'iam' => $iam,
                'subject' => $subject_f,
                'grade' => $grade,
                'curriculum' => $curriculum,
                'terms_accepted' => 1,
                'ip_address' => $user_ip,
                'submitted_at' => current_time('mysql'),
                'is_spam' => $spam_detected ? 1 : 0,
                'spam_reason' => $spam_reason
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s']
        );

        // Only send email if NOT spam
        $sent = false;
        if (!$spam_detected) {
            $to = 'info@aceeducation.com.my, acekl2018@gmail.com';
            $subject = 'New Enquiry Form Submission';

            $message = '<html><body style="font-family: Arial, sans-serif;">';
            $message .= '<h2 style="color: #002D62;">New Enquiry from ACE Education Website</h2>';
            $message .= '<table style="border-collapse: collapse; width: 100%; max-width: 600px;">';
            $fields = [
                'Name' => $name,
                'Email' => $email,
                'WhatsApp' => $whatsapp,
                'I am' => $iam,
                'Subject(s)' => $subject_f,
                'Grade' => $grade,
                'Curriculum' => $curriculum,
                'Terms Accepted' => 'Yes'
            ];
            foreach ($fields as $label => $value) {
                $message .= '<tr><td style="padding:10px;border:1px solid #ddd;"><strong>' . esc_html($label) . ':</strong></td><td style="padding:10px;border:1px solid #ddd;">' . esc_html($value) . '</td></tr>';
            }
            $message .= '</table>';
            $message .= '<p style="margin-top:20px;color:#666;">Submitted on: ' . date_i18n('F j, Y, g:i a') . '</p>';
            $message .= '</body></html>';

            $headers = [
                'From: ACE Education Malaysia <info@aceeducation.com.my>',
                'Reply-To: ' . $email,
                'Content-Type: text/html; charset=UTF-8'
            ];

            $sent = wp_mail($to, $subject, $message, $headers);
            error_log('ACE: Email ' . ($sent ? 'SENT' : 'FAILED'));
        } else {
            error_log('ACE: Spam blocked - ' . $spam_reason);
        }

        // Redirect with appropriate status
        $status = $spam_detected ? 'spam' : ($sent || $db_saved ? 'success' : 'error');
        wp_safe_redirect(add_query_arg('ace_popup_status', $status, wp_get_referer()));
        exit;
    }
}

// Admin page with spam filtering
add_action('admin_menu', 'ace_popup_admin_menu');

function ace_popup_admin_menu() {
    add_menu_page(
        'Form Submissions',
        'Popup Forms',
        'manage_options',
        'ace-popup-submissions',
        'ace_popup_submissions_page',
        'dashicons-email-alt',
        30
    );
}

function ace_popup_submissions_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ace_popup_submissions';
    
    // Handle actions
    if (isset($_GET['action']) && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        if ($_GET['action'] === 'delete') {
            $wpdb->delete($table_name, ['id' => $id], ['%d']);
            echo '<div class="notice notice-success"><p>Deleted successfully.</p></div>';
        } elseif ($_GET['action'] === 'mark_spam') {
            $wpdb->update($table_name, ['is_spam' => 1], ['id' => $id]);
            echo '<div class="notice notice-success"><p>Marked as spam.</p></div>';
        } elseif ($_GET['action'] === 'mark_legit') {
            $wpdb->update($table_name, ['is_spam' => 0], ['id' => $id]);
            echo '<div class="notice notice-success"><p>Marked as legitimate.</p></div>';
        }
    }
    
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        echo '<div class="notice notice-warning"><p>Table not found.</p></div>';
        return;
    }
    
    $filter = isset($_GET['filter']) ? $_GET['filter'] : 'legitimate';
    $where = $filter === 'spam' ? 'WHERE is_spam = 1' : ($filter === 'all' ? '' : 'WHERE is_spam = 0');
    
    $submissions = $wpdb->get_results("SELECT * FROM $table_name $where ORDER BY submitted_at DESC LIMIT 100");
    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $spam_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE is_spam = 1");
    $legit_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE is_spam = 0");
    
    ?>
    <div class="wrap">
        <h1>📧 Popup Form Submissions</h1>
        
        <ul class="subsubsub">
            <li><a href="?page=ace-popup-submissions&filter=legitimate" class="<?php echo $filter === 'legitimate' ? 'current' : ''; ?>">✅ Legitimate (<?php echo $legit_count; ?>)</a> | </li>
            <li><a href="?page=ace-popup-submissions&filter=spam" class="<?php echo $filter === 'spam' ? 'current' : ''; ?>">🚫 Spam (<?php echo $spam_count; ?>)</a> | </li>
            <li><a href="?page=ace-popup-submissions&filter=all" class="<?php echo $filter === 'all' ? 'current' : ''; ?>">All (<?php echo $total; ?>)</a></li>
        </ul>
        
        <br clear="all"><br>
        
        <div style="background: #e7f3ff; padding: 15px; border-left: 4px solid #0073aa; margin: 20px 0;">
            <strong>🛡️ Active Spam Protection:</strong>
            <ul style="margin: 10px 0 0 20px; list-style: disc;">
                <li>✅ Honeypot trap (invisible fields)</li>
                <li>✅ Math question verification</li>
                <li>✅ Time-based detection (min 3 seconds)</li>
                <li>✅ Rate limiting (max 3 per hour)</li>
                <li>✅ Disposable email blocking</li>
                <li>✅ Spam keyword filtering</li>
                <li>✅ Duplicate submission check</li>
            </ul>
            <p style="margin-top: 10px;"><strong>📊 Block Rate:</strong> <?php echo $spam_count > 0 ? round(($spam_count / $total) * 100, 1) : 0; ?>% of submissions blocked as spam</p>
        </div>
        
        <?php if ($submissions): ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th width="40">ID</th>
                        <th width="60">Status</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>WhatsApp</th>
                        <th>Subject</th>
                        <th>Grade</th>
                        <th>Date</th>
                        <th>Spam Reason</th>
                        <th width="150">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $sub): ?>
                        <tr style="<?php echo $sub->is_spam ? 'background: #ffe6e6;' : ''; ?>">
                            <td><?php echo $sub->id; ?></td>
                            <td>
                                <?php if ($sub->is_spam): ?>
                                    <span style="color: red; font-weight: bold;">🚫 SPAM</span>
                                <?php else: ?>
                                    <span style="color: green; font-weight: bold;">✅ OK</span>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo esc_html($sub->name); ?></strong></td>
                            <td><?php echo esc_html($sub->email); ?></td>
                            <td>
                                <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $sub->whatsapp); ?>" target="_blank">
                                    <?php echo esc_html($sub->whatsapp); ?>
                                </a>
                            </td>
                            <td><?php echo esc_html($sub->subject); ?></td>
                            <td><?php echo esc_html($sub->grade); ?></td>
                            <td><?php echo date('M j, g:i A', strtotime($sub->submitted_at)); ?></td>
                            <td><small><?php echo esc_html($sub->spam_reason); ?></small></td>
                            <td>
                                <?php if ($sub->is_spam): ?>
                                    <a href="?page=ace-popup-submissions&action=mark_legit&id=<?php echo $sub->id; ?>&filter=<?php echo $filter; ?>" class="button button-small">Not Spam</a>
                                <?php else: ?>
                                    <a href="?page=ace-popup-submissions&action=mark_spam&id=<?php echo $sub->id; ?>&filter=<?php echo $filter; ?>" class="button button-small">Mark Spam</a>
                                <?php endif; ?>
                                <a href="?page=ace-popup-submissions&action=delete&id=<?php echo $sub->id; ?>&filter=<?php echo $filter; ?>" onclick="return confirm('Delete this entry?');" class="button button-small button-link-delete">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No submissions found in this category.</p>
        <?php endif; ?>
    </div>
    <?php
}
?>