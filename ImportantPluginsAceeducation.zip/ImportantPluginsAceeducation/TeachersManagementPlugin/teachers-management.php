<?php
/**
 * Plugin Name: Teachers Management
 * Plugin URI: https://acelanguagecentre.edu.my
 * Description: Manage teachers with custom post type and display them on your site
 * Version: 1.0.0
 * Author: Adina Pervaiz
 * Author URI: https://acelanguagecentre.edu.my
 * Text Domain: teachers-management
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Register Custom Post Type for Teachers
function tm_register_teacher_post_type() {
    $labels = array(
        'name'                  => 'Teachers',
        'singular_name'         => 'Teacher',
        'menu_name'             => 'Teachers',
        'add_new'               => 'Add New Teacher',
        'add_new_item'          => 'Add New Teacher',
        'edit_item'             => 'Edit Teacher',
        'new_item'              => 'New Teacher',
        'view_item'             => 'View Teacher',
        'search_items'          => 'Search Teachers',
        'not_found'             => 'No teachers found',
        'not_found_in_trash'    => 'No teachers found in trash',
    );

    $args = array(
        'labels'                => $labels,
        'public'                => true,
        'has_archive'           => true,
        'publicly_queryable'    => true,
        'query_var'             => true,
        'rewrite'               => array('slug' => 'teachers'),
        'capability_type'       => 'post',
        'hierarchical'          => false,
        'supports'              => array('title', 'editor', 'thumbnail'),
        'menu_icon'             => 'dashicons-groups',
        'show_in_rest'          => true,
        'menu_position'         => 5,
    );

    register_post_type('teacher', $args);
}
add_action('init', 'tm_register_teacher_post_type');

// Add Meta Boxes for Teacher Information
function tm_add_teacher_meta_boxes() {
    add_meta_box(
        'teacher_details',
        'Teacher Details',
        'tm_teacher_details_callback',
        'teacher',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'tm_add_teacher_meta_boxes');

// Meta Box Callback Function
function tm_teacher_details_callback($post) {
    wp_nonce_field('tm_save_teacher_details', 'tm_teacher_details_nonce');
    
    $position = get_post_meta($post->ID, '_teacher_position', true);
    $facebook = get_post_meta($post->ID, '_teacher_facebook', true);
    $twitter = get_post_meta($post->ID, '_teacher_twitter', true);
    $instagram = get_post_meta($post->ID, '_teacher_instagram', true);
    $linkedin = get_post_meta($post->ID, '_teacher_linkedin', true);
    ?>
    <table class="form-table">
        <tr>
            <th><label for="teacher_position">Position/Title</label></th>
            <td>
                <input type="text" id="teacher_position" name="teacher_position" 
                       value="<?php echo esc_attr($position); ?>" 
                       class="regular-text" 
                       placeholder="e.g., Art Director, Marketing Expert">
            </td>
        </tr>
        <tr>
            <th><label for="teacher_facebook">Facebook URL</label></th>
            <td>
                <input type="url" id="teacher_facebook" name="teacher_facebook" 
                       value="<?php echo esc_attr($facebook); ?>" 
                       class="regular-text" 
                       placeholder="https://facebook.com/username">
            </td>
        </tr>
        <tr>
            <th><label for="teacher_twitter">Twitter URL</label></th>
            <td>
                <input type="url" id="teacher_twitter" name="teacher_twitter" 
                       value="<?php echo esc_attr($twitter); ?>" 
                       class="regular-text" 
                       placeholder="https://twitter.com/username">
            </td>
        </tr>
        <tr>
            <th><label for="teacher_instagram">Instagram URL</label></th>
            <td>
                <input type="url" id="teacher_instagram" name="teacher_instagram" 
                       value="<?php echo esc_attr($instagram); ?>" 
                       class="regular-text" 
                       placeholder="https://instagram.com/username">
            </td>
        </tr>
        <tr>
            <th><label for="teacher_linkedin">LinkedIn URL</label></th>
            <td>
                <input type="url" id="teacher_linkedin" name="teacher_linkedin" 
                       value="<?php echo esc_attr($linkedin); ?>" 
                       class="regular-text" 
                       placeholder="https://linkedin.com/in/username">
            </td>
        </tr>
    </table>
    <p><strong>Note:</strong> Set the featured image as the teacher's photo.</p>
    <?php
}

// Save Meta Box Data
function tm_save_teacher_details($post_id) {
    // Check nonce
    if (!isset($_POST['tm_teacher_details_nonce']) || 
        !wp_verify_nonce($_POST['tm_teacher_details_nonce'], 'tm_save_teacher_details')) {
        return;
    }

    // Check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Save fields
    $fields = array('teacher_position', 'teacher_facebook', 'teacher_twitter', 
                    'teacher_instagram', 'teacher_linkedin');
    
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
        }
    }
}
add_action('save_post', 'tm_save_teacher_details');


// Shortcode to Display Teachers – Responsive 6 per row
function tm_display_teachers_shortcode($atts) {
    $atts = shortcode_atts(array(
        'count' => -1,
        'orderby' => 'date',
        'order' => 'DESC'
    ), $atts);

    $args = array(
        'post_type' => 'teacher',
        'posts_per_page' => intval($atts['count']),
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'post_status' => 'publish'
    );

    $teachers_query = new WP_Query($args);
    ob_start();

    if ($teachers_query->have_posts()) : ?>
        <div class="row">
            <?php while ($teachers_query->have_posts()) : $teachers_query->the_post();
                $position  = get_post_meta(get_the_ID(), '_teacher_position', true);
                $facebook  = get_post_meta(get_the_ID(), '_teacher_facebook', true);
                $twitter   = get_post_meta(get_the_ID(), '_teacher_twitter', true);
                $instagram = get_post_meta(get_the_ID(), '_teacher_instagram', true);
                $linkedin  = get_post_meta(get_the_ID(), '_teacher_linkedin', true);
            ?>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2 mb-4">
                <div class="team-member card position-relative border-0 shadow-sm p-2">
                    <div class="image-holder rounded-3 position-relative overflow-hidden">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail('medium', array(
                                'class' => 'img-fluid rounded-3'
                            )); ?>
                        <?php else : ?>
                            <img src="<?php echo esc_url(plugins_url('assets/default-teacher.jpg', __FILE__)); ?>" 
                                 class="img-fluid rounded-3" alt="<?php the_title(); ?>">
                        <?php endif; ?>

                        <ul class="social-links list-unstyled position-absolute">
                            <?php if ($facebook) : ?>
                                <li><a href="<?php echo esc_url($facebook); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <?php endif; ?>
                            <?php if ($twitter) : ?>
                                <li><a href="<?php echo esc_url($twitter); ?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
                            <?php endif; ?>
                            <?php if ($instagram) : ?>
                                <li><a href="<?php echo esc_url($instagram); ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
                            <?php endif; ?>
                            <?php if ($linkedin) : ?>
                                <li><a href="<?php echo esc_url($linkedin); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>

                    <div class="card-body p-0 mt-2 text-center">
                        <p class="fw-bold m-0"><?php the_title(); ?></p>
                        <p class="text-secondary m-0"><?php echo esc_html($position ? $position : 'Teacher'); ?></p>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    <?php
    else :
        echo '<p class="text-center">No teachers found.</p>';
    endif;

    wp_reset_postdata();
    return ob_get_clean();
}
add_shortcode('teachers', 'tm_display_teachers_shortcode');



// Add custom columns to admin list
function tm_teacher_columns($columns) {
    $new_columns = array();
    $new_columns['cb'] = $columns['cb'];
    $new_columns['featured_image'] = 'Photo';
    $new_columns['title'] = 'Name';
    $new_columns['position'] = 'Position';
    $new_columns['social_links'] = 'Social Links';
    $new_columns['date'] = $columns['date'];
    return $new_columns;
}
add_filter('manage_teacher_posts_columns', 'tm_teacher_columns');

// Display custom column content
function tm_teacher_column_content($column, $post_id) {
    switch ($column) {
        case 'featured_image':
            if (has_post_thumbnail($post_id)) {
                echo get_the_post_thumbnail($post_id, array(50, 50));
            } else {
                echo '—';
            }
            break;
        case 'position':
            $position = get_post_meta($post_id, '_teacher_position', true);
            echo $position ? esc_html($position) : '—';
            break;
        case 'social_links':
            $facebook = get_post_meta($post_id, '_teacher_facebook', true);
            $twitter = get_post_meta($post_id, '_teacher_twitter', true);
            $instagram = get_post_meta($post_id, '_teacher_instagram', true);
            $linkedin = get_post_meta($post_id, '_teacher_linkedin', true);
            $links = array_filter(array($facebook, $twitter, $instagram, $linkedin));
            echo !empty($links) ? count($links) . ' links' : '—';
            break;
    }
}
add_action('manage_teacher_posts_custom_column', 'tm_teacher_column_content', 10, 2);

// Flush rewrite rules on activation
function tm_activate_plugin() {
    tm_register_teacher_post_type();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'tm_activate_plugin');

// Flush rewrite rules on deactivation
function tm_deactivate_plugin() {
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'tm_deactivate_plugin');