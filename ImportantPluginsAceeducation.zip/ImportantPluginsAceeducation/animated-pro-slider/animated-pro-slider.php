<?php
/**
 * Plugin Name: Animated Pro Slider
 * Plugin URI: https://adinapervaiz.weebly.com
 * Description: Professional responsive slider with text and shape animations
 * Version: 1.0.0
 * Author: Adina Pervaiz
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AnimatedProSlider {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('animated_slider', array($this, 'slider_shortcode'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
     
    }
    
   

    public function enqueue_scripts() {
        wp_enqueue_style('animated-slider-css', plugins_url('css/slider.css', __FILE__));
        wp_enqueue_script('animated-slider-js', plugins_url('js/slider.js', __FILE__), array('jquery'), '1.0.0', true);
    }
    
    public function slider_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => '1'
        ), $atts);
        
        ob_start();
        ?>
        <div class="animated-pro-slider">
            <div class="slider-wrapper">
                
                <!-- Slide 1 -->
              <div class="slide active" style="background-image: url('https://aceweb.bh/wp-content/uploads/2025/12/banner1Home.webp'); background-size: cover; background-position: center;">
           
                 

                    <div class="slide-content">
                        <div class="shape shape-circle"></div>
                        <div class="shape shape-triangle"></div>
                        <div class="shape shape-square"></div>
                        
                        <div class="text-content">
                            <h1 class="slide-title" data-animation="fadeInUp">Grow Faster with Smart Digital Marketing</h1>
                            <p class="slide-description" data-animation="fadeInUp" data-delay="200">No.1 Digital Marketing Services in BAHRAIN</p>
                                                        <p class="slide-description" data-animation="fadeInUp" data-delay="200">From SEO and Google Ads to social media campaigns, we help Bahrain businesses get real results.</p>
                            <a href="#" class="slide-button" data-animation="fadeInUp" data-delay="400">Boost your online presence</a>
                        </div>
                    </div>
                </div>
                
                <!-- Slide 2 -->
         <div class="slide" style="background-image: url('https://aceweb.bh/wp-content/uploads/2025/12/banner2Home.webp'); background-size: cover; background-position: center;">
      

                    <div class="slide-content">
                        <div class="shape shape-circle"></div>
                        <div class="shape shape-hexagon"></div>
                        <div class="shape shape-square"></div>
                        
                        <div class="text-content">
                            <h1 class="slide-title" data-animation="slideInLeft">Complete Branding & IT Solutions for Bahrain Businesses</h1>
                            <p class="slide-description" data-animation="slideInLeft" data-delay="200">Business Branding and IT Solutions in BAHRAIN</p>
                            <p class="slide-description" data-animation="slideInLeft" data-delay="200">Create a powerful brand identity and streamline operations with our IT and cloud solutions.</p>
                            <a href="#" class="slide-button" data-animation="slideInLeft" data-delay="400">Learn More</a>
                        </div>
                    </div>
                </div>
                
                <!-- Slide 3 -->
               <div class="slide" style="background-image: url('https://aceweb.bh/wp-content/uploads/2025/12/Banner3Home.webp'); background-size: cover; background-position: center;">
                
               <div class="slide-content">
                        <div class="shape shape-circle"></div>
                        <div class="shape shape-triangle"></div>
                        <div class="shape shape-pentagon"></div>
                        
                        <div class="text-content">
                            <h1 class="slide-title" data-animation="zoomIn">Build a Stunning Website That Converts </h1>
                            <p class="slide-description" data-animation="zoomIn" data-delay="200">No. 1 Web Development and Design in Bahrain</p>
                            <p class="slide-description" data-animation="zoomIn" data-delay="200">Professional Website in Dubai with SEO, speed and mobile-first design at its core</p>

                            <a href="#" class="slide-button" data-animation="zoomIn" data-delay="400">Start your website today</a>
                        </div>
                    </div>
                </div>
                
            </div>
            
            <!-- Navigation -->
            <button class="slider-nav prev" aria-label="Previous slide">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
            </button>
            <button class="slider-nav next" aria-label="Next slide">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
            </button>
            
            <!-- Pagination Dots -->
            <div class="slider-pagination">
                <span class="dot active" data-slide="0"></span>
                <span class="dot" data-slide="1"></span>
                <span class="dot" data-slide="2"></span>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'Animated Pro Slider',
            'Pro Slider',
            'manage_options',
            'animated-pro-slider',
            array($this, 'admin_page'),
            'dashicons-images-alt2'
        );
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Animated Pro Slider</h1>
            <p>Use shortcode: <code>[animated_slider]</code></p>
            <p>You can customize slides by editing the plugin files or adding your own images.</p>
        </div>
        <?php
    }
}

new AnimatedProSlider();

