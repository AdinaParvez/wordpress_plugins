jQuery(document).ready(function($) {
    const slider = {
        currentSlide: 0,
        slides: $('.slide'),
        dots: $('.dot'),
        totalSlides: $('.slide').length,
        autoplayInterval: null,
        
        init: function() {
            this.bindEvents();
            this.startAutoplay();
        },
        
        bindEvents: function() {
            const self = this;
            
            $('.slider-nav.next').on('click', function() {
                self.nextSlide();
            });
            
            $('.slider-nav.prev').on('click', function() {
                self.prevSlide();
            });
            
            $('.dot').on('click', function() {
                const slideIndex = $(this).data('slide');
                self.goToSlide(slideIndex);
            });
            
            // Pause on hover
            $('.animated-pro-slider').hover(
                function() { self.stopAutoplay(); },
                function() { self.startAutoplay(); }
            );
            
            // Touch events for mobile
            let touchStartX = 0;
            let touchEndX = 0;
            
            $('.animated-pro-slider').on('touchstart', function(e) {
                touchStartX = e.changedTouches[0].screenX;
            });
            
            $('.animated-pro-slider').on('touchend', function(e) {
                touchEndX = e.changedTouches[0].screenX;
                self.handleSwipe(touchStartX, touchEndX);
            });
        },
        
        handleSwipe: function(startX, endX) {
            if (startX - endX > 50) {
                this.nextSlide();
            } else if (endX - startX > 50) {
                this.prevSlide();
            }
        },
        
        nextSlide: function() {
            this.currentSlide = (this.currentSlide + 1) % this.totalSlides;
            this.updateSlider();
        },
        
        prevSlide: function() {
            this.currentSlide = (this.currentSlide - 1 + this.totalSlides) % this.totalSlides;
            this.updateSlider();
        },
        
        goToSlide: function(index) {
            this.currentSlide = index;
            this.updateSlider();
        },
        
        updateSlider: function() {
            // Remove active class from all slides and dots
            this.slides.removeClass('active');
            this.dots.removeClass('active');
            
            // Add active class to current slide and dot
            $(this.slides[this.currentSlide]).addClass('active');
            $(this.dots[this.currentSlide]).addClass('active');
            
            // Reset autoplay
            this.stopAutoplay();
            this.startAutoplay();
        },
        
        startAutoplay: function() {
            const self = this;
            this.autoplayInterval = setInterval(function() {
                self.nextSlide();
            }, 5000); // Change slide every 5 seconds
        },
        
        stopAutoplay: function() {
            if (this.autoplayInterval) {
                clearInterval(this.autoplayInterval);
            }
        }
    };
    
    slider.init();
});