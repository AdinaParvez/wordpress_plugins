<?php
use Elementor\Widget_Base;

class TuitionKL_Elementor_Widget extends Widget_Base {

    public function get_name(){ return 'tuitionkl_contact'; }
    public function get_title(){ return 'TuitionKL Contact Form'; }
    public function get_icon(){ return 'eicon-mail'; }
    public function get_categories(){ return ['general']; }

    protected function render() {
        echo do_shortcode('[tuitionkl_contact_form]');
    }
}
