<?php
/**
 * Plugin Name: TuitionKL Contact Form
 * Description: CWV-optimized contact form with admin dashboard, Elementor widget, WhatsApp, email confirmation & reCAPTCHA v3.
 * Version: 2.1
 * Author: TuitionKL
 */

if (!defined('ABSPATH')) exit;

class TuitionKL_Contact_Form_Pro {

    private $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'tuitionkl_contacts';

        register_activation_hook(__FILE__, [$this,'create_table']);

        add_shortcode('tuitionkl_contact_form', [$this,'render_form']);
        add_action('wp_enqueue_scripts', [$this,'assets']);

        add_action('wp_ajax_submit_tuitionkl_form', [$this,'submit']);
        add_action('wp_ajax_nopriv_submit_tuitionkl_form', [$this,'submit']);

        add_action('admin_menu', [$this,'admin_menu']);

        add_action('elementor/widgets/register', [$this,'register_elementor_widget']);
    }

    /* ---------------- DATABASE ---------------- */
    public function create_table() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$this->table} (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100),
            email VARCHAR(100),
            phone VARCHAR(50),
            message TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) $charset;";

        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /* ---------------- ADMIN PANEL ---------------- */
    public function admin_menu() {
        add_menu_page(
            'Contact Submissions',
            'Contact Submissions',
            'manage_options',
            'tuitionkl-submissions',
            [$this,'admin_page'],
            'dashicons-email'
        );
    }

    public function admin_page() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->table} ORDER BY created_at DESC");
        echo '<div class="wrap"><h1>Contact Submissions</h1><table class="widefat striped">';
        echo '<thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Message</th><th>Date</th></tr></thead><tbody>';
        foreach($rows as $r){
            echo "<tr>
                <td>{$r->name}</td>
                <td>{$r->email}</td>
                <td>{$r->phone}</td>
                <td>{$r->message}</td>
                <td>{$r->created_at}</td>
            </tr>";
        }
        echo '</tbody></table></div>';
    }

    /* ---------------- ASSETS ---------------- */
    public function assets() {
        wp_enqueue_style('tkl-form', false);
        // Enqueue Bootstrap CSS & JS
        wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css');
        wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', [], null, true);

        wp_add_inline_style('tkl-form', $this->css());

        // Load Google reCAPTCHA v3
        wp_enqueue_script('google-recaptcha','https://www.google.com/recaptcha/api.js?render=YOUR_SITE_KEY',[],null,true);

        wp_enqueue_script('tkl-form', false, ['jquery'], null, true);
        wp_add_inline_script('tkl-form', $this->js());

        // Localize variables for JS
        wp_localize_script('tkl-form','TKL',[
            'ajax'=>admin_url('admin-ajax.php'),
            'nonce'=>wp_create_nonce('tkl_nonce'),
            'whatsapp'=>'https://wa.me/60164777167',
            'siteKey'=>'6LcOr1gsAAAAAJ1dGr7doPOnGbkxbfBSrRzK9Xd5' // Replace with your actual site key
        ]);
    }

    /* ---------------- FORM ---------------- */
  public function render_form() {
    return '
    <section class="tkl-wrap py-5">
        <div class="container tkl-container">

            <div class="row justify-content-center align-items-start g-4">

                <!-- Contact Form -->
                <div class="col-lg-6 col-md-8 col-12">
                    <div class="tkl-form-card card p-4 shadow-sm h-100">
                        <h2 class="text-center mb-4">Contact Us</h2>
                        <form id="tkl-form" class="needs-validation" novalidate>
                            <div class="mb-3">
                                <label for="name" class="form-label">Name*</label>
                                <input type="text" name="name" class="form-control" placeholder="Enter your name" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email*</label>
                                <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" name="phone" class="form-control" placeholder="Enter your phone number">
                            </div>
                            <div class="mb-3">
                                <label for="message" class="form-label">Message*</label>
                                <textarea name="message" class="form-control" rows="5" placeholder="Your message" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Send Message</button>
                            <p class="tkl-msg mt-3 text-center"></p>
                        </form>
                    </div>
                </div>

                <!-- Embedded Google Map -->
                <div class="col-lg-6 col-md-8 col-12">
                    <div class="tkl-map-card">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3983.728911341752!2d101.64954407509185!3d3.1659488530488975!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc49ea1138bd6d%3A0xb92b17c23c45963d!2sTuitionKL%20-%20Home%20Tuition%2FPrivate%20Tutor%2FOnline%20Tuition%20in%20Malaysia!5e0!3m2!1sen!2s!4v1769583402238!5m2!1sen!2s"
                                width="420px"
                                height="620px"
                                style="border:0;"
                                allowfullscreen=""
                                loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>
                </div>

            </div>

        </div>
    </section>';
}






    /* ---------------- SUBMIT ---------------- */
    public function submit() {
        check_ajax_referer('tkl_nonce','nonce');

        // Sanitize form inputs
        $name    = sanitize_text_field($_POST['name']);
        $email   = sanitize_email($_POST['email']);
        $phone   = sanitize_text_field($_POST['phone']);
        $message = sanitize_textarea_field($_POST['message']);
        $token   = sanitize_text_field($_POST['token']); // token from reCAPTCHA

        // Verify reCAPTCHA server-side
        $secret = '6LcOr1gsAAAAAPPw_vdWdaUITIsIzAbaG1hdtApF'; // ← Replace with your actual secret key
        $response = wp_remote_post(
            'https://www.google.com/recaptcha/api/siteverify',
            [
                'body' => [
                    'secret'   => $secret,
                    'response' => $token,
                    'remoteip' => $_SERVER['REMOTE_ADDR']
                ]
            ]
        );
        $result = json_decode(wp_remote_retrieve_body($response));

        if (!$result->success || $result->score < 0.5) {
            wp_send_json_error('reCAPTCHA verification failed. Are you a robot?');
        }

        // Required fields check
        if(!$name || !$email || !$message) {
            wp_send_json_error('Required fields missing');
        }

        // Save submission to database
        global $wpdb;
        $wpdb->insert($this->table, compact('name','email','phone','message'));

        // Admin email
        wp_mail('info@tuitionkl.com', 'New Contact Submission', nl2br($message), ['Content-Type:text/html']);

        // User confirmation email
        wp_mail($email, 'Thank you for contacting TuitionKL', 'We received your message. Our team will contact you shortly.');

        wp_send_json_success('Message sent! You can also contact us on WhatsApp.');
    }

    /* ---------------- ELEMENTOR ---------------- */
    public function register_elementor_widget($widgets_manager) {
        require_once __DIR__.'/widget.php';
        $widgets_manager->register(new \TuitionKL_Elementor_Widget());
    }

    /* ---------------- CSS ---------------- */
   private function css() {
    return "
    .tkl-wrap {
        padding-bottom: 3rem; /* prevents footer overlap */
    }

    /* Form card */
    .tkl-form-card {
        border-radius:15px;
        box-shadow:0 8px 25px rgba(0,0,0,.08);
    }
    .tkl-form-card h2 {
        font-weight:700;
        color:#1f2937;
    }
    #tkl-form .form-control {
        box-shadow:none;
        transition:0.3s;
    }
    #tkl-form .form-control:focus {
        border-color:#2563eb;
        box-shadow:0 0 0 0.2rem rgba(37,99,235,.25);
    }
    #tkl-form button {
        font-weight:600;
        font-size:1rem;
        transition:0.3s;
    }
    #tkl-form button:hover {
        background-color:#1d4ed8;
    }

    /* Map card */
    .tkl-map-card {
        position: relative;
        width: 100%;
        aspect-ratio: 16 / 9;
        border-radius: 15px;
        overflow: hidden;
        box-shadow:0 8px 25px rgba(0,0,0,.08);
    }
    .tkl-map-card iframe {
        position: absolute;
        top:0;
        left:0;
        width:100%;
        height:100%;
        border:0;
    }

    /* Responsive tweaks for mobile */
    @media (max-width: 480px) {
        .tkl-wrap {
            padding-left: 1rem;
            padding-right: 1rem;
        }
        .tkl-form-card, .tkl-map-card {
            margin-left: auto;
            margin-right: auto;
        }
        #tkl-form button {
            font-size: 1.1rem;
            padding: 0.6rem;
        }
    }
    ";
  }






    /* ---------------- JS ---------------- */
    private function js() {
        return "
        jQuery(function($){
            $('#tkl-form').submit(function(e){
                e.preventDefault();
                grecaptcha.ready(function(){
                    grecaptcha.execute(TKL.siteKey,{action:'submit'}).then(function(token){
                        $.post(TKL.ajax,{
                            action:'submit_tuitionkl_form',
                            nonce:TKL.nonce,
                            name:$('[name=name]').val(),
                            email:$('[name=email]').val(),
                            phone:$('[name=phone]').val(),
                            message:$('[name=message]').val(),
                            token:token
                        },res=>{
                            $('.tkl-msg').text(res.data).css('color',res.success?'green':'red');
                            if(res.success)window.open(TKL.whatsapp,'_blank');
                        });
                    });
                });
            });
        });
        ";
    }
}

new TuitionKL_Contact_Form_Pro();
