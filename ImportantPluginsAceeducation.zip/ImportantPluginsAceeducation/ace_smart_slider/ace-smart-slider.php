<?php
/**
 * Plugin Name: Ace Smart Slider Manager
 * Description: Assign and display Smart Slider sliders per page, with a global default fallback. Use <?php alcsm_display_page_slider(); ?> inside your theme where you want the slider to appear.
 * Version: 1.0
 * Author: Adina Pervaiz
 */

// ==============================
// 1. Add Meta Box (per-page slider)
// ==============================
function alcsm_add_slider_meta_box() {
    add_meta_box(
        'alcsm_slider_meta_box',
        'Smart Slider Settings',
        'alcsm_slider_meta_box_callback',
        ['page', 'post'], 
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'alcsm_add_slider_meta_box');

function alcsm_slider_meta_box_callback($post) {
    $value = get_post_meta($post->ID, '_alcsm_slider_shortcode', true);
    ?>
    <p><label for="alcsm_slider_shortcode">Smart Slider Shortcode:</label></p>
    <input type="text" id="alcsm_slider_shortcode" name="alcsm_slider_shortcode"
           value="<?php echo esc_attr($value); ?>" style="width:100%;" 
           placeholder="[smartslider3 slider=&quot;1&quot;]" />
    <p class="description">Paste the Smart Slider shortcode for this page. If empty, the global default slider will be used.</p>
    <?php
}

// ==============================
// 2. Save per-page shortcode
// ==============================
function alcsm_save_slider_meta_box($post_id) {
    if (array_key_exists('alcsm_slider_shortcode', $_POST)) {
        update_post_meta(
            $post_id,
            '_alcsm_slider_shortcode',
            sanitize_text_field($_POST['alcsm_slider_shortcode'])
        );
    }
}
add_action('save_post', 'alcsm_save_slider_meta_box');

// ==============================
// 3. Global default slider option
// ==============================
function alcsm_register_settings() {
    register_setting('alcsm_slider_settings', 'alcsm_default_slider');
}
add_action('admin_init', 'alcsm_register_settings');

function alcsm_settings_page() {
    ?>
    <div class="wrap">
        <h1>Smart Slider Manager Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('alcsm_slider_settings'); ?>
            <?php do_settings_sections('alcsm_slider_settings'); ?>

            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Default Slider Shortcode</th>
                    <td>
                        <input type="text" name="alcsm_default_slider" 
                               value="<?php echo esc_attr(get_option('alcsm_default_slider', '[smartslider3 slider="1"]')); ?>" 
                               style="width: 400px;" />
                        <p class="description">This slider will be used if a page doesn’t have a custom slider set.</p>
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

function alcsm_add_settings_menu() {
    add_options_page(
        'Smart Slider Manager',
        'Smart Slider Manager',
        'manage_options',
        'alcsm-slider-settings',
        'alcsm_settings_page'
    );
}
add_action('admin_menu', 'alcsm_add_settings_menu');

// ==============================
// 4. Display slider with fallback
// ==============================
function alcsm_display_page_slider($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }

    // Per-page slider shortcode
    $shortcode = get_post_meta($post_id, '_alcsm_slider_shortcode', true);

    // Global default slider shortcode
    $fallback_shortcode = get_option('alcsm_default_slider', '[smartslider3 slider="1"]');

    if ($shortcode) {
        echo do_shortcode($shortcode);
    } else {
        echo do_shortcode($fallback_shortcode);
    }
}
