jQuery(document).ready(function($) {
    $(".ace-toc-toggle").on("click", function() {
        $(this).next(".ace-toc-list").slideToggle();
    });
});
