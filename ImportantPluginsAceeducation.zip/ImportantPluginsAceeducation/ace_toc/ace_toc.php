<?php
/*
Plugin Name: ACE Table of Contents
Description: Auto-generate Collapsible Table of Contents with Schema Markup using [ace_toc].
Version: 1.3
Author: Adina Pervaiz, WebACE
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Prevent direct access

// --------------------
// Generate TOC content
// --------------------
function ace_generate_toc($content) {
    preg_match_all('/<h([2-4])[^>]*>(.*?)<\/h[2-4]>/', $content, $matches, PREG_SET_ORDER);

    if (empty($matches)) return '';

    $toc_list = [];
    $toc_html = '<div class="ace-toc">';
    $toc_html .= '<button class="ace-toc-toggle" type="button">📑 Table of Contents</button>';
    $toc_html .= '<ul class="ace-toc-list" style="display:none;">';

    foreach ($matches as $match) {
        $title = strip_tags($match[2]);
        $id = sanitize_title($title);

        // Add ID if missing
        if (strpos($match[0], "id=") === false) {
            $new_heading = str_replace(">{$title}<", " id='{$id}'>{$title}<", $match[0]);
            $content = str_replace($match[0], $new_heading, $content);
        }

        $toc_html .= "<li class='toc-level-{$match[1]}'><a href='#{$id}'>{$title}</a></li>";

        $toc_list[] = [
            "@type" => "ListItem",
            "position" => count($toc_list) + 1,
            "name" => $title,
            "item" => get_permalink() . "#{$id}"
        ];
    }

    $toc_html .= '</ul></div>';

    $GLOBALS['ace_toc_schema'] = $toc_list;
    $GLOBALS['ace_toc_content'] = $content;

    return $toc_html;
}

// --------------------
// Shortcode [ace_toc]
// --------------------
function ace_toc_shortcode() {
    global $post, $ace_toc_content;

    if (!$post) return '';

    $toc = ace_generate_toc($post->post_content);

    if ($ace_toc_content) {
        add_filter('the_content', function() use ($ace_toc_content) {
            return $ace_toc_content;
        });
    }

    return $toc;
}
add_shortcode('ace_toc', 'ace_toc_shortcode');

// --------------------
// Schema JSON-LD Output
// --------------------
function ace_toc_schema_output() {
    global $ace_toc_schema;

    if (empty($ace_toc_schema)) return;

    $schema = [
        "@context" => "https://schema.org",
        "@type" => "ItemList",
        "name" => "Table of Contents",
        "itemListElement" => $ace_toc_schema
    ];

    echo '<script type="application/ld+json">' . wp_json_encode($schema) . '</script>';
}
add_action('wp_footer', 'ace_toc_schema_output');

// --------------------
// Enqueue CSS + JS
// --------------------
function ace_toc_enqueue_assets() {
    wp_enqueue_style(
        'ace-toc-style',
        plugin_dir_url(__FILE__) . 'assets/ace-toc.css',
        [],
        '1.3'
    );

    wp_enqueue_script(
        'ace-toc-script',
        plugin_dir_url(__FILE__) . 'assets/ace-toc.js',
        ['jquery'],
        '1.3',
        true
    );
}
add_action('wp_enqueue_scripts', 'ace_toc_enqueue_assets');
