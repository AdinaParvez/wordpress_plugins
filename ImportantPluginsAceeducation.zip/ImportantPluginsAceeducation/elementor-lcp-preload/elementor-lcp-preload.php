<?php
/*
Plugin Name: Elementor Hero LCP Preload
Description: Preloads the first Elementor slider image for LCP optimization with fetchpriority=high
Version: 1.2
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

add_action('wp_head', function() {

    // Only on singular pages
    if ( ! is_singular() ) return;

    // Check Elementor is active
    if ( ! class_exists('\Elementor\Plugin') ) return;

    global $post;

    // Get Elementor elements data
    $elements = \Elementor\Plugin::$instance->documents->get($post->ID)->get_elements_data();
    if ( empty($elements) ) return;

    // Recursive function to find first slider/background image
    $find_slide_image = function($items) use (&$find_slide_image) {
        foreach ($items as $item) {
            // Classic Slider or Section background image
            if ( isset($item['settings']['background_image']) ) {
                $bg = $item['settings']['background_image'];
                if ( isset($bg['id']) && $bg['id'] ) {
                    return wp_get_attachment_url($bg['id']);
                } elseif ( isset($bg['url']) && $bg['url'] ) {
                    return $bg['url'];
                }
            }

            // Slides widget
            if ( isset($item['widgetType']) && $item['widgetType'] === 'slides' && isset($item['settings']['slides']) ) {
                foreach ($item['settings']['slides'] as $slide) {
                    if ( isset($slide['image']['id']) && $slide['image']['id'] ) {
                        return wp_get_attachment_url($slide['image']['id']);
                    } elseif ( isset($slide['image']['url']) && $slide['image']['url'] ) {
                        return $slide['image']['url'];
                    }
                }
            }

            // Recurse into children elements
            if ( isset($item['elements']) && !empty($item['elements']) ) {
                $found = $find_slide_image($item['elements']);
                if ( $found ) return $found;
            }
        }
        return false;
    };

    $hero_image_url = $find_slide_image($elements);

    if ( $hero_image_url ) {
        // Preload link for browser
        echo '<link rel="preload" as="image" href="' . esc_url($hero_image_url) . '" fetchpriority="high">' . "\n";
        // Hidden image for Lighthouse detection
        echo '<img src="' . esc_url($hero_image_url) . '" style="display:none;" fetchpriority="high" alt="LCP hero">' . "\n";
    }

});
