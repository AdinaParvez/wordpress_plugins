<?php
/**
 * Plugin Name: Teachers Management Plugin
 * Plugin URI: https://acelanguagecentre.edu.my
 * Description: Manage teachers with custom post type and display them on your site
 * Version: 1.0.1
 * Author: Adina Pervaiz
 * Author URI: https://acelanguagecentre.edu.my
 * Text Domain: teachers-management
 */

if (!defined('ABSPATH')) exit;

// ----------------------
// 1. Register Custom Post Type
// ----------------------
function tm_register_teacher_post_type() {
    $labels = array(
        'name'                  => 'Teachers',
        'singular_name'         => 'Teacher',
        'menu_name'             => 'Teachers',
        'add_new'               => 'Add New Teacher',
        'add_new_item'          => 'Add New Teacher',
        'edit_item'             => 'Edit Teacher',
        'new_item'              => 'New Teacher',
        'view_item'             => 'View Teacher',
        'search_items'          => 'Search Teachers',
        'not_found'             => 'No teachers found',
        'not_found_in_trash'    => 'No teachers found in trash',
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'has_archive'        => true,
        'publicly_queryable' => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'teachers'),
        'capability_type'    => 'post',
        'hierarchical'       => false,
        'supports'           => array('title', 'editor', 'thumbnail'),
        'menu_icon'          => 'dashicons-groups',
        'show_in_rest'       => true,
        'menu_position'      => 5,
    );

    register_post_type('teacher', $args);
}
add_action('init', 'tm_register_teacher_post_type');

// ----------------------
// 2. Meta Boxes
// ----------------------
function tm_add_teacher_meta_boxes() {
    add_meta_box('teacher_details','Teacher Details','tm_teacher_details_callback','teacher','normal','high');
}
add_action('add_meta_boxes','tm_add_teacher_meta_boxes');

function tm_teacher_details_callback($post){
    wp_nonce_field('tm_save_teacher_details','tm_teacher_details_nonce');
    $position = get_post_meta($post->ID,'_teacher_position',true);
    $facebook = get_post_meta($post->ID,'_teacher_facebook',true);
    $twitter = get_post_meta($post->ID,'_teacher_twitter',true);
    $instagram = get_post_meta($post->ID,'_teacher_instagram',true);
    $linkedin = get_post_meta($post->ID,'_teacher_linkedin',true);
    ?>
    <table class="form-table">
        <tr><th><label for="teacher_position">Position/Title</label></th>
            <td><input type="text" id="teacher_position" name="teacher_position" class="regular-text"
                       placeholder="e.g., Art Director" value="<?php echo esc_attr($position); ?>"></td>
        </tr>
        <tr><th><label for="teacher_facebook">Facebook URL</label></th>
            <td><input type="url" id="teacher_facebook" name="teacher_facebook" class="regular-text"
                       placeholder="https://facebook.com/username" value="<?php echo esc_attr($facebook); ?>"></td>
        </tr>
        <tr><th><label for="teacher_twitter">Twitter URL</label></th>
            <td><input type="url" id="teacher_twitter" name="teacher_twitter" class="regular-text"
                       placeholder="https://twitter.com/username" value="<?php echo esc_attr($twitter); ?>"></td>
        </tr>
        <tr><th><label for="teacher_instagram">Instagram URL</label></th>
            <td><input type="url" id="teacher_instagram" name="teacher_instagram" class="regular-text"
                       placeholder="https://instagram.com/username" value="<?php echo esc_attr($instagram); ?>"></td>
        </tr>
        <tr><th><label for="teacher_linkedin">LinkedIn URL</label></th>
            <td><input type="url" id="teacher_linkedin" name="teacher_linkedin" class="regular-text"
                       placeholder="https://linkedin.com/in/username" value="<?php echo esc_attr($linkedin); ?>"></td>
        </tr>
    </table>
    <p><strong>Note:</strong> Set the featured image as the teacher's photo.</p>
    <?php
}

function tm_save_teacher_details($post_id){
    if(!isset($_POST['tm_teacher_details_nonce']) || !wp_verify_nonce($_POST['tm_teacher_details_nonce'],'tm_save_teacher_details')) return;
    if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if(!current_user_can('edit_post',$post_id)) return;
    
    $fields = ['teacher_position','teacher_facebook','teacher_twitter','teacher_instagram','teacher_linkedin'];
    foreach($fields as $field){
        if(isset($_POST[$field])) update_post_meta($post_id,'_'.$field,sanitize_text_field($_POST[$field]));
    }
}
add_action('save_post','tm_save_teacher_details');

// ----------------------
// 3. Shortcode
// ----------------------
function tm_display_teachers_shortcode($atts){
    $atts = shortcode_atts([
        'count'=>-1,
        'orderby'=>'date',
        'order'=>'DESC',
        'section_title'=>'Our Teachers',
        'section_subtitle'=>'Meet our popular teachers',
    ], $atts);

    $args = [
        'post_type'=>'teacher',
        'posts_per_page'=>intval($atts['count']),
        'orderby'=>$atts['orderby'],
        'order'=>$atts['order'],
        'post_status'=>'publish',
    ];

    $query = new WP_Query($args);
    ob_start();
    ?>
    <section id="teachers-section" style="padding:60px 15px; background:#f9f9f9;">
        <div style="max-width:1200px; margin:0 auto; text-align:center; margin-bottom:40px;">
            <p style="color:red !important; font-size:16px; margin-bottom:8px;"><?php echo esc_html($atts['section_subtitle']); ?></p>
            <h2 style="font-size:32px; font-weight:600; margin:0;"><?php echo esc_html($atts['section_title']); ?></h2>
        </div>

        <?php if($query->have_posts()): ?>
        <div class="tm-teachers-grid">
            <?php while($query->have_posts()): $query->the_post(); 
                $position  = get_post_meta(get_the_ID(),'_teacher_position',true);
                $facebook  = get_post_meta(get_the_ID(),'_teacher_facebook',true);
                $twitter   = get_post_meta(get_the_ID(),'_teacher_twitter',true);
                $instagram = get_post_meta(get_the_ID(),'_teacher_instagram',true);
                $linkedin  = get_post_meta(get_the_ID(),'_teacher_linkedin',true);
            ?>
            <div class="tm-teacher-card">
                <div class="tm-card-inner">
                    <div class="tm-image-holder">
                        <?php if(has_post_thumbnail()): ?>
                            <?php the_post_thumbnail('medium',['alt'=>get_the_title()]); ?>
                        <?php else: ?>
                            <img src="<?php echo esc_url(plugins_url('assets/default-teacher.jpg',__FILE__)); ?>" alt="<?php the_title(); ?>">
                        <?php endif; ?>

                        <ul class="tm-social-links">
                            <?php if($facebook): ?><li><a href="<?php echo esc_url($facebook); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a></li><?php endif; ?>
                            <?php if($twitter): ?><li><a href="<?php echo esc_url($twitter); ?>" target="_blank"><i class="fab fa-twitter"></i></a></li><?php endif; ?>
                            <?php if($instagram): ?><li><a href="<?php echo esc_url($instagram); ?>" target="_blank"><i class="fab fa-instagram"></i></a></li><?php endif; ?>
                            <?php if($linkedin): ?><li><a href="<?php echo esc_url($linkedin); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li><?php endif; ?>
                        </ul>
                    </div>
                    <div class="tm-card-body">
                        <p class="tm-teacher-name"><?php the_title(); ?></p>
                        <p class="tm-teacher-position"><?php echo esc_html($position ?: 'Teacher'); ?></p>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        <?php else: ?>
            <p style="text-align:center;">No teachers found.</p>
        <?php endif; ?>
    </section>

    <!-- Styles -->
    <style>
    /* Grid */
    .tm-teachers-grid {
        display: flex;
        flex-wrap: wrap;
        margin: -12px;
    }
    .tm-teacher-card {
        flex: 0 0 16.66%; /* 6 per row desktop */
        padding: 12px;
        box-sizing: border-box;
    }

    /* Card inner */
    .tm-card-inner {
        background:#fff;
        border-radius:16px;
        overflow:hidden;
        text-align:center;
        box-shadow:0 4px 12px rgba(0,0,0,0.08);
        transition: transform 0.3s, box-shadow 0.3s;
    }
    .tm-card-inner:hover {
        transform: translateY(-6px);
        box-shadow:0 20px 40px rgba(0,0,0,0.08);
    }

    /* Image */
    .tm-image-holder {
        position: relative;
        overflow: hidden;
        border-radius:12px;
        width:100%;
        height:150px;
    }
    .tm-image-holder img {
        width:100%;
        height:100%;
        object-fit:cover;
        display:block;
        transition: transform 0.3s;
    }

    /* Social links */
    .tm-social-links {
        position: absolute;
        bottom:8px;
        left:50%;
        transform:translateX(-50%);
        display:flex;
        gap:6px;
        opacity:0;
        transition: opacity 0.3s;
        pointer-events:none;
    }
    .tm-card-inner:hover .tm-social-links {
        opacity:1;
        pointer-events:auto;
    }
    .tm-social-links li a {
        display:inline-block;
        color:#fff;
        font-size:14px;
        background:rgba(0,0,0,0.6);
        padding:5px;
        border-radius:50%;
        transition: background 0.3s;
    }
    .tm-social-links li a:hover {
        background:rgba(0,0,0,0.8);
    }

    /* Card body */
    .tm-card-body {
        padding:12px 6px;
    }
    .tm-teacher-name {
        font-weight:bold;
        margin:4px 0;
    }
    .tm-teacher-position {
        margin:0;
        color:#666;
        font-size:14px;
    }

    /* Responsive */
    @media(max-width:1200px){ .tm-teacher-card { flex:0 0 20%; } }   /* 5 per row */
    @media(max-width:992px){ .tm-teacher-card { flex:0 0 25%; } }    /* 4 per row */
    @media(max-width:768px){ .tm-teacher-card { flex:0 0 33.33%; } }/* 3 per row */
    @media(max-width:576px){ .tm-teacher-card { flex:0 0 100%; } }   /* 1 per row mobile */
    </style>

    <?php
    wp_reset_postdata();
    return ob_get_clean();
}
add_shortcode('teachers','tm_display_teachers_shortcode');


// ----------------------
// 4. Admin Columns
// ----------------------
function tm_teacher_columns($columns){
    $new_columns = [];
    $new_columns['cb'] = $columns['cb'];
    $new_columns['featured_image'] = 'Photo';
    $new_columns['title'] = 'Name';
    $new_columns['position'] = 'Position';
    $new_columns['social_links'] = 'Social Links';
    $new_columns['date'] = $columns['date'];
    return $new_columns;
}
add_filter('manage_teacher_posts_columns','tm_teacher_columns');

function tm_teacher_column_content($column,$post_id){
    switch($column){
        case 'featured_image': echo has_post_thumbnail($post_id)?get_the_post_thumbnail($post_id,[50,50]):'—'; break;
        case 'position': echo get_post_meta($post_id,'_teacher_position',true) ?: '—'; break;
        case 'social_links':
            $links = array_filter([
                get_post_meta($post_id,'_teacher_facebook',true),
                get_post_meta($post_id,'_teacher_twitter',true),
                get_post_meta($post_id,'_teacher_instagram',true),
                get_post_meta($post_id,'_teacher_linkedin',true)
            ]);
            echo !empty($links) ? count($links).' links':'—';
            break;
    }
}
add_action('manage_teacher_posts_custom_column','tm_teacher_column_content',10,2);

// ----------------------
// 5. Activation / Deactivation
// ----------------------
function tm_activate_plugin(){ tm_register_teacher_post_type(); flush_rewrite_rules(); }
register_activation_hook(__FILE__,'tm_activate_plugin');

function tm_deactivate_plugin(){ flush_rewrite_rules(); }
register_deactivation_hook(__FILE__,'tm_deactivate_plugin');

// ----------------------
// 6. Enqueue Font Awesome
// ----------------------
function tm_enqueue_font_awesome(){ wp_enqueue_style('font-awesome','https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'); }
add_action('wp_enqueue_scripts','tm_enqueue_font_awesome');
