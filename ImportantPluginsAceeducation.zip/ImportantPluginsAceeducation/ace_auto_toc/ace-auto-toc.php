<?php
/*
Plugin Name: ACE Table of Contents
Description: Auto-generate Collapsible TOC with admin settings (posts/pages toggle), smooth scroll, and shortcode support.
Version: 1.0
Author: Adina Pervaiz, WebACE
*/

if(!defined('ABSPATH')) exit;

// --------------------
// Build TOC
// --------------------
function ace_build_toc($content){
    preg_match_all('/<h([2-4])[^>]*>(.*?)<\/h[2-4]>/', $content, $matches, PREG_SET_ORDER);
    if(empty($matches)) return $content;

    $toc_html = '<div class="ace-toc"><button class="ace-toc-toggle">📑 Table of Contents</button><ul class="ace-toc-list" style="display:none;">';

    foreach($matches as $match){
        $title = strip_tags($match[2]);
        $id = sanitize_title($title);

        if(strpos($match[0],'id=')===false){
            $new_heading = preg_replace('/^(<h'.$match[1].'[^>]*)>/','$1 id="'.$id.'">',$match[0]);
            $content = str_replace($match[0],$new_heading,$content);
        }

        $toc_html .= '<li class="toc-level-'.$match[1].'"><a href="#'.$id.'">'.$title.'</a></li>';
    }

    $toc_html .= '</ul></div>';

    // Toggle + smooth scroll JS
    $toc_html .= '<script>
    document.querySelectorAll(".ace-toc-toggle").forEach(btn=>{
        btn.addEventListener("click",()=>{const list=btn.nextElementSibling;list.style.display=(list.style.display==="none"||list.style.display==="")?"block":"none";});
    });
    document.querySelectorAll(".ace-toc a").forEach(link=>{
        link.addEventListener("click",e=>{e.preventDefault();const target=document.querySelector(link.getAttribute("href"));if(target){window.scrollTo({top:target.offsetTop-80,behavior:"smooth"});}});
    });
    </script>';

    return $toc_html.$content;
}

// --------------------
// Auto Insert TOC
// --------------------
function ace_auto_insert_toc($content){
    if(is_admin() || is_feed()) return $content;

    $settings = get_option('ace_toc_settings', [
        'auto_insert'=>'yes',
        'show_on_posts'=>'yes',
        'show_on_pages'=>'no'
    ]);

    if($settings['auto_insert']!=='yes') return $content;

    if(is_singular('post') && $settings['show_on_posts']!=='yes') return $content;
    if(is_page() && $settings['show_on_pages']!=='yes') return $content;

    return ace_build_toc($content);
}
add_filter('the_content','ace_auto_insert_toc');

// --------------------
// Shortcode [ace_toc]
// --------------------
function ace_toc_shortcode(){
    global $post;
    if(!$post) return '';
    return ace_build_toc($post->post_content);
}
add_shortcode('ace_toc','ace_toc_shortcode');

// --------------------
// Admin Settings Page
// --------------------
function ace_toc_register_settings(){
    register_setting('ace_toc_group','ace_toc_settings');
}
add_action('admin_init','ace_toc_register_settings');

function ace_toc_settings_page(){
    $settings = get_option('ace_toc_settings',[
        'auto_insert'=>'yes',
        'show_on_posts'=>'yes',
        'show_on_pages'=>'no'
    ]);
    ?>
    <div class="wrap">
        <h1>ACE TOC Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('ace_toc_group'); ?>
            <table class="form-table">
                <tr>
                    <th>Auto Insert TOC</th>
                    <td>
                        <select name="ace_toc_settings[auto_insert]">
                            <option value="yes" <?php selected($settings['auto_insert'],'yes'); ?>>Yes</option>
                            <option value="no" <?php selected($settings['auto_insert'],'no'); ?>>No (shortcode only)</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Show on Posts</th>
                    <td>
                        <input type="checkbox" name="ace_toc_settings[show_on_posts]" value="yes" <?php checked($settings['show_on_posts'],'yes'); ?> />
                    </td>
                </tr>
                <tr>
                    <th>Show on Pages</th>
                    <td>
                        <input type="checkbox" name="ace_toc_settings[show_on_pages]" value="yes" <?php checked($settings['show_on_pages'],'yes'); ?> />
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
function ace_toc_menu(){
    add_options_page('ACE TOC','ACE TOC','manage_options','ace-toc','ace_toc_settings_page');
}
add_action('admin_menu','ace_toc_menu');

// --------------------
// Basic Styling
// --------------------
function ace_toc_assets(){
    echo '<style>
    .ace-toc{background:#f7f9fb;border:1px solid #ddd;padding:12px 15px;border-radius:8px;margin:20px 0;}
    .ace-toc-toggle{width:100%;text-align:left;background:#002D62;color:#fff;padding:10px 15px;border:none;border-radius:6px;cursor:pointer;font-size:16px;font-weight:600;}
    .ace-toc-toggle:hover{background:#004080;}
    .ace-toc-list{list-style:none;padding-left:0;margin-top:10px;}
    .ace-toc li{margin:5px 0;}
    .ace-toc a{text-decoration:none;color:#002D62;}
    .ace-toc a:hover{text-decoration:underline;}
    .toc-level-3{margin-left:15px;}
    .toc-level-4{margin-left:30px;}
    </style>';
}
add_action('wp_head','ace_toc_assets');

