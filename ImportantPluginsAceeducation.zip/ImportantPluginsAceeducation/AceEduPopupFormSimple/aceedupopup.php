<?php
/*
Plugin Name: ACEEducation Popup Form
Description: A responsive popup form that sends email.
Version: 1.5
Author: Adina Pervaiz
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue jQuery if not already loaded
add_action('wp_enqueue_scripts', 'ace_popup_enqueue_scripts');
function ace_popup_enqueue_scripts() {
    wp_enqueue_script('jquery');
}

// Add popup to footer automatically on all pages
add_action('wp_footer', 'ace_popup_form');
function ace_popup_form() {
    ?>
    <style>
        /* Overlay background */
        #ace-popup-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 45, 98, 0.9);
            z-index: 9999;
        }

        /* Popup container */
        #ace-popup {
            background: #ffffff;
            color: #002D62;
            padding: 25px;
            border-radius: 15px;
            max-width: 400px;
            width: 90%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            box-shadow: 0 10px 25px rgba(0, 45, 98, 0.3);
            text-align: center;
            border: 2px solid #002D62;
            animation: aceFadeIn 0.4s ease-in-out;
        }

        @keyframes aceFadeIn {
            from { opacity: 0; transform: translate(-50%, -48%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }

        #ace-popup h2 {
            margin-bottom: 15px;
            color: #002D62;
        }

        #ace-popup form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        #ace-popup input,
        #ace-popup select {
            padding: 10px;
            border: 1px solid #002D62;
            border-radius: 8px;
            font-size: 15px;
            color: #002D62;
            background: #f8f8f8;
            transition: background 0.3s ease, border-color 0.3s ease;
        }

        #ace-popup input:focus,
        #ace-popup select:focus {
            background: #ffffff;
            border-color: #002D62;
            outline: none;
        }

        .ace-submit-btn {
            background: #dcb225;
            color: #002D62;
            font-weight: bold;
            border: none;
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: background 0.3s ease, color 0.3s ease;
        }

        .ace-submit-btn:hover {
            background: #002D62;
            color: #ffffff;
        }

        #ace-popup-close {
            position: absolute;
            top: 8px;
            right: 12px;
            background: transparent;
            color: #002D62;
            font-size: 24px;
            border: none;
            cursor: pointer;
            line-height: 1;
            transition: transform 0.2s ease, color 0.3s ease;
        }

        #ace-popup-close:hover {
            transform: scale(1.2);
            color: #dcb225;
        }

        #ace-popup label {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 10px 0;
            text-align: left;
            color: #002D62;
        }

        #ace-popup label span {
            font-size: 13px;
        }

        .ace-success-message {
            background: #28a745;
            color: #ffffff;
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
            text-align: center;
        }

        .ace-error-message {
            background: #dc3545;
            color: #ffffff;
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
            text-align: center;
        }

        @media (max-width: 600px) {
            #ace-popup {
                width: 95%;
                padding: 20px;
            }

            #ace-popup h2 {
                font-size: 20px;
            }
        }
    </style>

    <div id="ace-popup-overlay">
        <div id="ace-popup">
            <button id="ace-popup-close" aria-label="Close popup">&times;</button>
            <h2>🎓 Enquire Now!</h2>
            <?php
            // Show form status messages (sanitized for safety)
            if (isset($_GET['ace_popup_status'])) {
                $status = sanitize_text_field($_GET['ace_popup_status']);
                if ($status === 'success') {
                    echo '<div class="ace-success-message">✅ Thank you! Your inquiry has been submitted.</div>';
                } elseif ($status === 'error') {
                    echo '<div class="ace-error-message">❌ Something went wrong. Please try again.</div>';
                } elseif ($status === 'terms_error') {
                    echo '<div class="ace-error-message">⚠️ You must agree to the Terms & Conditions.</div>';
                } elseif ($status === 'nonce_error') {
                    echo '<div class="ace-error-message">⚠️ Security check failed. Please reload the page.</div>';
                }
            }
            ?>

            <form id="ace-popup-form" method="post" action="">
                <?php wp_nonce_field('ace_popup_form_action', 'ace_popup_form_nonce'); ?>

                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input type="text" name="whatsapp" placeholder="WhatsApp Number" required>
                <select name="iam" required>
                    <option value="">I am...</option>
                    <option value="Student">A Student</option>
                    <option value="Parent">A Parent</option>
                    <option value="Other">Other</option>
                </select>
                <input type="text" name="subject" placeholder="Subject(s)" required>
                <input type="text" name="grade" placeholder="Grade" required>
                <input type="text" name="curriculum" placeholder="Curriculum" required>

                <label>
                    <input type="checkbox" name="terms" value="1" required>
                    <span>I agree to the Terms & Conditions</span>
                </label>

                <button type="submit" name="ace_popup_submit" class="ace-submit-btn">Submit</button>
            </form>

        </div>
    </div>

    <script>
        jQuery(document).ready(function ($) {
            // Auto show after 3 seconds
            setTimeout(() => {
                if (!sessionStorage.getItem('acePopupClosed')) {
                    $('#ace-popup-overlay').fadeIn();
                }
            }, 3000);

            // Close popup when clicking outside
            $('#ace-popup-overlay').on('click', function (e) {
                if ($(e.target).is('#ace-popup-overlay')) {
                    $('#ace-popup-overlay').fadeOut();
                    sessionStorage.setItem('acePopupClosed', 'true');
                }
            });

            // Close popup on X button
            $('#ace-popup-close').on('click', function () {
                $('#ace-popup-overlay').fadeOut();
                sessionStorage.setItem('acePopupClosed', 'true');
            });

            // Show popup if there's a status message
            <?php if (isset($_GET['ace_popup_status'])): ?>
                $('#ace-popup-overlay').fadeIn();
                sessionStorage.removeItem('acePopupClosed');
            <?php endif; ?>
        });
    </script>
    <?php
}

// Handle form submission
add_action('init', 'ace_popup_handle_form');
function ace_popup_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ace_popup_submit'])) {

        // Verify nonce
        if (!isset($_POST['ace_popup_form_nonce']) || !wp_verify_nonce($_POST['ace_popup_form_nonce'], 'ace_popup_form_action')) {
            wp_safe_redirect(add_query_arg('ace_popup_status', 'nonce_error', wp_get_referer()));
            exit;
        }

        // Terms check
        if (empty($_POST['terms'])) {
            wp_safe_redirect(add_query_arg('ace_popup_status', 'terms_error', wp_get_referer()));
            exit;
        }

        // Sanitize all inputs
        $name       = sanitize_text_field($_POST['name']);
        $email      = sanitize_email($_POST['email']);
        $whatsapp   = sanitize_text_field($_POST['whatsapp']);
        $iam        = sanitize_text_field($_POST['iam']);
        $subject_f  = sanitize_text_field($_POST['subject']);
        $grade      = sanitize_text_field($_POST['grade']);
        $curriculum = sanitize_text_field($_POST['curriculum']);

        // Email details
        $to = 'info@aceeducation.com.my, acekl2018@gmail.com';
        $subject = 'New Enquiry Form Submission';

        // HTML message
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #002D62;">New Enquiry from ACE Education Website</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%; max-width: 600px;">';
        $fields = [
            'Name' => $name,
            'Email' => $email,
            'WhatsApp' => $whatsapp,
            'I am' => $iam,
            'Subject(s)' => $subject_f,
            'Grade' => $grade,
            'Curriculum' => $curriculum,
            'Terms Accepted' => 'Yes'
        ];
        foreach ($fields as $label => $value) {
            $message .= '<tr><td style="padding:10px;border:1px solid #ddd;"><strong>' . esc_html($label) . ':</strong></td><td style="padding:10px;border:1px solid #ddd;">' . esc_html($value) . '</td></tr>';
        }
        $message .= '</table>';
        $message .= '<p style="margin-top:20px;color:#666;">Submitted on: ' . date_i18n('F j, Y, g:i a') . '</p>';
        $message .= '</body></html>';

        // Headers
        $from_email = 'info@' . wp_parse_url(home_url(), PHP_URL_HOST);
        $headers = [
            'From: ACE Education Malaysia <' . $from_email . '>',
            'Reply-To: ' . $email,
            'Content-Type: text/html; charset=UTF-8'
        ];


        // Send mail
        $sent = wp_mail($to, $subject, $message, $headers);

        // Redirect with status
        $status = $sent ? 'success' : 'error';
        $redirect_url = wp_get_referer() ? wp_get_referer() : home_url('/');
        wp_safe_redirect(add_query_arg('ace_popup_status', $status, $redirect_url));
        exit;

    }
}


//for testing purpose only
// 🔹 TEST MAIL FUNCTION (for debugging only)
// ✅ IMPROVED: Test mail function with better display
add_action('init', function() {
    if (isset($_GET['testmail'])) {
        echo '<h2>📧 Email Test Results</h2>';
        
        $to = 'pervaizadina@gmail.com';
        $subject = 'Test Email from ACE Education - ' . date('Y-m-d H:i:s');
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #002D62;">Test Email from ACE Education</h2>';
        $message .= '<p>This is a test email sent at: <strong>' . date('F j, Y, g:i a') . '</strong></p>';
        $message .= '<p>If you received this, your email system is working correctly!</p>';
        $message .= '</body></html>';
        
        $headers = [
            'From: ACE Education Malaysia <info@aceeducation.com.my>',
            'Content-Type: text/html; charset=UTF-8'
        ];
        
        $sent = wp_mail($to, $subject, $message, $headers);
        
        echo '<div style="padding: 20px; margin: 20px; border: 2px solid ' . ($sent ? 'green' : 'red') . '; background: ' . ($sent ? '#d4edda' : '#f8d7da') . ';">';
        echo $sent ? '✅ <strong>Mail sent successfully!</strong>' : '❌ <strong>Mail sending failed!</strong>';
        echo '<br><br><strong>Sender:</strong> ACE Education Malaysia';
        echo '<br><strong>From Email:</strong> info@aceeducation.com.my';
        echo '<br><strong>To:</strong> ' . $to;
        echo '<br><br><em>Note: Check spam folder if not in inbox</em>';
        echo '</div>';
        
        echo '<p><a href="' . home_url() . '">← Back to Home</a></p>';
        
        exit;

    }
});
