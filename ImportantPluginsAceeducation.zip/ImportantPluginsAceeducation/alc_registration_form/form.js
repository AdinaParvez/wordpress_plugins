jQuery(document).ready(function($){
    // Initialize Owl Carousel
    $('.alc-slider-owl').owlCarousel({
        items: 1,
        loop: true,
        nav: false,
        dots: true,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        autoHeight: true // dynamic height for mobile
    });

    // Refresh carousel on window resize to recalc height
    $(window).on('resize', function() {
        $('.alc-slider-owl').trigger('refresh.owl.carousel');
    });

    // Handle multiple registration forms
    $('.alc-regform').each(function(){
        var form = $(this);
        var response = form.find('.alc-response');

        form.on('submit', function(e){
            e.preventDefault();

            $.ajax({
                type: 'POST',
                url: alcRegForm.ajaxurl,
                data: form.serialize() + '&action=alc_regform_submit',
                beforeSend: function(){
                    response.html('Submitting...');
                },
                success: function(res){
                    if(res.success){
                        response.html(res.data.message);
                        form[0].reset();
                    } else{
                        response.html('Something went wrong, please try again.');
                    }
                },
                error: function(){
                    response.html('Error submitting form.');
                }
            });
        });
    });
});
