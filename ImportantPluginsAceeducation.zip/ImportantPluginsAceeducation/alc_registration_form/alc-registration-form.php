<?php
/*
Plugin Name: ALC Slider with Registration Form
Description: Custom plugin to display a slider with a registration form on the right with auto sliding.
Version: 1.6
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

// ==========================
// Enqueue Scripts & Styles
// ==========================
function alc_slider_enqueue_assets() {
    // CSS
    wp_enqueue_style('alc-slider-style', plugin_dir_url(__FILE__) . 'style.css');
    
    // Owl Carousel (JS & CSS)
    wp_enqueue_style('owl-carousel-css', plugin_dir_url(__FILE__) . 'lib/owlcarousel/assets/owl.carousel.min.css');
    wp_enqueue_style('owl-carousel-theme', plugin_dir_url(__FILE__) . 'lib/owlcarousel/assets/owl.theme.default.min.css');
    wp_enqueue_script('owl-carousel-js', plugin_dir_url(__FILE__) . 'lib/owlcarousel/owl.carousel.min.js', array('jquery'), null, true);

    // JS - keep form.js
    wp_enqueue_script('alc-slider-js', plugin_dir_url(__FILE__) . 'form.js', array('jquery'), null, true);

    // Pass ajaxurl and success message to JS
    wp_localize_script('alc-slider-js', 'alcRegForm', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'successMsg' => '✅ Thank you! Your registration has been received.'
    ));
}
add_action('wp_enqueue_scripts', 'alc_slider_enqueue_assets');

// ==========================
// Register Slider CPT
// ==========================
function alc_register_slider_cpt() {
    $labels = array(
        'name' => 'Sliders',
        'singular_name' => 'Slider',
        'add_new' => 'Add New Slider',
        'edit_item' => 'Edit Slider',
        'new_item' => 'New Slider',
        'view_item' => 'View Slider',
        'search_items' => 'Search Sliders',
        'not_found' => 'No Sliders Found',
        'not_found_in_trash' => 'No Sliders Found in Trash',
    );
    $args = array(
        'labels' => $labels,
        'public' => true,
        'supports' => array('title','editor','thumbnail'),
        'menu_icon' => 'dashicons-images-alt2'
    );
    register_post_type('alc_slider', $args);
}
add_action('init', 'alc_register_slider_cpt');

// ==========================
// AJAX Form Handler
// ==========================
function alc_regform_submit() {
    $name    = sanitize_text_field($_POST['alc_name']);
    $email   = sanitize_email($_POST['alc_email']);
    $phone   = sanitize_text_field($_POST['alc_phone']);
    $course  = sanitize_text_field($_POST['alc_course']);
    $message = sanitize_textarea_field($_POST['alc_message']);

    $admin_email = get_option('admin_email');
    $subject = "New Registration Form Submission";
    $body    = "Name: $name\nEmail: $email\nPhone: $phone\nCourse: $course\nMessage:\n$message";
    $headers = array('Content-Type: text/plain; charset=UTF-8');

    wp_mail($admin_email, $subject, $body, $headers);

    wp_send_json_success(array('message' => '✅ Thank you! Your registration has been received.'));
}
add_action('wp_ajax_alc_regform_submit', 'alc_regform_submit');
add_action('wp_ajax_nopriv_alc_regform_submit', 'alc_regform_submit');

// ==========================
// Registration Form Shortcode
// ==========================
function alc_registration_form_shortcode($atts = array()) {
    $atts = shortcode_atts(array(
        'unique_id' => '0'
    ), $atts);

    $courses = get_posts(array(
            'post_type'      => 'alc_courses',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
            'post_status'    => 'publish', // only published courses
            'suppress_filters' => false
    ));
    ob_start(); ?>

    <form method="post" class="alc-regform" id="alc-regform-<?php echo esc_attr($atts['unique_id']); ?>">
        <div class="alc-response"></div>
        <h3>Registration Form</h3>
        <input type="text" name="alc_name" placeholder="Your Name" required>
        <input type="email" name="alc_email" placeholder="Your Email" required>
        <input type="text" name="alc_phone" placeholder="Phone Number" required>
        <select name="alc_course" required>
            <option value="">Select Course</option>
            <?php foreach($courses as $course): ?>
                <option value="<?php echo esc_attr($course->post_title); ?>"><?php echo esc_html($course->post_title); ?></option>
            <?php endforeach; ?>
        </select>
        <textarea name="alc_message" placeholder="Message" required></textarea>
        <button type="submit">Register Now</button>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('alc_registration_form', 'alc_registration_form_shortcode');

// ==========================
// Slider with Form Shortcode (max 5 slides + unique forms)
// ==========================
function alc_slider_with_form_shortcode() {
    $sliders = get_posts(array(
        'post_type'      => 'alc_slider',
        'posts_per_page' => 5, // Limit to 5 slides
        'orderby'        => 'date',
        'order'          => 'DESC'
    ));
    
    if(!$sliders) return '';

    ob_start(); ?>
    <div class="alc-slider-owl owl-carousel owl-theme">
        <?php foreach($sliders as $index => $slide):
            $img = get_the_post_thumbnail_url($slide->ID,'full'); ?>
            <div class="alc-slide-item" style="background-image:url('<?php echo esc_url($img); ?>');">
                <div class="slider-overlay"></div>
                <div class="container position-relative z-2 h-100">
                    <div class="row align-items-center h-100">
                        <!-- Left Text Column -->
                        <div class="col-lg-6">
                            <h2 class="mb-3 text-white"><?php echo esc_html($slide->post_title); ?></h2>
                            <p class="text-white"><?php echo esc_html(wp_trim_words($slide->post_content, 30)); ?></p>
                        </div>

                        <!-- Right Form Column -->
                        <div class="col-lg-6 d-flex justify-content-end align-items-center">
                            <div class="slider-form">
                                <?php echo do_shortcode('[alc_registration_form unique_id="' . $index . '"]'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('alc_slider_with_form', 'alc_slider_with_form_shortcode');
