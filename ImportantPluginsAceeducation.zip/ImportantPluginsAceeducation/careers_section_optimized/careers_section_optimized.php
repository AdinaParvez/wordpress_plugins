<?php
/**
 * Plugin Name: Careers Section Optimized
 * Description: Fully responsive Careers Section with animations, lazy-load logos, and admin panel.
 * Version: 1.6
 * Author: Adina Pervaiz
 */

if (!defined('ABSPATH')) exit;

class CareersSectionOptimized {

    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_shortcode('careers_section', [$this, 'render_careers_section']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
    }

    // Enqueue CSS and JS
    public function enqueue_assets() {
        wp_enqueue_style(
            'careers-style',
            plugin_dir_url(__FILE__) . 'assets/style.css',
            [],
            '1.6'
        );

        wp_enqueue_script(
            'careers-js',
            plugin_dir_url(__FILE__) . 'assets/script.js',
            ['jquery'],
            '1.6',
            true
        );
    }

    // Shortcode
    public function render_careers_section($atts) {
        $jobs = get_option('careers_jobs', []);

        // Default jobs
        if (empty($jobs)) {
            $jobs = [
                [
                    'title' => 'English Language Tutor',
                    'location' => 'Kuala Lumpur',
                    'department' => 'Academics',
                    'description' => 'Teach students using modern English learning methodologies.',
                    'apply_link' => '#',
                    'logo' => 'https://thumbs.dreamstime.com/b/avatar-profile-icon-flat-style-female-user-vector-illustration-isolated-background-women-sign-business-concept-321407993.jpg'
                ],
                [
                    'title' => 'Academic Coordinator',
                    'location' => 'Onsite',
                    'department' => 'Management',
                    'description' => 'Coordinate academic planning and manage teaching staff.',
                    'apply_link' => '#',
                    'logo' => 'https://img.freepik.com/premium-vector/portrait-business-woman_505024-2799.jpg'
                ],
                [
                    'title' => 'Mathematics Teacher',
                    'location' => 'Online',
                    'department' => 'STEM',
                    'description' => 'Deliver engaging math lessons aligned with international syllabi.',
                    'apply_link' => '#',
                    'logo' => 'https://thumbs.dreamstime.com/b/male-avatar-realistic-face-man-suit-shirt-necktie-businessman-head-shoulder-icon-vector-186025729.jpg'
                ]
            ];
        }

        ob_start(); ?>
        <section class="careers-section">
            <div class="container">
                <h2>Join Our Team</h2>
                <div class="jobs-grid">
                    <?php foreach($jobs as $job): ?>
                        <div class="job-card">
                            <h3><?php echo esc_html($job['title']); ?></h3>
                            <p><strong>Location:</strong> <?php echo esc_html($job['location']); ?></p>
                            <p><strong>Department:</strong> <?php echo esc_html($job['department']); ?></p>
                            <p><?php echo esc_html($job['description']); ?></p>
                            <img 
                                src="<?php echo esc_url($job['logo'] ?? plugin_dir_url(__FILE__) . 'assets/placeholder.webp'); ?>" 
                                data-src="<?php echo esc_url($job['logo'] ?? plugin_dir_url(__FILE__) . 'assets/placeholder.webp'); ?>" 
                                alt="<?php echo esc_attr($job['title']); ?> logo" 
                                loading="lazy" 
                                class="lazy-logo" 
                                width="80" 
                                height="80"
                                onerror="this.onerror=null;this.src='<?php echo plugin_dir_url(__FILE__); ?>assets/placeholder.webp';"
                            >

                            <a href="<?php echo esc_url($job['show-application-form']); ?>" class="apply-btn" target="_blank" rel="noopener">Apply Now</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    // Admin menu
    public function add_admin_menu() {
        add_menu_page(
            'Careers', 
            'Careers', 
            'manage_options', 
            'careers-section', 
            [$this, 'admin_page'], 
            'dashicons-businessman', 
            30
        );
    }

    // Register settings
    public function register_settings() {
        register_setting('careers_section_group', 'careers_jobs');
    }

    // Admin page
    public function admin_page() {
        $jobs = get_option('careers_jobs', []); ?>
        <div class="wrap">
            <h1>Careers Section</h1>
            <form method="post" action="options.php">
                <?php settings_fields('careers_section_group'); ?>
                <table class="form-table" id="jobs-table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Location</th>
                            <th>Department</th>
                            <th>Description</th>
                            <th>Apply Link</th>
                            <th>Logo URL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($jobs as $i => $job): ?>
                        <tr>
                            <td><input type="text" name="careers_jobs[<?php echo $i; ?>][title]" value="<?php echo esc_attr($job['title']); ?>"></td>
                            <td><input type="text" name="careers_jobs[<?php echo $i; ?>][location]" value="<?php echo esc_attr($job['location']); ?>"></td>
                            <td><input type="text" name="careers_jobs[<?php echo $i; ?>][department]" value="<?php echo esc_attr($job['department']); ?>"></td>
                            <td><textarea name="careers_jobs[<?php echo $i; ?>][description]"><?php echo esc_textarea($job['description']); ?></textarea></td>
                            <td><input type="text" name="careers_jobs[<?php echo $i; ?>][apply_link]" value="<?php echo esc_url($job['apply_link']); ?>"></td>
                            <td><input type="text" name="careers_jobs[<?php echo $i; ?>][logo]" value="<?php echo esc_url($job['logo'] ?? ''); ?>"></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="button" class="button" id="add-job">Add Job</button>
                <?php submit_button(); ?>
            </form>
        </div>
        <script>
        jQuery(document).ready(function($){
            var index = <?php echo count($jobs); ?>;
            $('#add-job').click(function(){
                $('#jobs-table tbody').append('<tr>'+
                    '<td><input type="text" name="careers_jobs['+index+'][title]" /></td>'+
                    '<td><input type="text" name="careers_jobs['+index+'][location]" /></td>'+
                    '<td><input type="text" name="careers_jobs['+index+'][department]" /></td>'+
                    '<td><textarea name="careers_jobs['+index+'][description]"></textarea></td>'+
                    '<td><input type="text" name="careers_jobs['+index+'][apply_link]" /></td>'+
                    '<td><input type="text" name="careers_jobs['+index+'][logo]" /></td>'+
                '</tr>');
                index++;
            });
        });
        </script>
        <?php
    }
}

new CareersSectionOptimized();
