jQuery(document).ready(function($) {
    // Check if National Day popup was closed before
    function wasNationalDayPopupClosed() {
        return document.cookie.split(';').some((item) => item.trim().startsWith('ace_national_day_popup_closed='));
    }
    
    // Set cookie for National Day popup
    function setNationalDayPopupCookie() {
        $.ajax({
            url: ace_popup_params.ajax_url,
            type: 'POST',
            data: {
                action: 'ace_popup_set_cookie',
                nonce: ace_popup_params.nonce
            }
        });
    }
    
    // Show National Day popup
    function showNationalDayPopup() {
        if ($('#ace-national-day-popup').length) {
            setTimeout(function() {
                $('#ace-national-day-popup').fadeIn(300);
                
                // Add animation classes
                $('.ace-offer-badge').addClass('animate');
                $('.ace-popup-students-image').css({
                    'transform': 'scale(1.05)',
                    'transition': 'transform 1s ease'
                });
            }, ace_popup_params.delay_after_first_popup);
        }
    }
    
    // Close National Day popup
    function closeNationalDayPopup() {
        $('#ace-national-day-popup').fadeOut(300);
        setNationalDayPopupCookie();
    }
    
    // Monitor first popup (enquiry popup)
    function monitorFirstPopup() {
        const selectors = ace_popup_params.popup_selector.split(',').map(s => s.trim());
        const maxChecks = ace_popup_params.timeout / ace_popup_params.check_interval;
        let checkCount = 0;
        
        const checkPopup = setInterval(function() {
            checkCount++;
            
            // Stop checking after timeout
            if (checkCount > maxChecks) {
                clearInterval(checkPopup);
                console.log('ACE National Day Popup: Timeout checking for first popup');
                
                // If timeout and popup never showed, show National Day popup anyway
                if (!wasNationalDayPopupClosed()) {
                    showNationalDayPopup();
                }
                return;
            }
            
            // Check each selector
            for (let selector of selectors) {
                if ($(selector).length) {
                    const $firstPopup = $(selector);
                    
                    // Check if first popup is visible
                    if ($firstPopup.is(':visible')) {
                        console.log('ACE National Day Popup: First popup found:', selector);
                        
                        // Monitor when first popup closes
                        monitorFirstPopupClose($firstPopup, selector);
                        clearInterval(checkPopup);
                        return;
                    }
                }
            }
            
            // If no first popup found after several checks, show National Day popup
            if (checkCount > 10 && !$(selectors.join(',')).length) {
                console.log('ACE National Day Popup: No first popup found, showing directly');
                if (!wasNationalDayPopupClosed()) {
                    showNationalDayPopup();
                }
                clearInterval(checkPopup);
            }
            
        }, ace_popup_params.check_interval);
    }
    
    // Monitor when first popup closes
    function monitorFirstPopupClose($popup, selector) {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                    const display = $popup.css('display');
                    const visibility = $popup.css('visibility');
                    const opacity = $popup.css('opacity');
                    
                    // Check if popup is closing/hidden
                    if (display === 'none' || visibility === 'hidden' || opacity === '0') {
                        console.log('ACE National Day Popup: First popup closed');
                        observer.disconnect();
                        
                        // Show National Day popup after delay
                        if (!wasNationalDayPopupClosed()) {
                            showNationalDayPopup();
                        }
                    }
                }
            });
        });
        
        // Also set up click handlers for close buttons in first popup
        const closeSelectors = [
            selector + ' .close',
            selector + ' .popup-close',
            selector + ' .modal-close',
            selector + ' [data-dismiss="modal"]',
            selector + ' button.close'
        ];
        
        $(closeSelectors.join(',')).on('click.ace', function() {
            console.log('ACE National Day Popup: First popup close button clicked');
            setTimeout(function() {
                if (!wasNationalDayPopupClosed()) {
                    showNationalDayPopup();
                }
            }, ace_popup_params.delay_after_first_popup);
        });
        
        // Monitor style changes
        observer.observe($popup[0], {
            attributes: true,
            attributeFilter: ['style', 'class']
        });
        
        // Fallback: Check visibility every second
        const visibilityCheck = setInterval(function() {
            if (!$popup.is(':visible')) {
                console.log('ACE National Day Popup: First popup no longer visible');
                clearInterval(visibilityCheck);
                if (!wasNationalDayPopupClosed()) {
                    showNationalDayPopup();
                }
            }
        }, 1000);
        
        // Clear fallback after 30 seconds
        setTimeout(function() {
            clearInterval(visibilityCheck);
        }, 30000);
    }
    
    // Initialize
    function initializePopup() {
        // Only proceed if popup should show
        if (wasNationalDayPopupClosed()) {
            console.log('ACE National Day Popup: Already closed by user');
            return;
        }
        
        // Start monitoring for first popup
        monitorFirstPopup();
        
        // Set up close handlers for National Day popup
        $(document)
            .on('click', '.ace-popup-close', closeNationalDayPopup)
            .on('click', function(e) {
                if ($(e.target).hasClass('ace-popup-overlay')) {
                    closeNationalDayPopup();
                }
            });
        
        // Escape key to close popup
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && $('#ace-national-day-popup').is(':visible')) {
                closeNationalDayPopup();
            }
        });
    }
    
    // Start after short delay to ensure first popup script loads
    setTimeout(initializePopup, 1000);
});