<?php
/**
 * Plugin Name: ACE Education Bahrain National Day Popup
 * Plugin URI: https://aceeducationbh.com
 * Description: Displays a National Day promotional popup after enquiry popup is closed
 * Version: 1.0.1
 * Author: Adina
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('ACE_POPUP_VERSION', '1.0.1');
define('ACE_POPUP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ACE_POPUP_PLUGIN_PATH', plugin_dir_path(__FILE__));

// Enqueue scripts and styles
function ace_national_day_popup_scripts() {
    // Enqueue CSS
    wp_enqueue_style(
        'ace-popup-css',
        ACE_POPUP_PLUGIN_URL . 'css/ace-popup-style.css',
        array(),
        ACE_POPUP_VERSION
    );
    
    // Enqueue JavaScript
    wp_enqueue_script(
        'ace-popup-js',
        ACE_POPUP_PLUGIN_URL . 'js/ace-popup-script.js',
        array('jquery'),
        ACE_POPUP_VERSION,
        true
    );
    
    // Localize script
    wp_localize_script('ace-popup-js', 'ace_popup_params', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ace_popup_nonce'),
        'delay_after_first_popup' => 1000, // 1 second delay after first popup closes
        'check_interval' => 500, // Check every 500ms for first popup
        'timeout' => 30000, // Stop checking after 30 seconds
        'popup_selector' => get_option('ace_first_popup_selector', '.enquiry-popup, .contact-popup, .modal-popup') // Common selectors
    ));
}
add_action('wp_enqueue_scripts', 'ace_national_day_popup_scripts');

// Admin menu
function ace_popup_admin_menu() {
    add_menu_page(
        'National Day Popup Settings',
        'National Day Popup',
        'manage_options',
        'ace-popup-settings',
        'ace_popup_settings_page',
        'dashicons-flag',
        30
    );
}
add_action('admin_menu', 'ace_popup_admin_menu');

// Settings page
function ace_popup_settings_page() {
    ?>
    <div class="wrap">
        <h1>National Day Popup Settings</h1>
        <p><strong>Note:</strong> This popup will appear AFTER your existing enquiry popup is closed.</p>
        
        <form method="post" action="options.php">
            <?php
            settings_fields('ace_popup_settings_group');
            do_settings_sections('ace-popup-settings');
            submit_button();
            ?>
        </form>
        
        <div class="ace-popup-help">
            <h3>Configuration Help</h3>
            <p>If the popup isn't appearing correctly, you might need to adjust the CSS selector for your enquiry popup.</p>
            <p>Common selectors for enquiry popups:</p>
            <ul>
                <li><code>.popup</code> - Generic popup class</li>
                <li><code>.modal</code> - Modal dialog class</li>
                <li><code>#enquiry-popup</code> - ID selector</li>
                <li><code>.contact-form-popup</code> - Contact form class</li>
            </ul>
            <p>Use your browser's developer tools (F12) to inspect your enquiry popup and find the correct selector.</p>
        </div>
        
        <style>
            .ace-popup-help {
                background: #f0f6fc;
                border-left: 4px solid #2271b1;
                padding: 15px;
                margin-top: 30px;
                max-width: 600px;
            }
            .ace-popup-help code {
                background: #e0e0e0;
                padding: 2px 5px;
                border-radius: 3px;
            }
        </style>
    </div>
    <?php
}

// Register settings
function ace_popup_register_settings() {
    register_setting('ace_popup_settings_group', 'ace_popup_enabled');
    register_setting('ace_popup_settings_group', 'ace_popup_discount');
    register_setting('ace_popup_settings_group', 'ace_popup_expiry');
    register_setting('ace_popup_settings_group', 'ace_popup_button_text');
    register_setting('ace_popup_settings_group', 'ace_popup_button_url');
    register_setting('ace_popup_settings_group', 'ace_first_popup_selector');
    register_setting('ace_popup_settings_group', 'ace_popup_delay');
    
    add_settings_section(
        'ace_popup_main_section',
        'Popup Configuration',
        null,
        'ace-popup-settings'
    );
    
    add_settings_field(
        'ace_popup_enabled',
        'Enable National Day Popup',
        'ace_popup_enabled_callback',
        'ace-popup-settings',
        'ace_popup_main_section'
    );
    
    add_settings_field(
        'ace_first_popup_selector',
        'First Popup CSS Selector',
        'ace_first_popup_selector_callback',
        'ace-popup-settings',
        'ace_popup_main_section'
    );
    
    add_settings_field(
        'ace_popup_delay',
        'Delay After First Popup (seconds)',
        'ace_popup_delay_callback',
        'ace-popup-settings',
        'ace_popup_main_section'
    );
    
    add_settings_field(
        'ace_popup_discount',
        'Discount Percentage',
        'ace_popup_discount_callback',
        'ace-popup-settings',
        'ace_popup_main_section'
    );
    
    add_settings_field(
        'ace_popup_expiry',
        'Offer Expiry Date',
        'ace_popup_expiry_callback',
        'ace-popup-settings',
        'ace_popup_main_section'
    );
    
    add_settings_field(
        'ace_popup_button_text',
        'Button Text',
        'ace_popup_button_text_callback',
        'ace-popup-settings',
        'ace_popup_main_section'
    );
    
    add_settings_field(
        'ace_popup_button_url',
        'Button URL',
        'ace_popup_button_url_callback',
        'ace-popup-settings',
        'ace_popup_main_section'
    );
}
add_action('admin_init', 'ace_popup_register_settings');

// Callback functions for settings
function ace_popup_enabled_callback() {
    $enabled = get_option('ace_popup_enabled', 'yes');
    ?>
    <label>
        <input type="checkbox" name="ace_popup_enabled" value="yes" <?php checked($enabled, 'yes'); ?>>
        Show National Day Popup
    </label>
    <p class="description">Popup will show after your enquiry popup is closed</p>
    <?php
}

function ace_first_popup_selector_callback() {
    $selector = get_option('ace_first_popup_selector', '.enquiry-popup, .contact-popup, .modal-popup');
    ?>
    <input type="text" name="ace_first_popup_selector" value="<?php echo esc_attr($selector); ?>" class="regular-text">
    <p class="description">CSS selector(s) for your existing enquiry popup. Separate multiple selectors with commas.</p>
    <?php
}

function ace_popup_delay_callback() {
    $delay = get_option('ace_popup_delay', '1');
    ?>
    <input type="number" name="ace_popup_delay" value="<?php echo esc_attr($delay); ?>" min="0" max="10" step="0.5"> seconds
    <p class="description">Delay before showing National Day popup after enquiry popup closes</p>
    <?php
}

function ace_popup_discount_callback() {
    $discount = get_option('ace_popup_discount', '50');
    ?>
    <input type="number" name="ace_popup_discount" value="<?php echo esc_attr($discount); ?>" min="1" max="100"> %
    <?php
}

function ace_popup_expiry_callback() {
    $expiry = get_option('ace_popup_expiry', '2023-12-31');
    ?>
    <input type="date" name="ace_popup_expiry" value="<?php echo esc_attr($expiry); ?>">
    <?php
}

function ace_popup_button_text_callback() {
    $text = get_option('ace_popup_button_text', 'Register Now');
    ?>
    <input type="text" name="ace_popup_button_text" value="<?php echo esc_attr($text); ?>" class="regular-text">
    <?php
}

function ace_popup_button_url_callback() {
    $url = get_option('ace_popup_button_url', '#');
    ?>
    <input type="url" name="ace_popup_button_url" value="<?php echo esc_attr($url); ?>" class="regular-text">
    <?php
}

// Display the popup HTML
function ace_display_national_day_popup() {
    if (get_option('ace_popup_enabled', 'yes') !== 'yes') {
        return;
    }
    
    $discount = get_option('ace_popup_discount', '50');
    $button_text = get_option('ace_popup_button_text', 'Register Now');
    $button_url = get_option('ace_popup_button_url', '#');
    $expiry = get_option('ace_popup_expiry', '2023-12-31');
    
    // Format expiry date
    $expiry_date = date('F j, Y', strtotime($expiry));
    ?>
    
    <div id="ace-national-day-popup" class="ace-popup-overlay" style="display: none;">
        <div class="ace-popup-container">
            <div class="ace-popup-header">
                <button class="ace-popup-close" aria-label="Close popup">&times;</button>
                <div class="ace-popup-flag" title="Bahrain Flag"></div>
            </div>
            
            <div class="ace-popup-content">
                <div class="ace-popup-greeting">
                    <h2>Assalam-o-Alaikum!</h2>
                    <p class="ace-arabic">السلام عليكم</p>
                </div>
                
                <div class="ace-popup-message">
                    <h3>Happy National Day Bahrain!</h3>
                    <p>ACE Education Bahrain celebrates National Day on 16th December</p>
                </div>
                
                <div class="ace-popup-students-image" title="Arabic Students at ACE Education"></div>
                
                <div class="ace-popup-offer">
                    <div class="ace-offer-badge">
                        <span class="ace-discount-percent"><?php echo esc_html($discount); ?>%</span>
                        <span class="ace-offer-text">OFF</span>
                    </div>
                    <h4>Special National Day Offer!</h4>
                    <p>Get <strong><?php echo esc_html($discount); ?>% discount</strong> on registration</p>
                    <p class="ace-expiry">Offer valid until: <?php echo esc_html($expiry_date); ?></p>
                </div>
                
                <div class="ace-popup-footer">
                    <a href="<?php echo esc_url($button_url); ?>" class="ace-popup-button">
                        <?php echo esc_html($button_text); ?>
                    </a>
                    <p class="ace-popup-note">Limited time offer for Bahrain National Day celebration</p>
                </div>
            </div>
            
            <div class="ace-popup-bahrain-text">
                <span class="ace-arabic-large">مملكة البحرين</span>
                <span>Kingdom of Bahrain</span>
            </div>
        </div>
    </div>
    
    <?php
}
add_action('wp_footer', 'ace_display_national_day_popup');

// AJAX handler for closing popup
function ace_popup_set_cookie() {
    check_ajax_referer('ace_popup_nonce', 'nonce');
    
    $expiry = time() + (24 * 60 * 60); // 24 hours
    setcookie('ace_national_day_popup_closed', 'true', $expiry, '/');
    
    wp_send_json_success(array('message' => 'Cookie set'));
}
add_action('wp_ajax_ace_popup_set_cookie', 'ace_popup_set_cookie');
add_action('wp_ajax_nopriv_ace_popup_set_cookie', 'ace_popup_set_cookie');

// Check if popup should be shown
function ace_popup_should_show() {
    // Check cookie
    if (isset($_COOKIE['ace_national_day_popup_closed']) && $_COOKIE['ace_national_day_popup_closed'] === 'true') {
        return false;
    }
    
    // Check if enabled
    if (get_option('ace_popup_enabled', 'yes') !== 'yes') {
        return false;
    }
    
    // Check expiry date
    $expiry = get_option('ace_popup_expiry', '2023-12-31');
    if (strtotime($expiry) < time()) {
        return false;
    }
    
    return true;
}