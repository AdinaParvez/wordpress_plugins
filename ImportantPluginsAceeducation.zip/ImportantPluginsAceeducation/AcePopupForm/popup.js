jQuery(document).ready(function ($) {
  // Auto show after 3 seconds
  setTimeout(() => {
    if (!sessionStorage.getItem('acePopupClosed')) {
      $('#ace-popup-overlay').fadeIn();
    }
  }, 3000);

  // AJAX form submission
  $('#ace-popup-form').on('submit', function (e) {
    e.preventDefault();

    const formData = $(this).serialize() + '&nonce=' + acePopup.nonce;

    $.post(acePopup.ajax_url, formData, function (response) {
      if (response.success) {
        alert(response.data);
        $('#ace-popup-overlay').fadeOut();
        sessionStorage.setItem('acePopupClosed', 'true');
      } else {
        alert(response.data || 'Error sending message. Please try again.');
      }
    }).fail(function () {
      alert('Submission failed. Please try again.');
    });
  });

  // Close popup when clicking outside
  $('#ace-popup-overlay').on('click', function (e) {
    if ($(e.target).is('#ace-popup-overlay')) {
      $('#ace-popup-overlay').fadeOut();
      sessionStorage.setItem('acePopupClosed', 'true');
    }
  });

  // Close popup on X
  $('#ace-popup-close').on('click', function () {
    $('#ace-popup-overlay').fadeOut();
    sessionStorage.setItem('acePopupClosed', 'true');
  });
});