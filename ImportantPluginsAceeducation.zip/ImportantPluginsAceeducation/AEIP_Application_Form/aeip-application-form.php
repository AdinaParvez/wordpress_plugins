<?php
/**
 * Plugin Name: Admission Form
 * Plugin URI: https://acelanguagecentre.edu.my
 * Description: A comprehensive, responsive admission form for educational institutions
 * Version: 1.0.2
 * Author: Adina Pervaiz
 * License: GPL v2 or later
 * Text Domain: admission-form
 */

if (!defined('ABSPATH')) exit;

class AdmissionFormPlugin {

    public function __construct() {
        add_shortcode('admission_form', [$this, 'render_form']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_submit_admission_form', [$this, 'handle_submission']);
        add_action('wp_ajax_nopriv_submit_admission_form', [$this, 'handle_submission']);
        register_activation_hook(__FILE__, [$this, 'create_table']);
    }

    public function enqueue_assets() {
        wp_enqueue_style(
            'admission-form-style',
            plugin_dir_url(__FILE__) . 'assets/style.css',
            [],
            '1.0.2'
        );

        wp_enqueue_script(
            'admission-form-script',
            plugin_dir_url(__FILE__) . 'assets/script.js',
            ['jquery'],
            '1.0.2',
            true
        );

        wp_localize_script('admission-form-script', 'admissionFormAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('admission_form_nonce')
        ]);
    }

    public function create_table() {
        global $wpdb;
        $table = $wpdb->prefix . 'admission_forms';
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            full_name varchar(255),
            passport_no varchar(100),
            nationality varchar(100),
            age int,
            street_address text,
            city varchar(100),
            postal_code varchar(20),
            state_region varchar(100),
            email varchar(255),
            phone varchar(50),
            contact_app varchar(50),
            wechat_line_id varchar(100),
            university_plan varchar(20),
            university_name varchar(255),
            program varchar(100),
            session varchar(100),
            study_duration varchar(50),
            preferred_centre varchar(100),
            message text,
            passport_copy varchar(255),
            photo varchar(255),
            certificates varchar(255),
            health_form varchar(255),
            offer_letter varchar(255),
            submission_date datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public function render_form() {
        ob_start();
        ?>
              <div class="admission-form-container">
            <div class="admission-form-header">
                <h2>Admission Application Form</h2>
                <p class="form-description">Please fill in the required details to enroll in our comprehensive English course designed to help you achieve fluency and confidence.</p>
                <div class="alert alert-info">
                    <strong>Important!</strong> If you are helping your friends to apply online, please key in a unique (different) email address for each application.
                </div>
            </div>
            
            <form id="admission-form" method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('admission_form_nonce', 'admission_nonce'); ?>
                
                <!-- Required Documents Section -->
                <div class="form-section">
                    <h3 class="section-title">📄 Required Documents</h3>
                    
                    <div class="form-group">
                        <label for="passport_copy">Upload Passport Copy* | Upload All Passport Pages (Blank & Stamped)</label>
                        <input type="file" id="passport_copy" name="passport_copy" accept=".pdf,.jpg,.jpeg,.png" required>
                        <small class="form-text">Accepted formats: PDF, JPG, PNG (Max 5MB)</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="photo">Upload Photo* | White background | 45 mm high x 35 mm wide</label>
                        <input type="file" id="photo" name="photo" accept=".jpg,.jpeg,.png" required>
                        <small class="form-text">Accepted formats: JPG, PNG (Max 2MB)</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="certificates">Upload High School Certificate & Transcripts*</label>
                        <input type="file" id="certificates" name="certificates" accept=".pdf,.jpg,.jpeg,.png" required multiple>
                        <small class="form-text">You can select multiple files</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="health_form">Upload EMGS Health Declaration Form* | <a href="#" class="download-link">Download the form from: EMGS</a></label>
                        <input type="file" id="health_form" name="health_form" accept=".pdf" required>
                    </div>
                </div>
                
                <!-- Personal Information Section -->
                <div class="form-section">
                    <h3 class="section-title">👤 Personal Information</h3>
                    
                    <div class="form-group">
                        <label for="full_name">Full Name (as in Passport)*</label>
                        <input type="text" id="full_name" name="full_name" class="form-control" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="passport_no">Passport No.*</label>
                            <input type="text" id="passport_no" name="passport_no" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="nationality">Nationality* (Write Your Country Name)</label>
                            <input type="text" id="nationality" name="nationality" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="age">Age*</label>
                            <input type="number" id="age" name="age" class="form-control" min="1" max="120" required>
                        </div>
                    </div>
                </div>
                
                <!-- Student's Current Address Section -->
                <div class="form-section">
                    <h3 class="section-title">📍 Student's Current Address</h3>
                    
                    <div class="form-group">
                        <label for="street_address">Street address*</label>
                        <input type="text" id="street_address" name="street_address" class="form-control" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="city">City*</label>
                            <input type="text" id="city" name="city" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="postal_code">Postal code*</label>
                            <input type="text" id="postal_code" name="postal_code" class="form-control" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="state_region">State/Region*</label>
                            <input type="text" id="state_region" name="state_region" class="form-control" required>
                        </div>
                    </div>
                </div>
                
                <!-- Student's Contact Information Section -->
                <div class="form-section">
                    <h3 class="section-title">📞 Student's Contact Information</h3>
                    <p class="form-note">If you are helping your friends to apply, please use a unique (different) email address for each application.</p>
                    
                    <div class="form-group">
                        <label for="email">Email Address*</label>
                        <input type="email" id="email" name="email" class="form-control" placeholder="Email Address*" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone number*</label>
                        <input type="tel" id="phone" name="phone" class="form-control" placeholder="Phone number*" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Which of the following app may we use to contact you?* Select one</label>
                        <div class="checkbox-group">
                            <label class="checkbox-label">
                                <input type="radio" name="contact_app" value="WhatsApp" required> WhatsApp
                            </label>
                            <label class="checkbox-label">
                                <input type="radio" name="contact_app" value="WeChat" required> WeChat
                            </label>
                            <label class="checkbox-label">
                                <input type="radio" name="contact_app" value="LINE" required> LINE
                            </label>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="wechat_line_id">WeChat/ LINE ID (if any)</label>
                        <input type="text" id="wechat_line_id" name="wechat_line_id" class="form-control">
                    </div>
                </div>
                
                <!-- University Plans Section -->
                <div class="form-section">
                    <h3 class="section-title">🎓 University Plans</h3>
                    
                    <div class="form-group">
                        <label>Do you plan on attending a Malaysian university after studying at ACE?</label>
                        <select id="university_plan" name="university_plan" class="form-control">
                            <option value="">Please Select</option>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                            <option value="maybe">Maybe</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="university_name_group" style="display: none;">
                        <label for="university_name">If yes, what is the University's Name?</label>
                        <select id="university_name" name="university_name" class="form-control">
                            <option value="">Please Select</option>
                            <option value="University of Malaya">University of Malaya</option>
                            <option value="Universiti Putra Malaysia">Universiti Putra Malaysia</option>
                            <option value="Universiti Kebangsaan Malaysia">Universiti Kebangsaan Malaysia</option>
                            <option value="Universiti Sains Malaysia">Universiti Sains Malaysia</option>
                            <option value="Universiti Teknologi Malaysia">Universiti Teknologi Malaysia</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="other_university_group" style="display: none;">
                        <label for="other_university">If you have selected Other in the above field, please specify the university's name here.</label>
                        <input type="text" id="other_university" name="other_university" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="offer_letter">Upload University Offer Letter (if any)</label>
                        <input type="file" id="offer_letter" name="offer_letter" accept=".pdf,.jpg,.jpeg,.png">
                    </div>
                </div>
                
                <!-- Programme Selection Section -->
                <div class="form-section">
                    <h3 class="section-title">📚 Programme Selection</h3>
                    
                    <div class="form-group">
                        <label for="program">ACE Programmes*</label>
                        <select id="program" name="program" class="form-control" required>
                            <option value="">Please Select</option>
                            <option value="Intensive English Programme">Intensive English Programme</option>
                            <option value="IELTS Preparation">IELTS Preparation</option>
                            <option value="Business English">Business English</option>
                            <option value="Academic English">Academic English</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="session">Session*</label>
                        <select id="session" name="session" class="form-control" required>
                            <option value="">Please Select</option>
                            <option value="January 2025">January 2025</option>
                            <option value="March 2025">March 2025</option>
                            <option value="May 2025">May 2025</option>
                            <option value="July 2025">July 2025</option>
                            <option value="September 2025">September 2025</option>
                            <option value="November 2025">November 2025</option>
                        </select>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="study_duration">Study Duration* | 6 & 12 sessions</label>
                            <select id="study_duration" name="study_duration" class="form-control" required>
                                <option value="">Please Select</option>
                                <option value="6 sessions">6 sessions</option>
                                <option value="12 sessions">12 sessions</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="preferred_centre">Preferred ACE Centre*</label>
                            <select id="preferred_centre" name="preferred_centre" class="form-control" required>
                                <option value="">Please Select</option>
                                <option value="Kuala Lumpur">Kuala Lumpur</option>
                                <option value="Penang">Penang</option>
                                <option value="Johor Bahru">Johor Bahru</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Additional Information Section -->
                <div class="form-section">
                    <h3 class="section-title">💬 Additional Information</h3>
                    
                    <div class="form-group">
                        <label for="message">Any questions or messages for us?</label>
                        <textarea id="message" name="message" class="form-control" rows="5"></textarea>
                    </div>
                </div>
                
                <!-- Consent & Verification Section -->
                <div class="form-section">
                    <h3 class="section-title">✅ Consent & Verification</h3>
                    
                    <div class="consent-group">
                        <label class="consent-label">
                            <input type="checkbox" name="consent_1" required>
                            <span>I certify that the information provided in this form is complete and correct.*</span>
                        </label>
                        
                        <label class="consent-label">
                            <input type="checkbox" name="consent_2" required>
                            <span>I agree to abide by the policies, terms and conditions set by ACE Language Centres in the ACE Student Code of Conduct and ACE Cancellation & Refund Policy.*</span>
                        </label>
                        
                        <label class="consent-label">
                            <input type="checkbox" name="consent_3" required>
                            <span>I agree to pay all fees due on the dates stipulated by ACE Language Centres.*</span>
                        </label>
                        
                        <label class="consent-label">
                            <input type="checkbox" name="consent_4" required>
                            <span>During ACE programmes, course components and events conducted online: I consent to the recording of my name, image, voice and any other personally identifiable information that may be shared during virtual sessions or meetings on Zoom or any other platforms (Meet, Teams, Facebook etc.)*</span>
                        </label>
                        
                        <label class="consent-label">
                            <input type="checkbox" name="consent_5" required>
                            <span>I understand and consent to the collection and processing of their Personal Data and Sensitive Personal Data as defined under the Personal Data Protection Act 2010 ("PDPA")*</span>
                        </label>
                        
                        <label class="consent-label">
                            <input type="checkbox" name="consent_6" required>
                            <span>I understand and agree to be placed on the ACE Online Certified Intensive English Programme as an alternative mode of study should ACE not offer in-person classes because of COVID-19 related constraints*</span>
                        </label>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn-submit">Send Application</button>
                </div>
                
                <div id="form-message" class="form-message"></div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    private function upload_file($field) {
        if (empty($_FILES[$field]['name'])) return '';

        require_once ABSPATH . 'wp-admin/includes/file.php';

        $upload = wp_handle_upload($_FILES[$field], ['test_form' => false]);

        return isset($upload['url']) ? esc_url_raw($upload['url']) : '';
    }

    public function handle_submission() {
        check_ajax_referer('admission_form_nonce', 'admission_nonce');

        global $wpdb;
        $table = $wpdb->prefix . 'admission_forms';

        $data = [
            'full_name'        => sanitize_text_field($_POST['full_name'] ?? ''),
            'passport_no'      => sanitize_text_field($_POST['passport_no'] ?? ''),
            'nationality'      => sanitize_text_field($_POST['nationality'] ?? ''),
            'age'              => intval($_POST['age'] ?? 0),
            'street_address'   => sanitize_textarea_field($_POST['street_address'] ?? ''),
            'city'             => sanitize_text_field($_POST['city'] ?? ''),
            'postal_code'      => sanitize_text_field($_POST['postal_code'] ?? ''),
            'state_region'     => sanitize_text_field($_POST['state_region'] ?? ''),
            'email'            => sanitize_email($_POST['email'] ?? ''),
            'phone'            => sanitize_text_field($_POST['phone'] ?? ''),
            'contact_app'      => sanitize_text_field($_POST['contact_app'] ?? ''),
            'wechat_line_id'   => sanitize_text_field($_POST['wechat_line_id'] ?? ''),
            'university_plan'  => sanitize_text_field($_POST['university_plan'] ?? ''),
            'university_name'  => sanitize_text_field($_POST['university_name'] ?? ''),
            'program'          => sanitize_text_field($_POST['program'] ?? ''),
            'session'          => sanitize_text_field($_POST['session'] ?? ''),
            'study_duration'   => sanitize_text_field($_POST['study_duration'] ?? ''),
            'preferred_centre' => sanitize_text_field($_POST['preferred_centre'] ?? ''),
            'message'          => sanitize_textarea_field($_POST['message'] ?? ''),
            'passport_copy'    => $this->upload_file('passport_copy'),
            'photo'            => $this->upload_file('photo'),
            'certificates'     => $this->upload_file('certificates'),
            'health_form'      => $this->upload_file('health_form'),
            'offer_letter'     => $this->upload_file('offer_letter'),
        ];

        $wpdb->insert($table, $data);

        wp_mail(
            'info@acelanguagecentre.edu.my',
            'New Admission Application',
            'A new admission form has been submitted.',
            ['Content-Type: text/html; charset=UTF-8']
        );

        wp_send_json_success(['message' => 'Application submitted successfully']);
    }
}

new AdmissionFormPlugin();
