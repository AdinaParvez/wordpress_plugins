<?php
/*
Plugin Name: Custom Language Form
Description: A responsive language form that sends email.
Version: 1.2
Author: Adina Pervaiz
*/



// Shortcode to display form
function cef_language_form_shortcode() {
    ob_start(); ?>
    
<style>
    .cef-form-wrapper {
        max-width: 100%; /* Full width like Elementor */
        margin: 0 auto;
        padding: 20px 0;
        background: #fff; /* White background */
        font-family: Arial, sans-serif;
    }

    .cef-form-wrapper form {
        display: grid;
        grid-template-columns: repeat(2, 1fr); /* Two columns by default */
        gap: 20px;
        align-items: start;
    }

    .cef-form-wrapper p {
        margin: 0;
    }

    .cef-form-wrapper label {
        font-weight: 600;
        font-size: 14px;
        display: block;
        margin-bottom: 6px;
        color: #333;
    }

    .cef-form-wrapper input[type="text"],
    .cef-form-wrapper input[type="number"],
    .cef-form-wrapper input[type="date"],
    .cef-form-wrapper input[type="tel"],
    .cef-form-wrapper input[type="email"],
    .cef-form-wrapper textarea,
    .cef-form-wrapper select {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        background: #fff;
        box-sizing: border-box;
    }

    /* Full-width fields */
    .cef-form-wrapper .full {
        grid-column: span 2;
        width: 100%;
    }

    /* Submit Button */
    .cef-form-wrapper input[type="submit"] {
        grid-column: span 2;
        background-color: #f9b000; /* Match ACE yellow button */
        width: 100%;
        color: #000;
        border: none;
        padding: 12px;
        cursor: pointer;
        border-radius: 4px;
        font-size: 16px;
        font-weight: bold;
        transition: background 0.3s ease;
    }

    .cef-form-wrapper input[type="submit"]:hover {
        background-color: #005177;
        color: #fff;
    }

    /* Checkbox label alignment */
    .cef-form-wrapper label input[type="checkbox"] {
        display: inline-block;
        width: auto;
        margin-right: 8px;
    }

    /* 🔹 Responsive Styles */
    @media (max-width: 768px) {
        .cef-form-wrapper form {
            grid-template-columns: 1fr; /* Single column on tablets/mobiles */
        }

        .cef-form-wrapper .full {
            grid-column: span 1; /* Reset full width inside 1-col layout */
        }

        .cef-form-wrapper input,
        .cef-form-wrapper select,
        .cef-form-wrapper textarea {
            font-size: 16px; /* Slightly bigger for touch screens */
        }

        .cef-form-wrapper input[type="submit"] {
            font-size: 18px;
            padding: 14px;
        }
    }
</style>



    <div class="cef-form-wrapper">
    <!--The code to check if emails are succeeding or failing-->
    <?php
    // Display success or error messages
    if (isset($_GET['form_status'])) {
        if ($_GET['form_status'] === 'success') {
            echo '<div class="cef-success-message">✓ Thank you! Your inquiry has been submitted successfully.</div>';
        } elseif ($_GET['form_status'] === 'error') {
            echo '<div class="cef-error-message">⚠ There was an error submitting your form. Please try again.</div>';
        } elseif ($_GET['form_status'] === 'terms_error') {
            echo '<div class="cef-error-message">⚠ You must agree to the Terms & Conditions.</div>';
        }
    }
    ?>
        <form method="post" action="">
           <?php wp_nonce_field('cef_language_form_action', 'cef_language_form_nonce'); ?>
            <p>
                <label>Parent's Name</label>
                <input type="text" placeholder="Please write your full name" name="parent_name" required>
            </p>
            <p>
                <label>Student's Name</label>
                <input type="text" placeholder="Please write your full name" name="student_name" required>
            </p>
       
            <p>
                <label>Date of Birth</label>
                <input type="date" placeholder="Please write your full name" name="dob" required>
            </p>
            <p>
                <label>Phone Number</label>
                <input type="tel" placeholder="Please write your full name" name="phone" required>
            </p>
                   <!-- FULL WIDTH -->
            <p class="full">
                <label>Email</label>
                <input type="email" name="email" required>
            </p>
            <p>
                <label>Tutoring Category</label>
                <select name="category" required>
                    <option value="">Please Choose</option>
                    <option value="Online">Online Tutoring</option>
                    <option value="Home">Home Tutoring</option>
                </select>
            </p>
            <p>
                <label>Choose Language</label>
                <select name="language" required>
                    <option value="">Please Choose</option>
                    <option value="English">English</option>
                    <option value="French">French</option>
                    <option value="German">German</option>
                    <option value="Italian">Italian</option>
                    <option value="Korean">Korean</option>
                    <option value="Chinese">Chinese</option>
                    <option value="Japanese">Japanese</option>
                </select>
            </p>
                   <!-- FULL WIDTH -->
            <p class="full">
                <label>Choose Level</label>
                <select name="level" required>
                    <option value="">Please Choose</option>
                    <option value="Beginner">Beginner</option>
                    <option value="Elementary">Elementary</option>
                    <option value="Pre-Intermediate">Pre-Intermediate</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Upper-Intermediate">Upper-Intermediate</option> 
                    <option value="Advanced">Advanced</option>
                    <option value="Proficient">Proficient</option>
                </select>
            </p>
            <p>
                <label>Session Duration</label>
                   <select name="session_duration" required>
                    <option value="">Please Choose</option>
                    <option value="1 Hour">1 Hour</option>
                    <option value="1.5 Hour">1.5 Hours</option>
                    <option value="2 Hours">2 Hours</option>
                    <option value="3 Hours">3 Hours</option>
                </select>
            </p>
            <p>
                <label>Preferred Days</label>
                <select name="preferred_days[]" multiple required>
                    <option value="">Please Choose</option>
                    <option value="Monday">Monday</option>
                    <option value="Tuesday">Tuesday</option>
                    <option value="Wednesday">Wednesday</option>
                    <option value="Thursday">Thursday</option>
                    <option value="Friday">Friday</option>
                     <option value="Saturday">Saturday</option>
                     <option value="Sunday">Sunday</option>
                </select>
            </p>
            <p>
                <label>Preferred Timing(s)</label>
                <select name="preferred_timing" required>
                    <option value="">Please Choose</option>
                    <option value="Pre12PM">Pre 12 PM</option>
                    <option value="12-5PM">12 - 5 PM</option>
                    <option value="After5PM">After 5 PM</option>
                </select>
            </p>
             <!-- FULL WIDTH -->
            <p class="full">
                <label>Message</label>
                <textarea name="message" rows="5" required></textarea>
            </p>
             <!-- FULL WIDTH -->
            <p class="full">
                <label>
                    <input type="checkbox" name="terms" value="Agreed" required>
                    Terms & Conditions - I agree to the Terms & Conditions of World Best Services Malaysia Sdn Bhd (ACE Education) </label>
            </p>
             <!-- FULL WIDTH -->
            <p class="full">
                <input type="submit" name="cef_language_submit" value="Send Enquiry">
            </p>
        </form>
        <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Auto-hide success/error messages after 5 seconds
            const successMsg = document.querySelector('.cef-success-message');
            const errorMsg = document.querySelector('.cef-error-message');
            
            if (successMsg || errorMsg) {
                setTimeout(function() {
                    // Remove message with fade effect
                    const msg = successMsg || errorMsg;
                    msg.style.transition = 'opacity 0.5s ease';
                    msg.style.opacity = '0';
                    
                    setTimeout(function() {
                        msg.remove();
                        // Clean URL by removing query parameter
                        const url = new URL(window.location);
                        url.searchParams.delete('form_status');
                        window.history.replaceState({}, document.title, url);
                    }, 500);
                }, 10000); // 10 seconds
            }
        });
        </script>
    </div>

    <?php
    return ob_get_clean();
}
add_shortcode('custom_language_form', 'cef_language_form_shortcode');


// Handle form submission early (Fixed Hook!)
add_action('init', 'cef_handle_language_form');

function cef_handle_language_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cef_language_submit']) ) {

         // Verify nonce
        if (!isset($_POST['cef_language_form_nonce']) || !wp_verify_nonce($_POST['cef_language_form_nonce'], 'cef_language_form_action')) {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
            exit;
        }

        // Terms & Conditions check
        if ( empty($_POST['terms']) ) {
            wp_redirect(add_query_arg('form_status', 'terms_error', wp_get_referer()));
            exit;
        }

        $to = ['info@aceeducation.com.my', 'acekl2018@gmail.com']; // Change this to your email
        $subject = 'New Language Learning Form Submission';

        $fields = [
                "Parent's Name" => sanitize_text_field($_POST['parent_name']),
                "Student's Name: " => sanitize_text_field($_POST['student_name']),
                "Date of Birth: " => sanitize_text_field($_POST['dob']),
                "Phone: " => sanitize_text_field($_POST['phone']),
                "Email: " => sanitize_email($_POST['email']),
                "Tutoring Category: " => sanitize_text_field($_POST['category']),
                "Language: " => sanitize_text_field($_POST['language']),
                "Level: " => sanitize_text_field($_POST['level']),
                "Session Duration: " => sanitize_text_field($_POST['session_duration']),
                "Preferred Days: " => implode(', ', array_map('sanitize_text_field', $_POST['preferred_days'])), 
                "Preferred Timing: " => sanitize_text_field($_POST['preferred_timing']),
                "Message: " => sanitize_textarea_field($_POST['message']),
                "Terms & Conditions: " => sanitize_text_field($_POST['terms']),

        ];


        // Create HTML email body
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #f9b000;">New Language Request</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%;">';
        
        foreach ($fields as $label => $value) {
            $message .= '<tr style="border-bottom: 1px solid #ddd;">';
            $message .= '<td style="padding: 10px; font-weight: bold; width: 200px;">' . $label . ':</td>';
            $message .= '<td style="padding: 10px;">' . $value . '</td>';
            $message .= '</tr>';
        }
        
        $message .= '</table>';
        $message .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
        $message .= '</body></html>';


        $headers = [
            'From: ACE Education Malaysia<info@aceeducation.com.my>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . sanitize_email($_POST['email'])
        ];

        
        // Send email
        $mail_sent = wp_mail($to, $subject, $message, $headers);

        // Redirect with success/error message
        if ($mail_sent) {
            wp_redirect(add_query_arg('form_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
        }
        exit;
    }
}
?>
