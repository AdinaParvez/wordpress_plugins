<?php
/**
 * Plugin Name: ACE Image Popup
 * Plugin URI: https://aceeducation.com.my
 * Description: Displays a single image popup after enquiry form appears. Core Web Vitals optimized.
 * Version: 1.1.0
 * Author: ACE Education
 * Author URI: https://aceeducation.com.my
 * License: GPL v2 or later
 * Text Domain: ace-image-popup
 */

if (!defined('ABSPATH')) exit;

class ACE_Image_Popup {

    private $plugin_version = '1.1.0';

    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_footer', [$this, 'popup_html']);
        add_action('admin_menu', [$this, 'add_settings_page']);
        add_action('admin_init', [$this, 'register_settings']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'add_settings_link']);
    }

    public function enqueue_assets() {
        if (is_admin()) return;

        $settings = $this->get_settings();

        wp_enqueue_style(
            'ace-image-popup-css',
            plugin_dir_url(__FILE__) . 'assets/css/ace-popup.css',
            [],
            $this->plugin_version
        );

        wp_enqueue_script(
            'ace-image-popup-js',
            plugin_dir_url(__FILE__) . 'assets/js/ace-popup.js',
            [],
            $this->plugin_version,
            true
        );

        wp_localize_script('ace-image-popup-js', 'acePopupSettings', [
            'imageUrl'    => esc_url($settings['image_url']),
            'delay'       => absint($settings['delay']),
            'cookieExpiry'=> absint($settings['cookie_expiry']),
            'enabled'     => $settings['enabled'] === 'yes'
        ]);
    }

    public function popup_html() {
        $settings = $this->get_settings();
        if ($settings['enabled'] !== 'yes') return;
        ?>
        <div class="ace-image-popup-overlay" id="aceImagePopup" role="dialog" aria-modal="true">
            <div class="ace-image-popup-container">
                <button class="ace-popup-close" id="acePopupClose" aria-label="Close popup">&times;</button>
                <img src="<?php echo esc_url($settings['image_url']); ?>" 
                     alt="<?php echo esc_attr($settings['image_alt']); ?>" 
                     class="ace-popup-image active" 
                     width="800" height="1000">
            </div>
        </div>
        <?php
    }

    private function get_settings() {
        $defaults = [
            'enabled' => 'yes',
            'image_url' => 'https://aceeducation.com.my/wp-content/uploads/2025/12/ACEEducation_DiscountOffer.webp',
            'image_alt' => 'ACE Education Discount Offer',
            'delay' => 2000,
            'cookie_expiry' => 1
        ];

        $saved_settings = get_option('ace_popup_settings', []);
        return wp_parse_args($saved_settings, $defaults);
    }

    public function add_settings_page() {
        add_options_page(
            'ACE Image Popup Settings',
            'ACE Image Popup',
            'manage_options',
            'ace-image-popup',
            [$this, 'settings_page_html']
        );
    }

    public function register_settings() {
        register_setting('ace_popup_settings_group', 'ace_popup_settings');
        add_settings_section('ace_popup_main_section', 'Popup Configuration', [$this, 'section_callback'], 'ace-image-popup');

        add_settings_field('enabled', 'Enable Popup', [$this, 'enabled_field_callback'], 'ace-image-popup', 'ace_popup_main_section');
        add_settings_field('image_url', 'Image URL', [$this, 'image_url_field_callback'], 'ace-image-popup', 'ace_popup_main_section');
        add_settings_field('image_alt', 'Image Alt Text', [$this, 'image_alt_field_callback'], 'ace-image-popup', 'ace_popup_main_section');
        add_settings_field('delay', 'Delay After Enquiry Form (ms)', [$this, 'delay_field_callback'], 'ace-image-popup', 'ace_popup_main_section');
        add_settings_field('cookie_expiry', 'Show Again After (days)', [$this, 'cookie_expiry_field_callback'], 'ace-image-popup', 'ace_popup_main_section');
    }

    public function section_callback() {
        echo '<p>Configure your image popup settings below.</p>';
    }

    public function enabled_field_callback() {
        $settings = $this->get_settings();
        ?>
        <label><input type="checkbox" name="ace_popup_settings[enabled]" value="yes" <?php checked($settings['enabled'], 'yes'); ?>> Enable image popup</label>
        <?php
    }

    public function image_url_field_callback() {
        $settings = $this->get_settings();
        ?>
        <input type="url" name="ace_popup_settings[image_url]" value="<?php echo esc_url($settings['image_url']); ?>" class="large-text">
        <p class="description">Enter the full URL of the image to display</p>
        <?php
    }

    public function image_alt_field_callback() {
        $settings = $this->get_settings();
        ?>
        <input type="text" name="ace_popup_settings[image_alt]" value="<?php echo esc_attr($settings['image_alt']); ?>" class="regular-text">
        <p class="description">Alt text for accessibility</p>
        <?php
    }

    public function delay_field_callback() {
        $settings = $this->get_settings();
        ?>
        <input type="number" name="ace_popup_settings[delay]" value="<?php echo absint($settings['delay']); ?>" min="0" step="100">
        <?php
    }

    public function cookie_expiry_field_callback() {
        $settings = $this->get_settings();
        ?>
        <input type="number" name="ace_popup_settings[cookie_expiry]" value="<?php echo absint($settings['cookie_expiry']); ?>" min="0" max="365">
        <?php
    }

    public function settings_page_html() {
        if (!current_user_can('manage_options')) return;
        if (isset($_GET['settings-updated'])) add_settings_error('ace_popup_messages', 'ace_popup_message', 'Settings Saved', 'updated');
        settings_errors('ace_popup_messages');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('ace_popup_settings_group');
                do_settings_sections('ace-image-popup');
                submit_button('Save Settings');
                ?>
            </form>
        </div>
        <?php
    }

    public function add_settings_link($links) {
        $settings_link = '<a href="options-general.php?page=ace-image-popup">Settings</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}

// Initialize
new ACE_Image_Popup();

register_activation_hook(__FILE__, function() {
    $defaults = [
        'enabled' => 'yes',
        'image_url' => 'https://aceeducation.com.my/wp-content/uploads/2025/12/ACEEducation_DiscountOffer.webp',
        'image_alt' => 'ACE Education Discount Offer',
        'delay' => 2000,
        'cookie_expiry' => 1
    ];
    add_option('ace_popup_settings', $defaults);
});
register_deactivation_hook(__FILE__, function() {});