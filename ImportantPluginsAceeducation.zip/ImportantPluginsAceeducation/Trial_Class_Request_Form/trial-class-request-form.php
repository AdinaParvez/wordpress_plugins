<?php
/**
 * Plugin Name: Trial Class Request Form
 * Description: Shortcode to embed a trial class request form, save to database, and send email using wp_mail (uses WP Mail SMTP).
 * Version: 1.3
 * Author: Adina Pervaiz
 */

// Create database table on plugin activation
register_activation_hook(__FILE__, 'create_trial_class_table');

function create_trial_class_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'trial_class_requests';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        first_name varchar(100) NOT NULL,
        last_name varchar(100) NOT NULL,
        email varchar(255) NOT NULL,
        phone varchar(50) NOT NULL,
        curriculum varchar(100) NOT NULL,
        submission_date datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Register shortcode
add_shortcode('trial_class_form', 'render_trial_class_form');

// Inline Styles (for the form only, not the banner)
function trial_class_form_styles() {
    ?>
    <style>
    .trial-form-box {
        background: white;
        padding: 30px;
        border-radius: 12px;
        color: black;
        box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        max-width: 450px;
        margin: 0 auto;
    }
    .trial-form-box input,
    .trial-form-box select {
        width: 100%;
        padding: 12px;
        border-radius: 6px;
        border: 1px solid #ccc;
        margin-bottom: 15px;
        font-size: 1rem;
    }
    .trial-form-box button {
        width: 100%;
        background: #007070;
        color: white;
        padding: 12px;
        border: none;
        border-radius: 6px;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
    }
    </style>
    <?php
}
add_action('wp_head', 'trial_class_form_styles');

// Form + Email logic + Database Save
function render_trial_class_form() {
    ob_start();

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['trial_class_submit'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'trial_class_requests';
        
        $first = sanitize_text_field($_POST['first_name']);
        $last = sanitize_text_field($_POST['last_name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $curriculum = sanitize_text_field($_POST['curriculum']);

        // Save to database
        $data = array(
            'first_name' => $first,
            'last_name' => $last,
            'email' => $email,
            'phone' => $phone,
            'curriculum' => $curriculum
        );
        
        $db_result = $wpdb->insert($table_name, $data);

        // Email to admin with CC
        $admin_to = 'info@aceeducation.bh';
        $admin_subject = "New Trial Class Request";
        $admin_message = "
            <strong>New Trial Class Request</strong><br><br>
            <strong>Name:</strong> $first $last<br>
            <strong>Email:</strong> $email<br>
            <strong>Phone:</strong> $phone<br>
            <strong>Curriculum:</strong> $curriculum<br>
        ";
        $headers_admin = [
            'Content-Type: text/html; charset=UTF-8',
            'From: AceEducation Bahrain <info@aceeducation.bh>',
            'Cc: acekl2018@gmail.com',
            "Reply-To: $email"
        ];

        // Confirmation to user
        $user_subject = "Your Trial Class Request Received!";
        $user_message = "
            <p>Dear $first,</p>
            <p>Thank you for requesting a trial class with us at Ace Education Bahrain. We will contact you shortly.</p>
            <p><strong>Submitted Details:</strong></p>
            <ul>
                <li><strong>Name:</strong> $first $last</li>
                <li><strong>Email:</strong> $email</li>
                <li><strong>Phone:</strong> $phone</li>
                <li><strong>Curriculum:</strong> $curriculum</li>
            </ul>
            <p>Warm regards,<br>AceEducation Bahrain Team</p>
        ";
        $headers_user = [
            'Content-Type: text/html; charset=UTF-8',
            'From: AceEducation Bahrain <no-reply@aceeducation.bh>'
        ];

        $admin_sent = wp_mail($admin_to, $admin_subject, $admin_message, $headers_admin);
        $user_sent = wp_mail($email, $user_subject, $user_message, $headers_user);

        if ($db_result && $admin_sent && $user_sent) {
            echo '<div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 20px;">✅ Your request has been sent successfully and saved to our records.</div>';
        } elseif ($db_result) {
            echo '<div style="background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin-bottom: 20px;">⚠️ Your request was saved, but email notification failed.</div>';
        } else {
            echo '<div style="background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin-bottom: 20px;">❌ Submission failed. Please try again later.</div>';
        }
    }
    ?>

    <div class="trial-form-box">
        <h3 style="text-align:center; color: #007070;">Request a Trial Class</h3>
        <form method="POST">
            <input type="text" name="first_name" placeholder="Enter First Name" required>
            <input type="text" name="last_name" placeholder="Enter Last Name" required>
            <input type="email" name="email" placeholder="Email ID" required>
            <input type="tel" name="phone" placeholder="Mobile No." required>
            <select name="curriculum" required>
                <option value="">- Select Your Curriculum -</option>
                <option value="IB">IB</option>
                <option value="IGCSE">IGCSE</option>
                <option value="AS/A Level">AS/A Level</option>
                <option value="CBSE">CBSE</option>
            </select>
            <button type="submit" name="trial_class_submit">Submit</button>
        </form>
    </div>

    <?php
    return ob_get_clean();
}

// Override default "From" email and name for wp_mail globally
add_filter('wp_mail_from', 'ace_custom_wp_mail_from');
add_filter('wp_mail_from_name', 'ace_custom_wp_mail_from_name');

function ace_custom_wp_mail_from($original_email_address) {
    return 'no-reply@aceeducation.bh'; // Make sure DNS settings are correct
}

function ace_custom_wp_mail_from_name($original_email_from) {
    return 'AceEducation Bahrain';
}