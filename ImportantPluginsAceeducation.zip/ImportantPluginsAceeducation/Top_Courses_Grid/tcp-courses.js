jQuery(function ($) {

    function tcpFilterInit() {
        $('.tcp-filter').on('click', function () {
            $('.tcp-filter').removeClass('active');
            $(this).addClass('active');

            let filter = $(this).data('filter');

            $('.tcp-item').each(function () {
                let cats = $(this).data('cat');
                if (filter === 'all' || cats.includes(filter)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
    }

    tcpFilterInit();

    // Elementor live preview support
    if (window.elementorFrontend) {
        elementorFrontend.hooks.addAction(
            'frontend/element_ready/global',
            tcpFilterInit
        );
    }
});
