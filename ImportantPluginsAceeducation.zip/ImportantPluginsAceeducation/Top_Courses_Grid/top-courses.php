<?php
/**
 * Plugin Name: Top Courses Grid (Elementor Compatible)
 * Description: Manage and display courses in a responsive grid with Elementor support.
 * Version: 1.1.0
 * Author: Adina Pervaiz
 */

if (!defined('ABSPATH')) exit;

/*---------------------------------------------------
 REGISTER COURSE POST TYPE
---------------------------------------------------*/
add_action('init', function () {
    register_post_type('tcp_course', [
        'labels' => [
            'name' => 'Courses',
            'singular_name' => 'Course',
        ],
        'public' => true,
        'menu_icon' => 'dashicons-welcome-learn-more',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes'],
        'rewrite' => ['slug' => 'courses', 'with_front' => false],
        'has_archive' => true,
    ]);
});

/*---------------------------------------------------
 COURSE CATEGORIES
---------------------------------------------------*/
add_action('init', function () {
    register_taxonomy('tcp_course_category', 'tcp_course', [
        'label' => 'Course Categories',
        'hierarchical' => true,
        'show_admin_column' => true,
        'rewrite' => ['slug' => 'course-category'],
    ]);
});

/*---------------------------------------------------
 ADMIN MEDIA SUPPORT
---------------------------------------------------*/
add_action('admin_enqueue_scripts', function () {
    wp_enqueue_media();
});

/*---------------------------------------------------
 META BOX
---------------------------------------------------*/
add_action('add_meta_boxes', function () {
    add_meta_box(
        'tcp_course_details',
        'Course Details',
        'tcp_course_meta_callback',
        'tcp_course',
        'normal',
        'high'
    );
});

function tcp_course_meta_callback($post) {
    $price = get_post_meta($post->ID, 'tcp_price', true);
    $logo  = get_post_meta($post->ID, 'tcp_logo', true);
    ?>
    <p>
        <label><strong>Price</strong></label>
        <input type="text" name="tcp_price" value="<?php echo esc_attr($price); ?>" style="width:100%;">
    </p>

    <p>
        <label><strong>Certified Company Logo</strong></label><br>
        <input type="hidden" id="tcp_logo" name="tcp_logo" value="<?php echo esc_url($logo); ?>">
        <img id="tcp_logo_preview" src="<?php echo esc_url($logo); ?>" style="max-width:80px;margin-bottom:10px;">
        <button type="button" class="button tcp-upload-logo">Upload Logo</button>
    </p>

    <script>
    jQuery(function($){
        let frame;
        $('.tcp-upload-logo').on('click', function(e){
            e.preventDefault();
            if(frame){ frame.open(); return; }
            frame = wp.media({ title:'Select Logo', button:{text:'Use this'}, multiple:false });
            frame.on('select', function(){
                let img = frame.state().get('selection').first().toJSON();
                $('#tcp_logo').val(img.url);
                $('#tcp_logo_preview').attr('src', img.url);
            });
            frame.open();
        });
    });
    </script>
<?php }

/*---------------------------------------------------
 SAVE META
---------------------------------------------------*/
add_action('save_post_tcp_course', function ($post_id) {
    if (isset($_POST['tcp_price'])) {
        update_post_meta($post_id, 'tcp_price', sanitize_text_field($_POST['tcp_price']));
    }
    if (isset($_POST['tcp_logo'])) {
        update_post_meta($post_id, 'tcp_logo', esc_url_raw($_POST['tcp_logo']));
    }
});

/*---------------------------------------------------
 FRONTEND SCRIPTS (ELEMENTOR SAFE)
---------------------------------------------------*/
add_action('wp_enqueue_scripts', function () {

    wp_register_script(
        'tcp-courses',
        plugin_dir_url(__FILE__) . 'tcp-courses.js',
        ['jquery'],
        '1.1',
        true
    );

    wp_enqueue_script('tcp-courses');
});

/*---------------------------------------------------
 SHORTCODE
---------------------------------------------------*/
function tcp_courses_shortcode() {

    $categories = get_terms(['taxonomy' => 'tcp_course_category', 'hide_empty' => true]);

    $query = new WP_Query([
        'post_type' => 'tcp_course',
        'posts_per_page' => -1,
        'orderby' => 'menu_order',
        'order' => 'ASC',
    ]);

    ob_start(); ?>

<section class="tcp-courses-section">
<div class="container">

<h2 class="mb-4">Top Courses</h2>

<div class="tcp-filters mb-4">
    <button class="tcp-filter active" data-filter="all">All</button>
    <?php foreach ($categories as $cat): ?>
        <button class="tcp-filter" data-filter="<?php echo esc_attr($cat->slug); ?>">
            <?php echo esc_html($cat->name); ?>
        </button>
    <?php endforeach; ?>
</div>

<div class="row tcp-grid">

<?php while ($query->have_posts()) : $query->the_post();
    $price = get_post_meta(get_the_ID(), 'tcp_price', true);
    $logo  = get_post_meta(get_the_ID(), 'tcp_logo', true);
    $terms = wp_get_post_terms(get_the_ID(), 'tcp_course_category');
    $slugs = wp_list_pluck($terms, 'slug');
?>

<div class="col-md-3 col-sm-6 tcp-item" data-cat="<?php echo esc_attr(implode(' ', $slugs)); ?>">
<a href="<?php the_permalink(); ?>" class="tcp-card">

<?php the_post_thumbnail('medium_large'); ?>

<?php if ($logo): ?>
<img class="tcp-logo" src="<?php echo esc_url($logo); ?>">
<?php endif; ?>

<h5><?php the_title(); ?></h5>
<p><?php echo wp_trim_words(get_the_content(), 12); ?></p>

<?php if ($price): ?>
<span class="tcp-price"><?php echo esc_html($price); ?></span>
<?php endif; ?>

</a>
</div>

<?php endwhile; wp_reset_postdata(); ?>

</div>
</div>
</section>

<?php
return ob_get_clean();
}
add_shortcode('top_courses', 'tcp_courses_shortcode');

/*---------------------------------------------------
 ELEMENTOR WIDGET
---------------------------------------------------*/
add_action('elementor/widgets/register', function ($widgets_manager) {

    class TCP_Elementor_Widget extends \Elementor\Widget_Base {

        public function get_name() { return 'tcp_courses'; }
        public function get_title() { return 'Top Courses Grid'; }
        public function get_icon() { return 'eicon-posts-grid'; }
        public function get_categories() { return ['general']; }

        protected function render() {
            echo do_shortcode('[top_courses]');
        }
    }

    $widgets_manager->register(new TCP_Elementor_Widget());
});
