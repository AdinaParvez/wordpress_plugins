<?php
/**
 * ACE Education - Complete Performance Fix
 * Target: LCP from 4.1s to under 2.5s
 * Add this to functions.php or create a plugin
 */

// ============================================
// 1. DEFER RENDER-BLOCKING CSS (940ms savings)
// ============================================
add_filter('style_loader_tag', function($html, $handle, $href) {
    // Critical styles that MUST load immediately (only hero section)
    $critical_handles = ['wp-block-library-inline'];
    
    if (in_array($handle, $critical_handles)) {
        return $html;
    }
    
    // Defer ALL other CSS
    $html = str_replace("rel='stylesheet'", "rel='preload' as='style' onload=\"this.onload=null;this.rel='stylesheet'\"", $html);
    
    // Noscript fallback
    $noscript = str_replace(
        "rel='preload' as='style' onload=\"this.onload=null;this.rel='stylesheet'\"",
        "rel='stylesheet'",
        $html
    );
    
    return $html . "\n<noscript>" . $noscript . "</noscript>";
}, 10, 3);

// ============================================
// 2. INLINE CRITICAL CSS IN HEAD
// ============================================
add_action('wp_head', function() {
    ?>
    <style id="critical-css">
        /* Critical Above-the-Fold CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Poppins', sans-serif;
            line-height: 1.6;
            color: #333;
        }
        
        /* Hero Section - Critical for LCP */
        .hero-section,
        .elementor-section-boxed,
        .slider-area {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .hero-content,
        .slide-content {
            position: relative;
            z-index: 2;
            text-align: center;
            color: #fff;
            max-width: 800px;
            padding: 2rem;
        }
        
        h1, .hero-title {
            font-size: clamp(2rem, 5vw, 3.5rem);
            font-weight: 700;
            margin-bottom: 1rem;
            line-height: 1.2;
        }
        
        /* LCP Image Optimization */
        .hero-image,
        .slide-image,
        .background-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: 0;
        }
        
        /* Header - if visible above fold */
        .site-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
        }
        
        /* Hide non-critical elements initially */
        .lazy-load,
        .below-fold {
            content-visibility: auto;
        }
    </style>
    <?php
}, 1);

// ============================================
// 3. DEFER JQUERY & ALL JAVASCRIPT (1,250ms savings)
// ============================================
add_filter('script_loader_tag', function($tag, $handle, $src) {
    // Scripts that should NOT be deferred (usually none needed)
    $critical_scripts = [];
    
    if (in_array($handle, $critical_scripts)) {
        return $tag;
    }
    
    // Defer all scripts
    if (!strpos($tag, 'defer') && !strpos($tag, 'async')) {
        return str_replace(' src', ' defer src', $tag);
    }
    
    return $tag;
}, 10, 3);

// Move jQuery to footer
add_action('wp_enqueue_scripts', function() {
    if (!is_admin()) {
        wp_scripts()->add_data('jquery', 'group', 1);
        wp_scripts()->add_data('jquery-core', 'group', 1);
        wp_scripts()->add_data('jquery-migrate', 'group', 1);
    }
});

// ============================================
// 4. AGGRESSIVE BROWSER CACHING (1 year)
// ============================================
add_action('wp_headers', function($headers) {
    // Cache static assets for 1 year
    if (is_singular() || is_front_page()) {
        $headers['Cache-Control'] = 'public, max-age=31536000, immutable';
    }
    return $headers;
});

// Add to .htaccess (or use this code to generate it)
add_action('init', function() {
    $htaccess_rules = '
# Browser Caching - 1 Year
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/webp "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
    ExpiresByType font/woff2 "access plus 1 year"
    ExpiresByType font/woff "access plus 1 year"
</IfModule>

<IfModule mod_headers.c>
    <FilesMatch "\.(js|css|jpg|jpeg|png|gif|webp|svg|woff|woff2)$">
        Header set Cache-Control "public, max-age=31536000, immutable"
    </FilesMatch>
</IfModule>
';
    // Note: Manually add these rules to your .htaccess file
});

// ============================================
// 5. PRELOAD LCP IMAGE
// ============================================
add_action('wp_head', function() {
    // Replace with your actual LCP image URL from thepixelcurve.com
    $lcp_image = 'https://thepixelcurve.com/01/EDUBIN0054.png';
    
    echo '<link rel="preload" as="image" href="' . esc_url($lcp_image) . '" fetchpriority="high">' . "\n";
}, 2);

// ============================================
// 6. OPTIMIZE FONT LOADING
// ============================================
add_action('wp_head', function() {
    ?>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preload" href="https://fonts.gstatic.com/s/poppins/v20/pxiEyp8kv8JHgFVrJJfecg.woff2" as="font" type="font/woff2" crossorigin>
    
    <style>
        /* Inline font-face with font-display: swap */
        @font-face {
            font-family: 'Poppins';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/poppins/v20/pxiEyp8kv8JHgFVrJJfecg.woff2) format('woff2');
        }
        @font-face {
            font-family: 'Poppins';
            font-style: normal;
            font-weight: 700;
            font-display: swap;
            src: url(https://fonts.gstatic.com/s/poppins/v20/pxiByp8kv8JHgFVrLCz7Z1xlFQ.woff2) format('woff2');
        }
    </style>
    <?php
}, 3);

// ============================================
// 7. REDUCE RESOURCE LOAD DELAY
// ============================================
// Disable WordPress emojis
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('admin_print_scripts', 'print_emoji_detection_script');
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('admin_print_styles', 'print_emoji_styles');

// Remove query strings from static resources
add_filter('script_loader_src', 'remove_query_strings', 15, 1);
add_filter('style_loader_src', 'remove_query_strings', 15, 1);
function remove_query_strings($src) {
    if (strpos($src, 'ver=')) {
        $src = remove_query_arg('ver', $src);
    }
    return $src;
}

// Disable RSS feeds (if not needed)
add_action('do_feed', function() { wp_redirect(home_url()); exit; }, 1);
add_action('do_feed_rdf', function() { wp_redirect(home_url()); exit; }, 1);
add_action('do_feed_rss', function() { wp_redirect(home_url()); exit; }, 1);
add_action('do_feed_rss2', function() { wp_redirect(home_url()); exit; }, 1);
add_action('do_feed_atom', function() { wp_redirect(home_url()); exit; }, 1);

// ============================================
// 8. FIX FORCED REFLOWS
// ============================================
add_action('wp_footer', function() {
    ?>
    <script>
    // Optimize JavaScript to prevent forced reflows
    (function() {
        // Batch DOM reads and writes
        const observer = new IntersectionObserver((entries) => {
            requestAnimationFrame(() => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                    }
                });
            });
        }, { rootMargin: '50px' });
        
        // Use content-visibility for off-screen content
        document.querySelectorAll('.lazy-section').forEach(el => {
            el.style.contentVisibility = 'auto';
        });
        
        // Debounce resize events
        let resizeTimer;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(() => {
                // Handle resize
            }, 250);
        });
    })();
    </script>
    <?php
}, 999);

// ============================================
// 9. LAZY LOAD FACEBOOK SDK
// ============================================
add_action('wp_footer', function() {
    ?>
    <script>
    // Lazy load Facebook SDK
    (function() {
        let fbLoaded = false;
        
        function loadFacebookSDK() {
            if (fbLoaded) return;
            fbLoaded = true;
            
            const script = document.createElement('script');
            script.src = 'https://connect.facebook.net/en_US/sdk.js';
            script.async = true;
            script.defer = true;
            document.body.appendChild(script);
        }
        
        // Load on scroll or after 5 seconds
        window.addEventListener('scroll', loadFacebookSDK, { once: true, passive: true });
        setTimeout(loadFacebookSDK, 5000);
    })();
    </script>
    <?php
}, 1000);

// ============================================
// 10. PRECONNECT TO CRITICAL DOMAINS
// ============================================
add_action('wp_head', function() {
    // Remove default WordPress resource hints
    remove_action('wp_head', 'wp_resource_hints', 2);
    
    // Add only critical preconnects
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
    echo '<link rel="preconnect" href="https://thepixelcurve.com">' . "\n";
    echo '<link rel="dns-prefetch" href="//cdnjs.cloudflare.com">' . "\n";
}, 1);

// ============================================
// 11. OPTIMIZE IMAGES ON-THE-FLY
// ============================================
add_filter('wp_get_attachment_image_attributes', function($attr, $attachment) {
    // Add fetchpriority to first image (LCP)
    static $first_image = true;
    
    if ($first_image) {
        $attr['fetchpriority'] = 'high';
        $attr['loading'] = 'eager'; // Don't lazy load LCP image
        $first_image = false;
    } else {
        $attr['loading'] = 'lazy';
    }
    
    return $attr;
}, 10, 2);

// ============================================
// 12. REDUCE INITIAL PAYLOAD
// ============================================
// Remove unnecessary WordPress features
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'rest_output_link_wp_head');
remove_action('wp_head', 'wp_oembed_add_discovery_links');

// ============================================
// 13. PERFORMANCE MONITORING (Admin Only)
// ============================================
add_action('wp_footer', function() {
    if (!current_user_can('administrator')) return;
    ?>
    <script>
    // Monitor Core Web Vitals
    new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
            console.log('LCP:', entry.renderTime || entry.loadTime, 'ms');
            console.log('LCP Element:', entry.element);
        }
    }).observe({ type: 'largest-contentful-paint', buffered: true });
    
    new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
            console.log('CLS:', entry.value);
        }
    }).observe({ type: 'layout-shift', buffered: true });
    </script>
    <?php
}, 9999);