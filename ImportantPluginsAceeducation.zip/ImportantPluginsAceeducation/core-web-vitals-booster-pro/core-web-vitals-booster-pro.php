<?php
/*
Plugin Name: Core Web Vitals Booster Pro
Description: Boosts LCP, FCP & CLS by deferring JS, optimizing fonts, adding image dimensions, lazy loading, and preloading critical assets.
Version: 2.0
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

// ===================================
// ✅ 1. Defer Non-Critical JS
// ===================================
add_filter('script_loader_tag', function($tag, $handle, $src) {
    if (is_admin()) return $tag;
    // Keep jQuery in head but defer others
    if (strpos($src, 'jquery.min.js') !== false) {
        return str_replace(' src', ' defer src', $tag);
    }
    return str_replace(' src', ' defer src', $tag);
}, 10, 3);

// ===================================
// ✅ 2. Async CSS + Preload Key Styles
// ===================================
add_filter('style_loader_tag', function($html, $handle, $href, $media) {
    if (is_admin()) return $html;
    if (strpos($handle, 'font') !== false || strpos($handle, 'googleapis') !== false) {
        return "<link rel='preload' as='style' href='$href' onload=\"this.onload=null;this.rel='stylesheet'\">";
    }
    return str_replace("rel='stylesheet'", "rel='stylesheet' media='print' onload=\"this.media='all'\"", $html);
}, 10, 4);


// ===================================
// ✅ 3. Preload Critical Logo + Hero (LCP) Image
// ===================================
add_action('wp_head', function() {
    // --- Preload Site Logo ---
    $logo = get_theme_mod('custom_logo');
    if ($logo) {
        $logo_url = wp_get_attachment_image_src($logo, 'full')[0];
        echo "<link rel='preload' as='image' href='$logo_url' fetchpriority='high'>";
    }

    // --- Detect and Preload Hero Background Image ---
    if (is_front_page() || is_home()) {
        // Example: Your main hero/slider image
        $hero_image = 'https://aceeducation.com.my/wp-content/uploads/2025/01/your-hero-banner.jpg';

        echo "<link rel='preload' as='image' href='$hero_image' fetchpriority='high'>";
        echo "<meta name='theme-color' content='#ffffff'>"; // Slight browser hint for better painting
    }
});


// ===================================
// ✅ 4. Add Width & Height to Unsized Images (JS fix)
// ===================================
add_action('wp_footer', function() { ?>
<script>
document.querySelectorAll('img:not([width]):not([height])').forEach(img => {
    if (img.naturalWidth && img.naturalHeight) {
        img.setAttribute('width', img.naturalWidth);
        img.setAttribute('height', img.naturalHeight);
    }
});
</script>
<?php });

// ===================================
// ✅ 5. Lazy Load All Images by Default
// ===================================
add_filter('wp_lazy_loading_enabled', '__return_true');

// ===================================
// ✅ 6. Font Optimization (Swap Display)
// ===================================
add_filter('style_loader_tag', function($html) {
    return str_replace('rel=\'stylesheet\'', 'rel=\'stylesheet\' crossorigin="anonymous"', $html);
}, 15);

// ===================================
// ✅ 7. Browser Caching
// ===================================
add_action('send_headers', function() {
    header('Cache-Control: public, max-age=31536000, immutable');
});

// ===================================
// ✅ 8. Delay Non-Essential Third-Party Scripts
// ===================================
add_action('wp_footer', function() { ?>
<script>
setTimeout(() => {
    const fb = document.createElement('script');
    fb.src = "https://connect.facebook.net/en_US/fbevents.js";
    document.body.appendChild(fb);
}, 5000);
</script>
<?php });

// ===================================
// ✅ 9. Admin Notice
// ===================================
add_action('admin_notices', function() {
    echo '<div class="notice notice-success is-dismissible"><p><strong>Core Web Vitals Booster Pro Active:</strong> Improved JS, font, and image optimization applied!</p></div>';
});
