<?php
/*
Plugin Name: LCP Hero FetchPriority
Description: Adds hidden hero images with fetchpriority="high" to improve LCP.
Version: 1.1
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit; // Exit if accessed directly

// Hook into wp_footer to output hidden images for hero slides
add_action('wp_footer', function() {
    ?>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        // Select all slides inside the main slider
        const slides = document.querySelectorAll('.edubin-slider .slide');
        slides.forEach(slide => {
            const bg = slide.style.backgroundImage; // get inline background-image
            if(bg && bg.includes('url(')) {
                const url = bg.match(/url\(["']?(.*?)["']?\)/)[1];
                if(url) {
                    const img = document.createElement('img');
                    img.src = url;
                    // Use slide title or fallback
                    const titleElem = slide.querySelector('.slider-title');
                    img.alt = titleElem ? titleElem.innerText.trim().substring(0, 100) : "Hero Image";
                    img.style.display = 'none';
                    img.fetchPriority = 'high';
                    document.body.appendChild(img);
                }
            }
        });
    });
    </script>
    <?php
});
