<?php
/*
Plugin Name: Auto WebP Converter
Description: Automatically converts uploaded JPG/PNG images to WebP and serves WebP to supported browsers. Includes batch conversion of existing uploads. Reverts on deactivation.
Version: 1.2
Author: Adina Pervaiz
*/

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

// ================= Convert image to WebP on upload =================
add_filter('wp_handle_upload', function($upload) {
    $file = $upload['file'];
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

    if (!in_array($ext, ['jpg','jpeg','png'])) return $upload;

    $webp_file = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', $file);

    switch($ext) {
        case 'jpg':
        case 'jpeg':
            $img = imagecreatefromjpeg($file);
            break;
        case 'png':
            $img = imagecreatefrompng($file);
            imagepalettetotruecolor($img);
            imagealphablending($img, true);
            imagesavealpha($img, true);
            break;
    }

    if ($img) {
        imagewebp($img, $webp_file, 80); // Quality 80
        imagedestroy($img);
    }

    return $upload;
});

// ================= Serve WebP in frontend if supported =================
function awc_filter_image_src($image, $attachment_id, $size, $icon) {
    if (!is_plugin_active('auto-webp-converter/auto-webp-converter.php')) return $image;

    $original_file = get_attached_file($attachment_id);
    $webp_file = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', $original_file);
    
    if (file_exists($webp_file)) {
        $mime_type = $_SERVER['HTTP_ACCEPT'] ?? '';
        if (strpos($mime_type, 'image/webp') !== false) {
            $url = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', wp_get_attachment_url($attachment_id));
            $image[0] = $url;

            $img_data = @getimagesize($webp_file);
            if ($img_data) {
                $image[1] = $img_data[0];
                $image[2] = $img_data[1];
            }
        }
    }
    return $image;
}
add_filter('wp_get_attachment_image_src', 'awc_filter_image_src', 10, 4);

// ================= Admin notice =================
add_action('admin_notices', function() {
    echo '<div class="notice notice-info is-dismissible">
        <p>Auto WebP Converter is active. All new uploads are converted to WebP. You can also batch convert existing images below.</p>
    </div>';
});

// ================= Deactivation hook =================
register_deactivation_hook(__FILE__, function() {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-success is-dismissible">
            <p>Auto WebP Converter deactivated. All images now revert to original JPG/PNG automatically.</p>
        </div>';
    });
});

// ================= Admin Page for Batch Conversion =================
add_action('admin_menu', function() {
    add_submenu_page(
        'tools.php',
        'WebP Batch Converter',
        'WebP Batch Converter',
        'manage_options',
        'webp-batch-converter',
        'awc_batch_converter_page'
    );
});

function awc_batch_converter_page() {
    if (!current_user_can('manage_options')) return;

    echo '<div class="wrap"><h1>WebP Batch Converter</h1>';

    $upload_dir = wp_get_upload_dir();
    $base_dir = $upload_dir['basedir'];
    $batch_size = 50; // Number of images per batch

    // Get all images
    $all_images = awc_scan_folder($base_dir);
    $total_images = count($all_images);

    if ($total_images === 0) {
        echo '<p>No JPG/PNG images found in uploads folder.</p></div>';
        return;
    }

    // Determine batch number
    if (isset($_GET['batch']) && is_numeric($_GET['batch'])) {
        $batch_num = intval($_GET['batch']);
    } else {
        $batch_num = 1;
    }

    $start_index = ($batch_num - 1) * $batch_size;
    $end_index = min($start_index + $batch_size, $total_images);

    // Calculate progress
    $progress = round(($end_index / $total_images) * 100);

    // Show progress bar
    echo '<div style="border:1px solid #ccc; width:100%; height:25px; margin-bottom:10px;">
            <div style="background:#0073aa; width:' . $progress . '%; height:100%; color:#fff; text-align:center; line-height:25px;">' . $progress . '%</div>
          </div>';

    echo '<p>Processing batch ' . $batch_num . ': images ' . ($start_index + 1) . ' to ' . $end_index . ' of ' . $total_images . '</p><pre>';

    $batch_images = array_slice($all_images, $start_index, $batch_size);
    foreach ($batch_images as $file) {
        $webp_file = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', $file);
        if (file_exists($webp_file)) {
            echo "Skipped (exists): $webp_file\n";
            continue;
        }

        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        switch($ext) {
            case 'jpg':
            case 'jpeg':
                $img = imagecreatefromjpeg($file);
                break;
            case 'png':
                $img = imagecreatefrompng($file);
                imagepalettetotruecolor($img);
                imagealphablending($img, true);
                imagesavealpha($img, true);
                break;
            default:
                continue 2;
        }

        if ($img) {
            imagewebp($img, $webp_file, 80);
            imagedestroy($img);
            echo "Converted: $file → $webp_file\n";
        }
    }

    echo '</pre>';

    // Auto-redirect to next batch
    if ($end_index < $total_images) {
        $next_batch = $batch_num + 1;
        echo '<p>Processing next batch automatically...</p>';
        echo '<script>setTimeout(function(){ window.location.href="' . admin_url('tools.php?page=webp-batch-converter&batch=' . $next_batch) . '"; }, 1000);</script>';
    } else {
        echo '<p>✅ All images processed!</p>';
    }

    echo '</div>';
}



// ================= Batch Conversion Function =================
function awc_batch_convert_images() {
    $upload_dir = wp_get_upload_dir();
    $base_dir = $upload_dir['basedir'];

    $files = awc_scan_folder($base_dir);
    if (empty($files)) return "No JPG/PNG images found.";

    $output = "";
    foreach ($files as $file) {
        $webp_file = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', $file);
        if (file_exists($webp_file)) {
            $output .= "Skipped (exists): $webp_file\n";
            continue;
        }

        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        switch($ext) {
            case 'jpg':
            case 'jpeg':
                $img = imagecreatefromjpeg($file);
                break;
            case 'png':
                $img = imagecreatefrompng($file);
                imagepalettetotruecolor($img);
                imagealphablending($img, true);
                imagesavealpha($img, true);
                break;
            default:
                continue 2;
        }

        if ($img) {
            imagewebp($img, $webp_file, 80);
            imagedestroy($img);
            $output .= "Converted: $file → $webp_file\n";
        }
    }
    return $output;
}

// ================= Recursive Scan Function =================
function awc_scan_folder($dir) {
    $files = [];
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        $path = $dir . '/' . $item;
        if (is_dir($path)) {
            $files = array_merge($files, awc_scan_folder($path));
        } elseif (is_file($path)) {
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg','jpeg','png'])) $files[] = $path;
        }
    }
    return $files;
}
