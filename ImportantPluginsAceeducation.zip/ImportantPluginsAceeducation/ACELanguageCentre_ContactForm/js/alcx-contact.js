jQuery(document).ready(function($) {
    $('#alcx-contact-form').on('submit', function(e) {
        e.preventDefault();

        const $btn = $(this).find('button[type="submit"]');
        $btn.prop('disabled', true).text('Sending...');

        const formData = $(this).serialize();

        $.ajax({
            type: 'POST',
            url: alcx_ajax_object.ajax_url,
            data: formData,
            dataType: 'json',
            success: function(response) {
                let modalTitle = '';
                let modalBody = '';

                if (response.success) {
                    modalTitle = 'Message Sent';
                    modalBody = response.data.message;
                    $('#alcx-contact-form')[0].reset();
                } else {
                    modalTitle = 'Error';
                    modalBody = response.data.message || 'An unexpected error occurred. Please try again.';
                }

                $('#alcxContactModal .modal-title').text(modalTitle);
                $('#alcxContactModal .modal-body').html('<p>' + modalBody + '</p>');
                const modal = new bootstrap.Modal(document.getElementById('alcxContactModal'));
                modal.show();

                $btn.prop('disabled', false).text('Send Message');
            },
            error: function(xhr, status, error) {
                $('#alcxContactModal .modal-title').text('Error');
                $('#alcxContactModal .modal-body').html('<p>An unexpected error occurred: ' + error + '</p>');
                const modal = new bootstrap.Modal(document.getElementById('alcxContactModal'));
                modal.show();
                $btn.prop('disabled', false).text('Send Message');
            }
        });
    });
});
