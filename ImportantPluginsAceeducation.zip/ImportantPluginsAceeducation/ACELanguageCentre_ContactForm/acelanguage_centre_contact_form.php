<?php
/*
Plugin Name: ACE Language Centre Contact Form
Description: Responsive AJAX contact form with email tracking, database storage, and admin view.
Version: 2.1
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

// ------------------------------
// 1. CREATE DATABASE TABLE
// ------------------------------
register_activation_hook(__FILE__, 'alcx_create_table');
function alcx_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'alcx_contact_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        subject varchar(255) NOT NULL,
        message text NOT NULL,
        email_sent tinyint(1) DEFAULT 0,
        submitted_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// ------------------------------
// 2. ENQUEUE SCRIPTS & STYLES
// ------------------------------
add_action('wp_enqueue_scripts', 'alcx_enqueue_scripts');
function alcx_enqueue_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script(
        'alcx-contact-js',
        plugin_dir_url(__FILE__) . 'js/alcx-contact.js',
        ['jquery'],
        '2.1',
        true
    );

    wp_localize_script('alcx-contact-js', 'alcx_ajax_object', [
        'ajax_url' => admin_url('admin-ajax.php')
    ]);

    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css');
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', ['jquery'], null, true);
    wp_enqueue_style('fontawesome-css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
}

// ------------------------------
// 3. AJAX HANDLER
// ------------------------------
add_action('wp_ajax_alcx_contact_submit', 'alcx_contact_submit');
add_action('wp_ajax_nopriv_alcx_contact_submit', 'alcx_contact_submit');

function alcx_contact_submit() {
    check_ajax_referer('alcx_contact_nonce', 'alcx_nonce');

    global $wpdb;
    $table_name = $wpdb->prefix . 'alcx_contact_submissions';

    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $subject = sanitize_text_field($_POST['subject']);
    $message = sanitize_textarea_field($_POST['message']);

    // Insert into DB
    $inserted = $wpdb->insert($table_name, [
        'name' => $name,
        'email' => $email,
        'subject' => $subject,
        'message' => $message
    ]);

    // Send Email
    $headers = ['From: ACE Language Centre <info@acelanguagecentre.my>'];
    $mail_sent = wp_mail('info@acelanguagecentre.my', $subject, "Name: $name\nEmail: $email\n\n$message", $headers);


    // Update DB if email sent
    if ($mail_sent && $inserted) {
        $wpdb->update($table_name, ['email_sent' => 1], ['id' => $wpdb->insert_id]);
        wp_send_json_success(['message' => 'Thank you! Your message has been sent successfully.']);
    } else {
        wp_send_json_error(['message' => 'Oops! Something went wrong. Please try again later.']);
    }
}

// ------------------------------
// 4. ADMIN MENU
// ------------------------------
add_action('admin_menu', 'alcx_add_admin_menu');
function alcx_add_admin_menu() {
    add_menu_page(
        'Contact Form Submissions',
        'Contact Forms',
        'manage_options',
        'alcx-contact-submissions',
        'alcx_display_submissions',
        'dashicons-email-alt',
        30
    );
}

// ------------------------------
// 5. DISPLAY SUBMISSIONS
// ------------------------------
function alcx_display_submissions() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'alcx_contact_submissions';

    if (isset($_GET['action']) && $_GET['action'] === 'export') {
        alcx_export_to_csv();
        exit;
    }

    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC");
    ?>
    <div class="wrap">
        <h1>Contact Form Submissions</h1>
        <p>
            <a href="<?php echo admin_url('admin.php?page=alcx-contact-submissions&action=export'); ?>" class="button button-primary">Export to CSV</a>
        </p>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Subject</th>
                    <th>Email Sent</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($submissions as $sub) : ?>
                    <tr>
                        <td><?php echo $sub->id; ?></td>
                        <td><?php echo esc_html($sub->name); ?></td>
                        <td><?php echo esc_html($sub->email); ?></td>
                        <td><?php echo esc_html($sub->subject); ?></td>
                        <td><?php echo $sub->email_sent ? '✓ Yes' : '✗ No'; ?></td>
                        <td><?php echo date('M j, Y g:i a', strtotime($sub->submitted_at)); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// ------------------------------
// 6. EXPORT TO CSV
// ------------------------------
function alcx_export_to_csv() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'alcx_contact_submissions';
    $submissions = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    if (empty($submissions)) wp_die('No data available to export.');

    if (ob_get_length()) ob_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=contact_submissions-' . date('Y-m-d') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');
    fputcsv($output, array_keys($submissions[0]));

    foreach ($submissions as $row) fputcsv($output, $row);

    fclose($output);
    exit;
}

// ------------------------------
// 7. SHORTCODE: Contact Form + Info + Map
// ------------------------------
add_shortcode('alcx_contact_form', 'alcx_contact_form_shortcode');
function alcx_contact_form_shortcode() {
    ob_start(); ?>
    
<section id="alc-contact-page" class="py-5 bg-light">
    <div class="container py-5">
        <div class="row g-5">

            <!-- Left Column: Info + Map -->
            <div class="col-lg-5">
                <div class="p-4 rounded-4 shadow-sm bg-white mb-4">
                    <div class="d-flex align-items-start mb-4">
                        <div class="rounded-circle bg-primary d-flex justify-content-center align-items-center me-3" style="width:55px;height:55px;">
                            <i class="fa fa-map-marker-alt text-white fa-lg"></i>
                        </div>
                        <div>
                            <h5 class="mb-1">Our Location</h5>
                            <p class="mb-0">D-05-08 & D-05-09, Block D, Plaza Mont Kiara,<br>Jalan Kiara, 50480 Kuala Lumpur</p>
                        </div>
                    </div>

                    <div class="d-flex align-items-start mb-4">
                        <div class="rounded-circle bg-secondary d-flex justify-content-center align-items-center me-3" style="width:55px;height:55px;">
                            <i class="fa fa-phone-alt text-white fa-lg"></i>
                        </div>
                        <div>
                            <h5 class="mb-1">Call Us</h5>
                            <p class="mb-0">+60 11-6247 7018</p>
                        </div>
                    </div>

                    <div class="d-flex align-items-start mb-4">
                        <div class="rounded-circle bg-warning d-flex justify-content-center align-items-center me-3" style="width:55px;height:55px;">
                            <i class="fa fa-envelope text-white fa-lg"></i>
                        </div>
                        <div>
                            <h5 class="mb-1">Email Us</h5>
                            <p class="mb-0">info@acelanguagecentre.my</p>
                        </div>
                    </div>

                    <div class="rounded-4 overflow-hidden shadow-sm">
                        <iframe 
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3983.7287107914963!2d101.6519883!3d3.166001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87b783c5818efed7%3A0xfa5b51c991c1d246!2sPlaza%20Mont%E2%80%99%20Kiara!5e0!3m2!1sen!2s!4v1758522905941!5m2!1sen!2s"
                            width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy">
                        </iframe>
                    </div>
                </div>
            </div>

            <!-- Right Column: Contact Form -->
            <div class="col-lg-7">
                <div class="mb-4">
                    <h6 class="text-secondary text-uppercase fw-bold">Need Help?</h6>
                    <h2 class="fw-bold display-5">Send Us A Message</h2>
                </div>

                <p class="mb-4">Contact Ace Language Centre for inquiries about English, Bahasa Malaysia, or Mandarin programs. Our team replies quickly to assist you with course details and registration.</p>

                <div class="p-4 shadow-sm rounded-4 bg-white">
                    <form id="alcx-contact-form">
                        <?php wp_nonce_field('alcx_contact_nonce', 'alcx_nonce'); ?>
                        <input type="hidden" name="action" value="alcx_contact_submit">

                        <div class="row g-3">
                            <div class="col-6">
                                <input type="text" name="name" class="form-control p-3 rounded-3" placeholder="Your Name" required>
                            </div>
                            <div class="col-6">
                                <input type="email" name="email" class="form-control p-3 rounded-3" placeholder="Your Email" required>
                            </div>
                        </div>

                        <div class="mt-3">
                            <input type="text" name="subject" class="form-control p-3 rounded-3" placeholder="Subject" required>
                        </div>

                        <div class="mt-3">
                            <textarea name="message" class="form-control p-3 rounded-3" rows="5" placeholder="Message" required></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary mt-4 px-4 py-3 rounded-3 fw-bold">Send Message</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- Modal -->
<div class="modal fade" id="alcxContactModal" tabindex="-1" aria-labelledby="alcxContactModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content rounded-4">
      <div class="modal-header">
        <h5 class="modal-title" id="alcxContactModalLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary rounded-3" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php
    return ob_get_clean();
}
