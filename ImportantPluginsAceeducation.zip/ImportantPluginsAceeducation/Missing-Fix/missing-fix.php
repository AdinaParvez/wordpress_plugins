<?php
/*
Plugin Name: Missing CSS/JS Fixer + Fallback
Description: Automatically fixes missing CSS/JS files and adds fallback/preload for critical resources.
Version: 1.1
Author: Adina Pervaiz
*/

// ----------------------------
// 1. List of critical files and their fallback
// ----------------------------
$critical_files = array(
    'engitech-style' => array(
        'fallback' => get_template_directory_uri() . '/style.css',
        'type' => 'css'
    ),
    // Add more critical files here if needed
);

// ----------------------------
// 2. Detect missing CSS files and apply fallback
// ----------------------------
add_action('wp_enqueue_scripts', function() use ($critical_files) {

    global $wp_styles;
    if (!empty($wp_styles->registered)) {
        foreach ($wp_styles->registered as $handle => $style) {

            $src_url = $style->src;
            if (strpos($src_url, home_url()) !== false) {
                $src_path = str_replace(home_url(), ABSPATH, $src_url);

                if (!file_exists($src_path)) {
                    wp_dequeue_style($handle);
                    wp_deregister_style($handle);
                    error_log("Removed missing CSS: $handle ($src_url)");

                    // Check for fallback
                    if (isset($critical_files[$handle]['fallback'])) {
                        wp_enqueue_style($handle, $critical_files[$handle]['fallback'], array(), wp_get_theme()->get('Version'));
                        error_log("Enqueued fallback for CSS: $handle");
                    }
                }
            }
        }
    }

}, 20);

// ----------------------------
// 3. Detect missing JS files and apply fallback
// ----------------------------
add_action('wp_enqueue_scripts', function() use ($critical_files) {

    global $wp_scripts;
    if (!empty($wp_scripts->registered)) {
        foreach ($wp_scripts->registered as $handle => $script) {

            $src_url = $script->src;
            if (strpos($src_url, home_url()) !== false) {
                $src_path = str_replace(home_url(), ABSPATH, $src_url);

                if (!file_exists($src_path)) {
                    wp_dequeue_script($handle);
                    wp_deregister_script($handle);
                    error_log("Removed missing JS: $handle ($src_url)");

                    // Check for fallback
                    if (isset($critical_files[$handle]['fallback'])) {
                        wp_enqueue_script($handle, $critical_files[$handle]['fallback'], array(), wp_get_theme()->get('Version'), true);
                        error_log("Enqueued fallback for JS: $handle");
                    }
                }
            }
        }
    }

}, 20);

// ----------------------------
// 4. Preload critical CSS
// ----------------------------
add_action('wp_head', function() use ($critical_files) {
    foreach ($critical_files as $handle => $info) {
        if ($info['type'] === 'css') {
            ?>
            <link rel="preload" href="<?php echo esc_url($info['fallback']); ?>" as="style" onload="this.onload=null;this.rel='stylesheet'">
            <noscript><link rel="stylesheet" href="<?php echo esc_url($info['fallback']); ?>"></noscript>
            <?php
        }
    }
});
