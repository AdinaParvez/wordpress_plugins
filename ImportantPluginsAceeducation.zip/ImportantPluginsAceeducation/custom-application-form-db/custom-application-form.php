<?php
/*
Plugin Name: Custom Application Form
Description: A responsive application form that sends email and saves to database.
Version: 2.1
Author: Adina Pervaiz
*/

// Create database table on plugin activation
register_activation_hook(__FILE__, 'cef_create_table');
function cef_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'application_form_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        parent_name varchar(255) NOT NULL,
        student_name varchar(255) NOT NULL,
        dob date NOT NULL,
        phone varchar(50) NOT NULL,
        email varchar(255) NOT NULL,
        message text NOT NULL,
        terms varchar(50) NOT NULL,
        email_sent tinyint(1) DEFAULT 0,
        submitted_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Extend nonce lifetime to 24 hours
add_filter('nonce_life', 'cef_extend_nonce_lifetime');
function cef_extend_nonce_lifetime() {
    return DAY_IN_SECONDS; // 24 hours
}

// Add admin menu to view submissions
add_action('admin_menu', 'cef_add_admin_menu');
function cef_add_admin_menu() {
    add_menu_page(
        'Application Form Submissions',
        'Application Forms',
        'manage_options',
        'application-form-submissions',
        'cef_display_submissions',
        'dashicons-email-alt',
        30
    );
}

// Display submissions in admin
function cef_display_submissions() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'application_form_submissions';
    
    // Handle delete action with nonce verification
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        // Verify nonce for security
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'delete_submission_' . $_GET['id'])) {
            wp_die(__('Security check failed. Please try again.', 'cef'));
        }
        
        $id = intval($_GET['id']);
        $deleted = $wpdb->delete($table_name, ['id' => $id], ['%d']);
        
        if ($deleted) {
            echo '<div class="notice notice-success is-dismissible"><p>Submission deleted successfully.</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>Failed to delete submission.</p></div>';
        }
    }
    
    // Handle export action
    if (isset($_GET['action']) && $_GET['action'] === 'export') {
        // Verify nonce for export
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'export_submissions')) {
            wp_die(__('Security check failed. Please try again.', 'cef'));
        }
        
        cef_export_to_csv();
        exit;
    }
    
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC");
    
    ?>
    <div class="wrap">
        <h1>Application Form Submissions</h1>
        <p>
            <a href="<?php echo wp_nonce_url(
                admin_url('admin.php?page=application-form-submissions&action=export'),
                'export_submissions'
            ); ?>" class="button button-primary">Export to CSV</a>
        </p>
        
        <?php if (empty($submissions)): ?>
            <p>No submissions found.</p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Parent Name</th>
                        <th>Student Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Email Sent</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $submission): ?>
                        <tr>
                            <td><?php echo esc_html($submission->id); ?></td>
                            <td><?php echo esc_html($submission->parent_name); ?></td>
                            <td><?php echo esc_html($submission->student_name); ?></td>
                            <td><?php echo esc_html($submission->email); ?></td>
                            <td><?php echo esc_html($submission->phone); ?></td>
                            <td><?php echo $submission->email_sent ? '✓ Yes' : '✗ No'; ?></td>
                            <td><?php echo esc_html(date('M j, Y g:i a', strtotime($submission->submitted_at))); ?></td>
                            <td>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=application-form-submissions&action=view&id=' . $submission->id)); ?>" class="button button-small">View</a>
                                <a href="<?php echo esc_url(wp_nonce_url(
                                    admin_url('admin.php?page=application-form-submissions&action=delete&id=' . $submission->id),
                                    'delete_submission_' . $submission->id
                                )); ?>" class="button button-small button-link-delete" onclick="return confirm('Are you sure you want to delete this submission?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
        <?php
        // Display full details if viewing a specific submission
        if (isset($_GET['action']) && $_GET['action'] === 'view' && isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $submission = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
            
            if ($submission) {
                ?>
                <div style="margin-top: 30px; padding: 20px; background: #fff; border: 1px solid #ccc;">
                    <h2>Submission Details - #<?php echo esc_html($submission->id); ?></h2>
                    <table class="form-table">
                        <tr><th>Parent's Name:</th><td><?php echo esc_html($submission->parent_name); ?></td></tr>
                        <tr><th>Student's Name:</th><td><?php echo esc_html($submission->student_name); ?></td></tr>
                        <tr><th>Date of Birth:</th><td><?php echo esc_html($submission->dob); ?></td></tr>
                        <tr><th>Phone:</th><td><?php echo esc_html($submission->phone); ?></td></tr>
                        <tr><th>Email:</th><td><?php echo esc_html($submission->email); ?></td></tr>
                        <tr><th>Message:</th><td><?php echo nl2br(esc_html($submission->message)); ?></td></tr>
                        <tr><th>Terms Agreed:</th><td><?php echo esc_html($submission->terms); ?></td></tr>
                        <tr><th>Email Sent:</th><td><?php echo $submission->email_sent ? 'Yes' : 'No'; ?></td></tr>
                        <tr><th>Submitted:</th><td><?php echo esc_html(date('F j, Y, g:i a', strtotime($submission->submitted_at))); ?></td></tr>
                    </table>
                    <p><a href="<?php echo esc_url(admin_url('admin.php?page=application-form-submissions')); ?>" class="button">Back to List</a></p>
                </div>
                <?php
            } else {
                echo '<div class="notice notice-error"><p>Submission not found.</p></div>';
            }
        }
        ?>
    </div>
    <?php
}

// Export submissions to CSV
function cef_export_to_csv(){
    global $wpdb;

    // Clear any previous output to avoid header errors
    if (ob_get_length()) ob_clean();

    $table_name = $wpdb->prefix . 'application_form_submissions';
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC", ARRAY_A);

    // If no records found, stop
    if (empty($submissions)) {
        wp_die(__('No data available to export.', 'cef'));
    }

    // Set headers for CSV file download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=application_form_submissions-' . date('Y-m-d') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Open output stream
    $output = fopen('php://output', 'w');

    // Add UTF-8 BOM (for Excel compatibility)
    fputs($output, "\xEF\xBB\xBF");

    // Output CSV header (column names)
    fputcsv($output, array_keys($submissions[0]));

    // Output CSV rows
    foreach ($submissions as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
    exit;
}

// Shortcode to display the form
function cef_application_form_shortcode() {
    ob_start(); ?>
    
<style>
    .cef-form-wrapper {
        max-width: 100%;
        margin: 0 auto;
        padding: 20px 0;
        background: #fff;
        font-family: Arial, sans-serif;
    }
    .cef-form-wrapper form {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        align-items: start;
    }
    .cef-form-wrapper p {
        margin: 0;
    }
    .cef-form-wrapper label {
        font-weight: 600;
        font-size: 14px;
        display: block;
        margin-bottom: 6px;
        color: #333;
    }
    .cef-form-wrapper input[type="text"],
    .cef-form-wrapper input[type="number"],
    .cef-form-wrapper input[type="date"],
    .cef-form-wrapper input[type="tel"],
    .cef-form-wrapper input[type="email"],
    .cef-form-wrapper textarea,
    .cef-form-wrapper select {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        background: #fff;
        box-sizing: border-box;
    }
    .cef-form-wrapper .full {
        grid-column: span 2;
        width: 100%;
    }
    .cef-form-wrapper input[type="submit"] {
        grid-column: span 2;
        background-color: #f9b000;
        width: 100%;
        color: #000;
        border: none;
        padding: 12px;
        cursor: pointer;
        border-radius: 4px;
        font-size: 16px;
        font-weight: bold;
        transition: background 0.3s ease;
    }
    .cef-form-wrapper input[type="submit"]:hover {
        background-color: #005177;
        color: #fff;
    }
    .cef-form-wrapper input[type="submit"]:disabled {
        background-color: #ccc;
        cursor: not-allowed;
    }
    .cef-form-wrapper label input[type="checkbox"] {
        display: inline-block;
        width: auto;
        margin-right: 8px;
    }
    .cef-success-message {
        background: #d4edda;
        color: #155724;
        padding: 15px;
        border: 1px solid #c3e6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }
    .cef-error-message {
        background: #f8d7da;
        color: #721c24;
        padding: 15px;
        border: 1px solid #f5c6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }
    
    @media (max-width: 768px) {
        .cef-form-wrapper form {
            grid-template-columns: 1fr;
        }
        .cef-form-wrapper .full {
            grid-column: span 1;
        }
        .cef-form-wrapper input,
        .cef-form-wrapper select,
        .cef-form-wrapper textarea {
            font-size: 16px;
        }
        .cef-form-wrapper input[type="submit"] {
            font-size: 18px;
            padding: 14px;
        }
    }
</style>

<div class="cef-form-wrapper">
    <?php
    // Display success or error messages
    if (isset($_GET['form_status'])) {
        if ($_GET['form_status'] === 'success') {
            echo '<div class="cef-success-message">✓ Thank you! Your inquiry has been submitted successfully.</div>';
        } elseif ($_GET['form_status'] === 'error') {
            echo '<div class="cef-error-message">⚠ There was an error submitting your form. Please try again.</div>';
        } elseif ($_GET['form_status'] === 'terms_error') {
            echo '<div class="cef-error-message">⚠ You must agree to the Terms & Conditions.</div>';
        } elseif ($_GET['form_status'] === 'invalid_date') {
            echo '<div class="cef-error-message">⚠ Please enter a valid date of birth.</div>';
        } elseif ($_GET['form_status'] === 'nonce_error') {
            echo '<div class="cef-error-message">⚠ Security verification failed. Please try again.</div>';
        }
    }
    ?>
    
    <form method="post" action="" id="cef-application-form">
        <?php wp_nonce_field('cef_application_form_action', 'cef_application_form_nonce'); ?>
       
        <p>
            <label for="cef-parent-name">Parent's Name</label>
            <input type="text" id="cef-parent-name" placeholder="Please write your full name" name="parent_name" required>
        </p>
        
        <p>
            <label for="cef-student-name">Student's Name</label>
            <input type="text" id="cef-student-name" placeholder="Please write Student's full name" name="student_name" required>
        </p>
        
        <p>
            <label for="cef-dob">Date of Birth</label>
            <input type="date" id="cef-dob" name="dob" max="<?php echo date('Y-m-d'); ?>" min="<?php echo date('Y-m-d', strtotime('-120 years')); ?>" required>
        </p>
        
        <p>
            <label for="cef-phone">Phone Number</label>
            <input type="tel" id="cef-phone" placeholder="Please write phone number" name="phone" required>
        </p>
        
        <p class="full">
            <label for="cef-email">Email</label>
            <input type="email" id="cef-email" placeholder="Please write your Email" name="email" required>
        </p>
        
        <p class="full">
            <label for="cef-message">Message</label>
            <textarea id="cef-message" name="message" placeholder="Message" rows="5" required></textarea>
        </p>
        
        <p class="full">
            <label for="cef-terms">
                <input type="checkbox" id="cef-terms" name="terms" value="Agreed" required>
                Terms & Conditions - I agree to the Terms & Conditions of World Best Services Malaysia Sdn Bhd (ACE Language Centre Malaysia)
            </label>
        </p>
        
        <p class="full">
            <input type="submit" name="cef_application_submit" value="Send Enquiry">
        </p>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Auto-hide success/error messages after 10 seconds
            const successMsg = document.querySelector('.cef-success-message');
            const errorMsg = document.querySelector('.cef-error-message');
            
            if (successMsg || errorMsg) {
                setTimeout(function() {
                    const msg = successMsg || errorMsg;
                    msg.style.transition = 'opacity 0.5s ease';
                    msg.style.opacity = '0';
                    
                    setTimeout(function() {
                        msg.remove();
                        const url = new URL(window.location);
                        url.searchParams.delete('form_status');
                        window.history.replaceState({}, document.title, url);
                    }, 500);
                }, 10000);
            }
            
            // Prevent double submission
            const form = document.getElementById('cef-application-form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    const submitBtn = form.querySelector('input[type="submit"]');
                    if (submitBtn.disabled) {
                        e.preventDefault();
                        return false;
                    }
                    submitBtn.disabled = true;
                    submitBtn.value = 'Sending...';
                });
            }
        });
    </script>
</div>

<?php
    return ob_get_clean();
}
add_shortcode('custom_application_form', 'cef_application_form_shortcode');

// Handle form submission
add_action('init', 'cef_handle_form');

function cef_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cef_application_submit'])) {

        // Verify nonce
        if (!isset($_POST['cef_application_form_nonce']) || !wp_verify_nonce($_POST['cef_application_form_nonce'], 'cef_application_form_action')) {
            wp_redirect(add_query_arg('form_status', 'nonce_error', wp_get_referer()));
            exit;
        }

        // Check terms agreement
        if (empty($_POST['terms'])) {
            wp_redirect(add_query_arg('form_status', 'terms_error', wp_get_referer()));
            exit;
        }

        // Validate and sanitize date of birth
        $dob = sanitize_text_field($_POST['dob']);
        $dob_timestamp = strtotime($dob);
        $min_date = strtotime('-120 years'); // Maximum 120 years old
        $max_date = strtotime('today'); // Cannot be future date

        if ($dob_timestamp === false || $dob_timestamp > $max_date || $dob_timestamp < $min_date) {
            wp_redirect(add_query_arg('form_status', 'invalid_date', wp_get_referer()));
            exit;
        }

        // Sanitize and prepare data
        $data = [
            'parent_name' => sanitize_text_field($_POST['parent_name']),
            'student_name' => sanitize_text_field($_POST['student_name']),
            'dob' => $dob,
            'phone' => sanitize_text_field($_POST['phone']),
            'email' => sanitize_email($_POST['email']),
            'message' => sanitize_textarea_field($_POST['message']),
            'terms' => sanitize_text_field($_POST['terms']),
        ];

        // Email recipients
        $to = ['info@acelanguagecentre.edu.my', 'acekl2018@gmail.com']; 
        $subject = 'New Application Services Form Submission';

        // Create HTML email body
        $email_body = '<html><body style="font-family: Arial, sans-serif;">';
        $email_body .= '<h2 style="color: #f9b000;">New Application Request</h2>';
        $email_body .= '<table style="border-collapse: collapse; width: 100%;">';
        
        $email_fields = [
            "Parent's Name" => $data['parent_name'],
            "Student's Name" => $data['student_name'],
            "Date of Birth" => $data['dob'],
            "Phone" => $data['phone'],
            "Email" => $data['email'],
            "Message" => nl2br(esc_html($data['message'])),
            "Terms & Conditions" => $data['terms'],
        ];
        
        foreach ($email_fields as $label => $value) {
            $email_body .= '<tr style="border-bottom: 1px solid #ddd;">';
            $email_body .= '<td style="padding: 10px; font-weight: bold; width: 200px;">' . esc_html($label) . ':</td>';
            $email_body .= '<td style="padding: 10px;">' . $value . '</td>';
            $email_body .= '</tr>';
        }
        
        $email_body .= '</table>';
        $email_body .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
        $email_body .= '</body></html>';

        // Email headers
        $headers = [
            'From: ACE Language Centre Malaysia <info@acelanguagecentre.edu.my>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . $data['email']
        ];

        // Send email
        $mail_sent = wp_mail($to, $subject, $email_body, $headers);

        // Save to database (always save, mark if email was sent)
        global $wpdb;
        $table_name = $wpdb->prefix . 'application_form_submissions';
        
        $data['email_sent'] = $mail_sent ? 1 : 0;
        
        $inserted = $wpdb->insert($table_name, $data, [
            '%s', // parent_name
            '%s', // student_name
            '%s', // dob
            '%s', // phone
            '%s', // email
            '%s', // message
            '%s', // terms
            '%d'  // email_sent
        ]);

        // Redirect with success message (form is saved regardless of email status)
        if ($inserted) {
            wp_redirect(add_query_arg('form_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
        }
        exit;
    }
}