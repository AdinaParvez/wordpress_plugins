# Admission Form WordPress Plugin

A comprehensive, responsive admission form plugin for educational institutions with file upload capabilities, email notifications, and database storage.

 Features

✨ Complete Form Sections:
- Required documents upload (Passport, Photo, Certificates, Health Form)
- Personal information collection
- Address details
- Contact information with messaging app preferences
- University plans and offer letter upload
- Programme selection with sessions and duration
- Consent and verification checkboxes

🎨 Modern Design:
- Beautiful gradient color scheme
- Smooth animations and transitions
- Fully responsive (mobile, tablet, desktop)
- Clean and professional UI
- Loading states and validation feedback

🔒 Security Features:
- Nonce verification for AJAX requests
- File type and size validation
- Sanitized data inputs
- Secure file uploads

📧 Notifications:
- Automatic email notifications to admin
- Success/error messages to users

 Installation

# Step 1: Create Plugin Structure

Create the following folder structure in your WordPress installation:

```
wp-content/
└── plugins/
    └── admission-form/
        ├── admission-form.php (main plugin file)
        └── assets/
            ├── style.css
            └── script.js
```

# Step 2: Upload Files

1. Copy the admission-form.php content into the main plugin file
2. Copy the style.css content into `assets/style.css`
3. Copy the script.js content into `assets/script.js`

# Step 3: Activate Plugin

1. Go to your WordPress admin dashboard
2. Navigate to Plugins → Installed Plugins
3. Find "Admission Form" in the list
4. Click Activate

# Step 4: Add Form to Page

Add the following shortcode to any page or post:

```
[admission_form]
```

 File Structure

```
admission-form/
├── admission-form.php          # Main plugin file with PHP logic
└── assets/
    ├── style.css              # All styling and responsive design
    └── script.js              # Form validation and AJAX handling
```

 Usage

# Adding the Form to a Page

1. Create a new page or edit an existing one
2. Add the shortcode `[admission_form]` where you want the form to appear
3. Publish or update the page

# Viewing Submissions

Submissions are stored in the database table: `wp_admission_forms`

You can access them via:
- phpMyAdmin
- WordPress database plugins
- Custom admin panel (can be added in future updates)

 Configuration

# Email Notifications

The plugin sends notifications to the admin email set in WordPress settings:
- Go to Settings → General
- Check the Administration Email Address field

# Upload Directory

Files are uploaded to: `wp-content/uploads/admission-forms/`

# File Size Limits

- Passport Copy: 5MB (PDF, JPG, PNG)
- Photo: 2MB (JPG, PNG)
- Certificates: 5MB per file (PDF, JPG, PNG)
- Health Form: 5MB (PDF only)
- Offer Letter: 5MB (PDF, JPG, PNG)

 Customization

# Changing Colors

Edit the gradient colors in `style.css`:

```css
/* Primary gradient */
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

/* Change to your brand colors */
background: linear-gradient(135deg, #YOUR_COLOR_1 0%, #YOUR_COLOR_2 100%);
```

# Adding New Fields

1. Add HTML field in `render_form()` method
2. Add database column in `create_table()` method
3. Add data handling in `handle_submission()` method

# Modifying Validation

Edit validation rules in `script.js`:

```javascript
// Example: Change photo size limit
const maxSize = 3 * 1024 * 1024; // 3MB instead of 2MB
```

 Database Schema

The plugin creates a table `wp_admission_forms` with the following columns:

- id (auto increment)
- full_name
- passport_no
- nationality
- age
- street_address
- city
- postal_code
- state_region
- email
- phone
- contact_app
- wechat_line_id
- university_plan
- university_name
- program
- session
- study_duration
- preferred_centre
- message
- passport_copy
- photo
- certificates
- health_form
- offer_letter
- submission_date

 Responsive Breakpoints

- Desktop: 1200px and above
- Tablet: 768px - 1199px
- Mobile: Below 768px
- Small Mobile: Below 480px

 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Opera (latest)

 Troubleshooting

# Form Not Appearing

1. Check if the plugin is activated
2. Verify the shortcode is correct: `[admission_form]`
3. Clear browser cache

# Files Not Uploading

1. Check PHP file upload settings in `php.ini`:
   ```
   upload_max_filesize = 10M
   post_max_size = 10M
   ```
2. Verify folder permissions for `wp-content/uploads/admission-forms/`
3. Check server disk space

# Styling Issues

1. Clear browser cache
2. Check for CSS conflicts with your theme
3. Verify `style.css` is loaded in browser inspector

# AJAX Not Working

1. Check JavaScript console for errors
2. Verify jQuery is loaded
3. Check AJAX URL in browser network tab

 Future Enhancements

Potential features for future versions:

- Admin dashboard to view submissions
- Export submissions to CSV/Excel
- Email templates customization
- Payment integration
- Multi-step form option
- Progress bar indicator
- Document preview before upload
- Conditional logic for fields
- ReCAPTCHA integration
- Multi-language support

 Support

For issues or questions:

1. Check the troubleshooting section
2. Review WordPress error logs
3. Check browser console for JavaScript errors
4. Verify all files are uploaded correctly

 License

GPL v2 or later

 Credits

Created for educational institutions to streamline their admission process with a modern, user-friendly interface.

---

Version: 1.0.0  
Last Updated: October 2025  
Tested up to: WordPress 6.4