jQuery(document).ready(function($) {
    
    // Show/hide university name field based on university plan selection
    $('#university_plan').on('change', function() {
        const value = $(this).val();
        if (value === 'yes') {
            $('#university_name_group').slideDown(300);
        } else {
            $('#university_name_group').slideUp(300);
            $('#university_name').val('');
            $('#other_university_group').slideUp(300);
            $('#other_university').val('');
        }
    });
    
    // Show/hide other university field
    $('#university_name').on('change', function() {
        const value = $(this).val();
        if (value === 'Other') {
            $('#other_university_group').slideDown(300);
        } else {
            $('#other_university_group').slideUp(300);
            $('#other_university').val('');
        }
    });
    
    // File upload validation
    function validateFile(input, maxSize, allowedTypes) {
        const file = input.files[0];
        if (!file) return true;
        
        // Check file size
        if (file.size > maxSize) {
            alert(`File size must be less than ${maxSize / (1024 * 1024)}MB`);
            input.value = '';
            return false;
        }
        
        // Check file type
        const fileType = file.type;
        if (!allowedTypes.includes(fileType)) {
            alert(`Invalid file type. Allowed types: ${allowedTypes.join(', ')}`);
            input.value = '';
            return false;
        }
        
        return true;
    }
    
    // Passport copy validation
    $('#passport_copy').on('change', function() {
        const maxSize = 5 * 1024 * 1024; // 5MB
        const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
        validateFile(this, maxSize, allowedTypes);
    });
    
    // Photo validation
    $('#photo').on('change', function() {
        const maxSize = 2 * 1024 * 1024; // 2MB
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
        validateFile(this, maxSize, allowedTypes);
    });
    
    // Certificates validation
    $('#certificates').on('change', function() {
        const maxSize = 5 * 1024 * 1024; // 5MB per file
        const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
        
        for (let i = 0; i < this.files.length; i++) {
            if (!validateFile({files: [this.files[i]]}, maxSize, allowedTypes)) {
                this.value = '';
                break;
            }
        }
    });
    
    // Health form validation
    $('#health_form').on('change', function() {
        const maxSize = 5 * 1024 * 1024; // 5MB
        const allowedTypes = ['application/pdf'];
        validateFile(this, maxSize, allowedTypes);
    });
    
    // Offer letter validation
    $('#offer_letter').on('change', function() {
        const maxSize = 5 * 1024 * 1024; // 5MB
        const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
        validateFile(this, maxSize, allowedTypes);
    });
    
    // Email validation
    $('#email').on('blur', function() {
        const email = $(this).val();
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (email && !emailPattern.test(email)) {
            $(this).css('border-color', '#fc8181');
            if (!$('#email-error').length) {
                $(this).after('<small id="email-error" class="form-text" style="color: #fc8181;">Please enter a valid email address</small>');
            }
        } else {
            $(this).css('border-color', '#e2e8f0');
            $('#email-error').remove();
        }
    });
    
    // Phone validation (basic)
    $('#phone').on('blur', function() {
        const phone = $(this).val();
        const phonePattern = /^[\d\s\+\-\(\)]+$/;
        
        if (phone && !phonePattern.test(phone)) {
            $(this).css('border-color', '#fc8181');
            if (!$('#phone-error').length) {
                $(this).after('<small id="phone-error" class="form-text" style="color: #fc8181;">Please enter a valid phone number</small>');
            }
        } else {
            $(this).css('border-color', '#e2e8f0');
            $('#phone-error').remove();
        }
    });
    
    // Age validation
    $('#age').on('input', function() {
        const age = parseInt($(this).val());
        if (age < 1 || age > 120) {
            $(this).css('border-color', '#fc8181');
        } else {
            $(this).css('border-color', '#e2e8f0');
        }
    });
    
    // Form submission
    $('#admission-form').on('submit', function(e) {
        e.preventDefault();
        
        // Validate all required checkboxes
        const requiredCheckboxes = $('input[type="checkbox"][required]');
        let allChecked = true;
        
        requiredCheckboxes.each(function() {
            if (!$(this).is(':checked')) {
                allChecked = false;
            }
        });
        
        if (!allChecked) {
            showMessage('Please accept all required consent statements', 'error');
            $('html, body').animate({
                scrollTop: $('.consent-group').offset().top - 100
            }, 500);
            return;
        }
        
        // Validate required radio buttons
        const contactApp = $('input[name="contact_app"]:checked').length;
        if (contactApp === 0) {
            showMessage('Please select a contact app preference', 'error');
            $('html, body').animate({
                scrollTop: $('input[name="contact_app"]').first().offset().top - 100
            }, 500);
            return;
        }
        
        // Show loading state
        const submitBtn = $('.btn-submit');
        submitBtn.prop('disabled', true).addClass('loading').text('Submitting...');
        
        // Prepare form data
        const formData = new FormData(this);
        formData.append('action', 'submit_admission_form');
        formData.append('nonce', admissionFormAjax.nonce);
        
        // Submit via AJAX
        $.ajax({
            url: admissionFormAjax.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    showMessage(response.data.message, 'success');
                    $('#admission-form')[0].reset();
                    $('html, body').animate({ scrollTop: 0 }, 500);
                } else {
                    showMessage(response.data.message, 'error');
                }
            },
            error: function() {
                showMessage('An error occurred. Please try again later.', 'error');
            },
            complete: function() {
                submitBtn.prop('disabled', false).removeClass('loading').text('Send Application');
            }
        });
    });
    
    // Show message function
    function showMessage(message, type) {
        const messageDiv = $('#form-message');
        messageDiv.removeClass('success error').addClass(type).text(message).slideDown(300);
        
        setTimeout(function() {
            messageDiv.slideUp(300);
        }, 5000);
    }
    
    // Smooth scroll for form navigation
    $('.form-section').each(function(index) {
        $(this).css('opacity', '0').css('transform', 'translateY(20px)');
    });
    
    $(window).on('scroll', function() {
        $('.form-section').each(function() {
            const elementTop = $(this).offset().top;
            const windowBottom = $(window).scrollTop() + $(window).height();
            
            if (elementTop < windowBottom - 50) {
                $(this).animate({
                    opacity: 1
                }, 600).css('transform', 'translateY(0)');
            }
        });
    });
    
    // Trigger initial check
    $(window).trigger('scroll');
    
    // Add asterisk to required fields label
    $('input[required], select[required], textarea[required]').each(function() {
        const label = $(this).closest('.form-group').find('label').first();
        if (label.length && !label.text().includes('*')) {
            label.html(label.html());
        }
    });
    
    // Character counter for textarea
    $('#message').after('<small class="char-counter" style="display: block; margin-top: 5px; color: #718096; font-size: 12px;">0 characters</small>');
    
    $('#message').on('input', function() {
        const length = $(this).val().length;
        $(this).next('.char-counter').text(length + ' characters');
    });
    
    // Auto-resize textarea
    $('textarea').on('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });
    
    // Add focus effects
    $('.form-control').on('focus', function() {
        $(this).closest('.form-group').addClass('focused');
    }).on('blur', function() {
        $(this).closest('.form-group').removeClass('focused');
    });
    
    // Prevent form submission on Enter key (except for textarea)
    $('#admission-form input').on('keypress', function(e) {
        if (e.which === 13 && $(this).attr('type') !== 'submit') {
            e.preventDefault();
            return false;
        }
    });
    
});