document.addEventListener('click', function(e){
    if (!e.target.classList.contains('tcp-filter')) return;

    document.querySelectorAll('.tcp-filter').forEach(b=>b.classList.remove('active'));
    e.target.classList.add('active');

    const filter = e.target.dataset.filter;

    document.querySelectorAll('.tcp-item').forEach(item => {
        item.style.display =
            filter === 'all' || item.dataset.cat.includes(filter)
            ? 'block'
            : 'none';
    });
});
