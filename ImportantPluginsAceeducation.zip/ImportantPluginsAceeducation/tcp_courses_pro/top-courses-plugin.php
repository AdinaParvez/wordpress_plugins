<?php
/**
 * Plugin Name: Top Courses Grid (Elementor Compatible)
 * Description: Manage and display courses in a responsive grid with full Elementor support.
 * Version: 1.1.0
 * Author: Adina Pervaiz
 */

if (!defined('ABSPATH')) exit;

/*---------------------------------------------------
 REGISTER COURSE POST TYPE
---------------------------------------------------*/
function tcp_register_courses() {
    register_post_type('tcp_course', [
        'labels' => [
            'name' => 'Courses',
            'singular_name' => 'Course',
        ],
        'public' => true,
        'menu_icon' => 'dashicons-welcome-learn-more',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes'],
        'rewrite' => ['slug' => 'courses','with_front' => false],
        'has_archive' => true,
    ]);
}
add_action('init', 'tcp_register_courses');

/*---------------------------------------------------
 COURSE CATEGORIES
---------------------------------------------------*/
function tcp_register_course_categories() {
    register_taxonomy('tcp_course_category', 'tcp_course', [
        'label' => 'Course Categories',
        'hierarchical' => true,
        'show_admin_column' => true,
        'rewrite' => ['slug' => 'course-category'],
    ]);
}
add_action('init', 'tcp_register_course_categories');

/*---------------------------------------------------
 META BOXES
---------------------------------------------------*/
add_action('add_meta_boxes', function () {
    add_meta_box(
        'tcp_course_details',
        'Course Details',
        'tcp_course_meta_callback',
        'tcp_course',
        'normal',
        'high'
    );
});

function tcp_course_meta_callback($post) {
    $price = get_post_meta($post->ID, 'tcp_price', true);
    $logo  = get_post_meta($post->ID, 'tcp_logo', true);
    wp_nonce_field('tcp_save_meta', 'tcp_nonce');
    ?>
    <p>
        <label><strong>Price</strong></label>
        <input type="text" name="tcp_price" value="<?php echo esc_attr($price); ?>" style="width:100%;">
    </p>

    <p>
        <label><strong>Certified Company Logo</strong></label><br>
        <input type="hidden" id="tcp_logo" name="tcp_logo" value="<?php echo esc_url($logo); ?>">
        <img id="tcp_logo_preview" src="<?php echo esc_url($logo); ?>" style="max-width:80px;margin-bottom:10px;">
        <button type="button" class="button tcp-upload-logo">Upload Logo</button>
    </p>

    <script>
    jQuery(function($){
        $('.tcp-upload-logo').on('click', function(e){
            e.preventDefault();
            const frame = wp.media({ title: 'Select Logo', multiple: false });
            frame.on('select', function(){
                const img = frame.state().get('selection').first().toJSON();
                $('#tcp_logo').val(img.url);
                $('#tcp_logo_preview').attr('src', img.url);
            });
            frame.open();
        });
    });
    </script>
<?php
}

/*---------------------------------------------------
 SAVE META
---------------------------------------------------*/
add_action('save_post', function ($post_id) {
    if (!isset($_POST['tcp_nonce']) || !wp_verify_nonce($_POST['tcp_nonce'], 'tcp_save_meta')) return;

    if (isset($_POST['tcp_price'])) {
        update_post_meta($post_id, 'tcp_price', sanitize_text_field($_POST['tcp_price']));
    }
    if (isset($_POST['tcp_logo'])) {
        update_post_meta($post_id, 'tcp_logo', esc_url_raw($_POST['tcp_logo']));
    }
});

/*---------------------------------------------------
 ENQUEUE FRONTEND ASSETS
---------------------------------------------------*/
function tcp_enqueue_assets() {
    wp_enqueue_script(
        'tcp-filter',
        plugin_dir_url(__FILE__) . 'tcp-filter.js',
        [],
        '1.0',
        true
    );
}
add_action('wp_enqueue_scripts', 'tcp_enqueue_assets');

/*---------------------------------------------------
 SHORTCODE
---------------------------------------------------*/
function tcp_courses_shortcode() {

    $categories = get_terms(['taxonomy' => 'tcp_course_category', 'hide_empty' => true]);

    $query = new WP_Query([
        'post_type' => 'tcp_course',
        'posts_per_page' => -1,
        'orderby' => 'menu_order',
        'order' => 'ASC',
    ]);

    ob_start(); ?>

<section class="tcp-courses">
<div class="container">

<h2 class="mb-4">Top Courses</h2>

<div class="mb-4 tcp-filters">
    <button class="tcp-filter active" data-filter="all">All</button>
    <?php foreach ($categories as $cat): ?>
        <button class="tcp-filter" data-filter="<?php echo esc_attr($cat->slug); ?>">
            <?php echo esc_html($cat->name); ?>
        </button>
    <?php endforeach; ?>
</div>

<div class="row tcp-grid">

<?php while ($query->have_posts()) : $query->the_post();
    $price = get_post_meta(get_the_ID(), 'tcp_price', true);
    $logo  = get_post_meta(get_the_ID(), 'tcp_logo', true);
    $terms = wp_get_post_terms(get_the_ID(), 'tcp_course_category');
    $slugs = wp_list_pluck($terms, 'slug');
?>

<div class="col-md-3 tcp-item" data-cat="<?php echo esc_attr(implode(' ', $slugs)); ?>">
<a href="<?php the_permalink(); ?>">

<div class="card h-100">
<?php the_post_thumbnail('large'); ?>

<?php if ($logo): ?>
<img src="<?php echo esc_url($logo); ?>" class="tcp-logo">
<?php endif; ?>

<div class="card-body">
<h5><?php the_title(); ?></h5>
<p><?php echo wp_trim_words(get_the_content(), 12); ?></p>
<?php if ($price): ?>
<span class="tcp-price"><?php echo esc_html($price); ?></span>
<?php endif; ?>
</div>

</div>
</a>
</div>

<?php endwhile; wp_reset_postdata(); ?>

</div>
</div>
</section>

<?php
return ob_get_clean();
}
add_shortcode('top_courses', 'tcp_courses_shortcode');

/*---------------------------------------------------
 ELEMENTOR WIDGET (PROPER WAY)
---------------------------------------------------*/
add_action('elementor/widgets/register', function($widgets_manager){

    class TCP_Elementor_Widget extends \Elementor\Widget_Base {

        public function get_name() { return 'tcp_courses'; }
        public function get_title() { return 'Top Courses Grid'; }
        public function get_icon() { return 'eicon-posts-grid'; }
        public function get_categories() { return ['general']; }

        protected function render() {
            echo do_shortcode('[top_courses]');
        }
    }

    $widgets_manager->register(new TCP_Elementor_Widget());
});
