<?php
/*
Plugin Name: Course Feature
Description: Display course title, price, and featured image using shortcode [course_header].
Version: 1.1
Author: Adina Pervaiz
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Prevent direct access

// Shortcode: [course_header]
function cf_course_header_shortcode() {
    global $post;

    // Get course title and price
    $course_title = get_the_title( $post->ID );
    $course_price = get_post_meta( $post->ID, 'course_price', true ); // assumes custom field 'course_price'

    ob_start();
    ?>
    <div class="course-row">
      <!-- Left Content (Title + Price) -->
      <div class="course-left">
        <h2><?php echo esc_html( $course_title ); ?></h2>
        <?php if ( $course_price ) : ?>
          <p class="course-price">Price: $<?php echo esc_html( $course_price ); ?></p>
        <?php endif; ?>
      </div>

      <!-- Right Content (Featured Image) -->
      <div class="course-right">
        <?php 
          if ( has_post_thumbnail() ) {
            the_post_thumbnail( 'medium', [ 'class' => 'featured-image wp-post-image' ] );
          }
        ?>
      </div>
    </div>
    <style>
    .course-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 40px 0;
      gap: 20px;
    }

    .course-left {
      flex: 1;
      text-align: left;
    }

    .course-left h2 {
      font-size: 24px;
      font-weight: bold;
      line-height: 1.3;
      margin-bottom: 10px;
    }

    .course-left .course-price {
      font-size: 18px;
      color: #2c7a7b;
      font-weight: 600;
      margin: 0;
    }

    .course-right {
      flex: 1;
      text-align: right;
    }

    .course-right img.featured-image {
      max-width: 300px; /* adjust size */
      height: auto;
      border-radius: 10px;
    }

    @media (max-width: 768px) {
      .course-row {
        flex-direction: column;
        text-align: center;
      }
      .course-right {
        text-align: center;
      }
    }
    </style>
    <?php
    return ob_get_clean();
}
add_shortcode('course_header', 'cf_course_header_shortcode');
