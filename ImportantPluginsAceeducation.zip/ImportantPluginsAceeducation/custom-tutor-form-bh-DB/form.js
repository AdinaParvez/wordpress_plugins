document.addEventListener('DOMContentLoaded', function () {
  const phoneInput = document.querySelector("#cef-phone");

  if (phoneInput) {
    window.intlTelInput(phoneInput, {
      initialCountry: "bh",
      separateDialCode: true,
      nationalMode: true // allows typing freely
    });
  }

  // Load schools dynamically
  fetch(cefVars.schoolsUrl)
    .then(res => res.json())
    .then(list => {
      const dropdown = document.getElementById('cef-school-select');
      list.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.name.replace(/\s+/g, '-');
        opt.textContent = `${s.name} (${s.city})`;
        dropdown.appendChild(opt);
      });
    })
    .catch(console.error);
});
