jQuery(document).ready(function ($) {

    $('#alcx-contact-form').on('submit', function (e) {
        e.preventDefault();

        var formData = $(this).serialize();

        $.post(alcx_ajax_object.ajax_url, formData, function (response) {
            $('#alcxContactModal .modal-body').text(response.data.message);
            var modal = new bootstrap.Modal(document.getElementById('alcxContactModal'));
            modal.show();

            if (response.success) {
                $('#alcx-contact-form')[0].reset();
            }
        }).fail(function () {
            $('#alcxContactModal .modal-body').text('Something went wrong. Please try again.');
            var modal = new bootstrap.Modal(document.getElementById('alcxContactModal'));
            modal.show();
        });

    });

});
