<?php
/**
 * Plugin Name: ACE Language Centre Contact Form
 * Description: Custom AJAX contact form that saves to DB and sends email.
 * Version: 1.0
 * Author: Adina Pervaiz
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

// ------------------------------
// 1. CREATE DATABASE TABLE
// ------------------------------
register_activation_hook(__FILE__, 'alcx_create_table');
function alcx_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'alcx_contact_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        subject varchar(255) NOT NULL,
        message text NOT NULL,
        submitted_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// ------------------------------
// 2. ENQUEUE SCRIPTS & LOCALIZE
// ------------------------------
add_action('wp_enqueue_scripts', 'alcx_enqueue_scripts');
function alcx_enqueue_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script(
        'alcx-contact-js',
        plugin_dir_url(__FILE__) . 'js/alcx-contact.js',
        array('jquery'),
        '1.0',
        true
    );

    wp_localize_script('alcx-contact-js', 'alcx_ajax_object', [
        'ajax_url' => admin_url('admin-ajax.php')
    ]);

    // Optional: enqueue Bootstrap 5 if not already loaded
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css');
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', ['jquery'], null, true);
}

// ------------------------------
// 3. AJAX HANDLER
// ------------------------------
add_action('wp_ajax_alcx_contact_submit', 'alcx_contact_form_handler');
add_action('wp_ajax_nopriv_alcx_contact_submit', 'alcx_contact_form_handler');

function alcx_contact_form_handler() {
    if (!isset($_POST['alcx_nonce']) || !wp_verify_nonce($_POST['alcx_nonce'], 'alcx_contact_nonce')) {
        wp_send_json_error(['message' => 'Security check failed']);
    }

    $name    = sanitize_text_field($_POST['name']);
    $email   = sanitize_email($_POST['email']);
    $subject = sanitize_text_field($_POST['subject']);
    $message = sanitize_textarea_field($_POST['message']);

    global $wpdb;
    $table_name = $wpdb->prefix . 'alcx_contact_submissions';
    $wpdb->insert($table_name, [
        'name'      => $name,
        'email'     => $email,
        'subject'   => $subject,
        'message'   => $message,
        'submitted_at' => current_time('mysql'),
    ]);

    // Email
    $to = 'info@acelanguagecentre.my'; // change to your email
    $headers = ['Content-Type: text/html; charset=UTF-8'];
    $body = "<p><strong>Name:</strong> $name</p>
             <p><strong>Email:</strong> $email</p>
             <p><strong>Subject:</strong> $subject</p>
             <p><strong>Message:</strong><br>$message</p>";

    if (wp_mail($to, $subject, $body, $headers)) {
        wp_send_json_success(['message' => 'Thank you! Your message has been sent.']);
    } else {
        wp_send_json_error(['message' => 'Failed to send email.']);
    }
}

// ------------------------------
// 4. SHORTCODE
// ------------------------------
add_shortcode('alcx_contact_form', 'alcx_contact_form_shortcode');
function alcx_contact_form_shortcode() {
    ob_start(); ?>

    <form id="alcx-contact-form">
        <?php wp_nonce_field('alcx_contact_nonce', 'alcx_nonce'); ?>
        <input type="hidden" name="action" value="alcx_contact_submit">

        <div class="row g-3">
            <div class="col-6">
                <input type="text" name="name" class="form-control p-3 rounded-3" placeholder="Your Name" required>
            </div>
            <div class="col-6">
                <input type="email" name="email" class="form-control p-3 rounded-3" placeholder="Your Email" required>
            </div>
        </div>

        <div class="mt-3">
            <input type="text" name="subject" class="form-control p-3 rounded-3" placeholder="Subject" required>
        </div>

        <div class="mt-3">
            <textarea name="message" class="form-control p-3 rounded-3" rows="5" placeholder="Message" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary mt-4 px-4 py-3 rounded-3 fw-bold">Send Message</button>
    </form>

    <!-- Modal -->
    <div class="modal fade" id="alcxContactModal" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4">
          <div class="modal-header">
            <h5 class="modal-title fw-bold">Message Status</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body"></div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary rounded-3" data-bs-dismiss="modal">OK</button>
          </div>
        </div>
      </div>
    </div>

    <?php
    return ob_get_clean();
}
