<?php
/**
 * Plugin Name: Animated Pro Slider
 * Plugin URI: https://adinapervaiz.weebly.com
 * Description: Professional responsive slider with text and shape animations
 * Version: 1.0.3
 * Author: Adina Pervaiz
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AnimatedProSlider {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('animated_slider', array($this, 'slider_shortcode'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('wp_head', array($this, 'preload_lcp_image'), 1);
    }
    
    // Preload LCP image and add critical inline CSS
    public function preload_lcp_image() {
        ?>
        <link rel="preload" as="image" href="https://aceweb.bh/wp-content/uploads/2025/12/banner1Home_11zon.webp" fetchpriority="high">
        <style id="slider-critical-css">
            /* CRITICAL LCP CSS - Must load before external CSS */
            .animated-pro-slider .slide:first-child,
            .animated-pro-slider .slide:first-child.active {
                opacity: 1 !important;
                visibility: visible !important;
                display: flex !important;
                z-index: 1 !important;
            }
            .animated-pro-slider .slide:first-child .slide-image {
                opacity: 1 !important;
                visibility: visible !important;
            }
            .animated-pro-slider .slide:first-child .slide-title,
            .animated-pro-slider .slide:first-child .slide-description,
            .animated-pro-slider .slide:first-child .slide-button {
                opacity: 1 !important;
                transform: none !important;
                animation: none !important;
                visibility: visible !important;
            }
        </style>
        <?php
    }

    public function enqueue_scripts() {
        wp_enqueue_style('animated-slider-css', plugins_url('css/slider.css', __FILE__), array(), '1.0.3');
        wp_enqueue_script('animated-slider-js', plugins_url('js/slider.js', __FILE__), array('jquery'), '1.0.3', true);
    }
    
    public function slider_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => '1'
        ), $atts);
        
        ob_start();
        ?>
        <div class="animated-pro-slider">
            <div class="slider-wrapper">
                
                <!-- Slide 1 - NO ANIMATIONS FOR FAST LCP -->
                <div class="slide active">
                    <img src="https://aceweb.bh/wp-content/uploads/2025/12/banner1Home_11zon.webp"
                         width="1920"
                         height="809"
                         fetchpriority="high"
                         decoding="async"
                         alt="Grow Faster with Smart Digital Marketing"
                         class="slide-image">

                    <div class="slide-content">
                        <div class="shape shape-circle"></div>
                        <div class="shape shape-triangle"></div>
                        <div class="shape shape-square"></div>
                        
                        <div class="text-content">
                            <h1 class="slide-title">Grow Faster with Smart Digital Marketing</h1>
                            <p class="slide-description">No.1 Digital Marketing Services in BAHRAIN</p>
                            <p class="slide-description">From SEO and Google Ads to social media campaigns, we help Bahrain businesses get real results.</p>
                            <a href="#contact" class="slide-button">Boost your online presence</a>
                        </div>
                    </div>
                </div>
                
                <!-- Slide 2 -->
                <div class="slide">
                    <img src="https://aceweb.bh/wp-content/uploads/2025/12/banner2Home_11zon.webp"
                         width="1920"
                         height="809"
                         fetchpriority="low"
                         loading="lazy"
                         decoding="async"
                         alt="Complete Branding & IT Solutions"
                         class="slide-image">
                    <div class="slide-content">
                        <div class="shape shape-circle"></div>
                        <div class="shape shape-hexagon"></div>
                        <div class="shape shape-square"></div>
                        
                        <div class="text-content">
                            <h2 class="slide-title" data-animation="slideInLeft">Complete Branding & IT Solutions for Bahrain Businesses</h2>
                            <p class="slide-description" data-animation="slideInLeft" data-delay="200">Business Branding and IT Solutions in BAHRAIN</p>
                            <p class="slide-description" data-animation="slideInLeft" data-delay="200">Create a powerful brand identity and streamline operations with our IT and cloud solutions.</p>
                            <a href="#services" class="slide-button" data-animation="slideInLeft" data-delay="400">Learn More</a>
                        </div>
                    </div>
                </div>
                
                <!-- Slide 3 -->
                <div class="slide">
                    <img src="https://aceweb.bh/wp-content/uploads/2025/12/Banner3Home_11zon.webp"
                         width="1920"
                         height="809"
                         fetchpriority="low"
                         loading="lazy"
                         decoding="async"
                         alt="Build a Stunning Website"
                         class="slide-image">          
                    <div class="slide-content">
                        <div class="shape shape-circle"></div>
                        <div class="shape shape-triangle"></div>
                        <div class="shape shape-pentagon"></div>
                        
                        <div class="text-content">
                            <h2 class="slide-title" data-animation="zoomIn">Build a Stunning Website That Converts</h2>
                            <p class="slide-description" data-animation="zoomIn" data-delay="200">No. 1 Web Development and Design in Bahrain</p>
                            <p class="slide-description" data-animation="zoomIn" data-delay="200">Professional Website in Dubai with SEO, speed and mobile-first design at its core</p>
                            <a href="#portfolio" class="slide-button" data-animation="zoomIn" data-delay="400">Start your website today</a>
                        </div>
                    </div>
                </div>
                
            </div>
            
            <!-- Navigation -->
            <button class="slider-nav prev" aria-label="Previous slide">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
            </button>
            <button class="slider-nav next" aria-label="Next slide">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
            </button>
            
            <!-- Pagination Dots -->
            <div class="slider-pagination">
                <span class="dot active" data-slide="0"></span>
                <span class="dot" data-slide="1"></span>
                <span class="dot" data-slide="2"></span>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'Animated Pro Slider',
            'Pro Slider',
            'manage_options',
            'animated-pro-slider',
            array($this, 'admin_page'),
            'dashicons-images-alt2'
        );
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Animated Pro Slider</h1>
            <p>Use shortcode: <code>[animated_slider]</code></p>
            <p><strong>Version 1.0.3</strong> - Optimized for Core Web Vitals</p>
            <p><strong>Features:</strong></p>
            <ul>
                <li>✅ LCP optimized - First slide loads instantly</li>
                <li>✅ Preloading enabled for hero image</li>
                <li>✅ Critical CSS inline in head</li>
                <li>✅ Lazy loading for slides 2 and 3</li>
            </ul>
        </div>
        <?php
    }
}

new AnimatedProSlider();