<?php
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! function_exists('td_register_shortcodes') ) :

function td_register_shortcodes() {
    add_shortcode('tutor_directory', 'td_render_tutor_directory');
}
add_action('init', 'td_register_shortcodes');

function td_render_tutor_directory($atts) {

    // Get subject terms from taxonomy
    $terms = get_terms([
        'taxonomy' => 'subject', // Replace with your taxonomy slug
        'hide_empty' => true,
    ]);

    ob_start();
    ?>

    <div class="td-filter-wrapper" style="margin-bottom: 20px;">
        <select id="td-subject-filter" style="padding:8px 12px;">
            <option value="">All Subjects</option>
            <?php if ( ! is_wp_error($terms) && ! empty($terms) ) : ?>
                <?php foreach ( $terms as $term ) : ?>
                    <option value="<?php echo esc_attr($term->slug); ?>"><?php echo esc_html($term->name); ?></option>
                <?php endforeach; ?>
            <?php endif; ?>
        </select>
    </div>

    <div id="td-tutor-results">
        <!-- Tutors will appear here -->
    </div>

    <?php
    return ob_get_clean();
}
endif;
