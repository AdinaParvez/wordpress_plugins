<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function td_tutor_meta_boxes() {
    add_meta_box(
        'tutor_details',
        'Tutor Details',
        'td_tutor_fields_callback',
        'tutor',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'td_tutor_meta_boxes');

function td_tutor_fields_callback($post) {
    $fields = [
        'qualification' => 'Qualifications',
        'experience'    => 'Teaching Experience',
        'results'       => 'Results / Achievements',
        'languages'     => 'Languages Spoken',
        'map_iframe'    => 'Google Map iframe',
    ];

    foreach ($fields as $key => $label) {
        $value = get_post_meta($post->ID, $key, true);
        echo "<p><strong>$label</strong><br>";
        echo "<textarea style='width:100%;min-height:60px' name='$key'>$value</textarea></p>";
    }
}

function td_save_tutor_fields($post_id) {
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;

    $keys = ['qualification','experience','results','languages','map_iframe'];
    foreach ($keys as $key) {
        if ( isset($_POST[$key]) ) {
            update_post_meta($post_id, $key, sanitize_textarea_field($_POST[$key]));
        }
    }
}
add_action('save_post', 'td_save_tutor_fields');
