<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function td_register_taxonomies() {

    register_taxonomy('subject', 'tutor', [
        'label' => 'Subjects',
        'hierarchical' => true,
        'show_in_rest' => true,
    ]);

    register_taxonomy('programme', 'tutor', [
        'label' => 'Programmes',
        'hierarchical' => true,
        'show_in_rest' => true,
    ]);

    register_taxonomy('location', 'tutor', [
        'label' => 'Locations',
        'hierarchical' => true,
        'show_in_rest' => true,
    ]);
}
add_action('init', 'td_register_taxonomies');
