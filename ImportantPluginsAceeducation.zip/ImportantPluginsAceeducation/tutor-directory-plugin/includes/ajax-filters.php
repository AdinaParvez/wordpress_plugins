<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function td_ajax_filter_tutors() {
    $filters = [
        'subject'   => sanitize_text_field($_POST['subject']),
        'programme' => sanitize_text_field($_POST['programme']),
        'location'  => sanitize_text_field($_POST['location']),
    ];

    echo td_render_tutors($filters);
    wp_die();
}
add_action('wp_ajax_td_filter', 'td_ajax_filter_tutors');
add_action('wp_ajax_nopriv_td_filter', 'td_ajax_filter_tutors');
