<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function td_register_tutor_cpt() {
    register_post_type('tutor', [
        'labels' => [
            'name' => 'Tutors',
            'singular_name' => 'Tutor',
        ],
        'public' => true,
        'has_archive' => true,
        'rewrite' => ['slug' => 'tutor'],
        'menu_icon' => 'dashicons-welcome-learn-more',
        'supports' => ['title', 'editor', 'thumbnail'],
        'show_in_rest' => true,
    ]);
}
add_action('init', 'td_register_tutor_cpt');
