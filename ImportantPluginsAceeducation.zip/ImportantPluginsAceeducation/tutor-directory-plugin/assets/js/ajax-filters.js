jQuery(document).ready(function($) {

    // Function to perform AJAX filtering
    function tdFilterTutors() {
        var subject = $('#td-subject-filter').val(); // Example: select dropdown with ID

        $.ajax({
            url: td_ajax.ajaxurl,
            type: 'POST',
            data: {
                action: 'td_filter',
                nonce: td_ajax.nonce,
                subject: subject
            },
            beforeSend: function() {
                $('#td-tutor-results').html('<p>Loading tutors...</p>');
            },
            success: function(response) {
                $('#td-tutor-results').html(response);
            },
            error: function() {
                $('#td-tutor-results').html('<p>Unable to fetch tutors. Please try again.</p>');
            }
        });
    }

    // Trigger filter on change
    $('#td-subject-filter').on('change', tdFilterTutors);

    // Optional: trigger filter on page load to show all tutors
    tdFilterTutors();

});
