<?php
/**
 * Plugin Name: Tutor Directory
 * Description: Lightweight tutor management system with filters & profiles.
 * Version: 1.1.0
 * Author: Adina Pervaiz
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'TutorDirectory' ) ) :

class TutorDirectory {

    // Plugin paths
    const PATH = __DIR__ . '/';
    const URL  = '';

    public function __construct() {
        // Define plugin URL
        define( 'TD_URL', plugin_dir_url( __FILE__ ) );

        // Includes
        $this->includes();

        // Hooks
        add_filter('template_include', [$this, 'load_templates']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_td_filter', [$this, 'ajax_filter']);
        add_action('wp_ajax_nopriv_td_filter', [$this, 'ajax_filter']);
    }

    /**
     * Include required files
     */
    private function includes() {
        $includes = [
            'includes/cpt-tutor.php',
            'includes/taxonomies.php',
            'includes/meta-fields.php',
            'includes/shortcodes.php',
            'includes/ajax-filters.php',
        ];

        foreach ($includes as $file) {
            $path = self::PATH . $file;
            if ( file_exists($path) ) {
                require_once $path;
            }
        }
    }

    /**
     * Load plugin templates
     */
    public function load_templates( $template ) {
        if ( is_post_type_archive('tutor') ) {
            $plugin_template = self::PATH . 'templates/archive-tutor.php';
            $theme_template = locate_template(['archive-tutor.php']);
            return $theme_template ?: ( file_exists($plugin_template) ? $plugin_template : $template );
        }

        if ( is_singular('tutor') ) {
            $plugin_template = self::PATH . 'templates/single-tutor.php';
            $theme_template = locate_template(['single-tutor.php']);
            return $theme_template ?: ( file_exists($plugin_template) ? $plugin_template : $template );
        }

        return $template;
    }

    /**
     * Enqueue scripts and styles
     */
    public function enqueue_assets() {
        wp_enqueue_style('td-style', TD_URL . 'assets/css/style.css', [], '1.0.0');
        wp_enqueue_script('td-ajax', TD_URL . 'assets/js/ajax-filters.js', ['jquery'], '1.0.0', true);

        wp_localize_script('td-ajax', 'td_ajax', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('td_ajax_nonce')
        ]);
    }

    /**
     * Handle AJAX filters securely
     */
   public function ajax_filter() {
    check_ajax_referer('td_ajax_nonce', 'nonce');

    $subject = isset($_POST['subject']) ? sanitize_text_field($_POST['subject']) : '';

    $args = [
        'post_type' => 'tutor',
        'posts_per_page' => -1,
        'meta_query' => [],
    ];

    if ( $subject ) {
        $args['tax_query'] = [
            [
                'taxonomy' => 'subject',
                'field'    => 'slug',
                'terms'    => $subject,
            ]
        ];
    }

    $query = new WP_Query($args);

    if ( $query->have_posts() ) :
        echo '<div class="td-tutor-grid">';
        while ( $query->have_posts() ) : $query->the_post();

            $photo = get_the_post_thumbnail_url(get_the_ID(), 'medium') ?: TD_URL . 'assets/images/default-tutor.jpg';
            $subjects = get_the_terms(get_the_ID(), 'subject');
            $subject_names = $subjects && !is_wp_error($subjects) ? implode(', ', wp_list_pluck($subjects, 'name')) : '';

            ?>
            <div class="td-tutor-card">
                <div class="td-tutor-photo">
                    <img src="<?php echo esc_url($photo); ?>" alt="<?php the_title_attribute(); ?>">
                </div>
                <div class="td-tutor-info">
                    <h3 class="td-tutor-name"><?php the_title(); ?></h3>
                    <p class="td-tutor-subject"><?php echo esc_html($subject_names); ?></p>
                    <a href="<?php the_permalink(); ?>" class="td-tutor-btn">View Profile</a>
                </div>
            </div>
            <?php

        endwhile;
        echo '</div>';
        wp_reset_postdata();
    else :
        echo '<div class="td-no-results">No tutors found.</div>';
    endif;

    wp_die();
}

}

new TutorDirectory();

endif;
