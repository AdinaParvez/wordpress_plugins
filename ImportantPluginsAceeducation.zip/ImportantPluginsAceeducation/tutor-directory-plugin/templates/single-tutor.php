<?php get_header(); ?>
<main class="td-single">
    <h1><?php the_title(); ?></h1>
    <?php the_post_thumbnail('large'); ?>

    <section>
        <h3>Qualifications</h3>
        <p><?= get_post_meta(get_the_ID(),'qualification',true); ?></p>

        <h3>Teaching Experience</h3>
        <p><?= get_post_meta(get_the_ID(),'experience',true); ?></p>

        <h3>Results</h3>
        <p><?= get_post_meta(get_the_ID(),'results',true); ?></p>

        <h3>Languages Spoken</h3>
        <p><?= get_post_meta(get_the_ID(),'languages',true); ?></p>

        <?php if ($map = get_post_meta(get_the_ID(),'map_iframe',true)) : ?>
            <div class="td-map"><?= $map; ?></div>
        <?php endif; ?>
    </section>
</main>
<?php get_footer(); ?>
