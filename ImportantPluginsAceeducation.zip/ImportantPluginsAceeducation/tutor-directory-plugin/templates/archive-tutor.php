<?php
get_header(); ?>

<main class="td-archive-wrap">

  <header class="td-archive-header">
    <h1>Our Tutors</h1>
    <p>Find the right tutor by subject, programme, and location.</p>
  </header>

  <section class="td-archive-content">
    <?php echo do_shortcode('[tutor_list]'); ?>
  </section>

</main>

<?php get_footer();
