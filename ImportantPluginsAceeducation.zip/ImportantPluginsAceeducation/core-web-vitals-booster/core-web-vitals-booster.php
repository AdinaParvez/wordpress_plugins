<?php
/*
Plugin Name: Core Web Vitals Booster
Description: Improves LCP and FCP by deferring JS, optimizing CSS delivery, enabling caching headers, and lazy-loading images, while preserving accessibility.
Version: 1.1
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

// ===================================
// ✅ 1. Defer Non-Critical JavaScript (Accessibility Safe)
// ===================================
add_filter('script_loader_tag', function($tag, $handle, $src) {
    if (is_admin()) return $tag;

    // ✅ Accessibility Safeguard: skip scripts that reference ARIA or accessibility code
    $a11y_keywords = ['aria-', 'accessibility', 'screenreader', 'voiceover', 'a11y'];
    foreach ($a11y_keywords as $keyword) {
        if (stripos($handle, $keyword) !== false || stripos($src, $keyword) !== false) {
            return $tag; // don’t defer accessibility-related scripts
        }
    }

    // Don’t defer jQuery or admin scripts
    if (strpos($src, 'jquery') !== false) return $tag;
    if (strpos($src, 'admin') !== false) return $tag;

    // Add defer attribute for all other front-end scripts
    return str_replace(' src', ' defer src', $tag);
}, 10, 3);

// ===================================
// ✅ 2. Load CSS Asynchronously (print media trick)
// ===================================
add_filter('style_loader_tag', function($html, $handle, $href, $media) {
    if (is_admin()) return $html;
    return str_replace(
        "rel='stylesheet'",
        "rel='stylesheet' media='print' onload=\"this.media='all'\"",
        $html
    );
}, 10, 4);

// ===================================
// ✅ 3. Enable Lazy Loading Globally
// ===================================
add_filter('wp_lazy_loading_enabled', '__return_true');

// ===================================
// ✅ 4. Add Browser Cache Headers
// ===================================
add_action('send_headers', function() {
    if (!is_admin()) {
        header('Cache-Control: public, max-age=2592000, immutable');
    }
});

// ===================================
// ✅ 5. Delay Third-Party Scripts
// ===================================
add_action('wp_footer', function() { ?>
<script>
setTimeout(function(){
    // Delay heavy third-party scripts
    const fb = document.createElement('script');
    fb.src = "https://connect.facebook.net/en_US/fbevents.js";
    document.body.appendChild(fb);
}, 4000);
</script>
<?php });

// ===================================
// ✅ 6. Safety Notice in Admin
// ===================================
add_action('admin_notices', function() {
    echo '<div class="notice notice-success is-dismissible"><p><strong>Core Web Vitals Booster Active:</strong> JS deferred, CSS async, lazy loading, and cache headers enabled — with accessibility safeguards!</p></div>';
});
