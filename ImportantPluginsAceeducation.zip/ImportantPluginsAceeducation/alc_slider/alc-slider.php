<?php
/**
 * Plugin Name: ALC Slider
 * Description: Custom slider with Owl Carousel. Assign slides to sliders via meta box.
 * Version: 1.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) exit;

/**
 * Register Custom Post Type: Sliders
 */
function alc_register_slider_cpt() {
    register_post_type('alc_slider', array(
        'label' => 'Sliders',
        'public' => true,
        'supports' => array('title'),
        'menu_icon' => 'dashicons-images-alt2',
    ));

    register_post_type('alc_slide', array(
        'label' => 'Slides',
        'public' => true,
        'supports' => array('title', 'thumbnail'),
        'menu_icon' => 'dashicons-format-gallery',
    ));
}
add_action('init', 'alc_register_slider_cpt');

/**
 * Add Meta Box for assigning slide → slider
 */
function alc_slide_metabox() {
    add_meta_box(
        'alc_slide_slider_box',
        'Assign to Slider',
        'alc_slide_slider_box_html',
        'alc_slide',
        'side'
    );
}
add_action('add_meta_boxes', 'alc_slide_metabox');

function alc_slide_slider_box_html($post) {
    $value = get_post_meta($post->ID, '_belongs_to_slider', true);
    $sliders = get_posts(array('post_type' => 'alc_slider', 'numberposts' => -1));

    echo '<select name="alc_belongs_to_slider" style="width:100%">';
    echo '<option value="">— Select Slider —</option>';
    foreach ($sliders as $slider) {
        echo '<option value="' . esc_attr($slider->ID) . '" ' . selected($value, $slider->ID, false) . '>'
             . esc_html($slider->post_title) . '</option>';
    }
    echo '</select>';
}

function alc_save_slide_slider($post_id) {
    if (array_key_exists('alc_belongs_to_slider', $_POST)) {
        update_post_meta($post_id, '_belongs_to_slider', intval($_POST['alc_belongs_to_slider']));
    }
}
add_action('save_post_alc_slide', 'alc_save_slide_slider');

/**
 * Enqueue Owl Carousel
 */
function alc_slider_assets() {
    wp_enqueue_style('owl-carousel', get_template_directory_uri() . '/assets/css/owl.carousel.min.css');
    wp_enqueue_script('owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'alc_slider_assets');

/**
 * Shortcode: [alc_slider id="123"]
 */
function alc_slider_shortcode($atts) {
    $atts = shortcode_atts(array('id' => ''), $atts, 'alc_slider');
    if (empty($atts['id'])) return '';

    $slides = get_posts(array(
        'post_type'      => 'alc_slide',
        'posts_per_page' => -1,
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        'post_status'    => 'publish',
        'meta_query'     => array(
            array(
                'key'   => '_belongs_to_slider',
                'value' => $atts['id']
            )
        )
    ));

    if (!$slides) return '';

    ob_start(); ?>
    <div class="owl-carousel alc-slider">
        <?php foreach ($slides as $slide): 
            $title    = get_the_title($slide->ID);
            $subtitle = get_post_meta($slide->ID, '_alc_subtitle', true);
            $button   = get_post_meta($slide->ID, '_alc_button_text', true);
            $link     = get_post_meta($slide->ID, '_alc_button_link', true);
            $image    = get_the_post_thumbnail_url($slide->ID, 'full');
        ?>
            <div class="slide-item" style="background-image:url('<?php echo esc_url($image); ?>');">
                <div class="slide-content container">
                    <?php if ($title): ?><h2><?php echo esc_html($title); ?></h2><?php endif; ?>
                    <?php if ($subtitle): ?><p><?php echo esc_html($subtitle); ?></p><?php endif; ?>
                    <?php if ($button && $link): ?>
                        <a href="<?php echo esc_url($link); ?>" class="btn btn-primary"><?php echo esc_html($button); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
    jQuery(document).ready(function($){
        $('.alc-slider').owlCarousel({
            items: 1,
            loop: true,
            autoplay: true,
            autoplayTimeout: 5000,
            dots: true,
            nav: true
        });
    });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('alc_slider', 'alc_slider_shortcode');
