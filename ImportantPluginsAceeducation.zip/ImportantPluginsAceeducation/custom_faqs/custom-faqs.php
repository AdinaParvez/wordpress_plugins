<?php
/*
Plugin Name: Custom FAQs
Description: Bootstrap-compatible FAQ accordion with Admin CPT and settings page.
Version: 2.5
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

// ======================
// Enqueue CSS + JS
// ======================
function custom_faqs_enqueue_assets() {
    wp_enqueue_style(
        'custom-faqs-style',
        plugin_dir_url(__FILE__) . 'assets/css/custom-faqs.css',
        array(),
        '2.5'
    );

    wp_enqueue_script(
        'custom-faqs-script',
        plugin_dir_url(__FILE__) . 'assets/js/custom-faqs.js',
        array('jquery'),
        '2.5',
        true
    );
}
add_action('wp_enqueue_scripts', 'custom_faqs_enqueue_assets');

// ======================
// Register CPT + Taxonomy
// ======================
function custom_faqs_register_cpt() {
    register_post_type('faq', array(
        'labels' => array(
            'name' => 'FAQs',
            'singular_name' => 'FAQ',
            'add_new_item' => 'Add New FAQ',
            'edit_item' => 'Edit FAQ',
        ),
        'public' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-editor-help',
        'supports' => array('title', 'editor'),
    ));

    register_taxonomy('faq_category', 'faq', array(
        'labels' => array(
            'name' => 'FAQ Categories',
            'singular_name' => 'FAQ Category',
        ),
        'public' => true,
        'hierarchical' => true,
        'show_admin_column' => true,
    ));
}
add_action('init', 'custom_faqs_register_cpt');

// ======================
// Settings Page
// ======================
function custom_faqs_register_settings() {
    register_setting('custom_faqs_settings_group', 'custom_faqs_default_state');
    register_setting('custom_faqs_settings_group', 'custom_faqs_limit');
    register_setting('custom_faqs_settings_group', 'custom_faqs_show_controls');
}
add_action('admin_init', 'custom_faqs_register_settings');

function custom_faqs_add_settings_page() {
    add_submenu_page(
        'edit.php?post_type=faq',
        'FAQ Settings',
        'Settings',
        'manage_options',
        'custom-faqs-settings',
        'custom_faqs_render_settings_page'
    );
}
add_action('admin_menu', 'custom_faqs_add_settings_page');

function custom_faqs_render_settings_page() { ?>
    <div class="wrap">
        <h1>FAQ Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('custom_faqs_settings_group'); ?>
            <?php do_settings_sections('custom_faqs_settings_group'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">Default State</th>
                    <td>
                        <select name="custom_faqs_default_state">
                            <option value="collapsed" <?php selected(get_option('custom_faqs_default_state', 'collapsed'), 'collapsed'); ?>>Collapsed</option>
                            <option value="expanded" <?php selected(get_option('custom_faqs_default_state'), 'expanded'); ?>>Expanded</option>
                        </select>
                        <p class="description">Choose if FAQs load collapsed or expanded by default.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">Number of FAQs per Category</th>
                    <td>
                        <input type="number" name="custom_faqs_limit" value="<?php echo esc_attr(get_option('custom_faqs_limit', -1)); ?>" />
                        <p class="description">Enter -1 to show all FAQs.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">Expand/Collapse Buttons</th>
                    <td>
                        <input type="checkbox" name="custom_faqs_show_controls" value="1" <?php checked(get_option('custom_faqs_show_controls', 1), 1); ?> />
                        <label for="custom_faqs_show_controls">Show Expand All / Collapse All buttons</label>
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>
    </div>
<?php }

// ======================
// Shortcode [custom_faqs]
// ======================

// Inside your plugin's shortcode handler
function render_custom_faqs_shortcode($atts) {
    ob_start();

    // Extract shortcode attributes
    $atts = shortcode_atts([
        'grouped' => 'false',
        'limit'   => -1,
        'category'=> ''
    ], $atts);

    echo '<div class="custom-faqs-wrapper">'; // ✅ Add wrapper here

    if ($atts['grouped'] === 'true') {
        // Grouped by category
        $categories = get_terms([
            'taxonomy' => 'faq_category',
            'hide_empty' => true,
        ]);

        foreach ($categories as $cat) {
            echo '<div class="custom-faqs-accordion">';
            echo '<h3 class="faq-category-title">' . esc_html($cat->name) . '</h3>';

            // Expand/Collapse controls
            echo '<div class="custom-faqs-controls">';
            echo '<button type="button" class="expand-all">Expand All</button>';
            echo '<button type="button" class="collapse-all">Collapse All</button>';
            echo '</div>';

            // FAQs for this category
            $faqs = new WP_Query([
                'post_type' => 'faq',
                'posts_per_page' => $atts['limit'],
                'tax_query' => [[
                    'taxonomy' => 'faq_category',
                    'field' => 'slug',
                    'terms' => $cat->slug,
                ]]
            ]);

            if ($faqs->have_posts()) {
                echo '<div class="accordion">';
                while ($faqs->have_posts()) {
                    $faqs->the_post();
                    $faq_id = get_the_ID();
                    ?>
                    <div class="faq-item accordion-item">
                        <h2 class="accordion-header" id="heading-<?php echo $faq_id; ?>">
                            <button class="faq-question accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo $faq_id; ?>" aria-expanded="false" aria-controls="collapse-<?php echo $faq_id; ?>">
                                <?php the_title(); ?>
                            </button>
                        </h2>
                        <div id="collapse-<?php echo $faq_id; ?>" class="faq-answer accordion-collapse collapse" aria-labelledby="heading-<?php echo $faq_id; ?>">
                            <div class="accordion-body">
                                <?php the_content(); ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                echo '</div>';
            }
            wp_reset_postdata();
            echo '</div>';
        }
    }

    echo '</div>'; // ✅ Close wrapper

    return ob_get_clean();
}

add_shortcode('custom_faqs', 'render_custom_faqs_shortcode');

