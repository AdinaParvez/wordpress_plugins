document.addEventListener("DOMContentLoaded", function () {
  var accordions = document.querySelectorAll(".custom-faqs-accordion");
  if (!accordions.length) return;

  accordions.forEach(function (acc) {
    var questions = acc.querySelectorAll(".faq-question");

    questions.forEach(function (q) {
      q.addEventListener("click", function () {
        var answer = this.nextElementSibling;
        var icon = this.querySelector(".faq-icon");

        // Close others in the same accordion
        acc.querySelectorAll(".faq-answer").forEach(function (a) {
          if (a !== answer) a.classList.remove("show");
        });
        acc.querySelectorAll(".faq-question").forEach(function (btn) {
          if (btn !== q) {
            btn.setAttribute("aria-expanded", "false");
            var otherIcon = btn.querySelector(".faq-icon");
            if (otherIcon) otherIcon.textContent = "+";
          }
        });

        var expanded = this.getAttribute("aria-expanded") === "true";
        this.setAttribute("aria-expanded", (!expanded).toString());
        answer.classList.toggle("show");
        icon.textContent = expanded ? "+" : "–";
      });
    });
  });
});
