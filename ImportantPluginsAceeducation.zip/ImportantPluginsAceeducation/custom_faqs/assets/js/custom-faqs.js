document.addEventListener("DOMContentLoaded", function () {
    if (typeof bootstrap === "undefined") {
        console.warn("Bootstrap JS not found. FAQ toggle may not work.");
        return;
    }

    // Handle individual toggle + scroll
    document.querySelectorAll(".faq-answer").forEach((faq) => {
        faq.addEventListener("shown.bs.collapse", function () {
            faq.scrollIntoView({ behavior: "smooth", block: "start" });
        });
    });

    // Expand All
    document.querySelectorAll(".expand-all").forEach((btn) => {
        btn.addEventListener("click", () => {
            const section = btn.closest(".custom-faqs-accordion");
            section.querySelectorAll(".faq-answer").forEach((faq) => {
                if (!faq.classList.contains("show")) {
                    new bootstrap.Collapse(faq, { toggle: true }).show();
                }
            });
        });
    });

    // Collapse All
    document.querySelectorAll(".collapse-all").forEach((btn) => {
        btn.addEventListener("click", () => {
            const section = btn.closest(".custom-faqs-accordion");
            section.querySelectorAll(".faq-answer.show").forEach((faq) => {
                new bootstrap.Collapse(faq, { toggle: true }).hide();
            });
        });
    });
});
