jQuery(document).ready(function ($) {

    // Upload image
    $(document).on('click', '.upload-image', function (e) {
        e.preventDefault();

        const button = $(this);
        const input = button.prev('.image-url');

        const frame = wp.media({
            title: 'Select Image',
            button: { text: 'Use this image' },
            multiple: false
        });

        frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();
            input.val(attachment.url);
        });

        frame.open();
    });

    // Add new slide
    $('#add-slide').on('click', function (e) {
        e.preventDefault();

        const count = $('#slider-table tbody tr').length;

        const row = `
        <tr>
            <td>
                <input type="text" name="tuition_slider_slides[${count}][image]" class="regular-text image-url">
                <button class="button upload-image">Upload</button>
            </td>
            <td><input type="text" name="tuition_slider_slides[${count}][title]"></td>
            <td><input type="text" name="tuition_slider_slides[${count}][subtitle]"></td>
            <td><input type="text" name="tuition_slider_slides[${count}][button_text]"></td>
            <td><input type="url" name="tuition_slider_slides[${count}][button_url]"></td>
            <td><button class="button remove-row">✕</button></td>
        </tr>`;

        $('#slider-table tbody').append(row);
    });

    // Remove slide
    $(document).on('click', '.remove-row', function (e) {
        e.preventDefault();
        $(this).closest('tr').remove();
    });

});
        