// High-Performance Slider - Optimized for Core Web Vitals
(function() {
    'use strict';
    
    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initSlider);
    } else {
        initSlider();
    }
    
    function initSlider() {
        const sliders = document.querySelectorAll('.tuition-slider');
        
        sliders.forEach(slider => {
            new Slider(slider);
        });
    }
    
    class Slider {
        constructor(element) {
            this.slider = element;
            this.slides = Array.from(element.querySelectorAll('.slide'));
            this.dots = Array.from(element.querySelectorAll('.dot'));
            this.prevBtn = element.querySelector('.prev');
            this.nextBtn = element.querySelector('.next');
            
            this.currentSlide = 0;
            this.autoplay = element.dataset.autoplay === 'true';
            this.interval = parseInt(element.dataset.interval) || 5000;
            this.autoplayTimer = null;
            
            this.init();
        }
        
        init() {
            // Lazy load images
            this.lazyLoadImages();
            
            // Event listeners
            this.prevBtn.addEventListener('click', () => this.prev());
            this.nextBtn.addEventListener('click', () => this.next());
            
            this.dots.forEach((dot, index) => {
                dot.addEventListener('click', () => this.goToSlide(index));
            });
            
            // Keyboard navigation
            this.slider.addEventListener('keydown', (e) => {
                if (e.key === 'ArrowLeft') this.prev();
                if (e.key === 'ArrowRight') this.next();
            });
            
            // Pause on hover
            this.slider.addEventListener('mouseenter', () => this.pause());
            this.slider.addEventListener('mouseleave', () => this.resume());
            
            // Start autoplay
            if (this.autoplay) {
                this.startAutoplay();
            }
            
            // Visibility API - pause when tab is hidden
            document.addEventListener('visibilitychange', () => {
                if (document.hidden) {
                    this.pause();
                } else if (this.autoplay) {
                    this.resume();
                }
            });
        }
        
        lazyLoadImages() {
            const lazyImages = this.slider.querySelectorAll('img.lazy-load');
            
            if ('IntersectionObserver' in window) {
                const imageObserver = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const img = entry.target;
                            img.src = img.dataset.src;
                            img.classList.remove('lazy-load');
                            imageObserver.unobserve(img);
                        }
                    });
                });
                
                lazyImages.forEach(img => imageObserver.observe(img));
            } else {
                // Fallback for older browsers
                lazyImages.forEach(img => {
                    img.src = img.dataset.src;
                    img.classList.remove('lazy-load');
                });
            }
        }
        
        goToSlide(index) {
            // Remove active classes
            this.slides[this.currentSlide].classList.remove('active');
            this.dots[this.currentSlide].classList.remove('active');
            
            // Update current slide
            this.currentSlide = index;
            
            // Add active classes
            this.slides[this.currentSlide].classList.add('active');
            this.dots[this.currentSlide].classList.add('active');
            
            // Reset autoplay
            if (this.autoplay) {
                this.resetAutoplay();
            }
        }
        
        next() {
            const nextSlide = (this.currentSlide + 1) % this.slides.length;
            this.goToSlide(nextSlide);
        }
        
        prev() {
            const prevSlide = (this.currentSlide - 1 + this.slides.length) % this.slides.length;
            this.goToSlide(prevSlide);
        }
        
        startAutoplay() {
            this.autoplayTimer = setInterval(() => this.next(), this.interval);
        }
        
        pause() {
            if (this.autoplayTimer) {
                clearInterval(this.autoplayTimer);
                this.autoplayTimer = null;
            }
        }
        
        resume() {
            if (this.autoplay && !this.autoplayTimer) {
                this.startAutoplay();
            }
        }
        
        resetAutoplay() {
            this.pause();
            this.startAutoplay();
        }
    }
})();