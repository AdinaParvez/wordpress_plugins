<?php
/**
 * Plugin Name: Tuition Center Slider
 * Plugin URI: https://github/adinapervaiz.com
 * Description: High-performance slider optimized for Core Web Vitals with auto-scroll and lazy loading
 * Version: 1.0
 * Author: Adina Pervaiz
 * Author URI: https://adinapervaiz.weebly.com
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class TuitionCenterSlider {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_shortcode('tuition_slider', array($this, 'slider_shortcode'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));

    }
    public function enqueue_admin_assets($hook) {

    // Load only on your plugin page
    if ($hook !== 'toplevel_page_tuition-slider') {
        return;
    }

    wp_enqueue_media();

    wp_enqueue_script(
        'tuition-slider-admin-js',
        plugins_url('js/admin-slider.js', __FILE__),
        array('jquery'),
        '1.0.0',
        true
    );
}

public function sanitize_slides($slides) {
    if (!is_array($slides)) {
        return [];
    }

    foreach ($slides as &$slide) {
        $slide['image'] = esc_url_raw($slide['image'] ?? '');
        $slide['title'] = sanitize_text_field($slide['title'] ?? '');
        $slide['subtitle'] = sanitize_text_field($slide['subtitle'] ?? '');
        $slide['button_text'] = sanitize_text_field($slide['button_text'] ?? '');
        $slide['button_url'] = esc_url_raw($slide['button_url'] ?? '');
    }

    return $slides;
}


    // Enqueue CSS and JS
 public function enqueue_assets() {
    global $post;

    if (!is_singular() || !$post || !has_shortcode($post->post_content, 'tuition_slider')) {
        return;
    }

    wp_enqueue_style(
        'tuition-slider-css',
        plugins_url('css/slider.css', __FILE__),
        array(),
        '1.0.0'
    );

    wp_enqueue_script(
        'tuition-slider-js',
        plugins_url('js/slider.js', __FILE__),
        array(),
        '1.0.0',
        true
    );
}


    
    // Slider shortcode
    public function slider_shortcode($atts) {
        $atts = shortcode_atts(array(
            'autoplay' => 'true',
            'interval' => '5000',
            'height' => '600'
        ), $atts);
        
        // Get slider images from settings
        $slides = get_option('tuition_slider_slides', $this->get_default_slides());
        
        ob_start();
        ?>
        <div class="tuition-slider" 
             data-autoplay="<?php echo esc_attr($atts['autoplay']); ?>"
             data-interval="<?php echo esc_attr($atts['interval']); ?>"
             style="--slider-height: <?php echo esc_attr($atts['height']); ?>px;">
            
            <div class="slider-wrapper">
                <?php foreach ($slides as $index => $slide) : ?>
                    <div class="slide <?php echo $index === 0 ? 'active' : ''; ?>" data-slide="<?php echo $index; ?>">
                        <?php if ($index === 0) : ?>
                            <!-- First image loads immediately -->
                            <img 
                                src="<?php echo esc_url($slide['image']); ?>" 
                                alt="<?php echo esc_attr($slide['title']); ?>"
                                width="1920"
                                height="600"
                                fetchpriority="high"
                            >
                        <?php else : ?>
                            <!-- Other images lazy load -->
                            <img 
                                data-src="<?php echo esc_url($slide['image']); ?>" 
                                alt="<?php echo esc_attr($slide['title']); ?>"
                                width="1920"
                                height="600"
                                loading="lazy"
                                class="lazy-load"
                            >
                        <?php endif; ?>
                        
                        <div class="slide-content">
                            <h2 class="slide-title"><?php echo esc_html($slide['title']); ?></h2>
                            <p class="slide-subtitle"><?php echo esc_html($slide['subtitle']); ?></p>
                            <?php if (!empty($slide['button_text']) && !empty($slide['button_url'])) : ?>
                                <a href="<?php echo esc_url($slide['button_url']); ?>" class="slide-button">
                                    <?php echo esc_html($slide['button_text']); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Navigation Dots -->
            <div class="slider-dots">
                <?php foreach ($slides as $index => $slide) : ?>
                    <button 
                        class="dot <?php echo $index === 0 ? 'active' : ''; ?>" 
                        data-slide="<?php echo $index; ?>"
                        aria-label="Go to slide <?php echo $index + 1; ?>">
                    </button>
                <?php endforeach; ?>
            </div>
            
            <!-- Navigation Arrows -->
            <button class="slider-arrow prev" aria-label="Previous slide">‹</button>
            <button class="slider-arrow next" aria-label="Next slide">›</button>
        </div>
        <?php
        return ob_get_clean();
    }
    
    // Default slides
    private function get_default_slides() {
        return array(
            array(
                'image' => 'https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=1920&h=600&fit=crop',
                'title' => 'Excellence in Education',
                'subtitle' => 'IGCSE, A-Level & GED Programmes in Kuala Lumpur',
                'button_text' => 'Explore Programmes',
                'button_url' => '/programmes'
            ),
            array(
                'image' => 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1920&h=600&fit=crop',
                'title' => 'Expert Tutors',
                'subtitle' => 'Qualified Teachers with Proven Track Records',
                'button_text' => 'Meet Our Tutors',
                'button_url' => '/our-tutors'
            ),
            array(
                'image' => 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=1920&h=600&fit=crop',
                'title' => 'Multiple Test Centres',
                'subtitle' => 'IELTS & PTE Test Centres Across KL',
                'button_text' => 'Find a Centre',
                'button_url' => '/centres'
            ),
            array(
                'image' => 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=1920&h=600&fit=crop',
                'title' => 'Proven Results',
                'subtitle' => 'Outstanding Student Achievements & Success Stories',
                'button_text' => 'View Results',
                'button_url' => '/results'
            )
        );
    }
    
    // Add admin menu
    public function add_admin_menu() {
        add_menu_page(
            'Slider Settings',
            'Tuition Slider',
            'manage_options',
            'tuition-slider',
            array($this, 'settings_page'),
            'dashicons-images-alt2',
            30
        );
    }
    
    // Register settings
    public function register_settings() {
        register_setting(
            'tuition_slider_settings',
            'tuition_slider_slides',
            array($this, 'sanitize_slides')
);

    }
    
    // Settings page
    public function settings_page() {
    $slides = get_option('tuition_slider_slides', $this->get_default_slides());
    ?>
    <div class="wrap">
        <h1>Tuition Slider Settings</h1>

        <form method="post" action="options.php">
            <?php settings_fields('tuition_slider_settings'); ?>

            <table class="widefat" id="slider-table">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Subtitle</th>
                        <th>Button Text</th>
                        <th>Button URL</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($slides as $index => $slide) : ?>
                        <tr>
                            <td>
                                <input type="text" 
                                       name="tuition_slider_slides[<?php echo $index; ?>][image]" 
                                       value="<?php echo esc_attr($slide['image']); ?>" 
                                       class="regular-text image-url">
                                <button type="button" class="button upload-image">Upload</button>
                            </td>
                            <td>
                                <input type="text" 
                                       name="tuition_slider_slides[<?php echo $index; ?>][title]" 
                                       value="<?php echo esc_attr($slide['title']); ?>">
                            </td>
                            <td>
                                <input type="text" 
                                       name="tuition_slider_slides[<?php echo $index; ?>][subtitle]" 
                                       value="<?php echo esc_attr($slide['subtitle']); ?>">
                            </td>
                            <td>
                                <input type="text" 
                                       name="tuition_slider_slides[<?php echo $index; ?>][button_text]" 
                                       value="<?php echo esc_attr($slide['button_text']); ?>">
                            </td>
                            <td>
                                <input type="url" 
                                       name="tuition_slider_slides[<?php echo $index; ?>][button_url]" 
                                       value="<?php echo esc_attr($slide['button_url']); ?>">
                            </td>
                            <td>
                                <button type="button" class="button remove-row">✕</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <br>
           <button type="button" class="button button-primary" id="add-slide">+ Add Slide</button>
            <br><br>

            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

}

// Initialize plugin
new TuitionCenterSlider();