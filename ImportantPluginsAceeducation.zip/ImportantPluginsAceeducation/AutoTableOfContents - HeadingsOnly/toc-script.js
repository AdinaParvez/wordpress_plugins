/**
 * Smart Table of Contents - JavaScript
 * Full Elementor Compatibility
 * Shows ALL heading tags (H1-H6) with jumplinks
 */

(function($) {
    'use strict';
    
    // Global initialization function for Elementor
    window.smartTocInit = function() {
        initAllTOCs();
    };
    
    $(document).ready(function() {
        initAllTOCs();
    });
    
    // Initialize all TOC instances on page
    function initAllTOCs() {
        $('.smart-toc-wrapper').each(function() {
            var $wrapper = $(this);
            var tocId = $wrapper.attr('id');
            
            // Skip if already initialized
            if ($wrapper.data('toc-initialized')) {
                return;
            }
            
            initSingleTOC($wrapper);
            $wrapper.data('toc-initialized', true);
        });
    }
    
    // Initialize a single TOC instance
    function initSingleTOC($wrapper) {
        var depth = parseInt($wrapper.data('depth')) || 6;
        var smoothScroll = $wrapper.data('smooth') === 'yes';
        var showNumbers = $wrapper.data('numbers') === 'yes';
        var $listContainer = $wrapper.find('.smart-toc-list');
        
        var headings = findAllHeadings(depth);
        
        if (headings.length > 0) {
            var tocHtml = buildTocHtml(headings, showNumbers);
            $listContainer.html(tocHtml);
            
            // Add IDs to headings that don't have them
            addHeadingIds(headings);
            
            // Setup event handlers
            setupEventHandlers($wrapper, smoothScroll);
            
            // Initial highlight
            highlightActiveSection($wrapper);
        } else {
            $wrapper.hide();
        }
    }
    
    // Find all headings in the content
    function findAllHeadings(depth) {
        var headings = [];
        var selectors = [];
        
        // Build selector for H1 through H6 based on depth
        for (var i = 1; i <= Math.min(depth, 6); i++) {
            selectors.push('h' + i);
        }
        
        var selectorString = selectors.join(', ');
        
        // Content areas to search (prioritize Elementor, then general content areas)
        var contentSelectors = [
            '.elementor-widget-theme-post-content',
            '.elementor-widget-container',
            '.elementor-section',
            '.entry-content',
            'article',
            'main',
            '.content',
            '.post-content',
            '#content'
        ];
        
        var $searchArea = $(contentSelectors.join(', '));
        
        // If Elementor is present, focus on Elementor sections
        if ($('.elementor').length) {
            $searchArea = $('.elementor');
        }
        
        // Find all matching headings
        $searchArea.find(selectorString).each(function(index) {
            var $heading = $(this);
            
            // Skip headings inside TOC wrapper itself
            if ($heading.closest('.smart-toc-wrapper').length) {
                return;
            }
            
            // Skip headings in Elementor editor/preview elements
            if ($heading.closest('.elementor-editor-active').length ||
                $heading.closest('.elementor-element-edit-mode').length ||
                $heading.closest('.elementor-preview').length) {
                return;
            }
            
            // Skip headings in header/footer/sidebar
            if ($heading.closest('header, footer, .sidebar, aside, nav').length) {
                return;
            }
            
            var level = parseInt(this.nodeName.substring(1));
            var text = $heading.text().trim();
            
            // Skip empty headings
            if (!text || text.length === 0) {
                return;
            }
            
            // Generate clean ID from text
            var baseId = text.toLowerCase()
                .replace(/[^\w\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/--+/g, '-')
                .substring(0, 50);
            
            var id = $heading.attr('id') || 'toc-' + baseId + '-' + index;
            
            headings.push({
                level: level,
                text: text,
                id: id,
                element: $heading
            });
        });
        
        return headings;
    }
    
    // Add IDs to headings
    function addHeadingIds(headings) {
        headings.forEach(function(heading) {
            if (!heading.element.attr('id')) {
                heading.element.attr('id', heading.id);
            }
        });
    }
    
    // Build hierarchical TOC HTML
    function buildTocHtml(items, showNumbers) {
        var html = '';
        var stack = [];
        var minLevel = Math.min.apply(Math, items.map(function(h) { return h.level; }));
        var numbering = showNumbers ? [0] : null;
        
        items.forEach(function(item, index) {
            var relativeLevel = item.level - minLevel;
            
            // Update numbering
            if (showNumbers) {
                while (numbering.length <= relativeLevel) {
                    numbering.push(0);
                }
                while (numbering.length > relativeLevel + 1) {
                    numbering.pop();
                }
                numbering[relativeLevel]++;
                
                var numberStr = numbering.slice(0, relativeLevel + 1).join('.');
            }
            
            // Close nested lists if going back to higher level
            while (stack.length > relativeLevel) {
                html += '</ul></li>';
                stack.pop();
                if (showNumbers && numbering.length > stack.length + 1) {
                    numbering.pop();
                }
            }
            
            // Open new nested list if going deeper
            while (stack.length < relativeLevel) {
                html += '<ul class="smart-toc-sublist">';
                stack.push(relativeLevel);
            }
            
            html += '<li class="toc-level-' + item.level + '">';
            html += '<a href="#' + item.id + '" class="toc-link" data-target="' + item.id + '">';
            
            if (showNumbers) {
                html += '<span class="toc-number">' + numberStr + '</span> ';
            }
            
            html += escapeHtml(item.text);
            html += '</a>';
            
            // Check if next item is deeper
            var nextItem = items[index + 1];
            if (!nextItem || nextItem.level <= item.level) {
                html += '</li>';
            }
        });
        
        // Close remaining nested lists
        while (stack.length > 0) {
            html += '</ul></li>';
            stack.pop();
        }
        
        return html;
    }
    
    // Escape HTML
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }
    
    // Setup event handlers
    function setupEventHandlers($wrapper, smoothScroll) {
        // Toggle button
        $wrapper.find('.smart-toc-toggle').off('click').on('click', function() {
            var $content = $wrapper.find('.smart-toc-content');
            var $icon = $(this).find('.toc-toggle-icon');
            
        $content.slideToggle(250, () => {
        var isExpanded = $content.is(':visible');
        $(this).attr('aria-expanded', isExpanded);
        $icon.html(isExpanded ? '📋 Hide Table of Contents' : '📋 Show Table of Contents');
     });

});

        
        // Link clicks with smooth scroll
        $wrapper.find('.toc-link').off('click').on('click', function(e) {
            e.preventDefault();
            
            var targetId = $(this).data('target');
            var $target = $('#' + targetId);
            
            if ($target.length) {
                var offsetTop = $target.offset().top;
                var scrollOffset = 100; // Offset for fixed headers
                
                // Check for admin bar
                if ($('#wpadminbar').length) {
                    scrollOffset += $('#wpadminbar').outerHeight();
                }
                
                if (smoothScroll) {
                    $('html, body').animate({
                        scrollTop: offsetTop - scrollOffset
                    }, 600, 'swing');
                } else {
                    window.scrollTo(0, offsetTop - scrollOffset);
                }
                
                // Update URL
                if (history.pushState) {
                    history.pushState(null, null, '#' + targetId);
                }
                
                // Focus for accessibility
                $target.attr('tabindex', '-1').focus().removeAttr('tabindex');
                
                // Highlight clicked link
                $wrapper.find('.toc-link').removeClass('active');
                $(this).addClass('active');
            }
        });
    }
    
    // Highlight active section on scroll
    function highlightActiveSection($wrapper) {
        var scrollPos = $(window).scrollTop() + 150;
        var $links = $wrapper.find('.toc-link');
        
        $links.each(function() {
            var targetId = $(this).data('target');
            var $target = $('#' + targetId);
            
            if ($target.length) {
                var targetTop = $target.offset().top;
                var targetBottom = targetTop + $target.outerHeight();
                
                if (scrollPos >= targetTop && scrollPos < targetBottom) {
                    $links.removeClass('active');
                    $(this).addClass('active');
                    return false; // Break loop
                }
            }
        });
    }
    
    // Scroll event with throttling
    var scrollTimeout;
    $(window).on('scroll', function() {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(function() {
            $('.smart-toc-wrapper').each(function() {
                highlightActiveSection($(this));
            });
        }, 100);
    });
    
    // Elementor compatibility - reinitialize on preview refresh
    $(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/widget', function($scope) {
            setTimeout(function() {
                initAllTOCs();
            }, 300);
        });
    });
    
    // Reinitialize after AJAX content loads (for dynamic sites)
    $(document).ajaxComplete(function() {
        setTimeout(initAllTOCs, 500);
    });
    
})(jQuery);