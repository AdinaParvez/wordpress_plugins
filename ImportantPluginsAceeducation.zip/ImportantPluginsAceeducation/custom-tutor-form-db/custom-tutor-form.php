<?php
/*
Plugin Name: Custom Tutor Form
Description: A responsive tutor form that sends email and saves to database.
Version: 2.0
Author: Adina Pervaiz
*/

// Create database table on plugin activation
register_activation_hook(__FILE__, 'cef_create_table');
function cef_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'tutor_form_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        parent_name varchar(255) NOT NULL,
        student_name varchar(255) NOT NULL,
        dob date NOT NULL,
        phone varchar(50) NOT NULL,
        email varchar(255) NOT NULL,
        category varchar(50) NOT NULL,
        school_year varchar(50) NOT NULL,
        preferred_subjects text NOT NULL,
        school_name varchar(255) NOT NULL,
        session_duration varchar(50) NOT NULL,
        preferred_days text NOT NULL,
        preferred_timing varchar(50) NOT NULL,
        message text NOT NULL,
        terms varchar(50) NOT NULL,
        email_sent tinyint(1) DEFAULT 0,
        submitted_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Extend nonce lifetime to 7 days
add_filter('nonce_life', 'cef_extend_nonce_lifetime');
function cef_extend_nonce_lifetime() {
    return 7 * DAY_IN_SECONDS; // 7 days
}

// Add admin menu to view submissions
add_action('admin_menu', 'cef_add_admin_menu');
function cef_add_admin_menu() {
    add_menu_page(
        'Tutor Form Submissions',
        'Tutor Forms',
        'manage_options',
        'tutor-form-submissions',
        'cef_display_submissions',
        'dashicons-email-alt',
        30
    );
}

// Display submissions in admin
function cef_display_submissions() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'tutor_form_submissions';
    
    // Handle delete action
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $wpdb->delete($table_name, ['id' => $id]);
        echo '<div class="notice notice-success"><p>Submission deleted successfully.</p></div>';
    }
    
    // Handle export action
    if (isset($_GET['action']) && $_GET['action'] === 'export') {
        cef_export_to_csv();
        exit;
    }
    
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC");
    
    ?>
    <div class="wrap">
        <h1>Tutor Form Submissions</h1>
        <p>
            <a href="<?php echo admin_url('admin.php?page=tutor-form-submissions&action=export'); ?>" class="button button-primary">Export to CSV</a>
        </p>
        
        <?php if (empty($submissions)): ?>
            <p>No submissions found.</p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Parent Name</th>
                        <th>Student Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Category</th>
                        <th>Email Sent</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $submission): ?>
                        <tr>
                            <td><?php echo $submission->id; ?></td>
                            <td><?php echo esc_html($submission->parent_name); ?></td>
                            <td><?php echo esc_html($submission->student_name); ?></td>
                            <td><?php echo esc_html($submission->email); ?></td>
                            <td><?php echo esc_html($submission->phone); ?></td>
                            <td><?php echo esc_html($submission->category); ?></td>
                            <td><?php echo $submission->email_sent ? '✓ Yes' : '✗ No'; ?></td>
                            <td><?php echo date('M j, Y g:i a', strtotime($submission->submitted_at)); ?></td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=tutor-form-submissions&action=view&id=' . $submission->id); ?>" class="button button-small">View</a>
                                <a href="<?php echo admin_url('admin.php?page=tutor-form-submissions&action=delete&id=' . $submission->id); ?>" class="button button-small" onclick="return confirm('Are you sure you want to delete this submission?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
        <?php
        // Display full details if viewing a specific submission
        if (isset($_GET['action']) && $_GET['action'] === 'view' && isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $submission = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
            
            if ($submission) {
                ?>
                <div style="margin-top: 30px; padding: 20px; background: #fff; border: 1px solid #ccc;">
                    <h2>Submission Details - #<?php echo $submission->id; ?></h2>
                    <table class="form-table">
                        <tr><th>Parent's Name:</th><td><?php echo esc_html($submission->parent_name); ?></td></tr>
                        <tr><th>Student's Name:</th><td><?php echo esc_html($submission->student_name); ?></td></tr>
                        <tr><th>Date of Birth:</th><td><?php echo esc_html($submission->dob); ?></td></tr>
                        <tr><th>Phone:</th><td><?php echo esc_html($submission->phone); ?></td></tr>
                        <tr><th>Email:</th><td><?php echo esc_html($submission->email); ?></td></tr>
                        <tr><th>Tutoring Category:</th><td><?php echo esc_html($submission->category); ?></td></tr>
                        <tr><th>School Year:</th><td><?php echo esc_html($submission->school_year); ?></td></tr>
                        <tr><th>Preferred Subjects:</th><td><?php echo esc_html($submission->preferred_subjects); ?></td></tr>
                        <tr><th>School Name:</th><td><?php echo esc_html($submission->school_name); ?></td></tr>
                        <tr><th>Session Duration:</th><td><?php echo esc_html($submission->session_duration); ?></td></tr>
                        <tr><th>Preferred Days:</th><td><?php echo esc_html($submission->preferred_days); ?></td></tr>
                        <tr><th>Preferred Timing:</th><td><?php echo esc_html($submission->preferred_timing); ?></td></tr>
                        <tr><th>Message:</th><td><?php echo nl2br(esc_html($submission->message)); ?></td></tr>
                        <tr><th>Terms Agreed:</th><td><?php echo esc_html($submission->terms); ?></td></tr>
                        <tr><th>Email Sent:</th><td><?php echo $submission->email_sent ? 'Yes' : 'No'; ?></td></tr>
                        <tr><th>Submitted:</th><td><?php echo date('F j, Y, g:i a', strtotime($submission->submitted_at)); ?></td></tr>
                    </table>
                    <p><a href="<?php echo admin_url('admin.php?page=tutor-form-submissions'); ?>" class="button">Back to List</a></p>
                </div>
                <?php
            }
        }
        ?>
    </div>
    <?php
}

// Export to CSV
// function cef_export_to_csv() {
//     global $wpdb;
//     $table_name = $wpdb->prefix . 'tutor_form_submissions';
//     $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC", ARRAY_A);
    
//     if (empty($submissions)) {
//         wp_die('No submissions to export.');
//     }
    
//     // Set headers for CSV download
//     header('Content-Type: text/csv; charset=utf-8');
//     header('Content-Disposition: attachment; filename=tutor-form-submissions-' . date('Y-m-d') . '.csv');
    
//     $output = fopen('php://output', 'w');
    
//     // Add CSV headers
//     fputcsv($output, array_keys($submissions[0]));
    
//     // Add data rows
//     foreach ($submissions as $row) {
//         fputcsv($output, $row);
//     }
    
//     fclose($output);
// }

function cef_export_to_csv(){
    global $wpdb;

    // Clear any previous output to avoid header errors
    if (ob_get_length()) ob_clean();

    $table_name = $wpdb->prefix . 'tutor_form_submissions';
    $submissions = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    // If no records found, stop
    if (empty($submissions)) {
        wp_die(__('No data available to export.', 'cef'));
    }

    // Set headers for CSV file download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=tutor_form_submissions-' . date('Y-m-d') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Open output stream
    $output = fopen('php://output', 'w');

    // Add UTF-8 BOM (for Excel compatibility)
    fputs($output, "\xEF\xBB\xBF");

    // Output CSV header (column names)
    fputcsv($output, array_keys($submissions[0]));

    // Output CSV rows
    foreach ($submissions as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
    exit;
}

// Shortcode to display the form
function cef_tutor_form_shortcode() {
    ob_start(); ?>
    
<style>
    .cef-form-wrapper {
        max-width: 100%;
        margin: 0 auto;
        padding: 20px 0;
        background: #fff;
        font-family: Arial, sans-serif;
    }
    .cef-form-wrapper form {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        align-items: start;
    }
    .cef-form-wrapper p {
        margin: 0;
    }
    .cef-form-wrapper label {
        font-weight: 600;
        font-size: 14px;
        display: block;
        margin-bottom: 6px;
        color: #333;
    }
    .cef-form-wrapper input[type="text"],
    .cef-form-wrapper input[type="number"],
    .cef-form-wrapper input[type="date"],
    .cef-form-wrapper input[type="tel"],
    .cef-form-wrapper input[type="email"],
    .cef-form-wrapper textarea,
    .cef-form-wrapper select {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        background: #fff;
        box-sizing: border-box;
    }
    .cef-form-wrapper .full {
        grid-column: span 2;
        width: 100%;
    }
    .cef-form-wrapper input[type="submit"] {
        grid-column: span 2;
        background-color: #f9b000;
        width: 100%;
        color: #000;
        border: none;
        padding: 12px;
        cursor: pointer;
        border-radius: 4px;
        font-size: 16px;
        font-weight: bold;
        transition: background 0.3s ease;
    }
    .cef-form-wrapper input[type="submit"]:hover {
        background-color: #005177;
        color: #fff;
    }
    .cef-form-wrapper label input[type="checkbox"] {
        display: inline-block;
        width: auto;
        margin-right: 8px;
    }
    .cef-success-message {
        background: #d4edda;
        color: #155724;
        padding: 15px;
        border: 1px solid #c3e6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }
    .cef-error-message {
        background: #f8d7da;
        color: #721c24;
        padding: 15px;
        border: 1px solid #f5c6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }
    
    @media (max-width: 768px) {
        .cef-form-wrapper form {
            grid-template-columns: 1fr;
        }
        .cef-form-wrapper .full {
            grid-column: span 1;
        }
        .cef-form-wrapper input,
        .cef-form-wrapper select,
        .cef-form-wrapper textarea {
            font-size: 16px;
        }
        .cef-form-wrapper input[type="submit"] {
            font-size: 18px;
            padding: 14px;
        }
    }
</style>

<div class="cef-form-wrapper">
    <?php
    // Display success or error messages
    if (isset($_GET['form_status'])) {
        if ($_GET['form_status'] === 'success') {
            echo '<div class="cef-success-message">✓ Thank you! Your inquiry has been submitted successfully.</div>';
        } elseif ($_GET['form_status'] === 'error') {
            echo '<div class="cef-error-message">⚠ There was an error submitting your form. Please try again.</div>';
        } elseif ($_GET['form_status'] === 'terms_error') {
            echo '<div class="cef-error-message">⚠ You must agree to the Terms & Conditions.</div>';
        }
    }
    ?>
    
    <form method="post" action="">
        <?php wp_nonce_field('cef_tutor_form_action', 'cef_tutor_form_nonce'); ?>
       
        <p><label>Parent's Name</label>
            <input type="text" placeholder="Please write your full name" name="parent_name" required></p>
        <p><label>Student's Name</label>
            <input type="text" placeholder="Please write Student's full name" name="student_name" required></p>
        <p><label>Date of Birth</label>
            <input type="date" placeholder="Please select your Date of Birth" name="dob" required></p>
        <p><label>Phone Number</label>
            <input type="tel" placeholder="Please write phone number" name="phone" required></p>
        
        <p class="full"><label>Email</label>
            <input type="email" placeholder="Please write your Email" name="email" required></p>
        
        <p><label>Tutoring Category</label>
            <select name="category" required>
                <option value="">Please Choose</option>
                <option value="Online">Online Tutoring</option>
                <option value="Home">Home Tutoring</option>
            </select></p>
        
        <p><label>School Year</label>
            <select name="year" required>
                <option value="">Please Choose</option>
                <?php
                for ($i = 1; $i <= 13; $i++) {
                    echo "<option value='Year $i'>Year $i</option>";
                }
                ?>
            </select></p>
        
        <p class="full"><label>Select Subject(s) - You can multiselect</label>
            <select name="preferred_subjects[]" multiple required>
                <option value="">Please Choose</option>
                <option value="Arabic">Arabic</option>
                <option value="Accounting">Accounting</option>
                <option value="Additional Mathematics">Additional Mathematics</option>
                <option value="Art & Design">Art & Design</option>
                <option value="Business Studies">Business Studies</option>
                <option value="Biology">Biology</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Chinese">Chinese - First Language / Second Language / Computer Science</option>
                <option value="Design & Technology">Design & Technology</option>
                <option value="Drama">Drama</option>
                <option value="Economics">Economics</option>
                <option value="English">English</option>
                <option value="English as a First Language">English as a First Language</option>
                <option value="English as a Second Language">English as a Second Language</option>
                <option value="English Literature">English Literature</option>
                <option value="Enterprise">Enterprise</option>
                <option value="Food & Nutrition">Food & Nutrition</option>
                <option value="French - Foreign Language">French - Foreign Language</option>
                <option value="Geography">Geography</option>
                <option value="German - Foreign Language">German - Foreign Language</option>
                <option value="Global Perspectives">Global Perspectives</option>
                <option value="History">History</option>
                <option value="Further Mathematics">Further Mathematics</option>
                <option value="ICT">ICT</option>
                <option value="Italian - Foreign Language">Italian - Foreign Language</option>
                <option value="Malay First Language">Malay First Language</option>
                <option value="Malay Foreign Language / Mathematics">Malay Foreign Language / Mathematics</option>
                <option value="Music">Music</option>
                <option value="Science Combined">Science Combined</option>
                <option value="Sciences Coordinated">Sciences Coordinated</option>
                <option value="Physics">Physics</option>
                <option value="Sociology">Sociology</option>
                <option value="Spanish">Spanish</option>
                <option value="Spanish First Language">Spanish First Language</option>
                <option value="Other">Other</option>
            </select></p>
        
        <p class="full"><label>School Name</label>
            <select name="school" id="cef-school-select" required>
                <option value="">Please Choose</option>
            </select></p>
        
        <p><label>Session Duration</label>
            <select name="session_duration" required>
                <option value="">Please Choose</option>
                <option value="1 Hour">1 Hour</option>
                <option value="1.5 Hours">1.5 Hours</option>
                <option value="2 Hours">2 Hours</option>
                <option value="3 Hours">3 Hours</option>
            </select></p>
        
        <p><label>Preferred Days</label>
            <select name="preferred_days[]" multiple required>
                <option value="">Please Choose</option>
                <option value="Monday">Monday</option>
                <option value="Tuesday">Tuesday</option>
                <option value="Wednesday">Wednesday</option>
                <option value="Thursday">Thursday</option>
                <option value="Friday">Friday</option>
                <option value="Saturday">Saturday</option>
                <option value="Sunday">Sunday</option>
            </select></p>
        
        <p><label>Preferred Timing(s)</label>
            <select name="preferred_timing" required>
                <option value="">Please Choose</option>
                <option value="Pre 12 PM">Pre 12 PM</option>
                <option value="12 - 5 PM">12 - 5 PM</option>
                <option value="After 5 PM">After 5 PM</option>
            </select></p>
        
        <p class="full"><label>Message</label>
            <textarea name="message" placeholder="Message" rows="5" required></textarea></p>
        
        <p class="full">
            <label>
                <input type="checkbox" name="terms" value="Agreed" required>
                Terms & Conditions - I agree to the Terms & Conditions of World Best Services Malaysia Sdn Bhd (ACE Education)
            </label>
        </p>
        
        <p class="full"><input type="submit" name="cef_tutor_submit" value="Send Enquiry"></p>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Load schools dropdown
            const dropdown = document.getElementById('cef-school-select');
            fetch("<?php echo plugin_dir_url(__FILE__); ?>schools.json")
            .then(res => res.json())
            .then(list => {
                list.forEach(s => {
                    const opt = document.createElement('option');
                    opt.value = s.name.replace(/\s+/g, '-');
                    opt.textContent = `${s.name} (${s.city})`;
                    dropdown.appendChild(opt);
                });
            })
            .catch(err => {
                console.error('Error loading schools:', err);
                const opt = document.createElement('option');
                opt.value = 'Other';
                opt.textContent = 'Other';
                dropdown.appendChild(opt);
            });
        
            // Auto-hide success/error messages after 10 seconds
            const successMsg = document.querySelector('.cef-success-message');
            const errorMsg = document.querySelector('.cef-error-message');
            
            if (successMsg || errorMsg) {
                setTimeout(function() {
                    const msg = successMsg || errorMsg;
                    msg.style.transition = 'opacity 0.5s ease';
                    msg.style.opacity = '0';
                    
                    setTimeout(function() {
                        msg.remove();
                        const url = new URL(window.location);
                        url.searchParams.delete('form_status');
                        window.history.replaceState({}, document.title, url);
                    }, 500);
                }, 10000);
            }
        });
    </script>
</div>

<?php
    return ob_get_clean();
}
add_shortcode('custom_tutor_form', 'cef_tutor_form_shortcode');

// Handle form submission
add_action('init', 'cef_handle_form');

function cef_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cef_tutor_submit'])) {

        // Verify nonce
        if (!isset($_POST['cef_tutor_form_nonce']) || !wp_verify_nonce($_POST['cef_tutor_form_nonce'], 'cef_tutor_form_action')) {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
            exit;
        }

        // Check terms agreement
        if (empty($_POST['terms'])) {
            wp_redirect(add_query_arg('form_status', 'terms_error', wp_get_referer()));
            exit;
        }

        // Sanitize and prepare data
        $data = [
            'parent_name' => sanitize_text_field($_POST['parent_name']),
            'student_name' => sanitize_text_field($_POST['student_name']),
            'dob' => sanitize_text_field($_POST['dob']),
            'phone' => sanitize_text_field($_POST['phone']),
            'email' => sanitize_email($_POST['email']),
            'category' => sanitize_text_field($_POST['category']),
            'school_year' => sanitize_text_field($_POST['year']),
            'preferred_subjects' => implode(', ', array_map('sanitize_text_field', $_POST['preferred_subjects'] ?? [])),
            'school_name' => sanitize_text_field($_POST['school']),
            'session_duration' => sanitize_text_field($_POST['session_duration']),
            'preferred_days' => implode(', ', array_map('sanitize_text_field', $_POST['preferred_days'] ?? [])),
            'preferred_timing' => sanitize_text_field($_POST['preferred_timing']),
            'message' => sanitize_textarea_field($_POST['message']),
            'terms' => sanitize_text_field($_POST['terms']),
        ];

        // Email recipients
        $to = ['info@aceeducation.com.my', 'acekl2018@gmail.com']; 
        $subject = 'New Tutor Services Form Submission';

        // Create HTML email body
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #f9b000;">New Tutor Request</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%;">';
        
        $email_fields = [
            "Parent's Name" => $data['parent_name'],
            "Student's Name" => $data['student_name'],
            "Date of Birth" => $data['dob'],
            "Phone" => $data['phone'],
            "Email" => $data['email'],
            "Tutoring Category" => $data['category'],
            "School Year" => $data['school_year'],
            "Preferred Subjects" => $data['preferred_subjects'],
            "School Name" => $data['school_name'],
            "Session Duration" => $data['session_duration'],
            "Preferred Days" => $data['preferred_days'],
            "Preferred Timing" => $data['preferred_timing'],
            "Message" => $data['message'],
            "Terms & Conditions" => $data['terms'],
        ];
        
        foreach ($email_fields as $label => $value) {
            $message .= '<tr style="border-bottom: 1px solid #ddd;">';
            $message .= '<td style="padding: 10px; font-weight: bold; width: 200px;">' . $label . ':</td>';
            $message .= '<td style="padding: 10px;">' . $value . '</td>';
            $message .= '</tr>';
        }
        
        $message .= '</table>';
        $message .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
        $message .= '</body></html>';

        // Email headers
        $headers = [
            'From: ACE Education Malaysia <info@aceeducation.com.my>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . $data['email']
        ];

        // Send email
        $mail_sent = wp_mail($to, $subject, $message, $headers);

        // Save to database (always save, mark if email was sent)
        global $wpdb;
        $table_name = $wpdb->prefix . 'tutor_form_submissions';
        
        $data['email_sent'] = $mail_sent ? 1 : 0;
        
        $inserted = $wpdb->insert($table_name, $data);

        // Redirect with success message (form is saved regardless of email status)
        if ($inserted) {
            wp_redirect(add_query_arg('form_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
        }
        exit;
    }
}