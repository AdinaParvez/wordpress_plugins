<?php
/**
 * Plugin Name: ACE Secure Forms & XSS Guard
 * Description: Protects WordPress forms from XSS, CSRF, and malicious input.
 * Version: 1.0
 * Author: Adina Pervaiz
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * --------------------------------------------------
 * 1. Add CSRF Protection (Nonce) Automatically
 * --------------------------------------------------
 */
function ace_add_csrf_nonce() {
    wp_nonce_field('ace_secure_action', 'ace_secure_nonce');
}
add_action('comment_form', 'ace_add_csrf_nonce');
add_action('login_form', 'ace_add_csrf_nonce');
add_action('register_form', 'ace_add_csrf_nonce');

/**
 * --------------------------------------------------
 * 2. Verify CSRF Token on Submission
 * --------------------------------------------------
 */
function ace_verify_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['ace_secure_nonce'])) {
            if (!wp_verify_nonce($_POST['ace_secure_nonce'], 'ace_secure_action')) {
                wp_die('Security check failed (CSRF detected)');
            }
        }
    }
}
add_action('init', 'ace_verify_csrf');

/**
 * --------------------------------------------------
 * 3. Sanitize ALL Incoming POST Data
 * --------------------------------------------------
 */
function ace_sanitize_post_data() {
    foreach ($_POST as $key => $value) {
        if (is_string($value)) {
            $_POST[$key] = sanitize_text_field($value);
        }
    }
}
add_action('init', 'ace_sanitize_post_data');

/**
 * --------------------------------------------------
 * 4. Escape Output (Helper Function)
 * --------------------------------------------------
 */
function ace_escape($string) {
    return esc_html($string);
}

/**
 * --------------------------------------------------
 * 5. Remove Dangerous Headers
 * --------------------------------------------------
 */
function ace_secure_headers() {
    header("X-XSS-Protection: 1; mode=block");
    header("X-Frame-Options: SAMEORIGIN");
    header("X-Content-Type-Options: nosniff");
    header("Referrer-Policy: strict-origin-when-cross-origin");
}
add_action('send_headers', 'ace_secure_headers');

/**
 * --------------------------------------------------
 * 6. Disable XML-RPC (Common Attack Point)
 * --------------------------------------------------
 */
add_filter('xmlrpc_enabled', '__return_false');

/**
 * --------------------------------------------------
 * 7. Basic Honeypot Protection (Bots)
 * --------------------------------------------------
 */
function ace_honeypot_check() {
    if (!empty($_POST['website'])) {
        wp_die('Bot detected');
    }
}
add_action('init', 'ace_honeypot_check');
