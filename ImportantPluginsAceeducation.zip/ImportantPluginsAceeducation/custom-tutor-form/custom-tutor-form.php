<?php
/*
Plugin Name: Custom Tutor Form
Description: A responsive tutor form that sends email.
Version: 1.4
Author: Adina Pervaiz
*/

// Extend nonce lifetime to 7 days
add_filter('nonce_life', 'cef_extend_nonce_lifetime');
function cef_extend_nonce_lifetime() {
    return 7 * DAY_IN_SECONDS; // 7 days
}

// Shortcode to display the form
function cef_tutor_form_shortcode() {
    ob_start(); ?>
    
<style>
    .cef-form-wrapper {
        max-width: 100%;
        margin: 0 auto;
        padding: 20px 0;
        background: #fff;
        font-family: Arial, sans-serif;
    }
    .cef-form-wrapper form {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        align-items: start;
    }
    .cef-form-wrapper p {
        margin: 0;
    }
    .cef-form-wrapper label {
        font-weight: 600;
        font-size: 14px;
        display: block;
        margin-bottom: 6px;
        color: #333;
    }
    .cef-form-wrapper input[type="text"],
    .cef-form-wrapper input[type="number"],
    .cef-form-wrapper input[type="date"],
    .cef-form-wrapper input[type="tel"],
    .cef-form-wrapper input[type="email"],
    .cef-form-wrapper textarea,
    .cef-form-wrapper select {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        background: #fff;
        box-sizing: border-box;
    }
    .cef-form-wrapper .full {
        grid-column: span 2;
        width: 100%;
    }
    .cef-form-wrapper input[type="submit"] {
        grid-column: span 2;
        background-color: #f9b000;
        width: 100%;
        color: #000;
        border: none;
        padding: 12px;
        cursor: pointer;
        border-radius: 4px;
        font-size: 16px;
        font-weight: bold;
        transition: background 0.3s ease;
    }
    .cef-form-wrapper input[type="submit"]:hover {
        background-color: #005177;
        color: #fff;
    }
    .cef-form-wrapper label input[type="checkbox"] {
        display: inline-block;
        width: auto;
        margin-right: 8px;
    }
    .cef-success-message {
        background: #d4edda;
        color: #155724;
        padding: 15px;
        border: 1px solid #c3e6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }
    .cef-error-message {
        background: #f8d7da;
        color: #721c24;
        padding: 15px;
        border: 1px solid #f5c6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }
    
    @media (max-width: 768px) {
        .cef-form-wrapper form {
            grid-template-columns: 1fr;
        }
        .cef-form-wrapper .full {
            grid-column: span 1;
        }
        .cef-form-wrapper input,
        .cef-form-wrapper select,
        .cef-form-wrapper textarea {
            font-size: 16px;
        }
        .cef-form-wrapper input[type="submit"] {
            font-size: 18px;
            padding: 14px;
        }
    }
</style>

<div class="cef-form-wrapper">
    <?php
    // Display success or error messages
    if (isset($_GET['form_status'])) {
        if ($_GET['form_status'] === 'success') {
            echo '<div class="cef-success-message">✓ Thank you! Your inquiry has been submitted successfully.</div>';
        } elseif ($_GET['form_status'] === 'error') {
            echo '<div class="cef-error-message">⚠ There was an error submitting your form. Please try again.</div>';
        } elseif ($_GET['form_status'] === 'terms_error') {
            echo '<div class="cef-error-message">⚠ You must agree to the Terms & Conditions.</div>';
        }
    }
    ?>
    
    <form method="post" action="">
        <?php wp_nonce_field('cef_tutor_form_action', 'cef_tutor_form_nonce'); ?>
       
        <p><label>Parent's Name</label>
            <input type="text" placeholder="Please write your full name" name="parent_name" required></p>
        <p><label>Student's Name</label>
            <input type="text" placeholder="Please write Student's full name" name="student_name" required></p>
        <p><label>Date of Birth</label>
            <input type="date" placeholder="Please select your Date of Birth" name="dob" required></p>
        <p><label>Phone Number</label>
            <input type="tel" placeholder="Please write phone number" name="phone" required></p>
        
        <p class="full"><label>Email</label>
            <input type="email" placeholder="Please write your Email" name="email" required></p>
        
        <p><label>Tutoring Category</label>
            <select name="category" required>
                <option value="">Please Choose</option>
                <option value="Online">Online Tutoring</option>
                <option value="Home">Home Tutoring</option>
            </select></p>
        
        <p><label>School Year</label>
            <select name="year" required>
                <option value="">Please Choose</option>
                <?php
                for ($i = 1; $i <= 13; $i++) {
                    echo "<option value='Year $i'>Year $i</option>";
                }
                ?>
            </select></p>
        
        <p class="full"><label>Select Subject(s) - You can multiselect</label>
            <select name="preferred_subjects[]" multiple required>
                <option value="">Please Choose</option>
                <option value="Arabic">Arabic</option>
                <option value="Accounting">Accounting</option>
                <option value="Additional Mathematics">Additional Mathematics</option>
                <option value="Art & Design">Art & Design</option>
                <option value="Business Studies">Business Studies</option>
                <option value="Biology">Biology</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Chinese">Chinese - First Language / Second Language / Computer Science</option>
                <option value="Design & Technology">Design & Technology</option>
                <option value="Drama">Drama</option>
                <option value="Economics">Economics</option>
                <option value="English">English</option>
                <option value="English as a First Language">English as a First Language</option>
                <option value="English as a Second Language">English as a Second Language</option>
                <option value="English Literature">English Literature</option>
                <option value="Enterprise">Enterprise</option>
                <option value="Food & Nutrition">Food & Nutrition</option>
                <option value="French - Foreign Language">French - Foreign Language</option>
                <option value="Geography">Geography</option>
                <option value="German - Foreign Language">German - Foreign Language</option>
                <option value="Global Perspectives">Global Perspectives</option>
                <option value="History">History</option>
                <option value="Further Mathematics">Further Mathematics</option>
                <option value="ICT">ICT</option>
                <option value="Italian - Foreign Language">Italian - Foreign Language</option>
                <option value="Malay First Language">Malay First Language</option>
                <option value="Malay Foreign Language / Mathematics">Malay Foreign Language / Mathematics</option>
                <option value="Music">Music</option>
                <option value="Science Combined">Science Combined</option>
                <option value="Sciences Coordinated">Sciences Coordinated</option>
                <option value="Physics">Physics</option>
                <option value="Sociology">Sociology</option>
                <option value="Spanish">Spanish</option>
                <option value="Spanish First Language">Spanish First Language</option>
                <option value="Other">Other</option>
            </select></p>
        
        <p class="full"><label>School Name</label>
            <select name="school" id="cef-school-select" required>
                <option value="">Please Choose</option>
            </select></p>
        
        <p><label>Session Duration</label>
            <select name="session_duration" required>
                <option value="">Please Choose</option>
                <option value="1 Hour">1 Hour</option>
                <option value="1.5 Hours">1.5 Hours</option>
                <option value="2 Hours">2 Hours</option>
                <option value="3 Hours">3 Hours</option>
            </select></p>
        
        <p><label>Preferred Days</label>
            <select name="preferred_days[]" multiple required>
                <option value="">Please Choose</option>
                <option value="Monday">Monday</option>
                <option value="Tuesday">Tuesday</option>
                <option value="Wednesday">Wednesday</option>
                <option value="Thursday">Thursday</option>
                <option value="Friday">Friday</option>
                <option value="Saturday">Saturday</option>
                <option value="Sunday">Sunday</option>
            </select></p>
        
        <p><label>Preferred Timing(s)</label>
            <select name="preferred_timing" required>
                <option value="">Please Choose</option>
                <option value="Pre 12 PM">Pre 12 PM</option>
                <option value="12 - 5 PM">12 - 5 PM</option>
                <option value="After 5 PM">After 5 PM</option>
            </select></p>
        
        <p class="full"><label>Message</label>
            <textarea name="message" placeholder="Message" rows="5" required></textarea></p>
        
        <p class="full">
            <label>
                <input type="checkbox" name="terms" value="Agreed" required>
                Terms & Conditions - I agree to the Terms & Conditions of World Best Services Malaysia Sdn Bhd (ACE Education)
            </label>
        </p>
        
        <p class="full"><input type="submit" name="cef_tutor_submit" value="Send Enquiry"></p>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
                        // Load schools dropdown
            const dropdown = document.getElementById('cef-school-select');
            fetch("<?php echo plugin_dir_url(__FILE__); ?>schools.json")
            .then(res => res.json())
            .then(list => {
                list.forEach(s => {
                    const opt = document.createElement('option');
                    opt.value = s.name.replace(/\s+/g, '-');
                    opt.textContent = `${s.name} (${s.city})`;
                    dropdown.appendChild(opt);
                });
            })
            .catch(err => {
                console.error('Error loading schools:', err);
                const opt = document.createElement('option');
                opt.value = 'Other';
                opt.textContent = 'Other';
                dropdown.appendChild(opt);
            });
        
                    // Auto-hide success/error messages after 5 seconds
            const successMsg = document.querySelector('.cef-success-message');
            const errorMsg = document.querySelector('.cef-error-message');
            
            if (successMsg || errorMsg) {
                setTimeout(function() {
                    // Remove message with fade effect
                    const msg = successMsg || errorMsg;
                    msg.style.transition = 'opacity 0.5s ease';
                    msg.style.opacity = '0';
                    
                    setTimeout(function() {
                        msg.remove();
                        // Clean URL by removing query parameter
                        const url = new URL(window.location);
                        url.searchParams.delete('form_status');
                        window.history.replaceState({}, document.title, url);
                    }, 500);
                }, 10000); // 10 seconds
            }
        });
    </script>
</div>

<?php
    return ob_get_clean();
}
add_shortcode('custom_tutor_form', 'cef_tutor_form_shortcode');

// Handle form submission
add_action('init', 'cef_handle_form');

function cef_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cef_tutor_submit'])) {

        // Verify nonce
        if (!isset($_POST['cef_tutor_form_nonce']) || !wp_verify_nonce($_POST['cef_tutor_form_nonce'], 'cef_tutor_form_action')) {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
            exit;
        }

        // Check terms agreement
        if (empty($_POST['terms'])) {
            wp_redirect(add_query_arg('form_status', 'terms_error', wp_get_referer()));
            exit;
        }

        // Email recipients
        $to = ['info@aceeducation.com.my', 'acekl2018@gmail.com']; 
        $subject = 'New Tutor Services Form Submission';

        // Sanitize and prepare data
        $fields = [
            "Parent's Name" => sanitize_text_field($_POST['parent_name']),
            "Student's Name" => sanitize_text_field($_POST['student_name']),
            "Date of Birth" => sanitize_text_field($_POST['dob']),
            "Phone" => sanitize_text_field($_POST['phone']),
            "Email" => sanitize_email($_POST['email']),
            "Tutoring Category" => sanitize_text_field($_POST['category']),
            "School Year" => sanitize_text_field($_POST['year']),
            "Preferred Subjects" => implode(', ', array_map('sanitize_text_field', $_POST['preferred_subjects'] ?? [])),
            "School Name" => sanitize_text_field($_POST['school']),
            "Session Duration" => sanitize_text_field($_POST['session_duration']),
            "Preferred Days" => implode(', ', array_map('sanitize_text_field', $_POST['preferred_days'] ?? [])),
            "Preferred Timing" => sanitize_text_field($_POST['preferred_timing']),
            "Message" => sanitize_textarea_field($_POST['message']),
            "Terms & Conditions" => sanitize_text_field($_POST['terms']),
        ];

        // Create HTML email body
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #f9b000;">New Tutor Request</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%;">';
        
        foreach ($fields as $label => $value) {
            $message .= '<tr style="border-bottom: 1px solid #ddd;">';
            $message .= '<td style="padding: 10px; font-weight: bold; width: 200px;">' . $label . ':</td>';
            $message .= '<td style="padding: 10px;">' . $value . '</td>';
            $message .= '</tr>';
        }
        
        $message .= '</table>';
        $message .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
        $message .= '</body></html>';

        // Email headers
        $headers = [
            'From: ACE Education Malaysia <info@aceeducation.com.my>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . sanitize_email($_POST['email'])
        ];

        // Send email
        $mail_sent = wp_mail($to, $subject, $message, $headers);

        // Redirect with success/error message
        if ($mail_sent) {
            wp_redirect(add_query_arg('form_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
        }
        exit;
    }
}