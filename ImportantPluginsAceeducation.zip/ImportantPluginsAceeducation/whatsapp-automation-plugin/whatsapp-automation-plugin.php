<?php
/**
 * Plugin Name: ACE Education WhatsApp Chatbot
 * Description: Interactive WhatsApp chatbot with Q&A automation for aceeducation.com.my
 * Version: 2.1
 * Author: ACE Education
 */

if (!defined('ABSPATH')) exit;

class ACE_WhatsApp_Chatbot {
    
    private $twilio_sid;
    private $twilio_token;
    private $twilio_whatsapp_number;
    
    public function __construct() {
        // Admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Register webhook - Use multiple hooks to ensure it works
        add_action('init', array($this, 'register_webhook'), 1);
        add_action('rest_api_init', array($this, 'register_webhook'), 1);
        
        // Activation hook to flush rewrite rules
        register_activation_hook(__FILE__, array($this, 'plugin_activation'));
        
        // Load settings
        $this->twilio_sid = get_option('wa_twilio_sid');
        $this->twilio_token = get_option('wa_twilio_token');
        $this->twilio_whatsapp_number = get_option('wa_twilio_whatsapp_number');
    }
    
    // Plugin activation - flush rewrite rules
    public function plugin_activation() {
        $this->register_webhook();
        flush_rewrite_rules();
    }
    
    // Register REST API webhook endpoint
    public function register_webhook() {
        // Prevent duplicate registration
        static $registered = false;
        if ($registered) return;
        $registered = true;
        
        register_rest_route('ace-whatsapp/v1', '/webhook', array(
            'methods' => array('GET', 'POST'),
            'callback' => array($this, 'handle_incoming_message'),
            'permission_callback' => '__return_true',
            'args' => array()
        ));
        
        error_log('ACE WhatsApp webhook registered at: ' . rest_url('ace-whatsapp/v1/webhook'));
    }
    
    // Handle incoming WhatsApp messages
    public function handle_incoming_message($request) {
        // Log that webhook was called
        error_log('WhatsApp webhook called!');
        
        // Handle both GET and POST
        if ($request->get_method() === 'GET') {
            return new WP_REST_Response(array(
                'status' => 'success',
                'message' => 'ACE WhatsApp Webhook is active!',
                'webhook_url' => rest_url('ace-whatsapp/v1/webhook')
            ), 200);
        }
        
        $params = $request->get_params();
        error_log('WhatsApp message params: ' . print_r($params, true));
        
        // Get message details
        $from = isset($params['From']) ? sanitize_text_field($params['From']) : '';
        $body = isset($params['Body']) ? sanitize_text_field($params['Body']) : '';
        $message_sid = isset($params['MessageSid']) ? sanitize_text_field($params['MessageSid']) : '';
        
        if (empty($from) || empty($body)) {
            error_log('Empty from or body in WhatsApp message');
            return new WP_REST_Response(array('status' => 'error', 'message' => 'Missing parameters'), 400);
        }
        
        // Log the conversation
        $this->log_conversation($from, $body, 'incoming');
        
        // Get bot response
        $response = $this->get_bot_response($body, $from);
        
        // Send reply
        $send_result = $this->send_whatsapp_message($from, $response);
        error_log('Send result: ' . print_r($send_result, true));
        
        // Log bot response
        $this->log_conversation($from, $response, 'outgoing');
        
        return new WP_REST_Response(array('status' => 'success'), 200);
    }
    
    // Intelligent response system
    private function get_bot_response($message, $from) {
        $message_lower = strtolower(trim($message));
        
        // Get custom Q&A from database
        $custom_responses = get_option('wa_custom_qna', array());
        
        // Check for custom Q&A matches
        if (!empty($custom_responses)) {
            foreach ($custom_responses as $qa) {
                $keywords = array_map('trim', explode(',', strtolower($qa['keywords'])));
                foreach ($keywords as $keyword) {
                    if (strpos($message_lower, $keyword) !== false) {
                        return $qa['answer'];
                    }
                }
            }
        }
        
        // Default responses for common queries
        $responses = array(
            // Greetings
            'hi|hello|hey|assalamualaikum|salam' => "🌟 *Welcome to ACE Education!*\n\nHello! How can I help you today?\n\n*Quick Menu:*\n1️⃣ Courses & Programs\n2️⃣ Fees & Payment\n3️⃣ Registration\n4️⃣ Contact Us\n5️⃣ Speak to Agent\n\nType a number or ask your question! 😊",
            
            // Course inquiries
            'course|courses|program|programs|class|classes|subjects|what do you offer' => "📚 *ACE Education Programs*\n\n✅ SPM/STPM Preparation\n✅ IGCSE/A-Levels\n✅ Foundation Programs\n✅ Intensive Courses\n✅ Online Classes\n✅ One-on-One Tuition\n\nWhich program are you interested in?\n\nFor detailed info: " . home_url('/courses'),
            
            // Fees
            'fee|fees|price|cost|how much|payment|pay' => "💰 *Fees & Payment*\n\n📌 Course fees vary by program:\n• SPM: RM150-300/month\n• IGCSE: RM200-400/month\n• Foundation: RM250-500/month\n\n💳 *Payment Methods:*\n✓ Bank Transfer\n✓ Credit/Debit Card\n✓ FPX Online Banking\n✓ Installment Plans Available\n\nNeed specific pricing? Reply with your course interest! 📞",
            
            // Registration
            'register|registration|enroll|enrollment|join|sign up|how to register' => "📝 *Registration Process*\n\n*Step 1:* Fill online form\n*Step 2:* Submit documents\n*Step 3:* Payment confirmation\n*Step 4:* Receive class schedule\n\n🔗 Register now:\n" . home_url('/register') . "\n\nNeed help? Type 'agent' to speak with our team!",
            
            // Location
            'location|address|where|branch|office' => "📍 *ACE Education Locations*\n\n*Main Campus:*\nKuala Lumpur\n\n*Operating Hours:*\n9:00 AM - 6:00 PM (Mon-Fri)\n9:00 AM - 2:00 PM (Sat)\n\n📞 Call: +60 3-XXXX XXXX\n📧 Email: info@aceeducation.com.my\n🌐 " . home_url(),
            
            // Schedule/Timetable
            'schedule|timetable|timing|time|when|class time' => "🕐 *Class Schedules*\n\n*Weekday Classes:*\n• Morning: 9:00 AM - 12:00 PM\n• Afternoon: 2:00 PM - 5:00 PM\n• Evening: 6:00 PM - 9:00 PM\n\n*Weekend Classes:*\n• Saturday: 9:00 AM - 5:00 PM\n• Sunday: 9:00 AM - 2:00 PM\n\n📅 Flexible scheduling available!\nReply with your preferred timing.",
            
            // Teachers/Tutors
            'teacher|tutor|lecturer|instructor|staff' => "👨‍🏫 *Our Educators*\n\n✨ Experienced & Qualified\n✨ Subject Matter Experts\n✨ SPM/IGCSE Specialists\n✨ Proven Track Record\n\nOur teachers have 5-15 years of teaching experience with excellent student results!\n\nWant to know about a specific subject teacher? Let me know! 📚",
            
            // Results/Success Rate
            'result|results|success|achievement|pass rate' => "🏆 *ACE Education Results*\n\n⭐ 95% Pass Rate\n⭐ 80% A/A+ Grades\n⭐ Top Scorers Every Year\n\n🎓 Our students consistently excel in:\n• SPM Examinations\n• IGCSE\n• Foundation Programs\n\nJoin our success story! 💪",
            
            // Online Classes
            'online|virtual|zoom|e-learning|distance learning' => "💻 *Online Learning Available!*\n\n✅ Live Interactive Classes\n✅ Recorded Sessions\n✅ Digital Resources\n✅ One-on-One Support\n✅ Same Quality as Physical Classes\n\n📱 Platform: Zoom + Learning Portal\n\nInterested in online classes? I can help you register! 🚀",
            
            // Trial Class
            'trial|free class|demo|try|test' => "🎁 *FREE Trial Class!*\n\nYes! We offer FREE trial classes.\n\n✨ Experience our teaching style\n✨ Meet our teachers\n✨ No commitment required\n\n📞 Book your trial:\nReply 'BOOK TRIAL' with:\n- Your name\n- Subject interest\n- Preferred date\n\nLimited slots available! ⏰",
            
            // Contact/Agent
            'agent|human|talk|speak|call|contact|help|support' => "👤 *Connect with Our Team*\n\n📞 *Call Us:*\n+60 3-XXXX XXXX\n\n📧 *Email:*\ninfo@aceeducation.com.my\n\n⏰ *Office Hours:*\nMon-Fri: 9 AM - 6 PM\nSat: 9 AM - 2 PM\n\n🔔 Our team will respond to you shortly!\nOr continue chatting with me for quick answers. 😊",
            
            // Thank you
            'thank|thanks|tq|terima kasih' => "You're welcome! 😊\n\nIs there anything else I can help you with?\n\n💬 Ask me about:\n• Courses\n• Fees\n• Registration\n• Class schedules\n\nHave a great day! 🌟",
        );
        
        // Check for matches
        foreach ($responses as $pattern => $response) {
            $keywords = explode('|', $pattern);
            foreach ($keywords as $keyword) {
                if (strpos($message_lower, $keyword) !== false) {
                    return $response;
                }
            }
        }
        
        // Menu number responses
        if ($message === '1') {
            return $responses['course|courses|program|programs|class|classes|subjects|what do you offer'];
        } elseif ($message === '2') {
            return $responses['fee|fees|price|cost|how much|payment|pay'];
        } elseif ($message === '3') {
            return $responses['register|registration|enroll|enrollment|join|sign up|how to register'];
        } elseif ($message === '4') {
            return $responses['location|address|where|branch|office'];
        } elseif ($message === '5') {
            return $responses['agent|human|talk|speak|call|contact|help|support'];
        }
        
        // Default response if no match
        return "🤖 I'm here to help!\n\n*I can help you with:*\n\n📚 Courses & Programs\n💰 Fees & Payment\n📝 Registration\n📍 Location & Hours\n👨‍🏫 Teachers & Results\n💻 Online Classes\n🎁 Trial Classes\n\nPlease ask your question or type *'menu'* to see options.\n\n💬 Need immediate assistance?\nType *'agent'* to connect with our team!";
    }
    
    // Log conversations to database
    private function log_conversation($phone, $message, $direction) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wa_conversations';
        
        // Create table if not exists
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            phone_number varchar(50) NOT NULL,
            message text NOT NULL,
            direction varchar(20) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Insert conversation
        $wpdb->insert(
            $table_name,
            array(
                'phone_number' => $phone,
                'message' => $message,
                'direction' => $direction
            ),
            array('%s', '%s', '%s')
        );
    }
    
    // Send WhatsApp message
    private function send_whatsapp_message($to, $message) {
        if (empty($this->twilio_sid) || empty($this->twilio_token) || empty($this->twilio_whatsapp_number)) {
            error_log('Twilio credentials not configured');
            return array('success' => false, 'error' => 'Twilio credentials not configured');
        }
        
        $url = "https://api.twilio.com/2010-04-01/Accounts/{$this->twilio_sid}/Messages.json";
        
        $data = array(
            'From' => $this->twilio_whatsapp_number,
            'To' => $to,
            'Body' => $message
        );
        
        $args = array(
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode($this->twilio_sid . ':' . $this->twilio_token)
            ),
            'body' => $data,
            'timeout' => 15
        );
        
        $response = wp_remote_post($url, $args);
        
        if (is_wp_error($response)) {
            error_log('Twilio API error: ' . $response->get_error_message());
            return array('success' => false, 'error' => $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error_message'])) {
            error_log('Twilio API error: ' . $body['error_message']);
            return array('success' => false, 'error' => $body['error_message']);
        }
        
        return array('success' => true, 'data' => $body);
    }
    
    // Admin menu
    public function add_admin_menu() {
        add_menu_page(
            'WhatsApp Chatbot',
            'WhatsApp Bot',
            'manage_options',
            'ace-whatsapp-bot',
            array($this, 'settings_page'),
            'dashicons-format-chat',
            100
        );
        
        add_submenu_page(
            'ace-whatsapp-bot',
            'Bot Settings',
            'Settings',
            'manage_options',
            'ace-whatsapp-bot',
            array($this, 'settings_page')
        );
        
        add_submenu_page(
            'ace-whatsapp-bot',
            'Manage Q&A',
            'Manage Q&A',
            'manage_options',
            'ace-whatsapp-qna',
            array($this, 'qna_page')
        );
        
        add_submenu_page(
            'ace-whatsapp-bot',
            'Conversations',
            'Conversations',
            'manage_options',
            'ace-whatsapp-logs',
            array($this, 'logs_page')
        );
    }
    
    // Register settings
    public function register_settings() {
        register_setting('wa_settings_group', 'wa_twilio_sid');
        register_setting('wa_settings_group', 'wa_twilio_token');
        register_setting('wa_settings_group', 'wa_twilio_whatsapp_number');
        register_setting('wa_settings_group', 'wa_custom_qna');
    }
    
    // Settings page
    public function settings_page() {
        $webhook_url = rest_url('ace-whatsapp/v1/webhook');
        
        // Test webhook registration
        if (isset($_POST['test_webhook']) && check_admin_referer('test_webhook_nonce')) {
            $test_url = $webhook_url;
            $response = wp_remote_get($test_url);
            
            if (is_wp_error($response)) {
                echo '<div class="notice notice-error"><p>❌ Webhook test failed: ' . esc_html($response->get_error_message()) . '</p></div>';
            } else {
                $body = wp_remote_retrieve_body($response);
                echo '<div class="notice notice-success"><p>✅ Webhook is responding! Response: ' . esc_html($body) . '</p></div>';
            }
        }
        ?>
        <div class="wrap">
            <h1>🤖 ACE Education WhatsApp Chatbot</h1>
            
            <div style="background: #fff; padding: 20px; margin: 20px 0; border-left: 4px solid #00a884;">
                <h3>📋 Setup Instructions:</h3>
                <ol>
                    <li><strong>Sign up for Twilio:</strong> <a href="https://www.twilio.com/try-twilio" target="_blank">https://www.twilio.com/try-twilio</a></li>
                    <li><strong>Get credentials:</strong> Account SID and Auth Token from dashboard</li>
                    <li><strong>Enable WhatsApp Sandbox:</strong> Console → Messaging → Try WhatsApp</li>
                    <li><strong>Configure webhook URL in Twilio:</strong>
                        <br><code style="background: #f0f0f0; padding: 10px; display: block; margin: 10px 0;"><?php echo esc_url($webhook_url); ?></code>
                        <small>Go to: Twilio Console → WhatsApp Sandbox → Sandbox Configuration → "When a message comes in" → Paste this URL</small>
                    </li>
                    <li><strong>Test:</strong> Send a WhatsApp message to your Twilio sandbox number</li>
                </ol>
            </div>
            
            <form method="post" action="options.php">
                <?php settings_fields('wa_settings_group'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="wa_twilio_sid">Twilio Account SID</label></th>
                        <td>
                            <input type="text" id="wa_twilio_sid" name="wa_twilio_sid" 
                                   value="<?php echo esc_attr(get_option('wa_twilio_sid')); ?>" 
                                   class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="wa_twilio_token">Twilio Auth Token</label></th>
                        <td>
                            <input type="password" id="wa_twilio_token" name="wa_twilio_token" 
                                   value="<?php echo esc_attr(get_option('wa_twilio_token')); ?>" 
                                   class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="wa_twilio_whatsapp_number">Twilio WhatsApp Number</label></th>
                        <td>
                            <input type="text" id="wa_twilio_whatsapp_number" name="wa_twilio_whatsapp_number" 
                                   value="<?php echo esc_attr(get_option('wa_twilio_whatsapp_number')); ?>" 
                                   class="regular-text" placeholder="whatsapp:+14155238886" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Webhook URL (Copy to Twilio)</th>
                        <td>
                            <input type="text" readonly value="<?php echo esc_url($webhook_url); ?>" 
                                   class="large-text" onclick="this.select(); document.execCommand('copy');" 
                                   style="background: #f0f0f0;" />
                            <p class="description">Click to copy. Paste this in Twilio WhatsApp Sandbox settings.</p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
            
            <hr>
            <h2>🧪 Test Webhook Connection</h2>
            <form method="post" action="">
                <?php wp_nonce_field('test_webhook_nonce'); ?>
                <p>Click below to test if your webhook URL is working:</p>
                <input type="submit" name="test_webhook" class="button button-secondary" value="Test Webhook" />
            </form>
            
            <hr>
            <h2>🧪 Test Bot Responses</h2>
            <p>Send a message to your Twilio WhatsApp sandbox number to test the bot!</p>
            <p><strong>Try these commands:</strong></p>
            <ul>
                <li>Hi</li>
                <li>What courses do you offer?</li>
                <li>How much are the fees?</li>
                <li>I want to register</li>
                <li>agent</li>
            </ul>
        </div>
        <?php
    }
    
    // Q&A Management Page
    public function qna_page() {
        // Handle form submission
        if (isset($_POST['add_qna']) && check_admin_referer('add_qna_nonce')) {
            $custom_qna = get_option('wa_custom_qna', array());
            $custom_qna[] = array(
                'keywords' => sanitize_text_field($_POST['keywords']),
                'answer' => sanitize_textarea_field($_POST['answer'])
            );
            update_option('wa_custom_qna', $custom_qna);
            echo '<div class="notice notice-success"><p>✅ Q&A added successfully!</p></div>';
        }
        
        // Handle delete
        if (isset($_GET['delete']) && check_admin_referer('delete_qna_' . $_GET['delete'])) {
            $custom_qna = get_option('wa_custom_qna', array());
            unset($custom_qna[$_GET['delete']]);
            update_option('wa_custom_qna', array_values($custom_qna));
            echo '<div class="notice notice-success"><p>✅ Q&A deleted successfully!</p></div>';
        }
        
        $custom_qna = get_option('wa_custom_qna', array());
        ?>
        <div class="wrap">
            <h1>📝 Manage Custom Q&A</h1>
            <p>Add custom questions and answers for your chatbot. Use keywords that students might type.</p>
            
            <div style="background: #fff; padding: 20px; margin: 20px 0;">
                <h2>Add New Q&A</h2>
                <form method="post" action="">
                    <?php wp_nonce_field('add_qna_nonce'); ?>
                    <table class="form-table">
                        <tr>
                            <th><label for="keywords">Keywords (comma-separated)</label></th>
                            <td>
                                <input type="text" id="keywords" name="keywords" class="large-text" 
                                       placeholder="e.g., scholarship, discount, financial aid" required />
                                <p class="description">Enter keywords that trigger this response (separated by commas)</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="answer">Answer</label></th>
                            <td>
                                <textarea id="answer" name="answer" rows="6" class="large-text" required 
                                          placeholder="Enter the bot's response when these keywords are detected..."></textarea>
                                <p class="description">The bot will send this message when it detects any of the keywords above</p>
                            </td>
                        </tr>
                    </table>
                    <input type="submit" name="add_qna" class="button button-primary" value="Add Q&A" />
                </form>
            </div>
            
            <h2>Existing Q&A Responses</h2>
            <?php if (empty($custom_qna)): ?>
                <p>No custom Q&A added yet. Add your first one above!</p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th width="30%">Keywords</th>
                            <th width="60%">Answer</th>
                            <th width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($custom_qna as $index => $qa): ?>
                            <tr>
                                <td><strong><?php echo esc_html($qa['keywords']); ?></strong></td>
                                <td><?php echo nl2br(esc_html($qa['answer'])); ?></td>
                                <td>
                                    <a href="?page=ace-whatsapp-qna&delete=<?php echo $index; ?>&_wpnonce=<?php echo wp_create_nonce('delete_qna_' . $index); ?>" 
                                       class="button button-small button-link-delete" 
                                       onclick="return confirm('Are you sure you want to delete this Q&A?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }
    
    // Conversation Logs Page
    public function logs_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wa_conversations';
        
        $conversations = $wpdb->get_results(
            "SELECT * FROM $table_name ORDER BY created_at DESC LIMIT 100"
        );
        ?>
        <div class="wrap">
            <h1>💬 Recent Conversations</h1>
            <p>View all WhatsApp conversations with students</p>
            
            <?php if (empty($conversations)): ?>
                <p>No conversations yet. Start chatting with your WhatsApp bot!</p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th width="15%">Phone Number</th>
                            <th width="10%">Direction</th>
                            <th width="55%">Message</th>
                            <th width="20%">Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($conversations as $conv): ?>
                            <tr>
                                <td><?php echo esc_html($conv->phone_number); ?></td>
                                <td>
                                    <?php if ($conv->direction === 'incoming'): ?>
                                        <span style="color: #0073aa;">📥 Received</span>
                                    <?php else: ?>
                                        <span style="color: #00a884;">📤 Sent</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo nl2br(esc_html($conv->message)); ?></td>
                                <td><?php echo esc_html($conv->created_at); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }
}

// Initialize the plugin
new ACE_WhatsApp_Chatbot();