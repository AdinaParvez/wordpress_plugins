document.addEventListener('DOMContentLoaded', function() {
    const toggle = document.getElementById('acebot-toggle');
    const popup = document.getElementById('acebot-popup');
    const sendBtn = document.getElementById('acebot-send');
    const messageInput = document.getElementById('acebot-message');
    const chatContainer = document.getElementById('acebot-messages');

    toggle.addEventListener('click', () => {
        popup.style.display = popup.style.display === 'none' ? 'block' : 'none';
    });

    sendBtn.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', function(e){
        if(e.key === 'Enter'){
            e.preventDefault();
            sendMessage();
        }
    });

    function sendMessage(){
        const message = messageInput.value.trim();
        if(message === '') return;

        // Append user message
        const userDiv = document.createElement('div');
        userDiv.textContent = 'You: ' + message;
        userDiv.style.textAlign = 'right';
        chatContainer.appendChild(userDiv);
        chatContainer.scrollTop = chatContainer.scrollHeight;

        fetch(acebot_ajax_object.ajax_url, {
            method: 'POST',
            headers: {'Content-Type':'application/x-www-form-urlencoded'},
            body: `action=acebot_send&message=${encodeURIComponent(message)}`
        })
        .then(res => res.json())
        .then(data => {
            if(data.success){
                const botDiv = document.createElement('div');
                botDiv.textContent = 'Bot: ' + data.data.reply;
                botDiv.style.textAlign = 'left';
                chatContainer.appendChild(botDiv);
                chatContainer.scrollTop = chatContainer.scrollHeight;
            } else {
                alert('Error sending message');
            }
            messageInput.value = '';
        });
    }
});
