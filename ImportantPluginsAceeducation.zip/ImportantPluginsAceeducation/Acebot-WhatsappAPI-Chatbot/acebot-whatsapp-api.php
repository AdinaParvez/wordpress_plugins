<?php
/**
 * Plugin Name: AceBot WhatsApp API Chatbot
 * Description: Fully automated WhatsApp chatbot integration using WhatsApp Business API with visitor info collection.
 * Version: 1.2
 * Author: Adina Pervaiz
 */

if (!defined('ABSPATH')) exit;

// Start session for tracking conversation
if (!session_id()) {
    session_start();
}

// Enqueue CSS & JS
function acebot_enqueue_scripts() {
    wp_enqueue_style('acebot-css', plugin_dir_url(__FILE__) . 'css/acebot.css');
    wp_enqueue_script('acebot-js', plugin_dir_url(__FILE__) . 'js/acebot.js', [], null, true);

    // Pass AJAX URL to JS
    wp_localize_script('acebot-js', 'acebot_ajax_object', [
        'ajax_url' => admin_url('admin-ajax.php')
    ]);
}
add_action('wp_enqueue_scripts', 'acebot_enqueue_scripts');

// Add WhatsApp button to footer
function acebot_whatsapp_button() {
    ?>
    <div id="acebot-whatsapp-chat">
        <div id="acebot-toggle">
            <img src="<?php echo plugin_dir_url(__FILE__) . 'image/whatsapp-icon.webp'; ?>" 
                 alt="Chat on WhatsApp" 
                 style="width:60px; height:60px; cursor:pointer;">
        </div>

        <div id="acebot-popup" style="display:none;">
            <div id="acebot-messages" style="height:200px; overflow-y:auto; margin-bottom:5px;"></div>
            <textarea id="acebot-message" placeholder="Type your message..."></textarea>
            <button id="acebot-send">Send</button>
        </div>
    </div>
    <?php
}
add_action('wp_footer', 'acebot_whatsapp_button');

// Handle AJAX request
add_action('wp_ajax_acebot_send', 'acebot_send_message');
add_action('wp_ajax_nopriv_acebot_send', 'acebot_send_message');

function acebot_send_message() {
    $message = strtolower(sanitize_text_field($_POST['message']));

    if (!isset($_SESSION['stage'])) $_SESSION['stage'] = 'start';

    $reply = '';

    switch ($_SESSION['stage']) {
        case 'start':
            if (strpos($message, 'hello') !== false) {
                $reply = 'Hi! Welcome to Ace Education. How can I help you today? Type "course", "fees", or "admission".';
            } elseif (strpos($message, 'course') !== false) {
                $reply = 'We offer multiple courses. Which one are you interested in?';
            } elseif (strpos($message, 'fees') !== false) {
                $reply = 'Our fees vary by course. Which course do you want info on?';
            } elseif (strpos($message, 'admission') !== false) {
                $reply = 'Admission is easy! What is your full name?';
                $_SESSION['stage'] = 'ask_name';
            } else {
                $reply = "Sorry, I didn't understand that. Please type 'course', 'fees', or 'admission'.";
            }
            break;

        case 'ask_name':
            $_SESSION['visitor_name'] = $message;
            $reply = 'Thanks, ' . $message . '! Please provide your email address.';
            $_SESSION['stage'] = 'ask_email';
            break;

        case 'ask_email':
            $_SESSION['visitor_email'] = $message;
            $reply = 'Thanks! We will contact you soon.';
            $_SESSION['stage'] = 'completed';
            break;

        case 'completed':
            $reply = 'Hi ' . $_SESSION['visitor_name'] . ', thank you for your interest. We will contact you soon.';
            break;
    }

    // Twilio WhatsApp API
    $sid = 'AC5ff3b030190318eb9ef0e084787c0378';
    $token = 'a99a4c0b4a8bc5ebe9359dd548df0fae';
    $twilio_number = 'whatsapp:+14155238886'; // Twilio sandbox number
    $to_number = 'whatsapp:+60164777167';    // Your WhatsApp number

    $data = [
        'From' => $twilio_number,
        'Body' => $reply,
        'To' => $to_number
    ];

    $ch = curl_init("https://api.twilio.com/2010-04-01/Accounts/$sid/Messages.json");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_USERPWD, "$sid:$token");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    wp_send_json_success(['reply' => $reply, 'twilio_response' => $response]);
}
