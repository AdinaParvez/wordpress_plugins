<?php
/*
Plugin Name: Custom Tutor Form Bahrain
Description: A responsive tutor form that sends email with multiselects and dynamic schools.
Version: 1.4
Author: Adina Pervaiz
*/

// Prevent direct access
if (!defined('ABSPATH')) exit;

// -----------------------------
// Shortcode to display the form
// -----------------------------
function cef_tutor_form_shortcode() {
    ob_start(); ?>

    <div class="cef-form-wrapper">
        <form method="post" action="">
            <?php wp_nonce_field('cef_tutor_form_action', 'cef_tutor_form_nonce'); ?>

            <p><label>Parent's Name</label>
                <input type="text" name="parent_name" placeholder="Please write your full name" required></p>

            <p><label>Student's Name</label>
                <input type="text" name="student_name" placeholder="Please write student's full name" required></p>

            <p><label>Date of Birth</label>
                <input type="date" name="dob" required></p>

            <p><label>Phone Number</label>
                <input id="cef-phone" type="tel" name="phone" placeholder="Please write phone number" required>
                <input type="hidden" name="phone_full" id="cef-phone-full">
            </p>

            <p class="full"><label>Email</label>
                <input type="email" name="email" placeholder="Please write your Email" required></p>

            <p><label>Tutoring Category</label>
                <select name="category" required>
                    <option value="">Please Choose</option>
                    <option value="Online">Online Tutoring</option>
                    <option value="Home">Home Tutoring</option>
                </select></p>

            <p><label>School Year</label>
                <select name="year" required>
                    <option value="">Please Choose</option>
                    <?php for ($i=1; $i<=13; $i++) echo "<option value='Year $i'>Year $i</option>"; ?>
                </select></p>

            <p class="full"><label>Select Subject(s) (multiselect)</label>
                <select name="preferred_subjects[]" multiple required>
                    <option value="Arabic">Arabic</option>
                    <option value="Accounting">Accounting</option>
                    <option value="Biology">Biology</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="English">English</option>
                    <option value="Mathematics">Mathematics</option>
                    <option value="Physics">Physics</option>
                    <option value="Other">Other</option>
                </select></p>

            <p class="full"><label>School Name</label>
                <select name="school" id="cef-school-select" required>
                    <option value="">Please Choose</option>
                    <!-- Options loaded dynamically from schools.json -->
                </select></p>

            <p><label>Session Duration</label>
                <select name="session_duration" required>
                    <option value="">Please Choose</option>
                    <option value="1 Hour">1 Hour</option>
                    <option value="1.5 Hour">1.5 Hours</option>
                    <option value="2 Hours">2 Hours</option>
                    <option value="3 Hours">3 Hours</option>
                </select></p>

            <p><label>Preferred Days</label>
                <select name="preferred_days[]" multiple required>
                    <option value="Monday">Monday</option>
                    <option value="Tuesday">Tuesday</option>
                    <option value="Wednesday">Wednesday</option>
                    <option value="Thursday">Thursday</option>
                    <option value="Friday">Friday</option>
                    <option value="Saturday">Saturday</option>
                    <option value="Sunday">Sunday</option>
                </select></p>

            <p><label>Preferred Timing(s)</label>
                <select name="preferred_timing" required>
                    <option value="">Please Choose</option>
                    <option value="Pre12PM">Pre 12 PM</option>
                    <option value="12-5PM">12 - 5 PM</option>
                    <option value="After5PM">After 5 PM</option>
                </select></p>

            <p class="full"><label>Message</label>
                <textarea name="message" placeholder="Message" rows="5" required></textarea></p>

            <p class="full">
                <label><input type="checkbox" name="terms" value="Agreed" required>
                I agree to the Terms & Conditions of ACE Education Bahrain.</label>
            </p>

            <p class="full"><input type="submit" name="cef_tutor_submit" value="Send Enquiry"></p>
        </form>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {

        // ----------------------
        // Phone input (intl-tel-input)
        // ----------------------
        const phoneInput = document.querySelector("#cef-phone");
        if(phoneInput && window.intlTelInput) {
            window.intlTelInputInstance = window.intlTelInput(phoneInput, {
                initialCountry: "bh",
                separateDialCode: true,
                nationalMode: false,
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js"
            });
        }

        const form = document.querySelector(".cef-form-wrapper form");
        form.addEventListener("submit", function () {
            if(window.intlTelInputInstance){
                document.querySelector("#cef-phone-full").value = window.intlTelInputInstance.getNumber();
            }
        });

        // ----------------------
        // Load schools dynamically
        // ----------------------
        const schoolDropdown = document.getElementById("cef-school-select");
        fetch("<?php echo plugin_dir_url(__FILE__); ?>schools.json")
            .then(res => res.json())
            .then(list => {
                list.forEach(s => {
                    const opt = document.createElement('option');
                    opt.value = s.name;
                    opt.textContent = `${s.name} (${s.city})`;
                    schoolDropdown.appendChild(opt);
                });
            })
            .catch(console.error);

        // ----------------------
        // Choices.js for multi-selects
        // ----------------------
        const selects = document.querySelectorAll("select");
        selects.forEach(s => {
            if(window.Choices){
                new Choices(s, {
                    removeItemButton: s.multiple,
                    searchEnabled: s.multiple,
                    placeholderValue: "Please choose..."
                });
            }
        });

    });
    </script>

    <?php
    return ob_get_clean();
}
add_shortcode('custom_tutor_form_bh', 'cef_tutor_form_shortcode');

// -----------------------------
// Handle form submission
// -----------------------------
add_action('init', 'cef_handle_form_submission');
function cef_handle_form_submission(){
    if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cef_tutor_submit'])){

        // Nonce check
        if(!isset($_POST['cef_tutor_form_nonce']) || !wp_verify_nonce($_POST['cef_tutor_form_nonce'],'cef_tutor_form_action')){
            echo '<p style="color:red;">Security check failed.</p>'; return;
        }

        // Terms check
        if(empty($_POST['terms'])){
            echo '<p style="color:red;">You must agree to Terms & Conditions.</p>'; return;
        }

        // Sanitize fields
        $fields = [
            "Parent's Name" => sanitize_text_field($_POST['parent_name']),
            "Student's Name" => sanitize_text_field($_POST['student_name']),
            "Date of Birth" => sanitize_text_field($_POST['dob']),
            "Phone" => sanitize_text_field($_POST['phone_full'] ?? ''),
            "Email" => sanitize_email($_POST['email']),
            "Tutoring Category" => sanitize_text_field($_POST['category']),
            "School Year" => sanitize_text_field($_POST['year']),
            "Preferred Subjects" => implode(', ', array_map('sanitize_text_field', $_POST['preferred_subjects'] ?? [])),
            "School Name" => sanitize_text_field($_POST['school']),
            "Session Duration" => sanitize_text_field($_POST['session_duration']),
            "Preferred Days" => implode(', ', array_map('sanitize_text_field', $_POST['preferred_days'] ?? [])),
            "Preferred Timing" => sanitize_text_field($_POST['preferred_timing']),
            "Message" => sanitize_textarea_field($_POST['message']),
            "Terms & Conditions" => sanitize_text_field($_POST['terms'])
        ];

        // HTML email
        $message = '<html><body><h2>New Tutor Request</h2><table>';
        foreach($fields as $label=>$value){
            $message .= "<tr><td><strong>{$label}:</strong></td><td>{$value}</td></tr>";
        }
        $message .= '</table></body></html>';

        $headers = [
            'From: ACE Education Bahrain <no-reply@aceeducation.bh>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . sanitize_email($_POST['email'])
        ];

        wp_mail(['info@aceeducation.bh','acekl2018@gmail.com'], 'New Tutor Services Form Submission', $message, $headers);

        echo '<script>alert("Thank you! Your inquiry has been submitted.");</script>';
    }
}

// -----------------------------
// Enqueue intl-tel-input & Choices.js
// -----------------------------
function cef_enqueue_assets(){
    wp_enqueue_style('intl-tel-input', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/css/intlTelInput.min.css');
    wp_enqueue_script('intl-tel-input', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/intlTelInput.min.js', [], null, true);

    wp_enqueue_style('choices-css', 'https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css');
    wp_enqueue_script('choices-js', 'https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js', [], null, true);
}
add_action('wp_enqueue_scripts', 'cef_enqueue_assets');
