jQuery(document).ready(function($) {
    console.log('Simple Contact Form: Script loaded');

    // Form validation and enhancement
    const form = $('.scf-form');
    const phoneInput = $('#scf_phone');
    const countrySelect = $('#scf_country_code');
    const submitBtn = $('.scf-submit-btn');

    // Phone number formatting based on country code
    const phoneFormats = {
        '+1': { placeholder: '(555) 123-4567', pattern: /^\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})$/ },
        '+44': { placeholder: '7700 123456', pattern: /^[0-9]{10,11}$/ },
        '+971': { placeholder: '50 123 4567', pattern: /^[0-9]{8,9}$/ },
        '+973': { placeholder: '3333 3333', pattern: /^[0-9]{8}$/ },
        '+966': { placeholder: '50 123 4567', pattern: /^[0-9]{8,9}$/ },
        '+974': { placeholder: '3333 3333', pattern: /^[0-9]{8}$/ },
        '+965': { placeholder: '9999 9999', pattern: /^[0-9]{8}$/ },
        '+968': { placeholder: '9999 9999', pattern: /^[0-9]{8}$/ },
        '+91': { placeholder: '98765 43210', pattern: /^[0-9]{10}$/ },
        '+92': { placeholder: '300 1234567', pattern: /^[0-9]{10}$/ },
        '+880': { placeholder: '1712 345678', pattern: /^[0-9]{10}$/ },
        '+94': { placeholder: '77 123 4567', pattern: /^[0-9]{9}$/ },
        '+60': { placeholder: '12 345 6789', pattern: /^[0-9]{9,10}$/ },
        '+65': { placeholder: '8123 4567', pattern: /^[0-9]{8}$/ },
        '+61': { placeholder: '412 345 678', pattern: /^[0-9]{9}$/ },
        '+49': { placeholder: '172 1234567', pattern: /^[0-9]{10,11}$/ },
        '+33': { placeholder: '6 12 34 56 78', pattern: /^[0-9]{9,10}$/ },
        '+39': { placeholder: '339 123 4567', pattern: /^[0-9]{9,10}$/ },
        '+34': { placeholder: '612 345 678', pattern: /^[0-9]{9}$/ },
        '+31': { placeholder: '6 12345678', pattern: /^[0-9]{9}$/ },
        '+86': { placeholder: '138 0013 8000', pattern: /^[0-9]{11}$/ },
        '+81': { placeholder: '80 1234 5678', pattern: /^[0-9]{10,11}$/ },
        '+82': { placeholder: '10 1234 5678', pattern: /^[0-9]{10,11}$/ },
        '+7': { placeholder: '912 345 67 89', pattern: /^[0-9]{10}$/ },
        '+55': { placeholder: '11 99999 9999', pattern: /^[0-9]{10,11}$/ },
        '+52': { placeholder: '55 1234 5678', pattern: /^[0-9]{10}$/ },
        '+27': { placeholder: '82 123 4567', pattern: /^[0-9]{9}$/ }
    };

    // Update phone placeholder when country changes
    countrySelect.on('change', function() {
        const countryCode = $(this).val();
        if (countryCode && phoneFormats[countryCode]) {
            phoneInput.attr('placeholder', phoneFormats[countryCode].placeholder);
        } else {
            phoneInput.attr('placeholder', 'Enter phone number');
        }
        
        // Clear any previous validation errors
        phoneInput.removeClass('error');
        $('.phone-error').remove();
    });

    // Phone number input formatting (basic)
    phoneInput.on('input', function() {
        // Remove non-numeric characters except spaces, dashes, and parentheses
        let value = $(this).val().replace(/[^\d\s\-\(\)]/g, '');
        $(this).val(value);
        
        // Remove error styling on input
        $(this).removeClass('error');
        $('.phone-error').remove();
    });

    // Real-time validation feedback
    const validateField = function(field) {
        const fieldName = field.attr('name');
        const fieldValue = field.val().trim();
        let isValid = true;
        let errorMessage = '';

        // Remove existing error messages
        field.removeClass('error');
        field.siblings('.field-error').remove();

        // Email validation
        if (fieldName === 'scf_email' && fieldValue) {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(fieldValue)) {
                isValid = false;
                errorMessage = 'Please enter a valid email address';
            }
        }

        // Phone validation
        if (fieldName === 'scf_phone' && fieldValue) {
            const countryCode = countrySelect.val();
            if (countryCode && phoneFormats[countryCode]) {
                const pattern = phoneFormats[countryCode].pattern;
                const cleanPhone = fieldValue.replace(/[\s\-\(\)]/g, '');
                if (!pattern.test(cleanPhone)) {
                    isValid = false;
                    errorMessage = 'Please enter a valid phone number for the selected country';
                }
            }
        }

        // Show error if validation failed
        if (!isValid && errorMessage) {
            field.addClass('error');
            field.after(`<span class="field-error" style="color: #e74c3c; font-size: 12px; margin-top: 4px;">${errorMessage}</span>`);
        }

        return isValid;
    };

    // Add validation on blur for key fields
    $('#scf_email, #scf_phone').on('blur', function() {
        validateField($(this));
    });

    // Form submission handling
    form.on('submit', function(e) {
        let isFormValid = true;
        
        // Add loading state
        form.addClass('loading');
        submitBtn.prop('disabled', true);

        // Validate all required fields
        form.find('input[required], select[required], textarea[required]').each(function() {
            const field = $(this);
            const fieldValue = field.val().trim();
            
            if (!fieldValue) {
                field.addClass('error');
                isFormValid = false;
            } else {
                field.removeClass('error');
                
                // Run specific validations
                if (field.attr('name') === 'scf_email' || field.attr('name') === 'scf_phone') {
                    if (!validateField(field)) {
                        isFormValid = false;
                    }
                }
            }
        });

        // Check consent checkbox
        const consentCheckbox = $('input[name="scf_consent"]');
        if (!consentCheckbox.is(':checked')) {
            consentCheckbox.closest('.scf-field').addClass('error');
            isFormValid = false;
        } else {
            consentCheckbox.closest('.scf-field').removeClass('error');
        }

        // If validation fails, prevent submission
        if (!isFormValid) {
            e.preventDefault();
            form.removeClass('loading');
            submitBtn.prop('disabled', false);
            
            // Scroll to first error
            const firstError = $('.error').first();
            if (firstError.length) {
                $('html, body').animate({
                    scrollTop: firstError.offset().top - 100
                }, 500);
            }
            
            // Show error message
            showMessage('Please fill in all required fields correctly.', 'error');
            return false;
        }

        // If all validations pass, show success message
        setTimeout(function() {
            form.removeClass('loading');
            submitBtn.prop('disabled', false);
        }, 500);
    });

    // Character counter for textarea
    const messageField = $('#scf_message');
    const maxLength = 1000;
    
    messageField.after(`<div class="char-counter" style="text-align: right; font-size: 12px; color: #8899a6; margin-top: 5px;">0 / ${maxLength} characters</div>`);
    
    messageField.on('input', function() {
        const currentLength = $(this).val().length;
        const counter = $(this).siblings('.char-counter');
        
        counter.text(`${currentLength} / ${maxLength} characters`);
        
        if (currentLength > maxLength * 0.9) {
            counter.css('color', '#e74c3c');
        } else if (currentLength > maxLength * 0.8) {
            counter.css('color', '#f39c12');
        } else {
            counter.css('color', '#8899a6');
        }
        
        // Limit characters
        if (currentLength > maxLength) {
            $(this).val($(this).val().substring(0, maxLength));
            counter.text(`${maxLength} / ${maxLength} characters`);
        }
    });

    // Auto-resize textarea
    messageField.on('input', function() {
        this.style.height = 'auto';
        this.style.height = this.scrollHeight + 'px';
    });

    // Utility function to show messages
    function showMessage(message, type) {
        // Remove existing messages
        $('.scf-temp-message').remove();
        
        const messageClass = type === 'error' ? 'scf-error' : 'scf-success';
        const messageHtml = `<div class="scf-temp-message ${messageClass}" style="margin-bottom: 20px;">${message}</div>`;
        
        form.before(messageHtml);
        
        // Auto-remove after 5 seconds
        setTimeout(function() {
            $('.scf-temp-message').fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
    }

    // Initialize with default country (Bahrain)
    if (countrySelect.val()) {
        countrySelect.trigger('change');
    }

    // Add smooth transitions
    $('input, select, textarea').on('focus', function() {
        $(this).parent().addClass('focused');
    }).on('blur', function() {
        $(this).parent().removeClass('focused');
    });

    // Prevent double submission
    let isSubmitting = false;
    form.on('submit', function() {
        if (isSubmitting) {
            return false;
        }
        isSubmitting = true;
        
        setTimeout(function() {
            isSubmitting = false;
        }, 3000);
    });

    console.log('Simple Contact Form: All features initialized');
});