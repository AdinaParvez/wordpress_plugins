<?php
/**
 * Plugin Name: Tuition Team Plugin
 * Description: Responsive team members plugin for tuition centres (Elementor Free friendly)
 * Version: 1.0
 * Author: Adina Pervaiz
 */

if (!defined('ABSPATH')) exit;

// Register Team Post Type
function ttp_register_team_post_type() {
    register_post_type('tuition_team', [
        'labels' => [
            'name' => 'Teaching Team',
            'singular_name' => 'Team Member'
        ],
        'public' => true,
        'supports' => ['title', 'thumbnail'],
        'menu_icon' => 'dashicons-groups',
        'show_in_rest' => true
    ]);
}
add_action('init', 'ttp_register_team_post_type');

// Enqueue Styles
function ttp_enqueue_styles() {
    wp_enqueue_style(
        'tuition-team-style',
        plugin_dir_url(__FILE__) . 'style.css',
        [],
        '1.0'
    );
}
add_action('wp_enqueue_scripts', 'ttp_enqueue_styles');

// Shortcode
function ttp_team_shortcode() {
    $query = new WP_Query([
        'post_type' => 'tuition_team',
        'posts_per_page' => -1
    ]);

    ob_start();
    echo '<div class="ttp-team-grid">';

    while ($query->have_posts()) {
        $query->the_post();
        ?>
        <div class="ttp-member">
            <div class="ttp-image">
                <?php the_post_thumbnail('medium'); ?>
            </div>
            <h3><?php the_title(); ?></h3>
            <p class="ttp-role"><?php echo esc_html(get_post_meta(get_the_ID(), 'role', true)); ?></p>
        </div>
        <?php
    }

    echo '</div>';
    wp_reset_postdata();

    return ob_get_clean();
}
add_shortcode('tuition_team', 'ttp_team_shortcode');

// Role Meta Field
function ttp_add_role_meta() {
    add_meta_box('ttp_role', 'Role', 'ttp_role_callback', 'tuition_team');
}
add_action('add_meta_boxes', 'ttp_add_role_meta');

function ttp_role_callback($post) {
    ?>
    <input type="text" name="ttp_role" value="<?php echo esc_attr(get_post_meta($post->ID, 'role', true)); ?>" style="width:100%">
    <?php
}

function ttp_save_role($post_id) {
    if (isset($_POST['ttp_role'])) {
        update_post_meta($post_id, 'role', sanitize_text_field($_POST['ttp_role']));
    }
}
add_action('save_post', 'ttp_save_role');
