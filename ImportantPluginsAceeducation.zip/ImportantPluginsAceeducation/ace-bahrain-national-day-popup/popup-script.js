/**
 * ACE Bahrain National Day Popup Script
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        const popup = $('#ace-bahrain-popup');
        const closeBtn = $('.ace-popup-close');
        const backdrop = $('.ace-popup-backdrop');
        const settings = acePopupSettings || {};
        
        // Check if popup should be shown
        function shouldShowPopup() {
            if (settings.showOnce) {
                // Check if popup was already shown in this session
                const shown = sessionStorage.getItem('ace_popup_shown');
                if (shown === 'true') {
                    return false;
                }
            }
            return true;
        }
        
        // Show popup
        function showPopup() {
            if (!shouldShowPopup()) {
                return;
            }
            
            const delay = parseInt(settings.delay) || 1000;
            
            setTimeout(function() {
                popup.fadeIn(300);
                $('body').css('overflow', 'hidden');
                
                // Mark as shown
                if (settings.showOnce) {
                    sessionStorage.setItem('ace_popup_shown', 'true');
                }
                
                // Track view (optional - you can add analytics here)
                console.log('ACE Popup displayed');
            }, delay);
        }
        
        // Close popup
        function closePopup() {
            popup.fadeOut(300);
            $('body').css('overflow', '');
        }
        
        // Event listeners
        closeBtn.on('click', function(e) {
            e.preventDefault();
            closePopup();
        });
        
        backdrop.on('click', function(e) {
            if (e.target === this) {
                closePopup();
            }
        });
        
        // Close on ESC key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && popup.is(':visible')) {
                closePopup();
            }
        });
        
        // Track button click
        $('.ace-cta-button').on('click', function() {
            console.log('ACE Popup CTA clicked');
            // Add your tracking code here (Google Analytics, etc.)
        });
        
        // Initialize
        showPopup();
    });
    
})(jQuery);