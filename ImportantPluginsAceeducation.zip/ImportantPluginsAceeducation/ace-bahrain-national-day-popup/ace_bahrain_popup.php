<?php
/**
 * Plugin Name: ACE Bahrain National Day Popup
 * Plugin URI: https://aceeducation.bh
 * Description: Beautiful animated popup for Bahrain National Day with 50% off registration offer
 * Version: 1.0.0
 * Author: ACE Education Bahrain
 * Author URI: https://aceeducation.bh
 * License: GPL v2 or later
 * Text Domain: ace-bahrain-popup
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ACE_Bahrain_National_Day_Popup {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_footer', array($this, 'render_popup'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
    }
    
    public function enqueue_scripts() {
        if (!$this->should_show_popup()) {
            return;
        }
        
        wp_enqueue_style('ace-popup-style', plugin_dir_url(__FILE__) . 'css/popup-style.css', array(), '1.0.0');
        wp_enqueue_script('ace-popup-script', plugin_dir_url(__FILE__) . 'js/popup-script.js', array('jquery'), '1.0.0', true);
        
        wp_localize_script('ace-popup-script', 'acePopupSettings', array(
            'delay' => get_option('ace_popup_delay', 1000),
            'showOnce' => get_option('ace_popup_show_once', false)
        ));
    }
    
    private function should_show_popup() {
        $enabled = get_option('ace_popup_enabled', true);
        $pages = get_option('ace_popup_pages', 'all');
        
        if (!$enabled) {
            return false;
        }
        
        if ($pages === 'homepage' && !is_front_page()) {
            return false;
        }
        
        return true;
    }
    
    public function render_popup() {
        if (!$this->should_show_popup()) {
            return;
        }
        
        $discount = get_option('ace_popup_discount', '50');
        $date = get_option('ace_popup_date', 'December 16, 2024');
        $button_text = get_option('ace_popup_button_text', 'Claim Your 50% Discount Now! 🎓');
        $button_url = get_option('ace_popup_button_url', '#');
        ?>
        
        <div id="ace-bahrain-popup" class="ace-popup-overlay" style="display:none;">
            <div class="ace-popup-backdrop"></div>
            <div class="ace-popup-container">
                <button class="ace-popup-close">&times;</button>
                
                <!-- Bahrain Flag Header -->
                <div class="ace-flag-header">
                    <div class="flag-red"></div>
                    <div class="flag-white">
                        <svg viewBox="0 0 100 100" preserveAspectRatio="none">
                            <polygon points="0,0 20,8.33 0,16.66 20,25 0,33.33 20,41.66 0,50 20,58.33 0,66.66 20,75 0,83.33 20,91.66 0,100 100,100 100,0" fill="#CE1126"/>
                        </svg>
                    </div>
                </div>
                
                <!-- Content -->
                <div class="ace-popup-content">
                    <!-- Arabic Greeting -->
                    <div class="ace-greeting">
                        <p class="arabic-text">عيد وطني سعيد</p>
                        <p class="english-text">Happy National Day</p>
                    </div>
                    
                    <!-- Students -->
                    <div class="ace-students">
                        <div class="student-avatar">
                            <div class="avatar-circle">👨‍🎓</div>
                        </div>
                        <div class="student-avatar">
                            <div class="avatar-circle">👩‍🎓</div>
                        </div>
                        <div class="student-avatar">
                            <div class="avatar-circle">👨‍🎓</div>
                        </div>
                    </div>
                    
                    <!-- Branding -->
                    <div class="ace-branding">
                        <h2>ACE Education Bahrain</h2>
                        <div class="brand-line"></div>
                    </div>
                    
                    <!-- Offer -->
                    <div class="ace-offer-box">
                        <div class="offer-content">
                            <span class="emoji">🎉</span>
                            <div class="discount-text"><?php echo esc_html($discount); ?>% OFF</div>
                            <span class="emoji">🎉</span>
                        </div>
                        <p class="offer-title">Registration Fee</p>
                        <p class="offer-subtitle">Limited Time Offer - National Day Special</p>
                    </div>
                    
                    <!-- Date -->
                    <div class="ace-date-badge">
                        <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/>
                        </svg>
                        <span><?php echo esc_html($date); ?></span>
                    </div>
                    
                    <!-- CTA Button -->
                    <a href="<?php echo esc_url($button_url); ?>" class="ace-cta-button">
                        <?php echo esc_html($button_text); ?>
                    </a>
                    
                    <!-- Footer -->
                    <p class="ace-footer-text">*Terms and conditions apply. Offer valid for National Day celebrations only.</p>
                </div>
                
                <!-- Decorative -->
                <div class="ace-decor ace-decor-1">🇧🇭</div>
                <div class="ace-decor ace-decor-2">✨</div>
            </div>
        </div>
        
        <?php
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'ACE National Day Popup',
            'ACE Popup',
            'manage_options',
            'ace-bahrain-popup',
            array($this, 'admin_page'),
            'dashicons-megaphone',
            100
        );
    }
    
    public function register_settings() {
        register_setting('ace_popup_settings', 'ace_popup_enabled');
        register_setting('ace_popup_settings', 'ace_popup_delay');
        register_setting('ace_popup_settings', 'ace_popup_show_once');
        register_setting('ace_popup_settings', 'ace_popup_pages');
        register_setting('ace_popup_settings', 'ace_popup_discount');
        register_setting('ace_popup_settings', 'ace_popup_date');
        register_setting('ace_popup_settings', 'ace_popup_button_text');
        register_setting('ace_popup_settings', 'ace_popup_button_url');
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>🇧🇭 ACE Bahrain National Day Popup Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('ace_popup_settings');
                do_settings_sections('ace_popup_settings');
                ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">Enable Popup</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ace_popup_enabled" value="1" <?php checked(1, get_option('ace_popup_enabled', true)); ?> />
                                Show popup on website
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Display Delay (ms)</th>
                        <td>
                            <input type="number" name="ace_popup_delay" value="<?php echo esc_attr(get_option('ace_popup_delay', 1000)); ?>" class="regular-text" />
                            <p class="description">Time before popup appears (1000 = 1 second)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Show Once Per Session</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ace_popup_show_once" value="1" <?php checked(1, get_option('ace_popup_show_once', false)); ?> />
                                Only show popup once per visitor session
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Display On</th>
                        <td>
                            <select name="ace_popup_pages">
                                <option value="all" <?php selected('all', get_option('ace_popup_pages', 'all')); ?>>All Pages</option>
                                <option value="homepage" <?php selected('homepage', get_option('ace_popup_pages', 'all')); ?>>Homepage Only</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Discount Percentage</th>
                        <td>
                            <input type="text" name="ace_popup_discount" value="<?php echo esc_attr(get_option('ace_popup_discount', '50')); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Event Date</th>
                        <td>
                            <input type="text" name="ace_popup_date" value="<?php echo esc_attr(get_option('ace_popup_date', 'December 16, 2024')); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Button Text</th>
                        <td>
                            <input type="text" name="ace_popup_button_text" value="<?php echo esc_attr(get_option('ace_popup_button_text', 'Claim Your 50% Discount Now! 🎓')); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Button URL</th>
                        <td>
                            <input type="url" name="ace_popup_button_url" value="<?php echo esc_attr(get_option('ace_popup_button_url', '#')); ?>" class="regular-text" />
                            <p class="description">Where should the button link to?</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}

// Initialize the plugin
new ACE_Bahrain_National_Day_Popup();

/* 
 * INSTALLATION INSTRUCTIONS:
 * 
 * 1. Create a folder called "ace-bahrain-national-day-popup" in wp-content/plugins/
 * 
 * 2. Save this file as "ace-bahrain-popup.php" in that folder
 * 
 * 3. Create a "css" subfolder and save the CSS as "popup-style.css"
 * 
 * 4. Create a "js" subfolder and save the JavaScript as "popup-script.js"
 * 
 * 5. Activate the plugin in WordPress Admin > Plugins
 * 
 * 6. Configure settings in WordPress Admin > ACE Popup
 */