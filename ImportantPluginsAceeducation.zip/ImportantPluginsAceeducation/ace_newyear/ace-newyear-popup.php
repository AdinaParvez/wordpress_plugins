<?php
/*
Plugin Name: Ace NewYear Image Popup
Description: Adds a conflict-free NewYear image popup window with admin controls and live preview.
Version: 1.3
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

// Enqueue CSS & JS
function ace_newyear_popup_enqueue_scripts() {
    wp_enqueue_style('ace-newyear-popup-style', plugin_dir_url(__FILE__) . 'css/ace-newyear-popup.css');
    wp_enqueue_script('ace-newyear-popup-script', plugin_dir_url(__FILE__) . 'js/ace-newyear-popup.js', array('jquery','jquery-ui-draggable'), null, true);
}
add_action('wp_enqueue_scripts', 'ace_newyear_popup_enqueue_scripts');

// Pass settings to JS
function ace_newyear_popup_localize_script() {
    $settings = array(
        'delay' => get_option('ace_newyear_popup_delay', 1000),
        'autoshow' => get_option('ace_newyear_popup_autoshow', 1),
        'device' => get_option('ace_newyear_popup_device', 'both')
    );
    wp_localize_script('ace-newyear-popup-script', 'aceNewYearPopup', $settings);
}
add_action('wp_enqueue_scripts', 'ace_newyear_popup_localize_script');

// Front-end popup HTML
function ace_newyear_popup_html() {
    ?>
    <div class="ace-newyear-popup" id="ace-newyear-popup">
        <button class="ace-newyear-close">X</button>
        <img src="<?php echo plugin_dir_url(__FILE__) . 'images/ace-education-newyear.webp'; ?>" alt="NewYear Popup Image" loading="lazy">
    </div>
    <?php
}
add_action('wp_footer', 'ace_newyear_popup_html');

// ------------------- Admin Settings -------------------
function ace_newyear_popup_admin_menu() {
    add_menu_page(
        'NewYear Popup Settings',
        'NewYear Popup',
        'manage_options',
        'ace-newyear-popup-settings',
        'ace_newyear_popup_settings_page',
        'dashicons-images-alt2',
        100
    );
}
add_action('admin_menu', 'ace_newyear_popup_admin_menu');

function ace_newyear_popup_settings_page() {
    if (isset($_POST['ace_newyear_popup_submit'])) {
        check_admin_referer('ace_newyear_popup_settings_save', 'ace_newyear_popup_nonce');
        update_option('ace_newyear_popup_delay', intval($_POST['delay']));
        update_option('ace_newyear_popup_autoshow', isset($_POST['autoshow']) ? 1 : 0);
        update_option('ace_newyear_popup_device', sanitize_text_field($_POST['device']));
        echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
    }

    $delay = get_option('ace_newyear_popup_delay', 1000);
    $autoshow = get_option('ace_newyear_popup_autoshow', 1);
    $device = get_option('ace_newyear_popup_device', 'both');
    ?>
    <div class="wrap">
        <h1>NewYear Popup Settings</h1>
        <form method="post">
            <?php wp_nonce_field('ace_newyear_popup_settings_save', 'ace_newyear_popup_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="delay">Auto-show delay (ms)</label></th>
                    <td><input type="number" name="delay" id="delay" value="<?php echo esc_attr($delay); ?>" /></td>
                </tr>
                <tr>
                    <th><label for="autoshow">Enable auto-show</label></th>
                    <td><input type="checkbox" name="autoshow" id="autoshow" value="1" <?php checked($autoshow, 1); ?> /></td>
                </tr>
                <tr>
                    <th><label for="device">Display on:</label></th>
                    <td>
                        <select name="device" id="device">
                            <option value="both" <?php selected($device, 'both'); ?>>Both Desktop & Mobile</option>
                            <option value="desktop" <?php selected($device, 'desktop'); ?>>Desktop Only</option>
                            <option value="mobile" <?php selected($device, 'mobile'); ?>>Mobile Only</option>
                        </select>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="ace_newyear_popup_submit" class="button button-primary" value="Save Settings"></p>
        </form>

        <h2>Live Preview</h2>
        <div id="ace-newyear-popup-preview" style="position:relative; height:300px;">
            <div class="ace-newyear-popup" id="ace-newyear-popup-admin">
                <button class="ace-newyear-close-admin">X</button>
                <img src="<?php echo plugin_dir_url(__FILE__) . 'images/ace-education-newyear.webp'; ?>" alt="NewYear Popup Image" style="max-width:100%;">
            </div>
            <button id="show-preview-btn" class="button">Show Preview</button>
        </div>

        <style>
            #ace-newyear-popup-admin { display:none; position:absolute; top:50px; left:50%; transform:translateX(-50%); z-index:9999; background:#fff; padding:20px; box-shadow:0 5px 15px rgba(0,0,0,0.3); border-radius:8px; cursor:move;}
            #ace-newyear-popup-admin .ace-newyear-close-admin { position:absolute; top:5px; right:10px; background:#000; color:#fff; border:none; cursor:pointer; font-size:14px; padding:2px 6px; border-radius:3px;}
        </style>

        <script>
        jQuery(document).ready(function($){
            var popup = $('#ace-newyear-popup-admin');
            popup.draggable();

            function showPopupWithDelay() {
                var selectedDevice = $('#device').val();
                var isMobileDevice = window.innerWidth <= 768;
                if ((selectedDevice === 'desktop' && isMobileDevice) || (selectedDevice === 'mobile' && !isMobileDevice)) return;

                var delay = parseInt($('#delay').val()) || 1000;
                popup.hide();
                setTimeout(function(){ popup.fadeIn(); }, delay);
            }

            $('#show-preview-btn').on('click', function(){ showPopupWithDelay(); });
            $('.ace-newyear-close-admin').on('click', function(){ popup.fadeOut(); });

            function autoShowPreview() {
                if($('#autoshow').is(':checked')) showPopupWithDelay();
            }

            autoShowPreview();
            $('#delay, #autoshow, #device').on('change', function(){ popup.fadeOut(); autoShowPreview(); });
        });
        </script>
    </div>
    <?php
}
// ------------------- End Admin Settings -------------------