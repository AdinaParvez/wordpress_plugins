jQuery(document).ready(function($) {
    var popup = $('#ace-newyear-popup');
    var device = aceNewYearPopup.device;

    function isMobile() {
        return /Mobi|Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    }

    if ((device === 'desktop' && isMobile()) || (device === 'mobile' && !isMobile())) return;

    if(aceNewYearPopup.autoshow == 1) {
        setTimeout(function() { popup.fadeIn(); }, aceNewYearPopup.delay);
    }

    $('.ace-newyear-close').on('click', function() { popup.fadeOut(); });

    $(document).mouseup(function(e) {
        if (!popup.is(e.target) && popup.has(e.target).length === 0) { popup.fadeOut(); }
    });
});
