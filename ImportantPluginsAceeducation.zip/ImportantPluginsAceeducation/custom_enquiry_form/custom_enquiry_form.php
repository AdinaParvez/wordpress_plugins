<?php
/*
Plugin Name: Custom Enquiry Form
Description: Popup modal enquiry form with email submission.
Version: 1.0
Author: Adina Pervaiz, Webace Services
*/

if (!defined('ABSPATH')) exit;

// ================= Handle Form Submission =================
add_action('init', 'cef_handle_form');
function cef_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cef_submit'])) {

        // Nonce Check
        if (!isset($_POST['cef_form_nonce']) || !wp_verify_nonce($_POST['cef_form_nonce'], 'cef_form_action')) {
            echo '<p style="color:red;">Security check failed. Please reload the page and try again.</p>';
            return;
        }

        $to = ['info@acelanguagecentre.my', 'acekl2018@gmail.com']; 
        $subject = 'New Enquiry Form Submission';

        $fields = [
            "Name" => sanitize_text_field($_POST['name']),
            "Phone" => sanitize_text_field($_POST['phone']),
            "Email" => sanitize_email($_POST['email']),
            "Message" => sanitize_textarea_field($_POST['message']),
        ];

        // Build email
        $message = '<html><body><h2>New Enquiry</h2><table>';
        foreach ($fields as $label => $value) {
            $message .= "<tr><td><strong>{$label}:</strong></td><td>{$value}</td></tr>";
        }
        $message .= '</table></body></html>';

        $headers = [
            'From: ACE Language Centre Malaysia <no-reply@acelanguagecentre.my>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . sanitize_email($_POST['email'])
        ];

        wp_mail($to, $subject, $message, $headers);

        echo '<script>alert("Thank you! Your enquiry has been submitted.");</script>';
    }
}

// ================= Enqueue Styles & Scripts =================
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('cef-style', plugin_dir_url(__FILE__) . 'cef-style.css');
    wp_enqueue_script('cef-script', plugin_dir_url(__FILE__) . 'cef-script.js', ['jquery'], null, true);
});

// ================== Popup Form HTML ==================
add_action('wp_footer', 'cef_popup_form');
function cef_popup_form() {
    ?>
   
    <!-- Modal -->
    <div id="cefModal" class="cef-modal">
        <div class="cef-modal-content">
            <span class="cef-close">&times;</span>
               <!-- Logo above heading -->
            <div class="cef-logo" style="text-align:center; margin-bottom:10px;">
                <img src="https://media.licdn.com/dms/image/v2/D4E0BAQHjZeBr7btbpw/company-logo_200_200/company-logo_200_200/0/1729324718691?e=2147483647&v=beta&t=3GzKQJkOZ1WIKQWdZt78GJZIlNU469dioIG55DjKnwE" alt="Company Logo" style="max-width:150px; height:auto;">
            </div>
            <h2 style="text-align:center; margin-bottom:15px;">Enquiry Form</h2>
            <form method="post" class="cef-form">
                <?php wp_nonce_field('cef_form_action', 'cef_form_nonce'); ?>
                
                <label for="name">Name</label>
                <input type="text" name="name" required>
                
                <label for="phone">Phone</label>
                <input type="text" name="phone" required>
                
                <label for="email">Email</label>
                <input type="email" name="email" required>
                
                <label for="message">Message</label>
                <textarea name="message" rows="4" required></textarea>
                
                <button type="submit" name="cef_submit" class="cef-submit-btn">Submit</button>
            </form>
        </div>
    </div>
    <?php
}


