jQuery(document).ready(function($) {
    let modal = $("#cefModal");
    let closeBtn = $(".cef-close");

    // When any button with .open-enquiry is clicked
    $(document).on("click", ".open-enquiry", function(e) {
        e.preventDefault();
        modal.css('display', 'flex').hide().fadeIn();
    });

    // Close modal when X is clicked
    closeBtn.on("click", function() {
        modal.fadeOut();
    });

    // Close modal when clicking outside the modal content
    $(window).on("click", function(e) {
        if ($(e.target).is("#cefModal")) {
            modal.fadeOut();
        }
    });
});