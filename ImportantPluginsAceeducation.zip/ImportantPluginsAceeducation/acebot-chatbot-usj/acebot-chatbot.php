<?php
/*
Plugin Name: AceBot Chatbot
Description: An AI chatbot for Ace Education with automatic lead capture and quick reply buttons.
Version: 1.2
Author: Adina Pervaiz
*/

// Enqueue chatbot script and styles, and localize AJAX URL
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('acebot-chat', plugin_dir_url(__FILE__) . 'acebot.js', [], null, true);
    wp_enqueue_style('acebot-style', plugin_dir_url(__FILE__) . 'acebot.css');

    wp_localize_script('acebot-chat', 'acebot_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
    ]);

    wp_add_inline_script('acebot-chat', 'console.log("AceBot AJAX URL:", acebot_ajax.ajax_url);');
});

// Add chatbot container and open button to footer
add_action('wp_footer', function () {
    echo '
    <button id="chat-open-btn" class="chat-open-btn">
      Chat With Us
    </button>

    <div id="chat-container" class="chat-container" style="display: none; flex-direction: column;">
      <div id="chat-header" class="chat-header">
        <div class="chat-header-left">
          <img src="https://cdn-icons-png.flaticon.com/512/4086/4086699.png" alt="Chatbot Avatar" class="chat-avatar">
          <span>Aina - AI Agent</span>
        </div>
        <div class="chat-header-right">
          <button id="chat-minimize-btn" class="chat-header-btn" title="Minimize">&#8211;</button>
          <button id="chat-close-btn" class="chat-header-btn" title="Close">&times;</button>
        </div>
      </div>

      <div id="chat-messages" class="chat-messages"></div>

      <div id="quick-replies" class="quick-replies" style="display:none; padding: 8px; gap: 6px; flex-wrap: wrap; background: #eef3f9;"></div>

      <div id="chat-input-container" class="chat-input-container">
        <input type="text" id="chat-input" class="chat-input" placeholder="Type your message..." />
        <button id="send-button" class="send-button">Send</button>
      </div>
    </div>
    ';
});

// AJAX handler to email the lead
add_action('wp_ajax_acebot_send_lead', 'acebot_send_lead');
add_action('wp_ajax_nopriv_acebot_send_lead', 'acebot_send_lead');

function acebot_send_lead() {
    $name = sanitize_text_field($_POST['name'] ?? '');
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    $conversation = sanitize_textarea_field($_POST['conversation'] ?? '');

    error_log("Lead info: Name=$name, Phone=$phone, Email=$email");

    $to = ['info@aceeducation.com.my', 'aceducationmarketing@gmail.com'];
    $subject = 'New Chatbot Lead from Website';
    $message = "New chatbot lead:\n\n"
             . "Name: $name\n"
             . "Phone: $phone\n"
             . "Email: $email\n\n"
             . "Conversation:\n$conversation";

    $headers = [
        'From: AceBot <no-reply@aceeducation.com.my>',
        'Reply-To: no-reply@aceeducation.com.my',
        'Content-Type: text/plain; charset=UTF-8'
    ];

    $sent = wp_mail($to, $subject, $message, $headers);

    error_log("wp_mail result: " . ($sent ? "Success" : "Failure"));

    if ($sent) {
        wp_send_json_success(['message' => 'Message sent successfully.']);
    } else {
        wp_send_json_error(['message' => 'Failed to send email.']);
    }

    wp_die();
}
