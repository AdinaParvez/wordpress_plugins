// document.addEventListener("DOMContentLoaded", () => {
//   let clientInfo = { name: '', phone: '', email: '' };
//   let currentStep = 'chat'; // chat -> name -> phone -> email -> done
//   let conversationLog = [];

//   const messagesDiv = document.getElementById("chat-messages");
//   const inputEl = document.getElementById("chat-input");
//   const sendBtn = document.getElementById("send-button");
//   const chatContainer = document.getElementById("chat-container");
//   const minimizeBtn = document.getElementById("chat-minimize-btn");
//   const closeBtn = document.getElementById("chat-close-btn");
//   const chatInputContainer = document.getElementById("chat-input-container");
//   const quickRepliesDiv = document.getElementById("quick-replies");

//   if (!messagesDiv || !inputEl || !sendBtn || !quickRepliesDiv) {
//     console.error("Chatbot required elements not found.");
//     return;
//   }



//  // let botSound = new Audio('https://notificationsounds.com/storage/sounds/file-sounds-1150-notification.mp3');
//   let botSound = new Audio('https://interactive-examples.mdn.mozilla.net/media/examples/t-rex-roar.mp3');

//   document.body.addEventListener('click', () => {
//     botSound.play().catch(e => console.log('Audio unlock attempt failed:', e));
//   }, { once: true });

//   function playBotSound() {
//     botSound.currentTime = 0; // rewind so it always starts from beginning
//     botSound.play().catch(e => console.log('Playback blocked:', e));
//   }


//   const GREETING_TRIGGERS = /\b(hi|hello|hey|good (morning|afternoon|evening))\b/i;
//   const THANKS_TRIGGERS = /\b(thank|thanks|thank you)\b/i;
//   const NEGATIVE_PHRASES = /(i (don't|do not) (want|wish) (to )?(talk|continue|ask|chat)|leave me alone|i hate this)/i;
//   const END_CONVERSATION_TRIGGERS = /\b(bye|goodbye|finish|done|nothing)\b/i;

//   const quickReplies = [
//     { label: "IELTS Info", question: "Tell me about IELTS Preparation" },
//     { label: "English Courses", question: "Do you offer English language courses?" },
//     { label: "Pricing", question: "What are your course prices?" },
//     { label: "Course Outline", question: "What is your course outline?" },
//     { label: "Duration", question: "What is the duration of the specific course?" },
//     { label: "Enrollment", question: "What is the procedure for enrolling in a specific course?" }
//   ];

//   function escapeHtml(text) {
//     const div = document.createElement('div');
//     div.textContent = text;
//     return div.innerHTML;
//   }

//   function renderQuickReplies() {
//     quickRepliesDiv.innerHTML = '';
//     quickReplies.forEach(reply => {
//       const btn = document.createElement('button');
//       btn.className = 'quick-reply-btn';
//       btn.textContent = reply.label;
//       btn.dataset.question = reply.question;
//       btn.addEventListener('click', () => {
//         inputEl.value = reply.question;
//         sendMessage();
//         quickRepliesDiv.style.display = 'none';
//       });
//       quickRepliesDiv.appendChild(btn);
//     });
//     quickRepliesDiv.style.display = 'flex';
//   }

//   async function sendMessage() {
//     if (currentStep === 'done') return;

//     const input = inputEl.value.trim();
//     if (!input) return;

//     //messagesDiv.innerHTML += `<div><strong>You:</strong> ${escapeHtml(input)}</div>`;
//     messagesDiv.innerHTML += `<div class="user-message">${escapeHtml(input)}</div>`;
//     conversationLog.push(`You: ${input}`);
//     messagesDiv.scrollTop = messagesDiv.scrollHeight;

//     inputEl.value = "";
//     quickRepliesDiv.style.display = 'none';

//     const cleanedInput = input.toLowerCase();

//     if (currentStep === 'chat' && GREETING_TRIGGERS.test(cleanedInput)) {
//       messagesDiv.innerHTML += `<div class="aina-message"> Hello! How can I assist you today with Ace Education’s services?</div>`;
//       playBotSound();
//       messagesDiv.scrollTop = messagesDiv.scrollHeight;
//       renderQuickReplies();
//       return;
//     } else if (currentStep === 'chat' && THANKS_TRIGGERS.test(cleanedInput)) {
//       messagesDiv.innerHTML += `<div class="aina-message"> You’re welcome! Is there anything else you’d like to know about Ace Education?</div>`;
//       playBotSound();
//       messagesDiv.scrollTop = messagesDiv.scrollHeight;
//       renderQuickReplies();
//       return;
//     } else if (currentStep === 'chat' && NEGATIVE_PHRASES.test(cleanedInput)) {
//       currentStep = 'name';
//       setTimeout(() => {
//         messagesDiv.innerHTML += `<div class="aina-message"> I'm sorry to hear that. Before you go, could you please share your name so we can assist you better?</div>`;
//         playBotSound();
//         messagesDiv.scrollTop = messagesDiv.scrollHeight;
//       }, 500);
//       return;
//     } else if (currentStep === 'chat' && END_CONVERSATION_TRIGGERS.test(cleanedInput)) {
//       currentStep = 'name';
//       setTimeout(() => {
//         messagesDiv.innerHTML += `<div class="aina-message"> Before you go, could you please share your name so we can assist you better?</div>`;
//         playBotSound();
//         messagesDiv.scrollTop = messagesDiv.scrollHeight;
//       }, 500);
//       return;
//     }

//     if (currentStep === 'chat') {
//       try {
//         const businessPrompt = "You are ACE Education AI assistant. Answer questions about courses, prices, and services clearly and politely.";

//         const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyD6hEVD__EXoN7PhQV7gF2D_25wNKHyN9A", {
//           method: "POST",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify({
//             contents: [
//               { parts: [{ text: businessPrompt + "\nUser question: " + input }] }
//             ]
//           })
//         });

//         if (!response.ok) throw new Error('API response not OK');
//         const data = await response.json();

//         let botReply = "Sorry, I couldn't understand. Please try asking differently.";
//         if (data.candidates && data.candidates.length > 0) {
//           botReply = data.candidates[0].content.parts[0].text;
//         }

//        // messagesDiv.innerHTML += `<div class="aina-message"> ${escapeHtml(botReply)}</div>`;
//         messagesDiv.innerHTML += `<div class="aina-message">${escapeHtml(botReply)}</div>`;
//         playBotSound();
//         conversationLog.push(`Aina: ${botReply}`);
//         messagesDiv.scrollTop = messagesDiv.scrollHeight;
//         renderQuickReplies();

//       } catch (error) {
//         console.error("Error fetching bot reply:", error);
//         messagesDiv.innerHTML += `<div class="aina-message"> Sorry, I am having trouble responding right now.</div>`;
//         playBotSound();
//         messagesDiv.scrollTop = messagesDiv.scrollHeight;
//       }
//     } else if (currentStep === 'name') {
//       clientInfo.name = input;
//       currentStep = 'phone';
//       messagesDiv.innerHTML += `<div class="aina-message"> Thank you, ${escapeHtml(clientInfo.name)}! Could you provide your phone number?</div>`;
//       playBotSound();
//       messagesDiv.scrollTop = messagesDiv.scrollHeight;
//     } else if (currentStep === 'phone') {
//       clientInfo.phone = input;
//       currentStep = 'email';
//       messagesDiv.innerHTML += `<div class="aina-message"> Great! Lastly, what's your email address?</div>`;
//       playBotSound();
//       messagesDiv.scrollTop = messagesDiv.scrollHeight;
//     } else if (currentStep === 'email') {
//       clientInfo.email = input;
//       currentStep = 'done';

//       sendBtn.disabled = true;
//       inputEl.disabled = true;

//       fetch(acebot_ajax.ajax_url + '?action=acebot_send_lead', {
//         method: "POST",
//         headers: { "Content-Type": "application/x-www-form-urlencoded" },
//         body: new URLSearchParams({
//           name: clientInfo.name,
//           phone: clientInfo.phone,
//           email: clientInfo.email,
//           conversation: conversationLog.join('\n')
//         })
//       })
//       .then(response => {
//         if (!response.ok) throw new Error('Network response was not ok');
//         return response.json();
//       }).then(data => {
//         if (data.success) {
//           messagesDiv.innerHTML = `<div class="aina-message"> Thank you for sharing your details! Our team will contact you soon.</div>`;
//           playBotSound();
//           conversationLog = [];
//           clientInfo = { name: '', phone: '', email: '' };
//         } else {
//           messagesDiv.innerHTML += `<div class="aina-message"> Sorry, something went wrong. Please try again later.</div>`;
//           playBotSound();
//           sendBtn.disabled = false;
//           inputEl.disabled = false;
//           currentStep = 'email';
//         }
//         messagesDiv.scrollTop = messagesDiv.scrollHeight;
//       })
//       .catch(error => {
//         console.error('Error sending lead:', error);
//         messagesDiv.innerHTML += `<div class="aina-message"> Sorry, an error occurred while sending your details.</div>`;
//         playBotSound();
//         messagesDiv.scrollTop = messagesDiv.scrollHeight;
//         sendBtn.disabled = false;
//         inputEl.disabled = false;
//         currentStep = 'email';
//       });
//     }
//   }

//   sendBtn.addEventListener("click", async () => {
//     await sendMessage();
//   });

//   inputEl.addEventListener("keydown", async (event) => {
//     if (event.key === "Enter") {
//       event.preventDefault();
//       await sendMessage();
//     }
//   });

//   if (minimizeBtn && chatInputContainer && messagesDiv) {
//     minimizeBtn.addEventListener("click", () => {
//       if (messagesDiv.style.display !== "none") {
//         messagesDiv.style.display = "none";
//         chatInputContainer.style.display = "none";
//         quickRepliesDiv.style.display = "none";
//         minimizeBtn.innerHTML = "▲";
//       } else {
//         messagesDiv.style.display = "block";
//         chatInputContainer.style.display = "flex";
//         minimizeBtn.innerHTML = "–";
//         if (currentStep === 'chat') renderQuickReplies();
//       }
//     });
//   }

//   if (closeBtn && chatContainer) {
//     closeBtn.addEventListener("click", () => {
//       chatContainer.style.display = "none";
//       const chatOpenBtn = document.getElementById("chat-open-btn");
//       if (chatOpenBtn) {
//         chatOpenBtn.style.display = "block";
//       }
//     });
//   }

//   const chatOpenBtn = document.getElementById("chat-open-btn");
//   if (chatOpenBtn && chatContainer) {
//     chatOpenBtn.addEventListener("click", () => {
//       chatContainer.style.display = "flex";
//       chatOpenBtn.style.display = "none";
//       if (currentStep === 'chat') renderQuickReplies();
//     });
//   }

//   chatContainer.style.display = "flex";
// //  messagesDiv.innerHTML += `<div class="aina-message"> Hello! How can I assist you today with Ace Education’s services?</div>`;
//   messagesDiv.innerHTML += `<div class="aina-message">Hello! How can I assist you today with Ace Education’s services?</div>`;
//   playBotSound();
//   renderQuickReplies();
// });


document.addEventListener("DOMContentLoaded", () => {
  let clientInfo = { name: '', phone: '', email: '' };
  let currentStep = 'chat';
  let conversationLog = [];

  const messagesDiv = document.getElementById("chat-messages");
  const inputEl = document.getElementById("chat-input");
  const sendBtn = document.getElementById("send-button");
  const chatContainer = document.getElementById("chat-container");
  const minimizeBtn = document.getElementById("chat-minimize-btn");
  const closeBtn = document.getElementById("chat-close-btn");
  const chatInputContainer = document.getElementById("chat-input-container");
  const quickRepliesDiv = document.getElementById("quick-replies");

  if (!messagesDiv || !inputEl || !sendBtn || !quickRepliesDiv) {
    console.error("Chatbot required elements not found.");
    return;
  }

  let botSound = new Audio('https://interactive-examples.mdn.mozilla.net/media/examples/t-rex-roar.mp3');

  document.body.addEventListener('click', () => {
    botSound.play().catch(e => console.log('Audio unlock attempt failed:', e));
  }, { once: true });

  function playBotSound() {
    botSound.currentTime = 0;
    botSound.play().catch(e => console.log('Playback blocked:', e));
  }

  const GREETING_TRIGGERS = /\b(hi|hello|hey|good (morning|afternoon|evening))\b/i;
  const THANKS_TRIGGERS = /\b(thank|thanks|thank you)\b/i;
  const NEGATIVE_PHRASES = /(i (don't|do not) (want|wish) (to )?(talk|continue|ask|chat)|leave me alone|i hate this)/i;
  const END_CONVERSATION_TRIGGERS = /\b(bye|goodbye|finish|done|nothing|no)\b/i;

  const quickReplies = [
    { label: "Test Preparation", question: "Tell me about Test Preparation like SAT, ACT, IELTS, TOEFL, PTE, GRE, GMAT, LNAT, UCAT" },
    { label: "Tutoring", question: "Provide information on Academic Tutoring like IGCSE, IB, CBSE, A-Levels, and more" },
    { label: "Languages", question: "Do you offer language courses?" },
    { label: "Pricing", question: "What are your course prices?" },
    { label: "Course Outline", question: "What is your course outline?" },
    { label: "Duration", question: "What is the duration of the specific course?" },
    { label: "Enrollment", question: "What is the procedure for enrolling in top universities in UK, US, Canada, Australia and Malaysia?" }
  ];

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function renderQuickReplies() {
    quickRepliesDiv.innerHTML = '';
    quickReplies.forEach(reply => {
      const btn = document.createElement('button');
      btn.className = 'quick-reply-btn';
      btn.textContent = reply.label;
      btn.dataset.question = reply.question;
      btn.addEventListener('click', () => {
        inputEl.value = reply.question;
        sendMessage();
        quickRepliesDiv.style.display = 'none';
      });
      quickRepliesDiv.appendChild(btn);
    });
    quickRepliesDiv.style.display = 'flex';
  }

  async function sendMessage() {
    if (currentStep === 'done') return;

    const input = inputEl.value.trim();
    if (!input) return;

    messagesDiv.innerHTML += `<div class="user-message">${escapeHtml(input)}</div>`;
    conversationLog.push(`You: ${input}`);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;

    inputEl.value = "";
    quickRepliesDiv.style.display = 'none';

    const cleanedInput = input.toLowerCase();

    const botReply = (text) => {
      messagesDiv.innerHTML += `<div class="aina-message">${escapeHtml(text)}</div>`;
      playBotSound();
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
    };

    if (currentStep === 'chat' && GREETING_TRIGGERS.test(cleanedInput)) {
      botReply("Hello! How can I assist you today with Ace Education’s services?");
      renderQuickReplies();
      return;
    } else if (currentStep === 'chat' && THANKS_TRIGGERS.test(cleanedInput)) {
      botReply("You’re welcome! Is there anything else you’d like to know about Ace Education?");
      renderQuickReplies();
      return;
    } else if (currentStep === 'chat' && NEGATIVE_PHRASES.test(cleanedInput)) {
      currentStep = 'name';
      setTimeout(() => botReply("I'm sorry to hear that. Before you go, could you please share your name so we can assist you better?"), 500);
      return;
    } else if (currentStep === 'chat' && END_CONVERSATION_TRIGGERS.test(cleanedInput)) {
      currentStep = 'name';
      setTimeout(() => botReply("Before you go, could you please share your name so we can assist you better?"), 500);
      return;
    }

    if (currentStep === 'chat') {
      try {
        const businessPrompt = `You are ACE Education AI assistant. 
                                Answer questions about languages, courses, prices, enrollment and services clearly and politely. 
                                Our contact info is:
                                Phone: +6016477738
                                Email: info@usj.aceeducation.com.my
                                Address: Subang Jaya Branch : C7, USJ10/1J, Taipan Business Centre, 47610, Selangor, Malaysia.`;
        const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyD6hEVD__EXoN7PhQV7gF2D_25wNKHyN9A", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: `${businessPrompt}\nUser question: ${input}` }] }]
          })
        });

        if (!response.ok) throw new Error('API response not OK');
        const data = await response.json();
        let replyText = "Sorry, I couldn't understand. Please try asking differently.";
        if (data.candidates?.[0]?.content?.parts?.[0]?.text) {
          replyText = data.candidates[0].content.parts[0].text;
        }

        botReply(replyText);
        conversationLog.push(`Aina: ${replyText}`);
        renderQuickReplies();
      } catch (error) {
        console.error("Error fetching bot reply:", error);
        botReply("Sorry, I am having trouble responding right now.");
      }
    } else if (currentStep === 'name') {
      clientInfo.name = input;
      currentStep = 'phone';
      botReply(`Thank you, ${escapeHtml(clientInfo.name)}! Could you provide your phone number?`);
    } else if (currentStep === 'phone') {
      clientInfo.phone = input;
      currentStep = 'email';
      botReply("Great! Lastly, what's your email address?");
    } else if (currentStep === 'email') {
      clientInfo.email = input;
      currentStep = 'done';

      sendBtn.disabled = true;
      inputEl.disabled = true;

      fetch(acebot_ajax.ajax_url + '?action=acebot_send_lead', {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          name: clientInfo.name,
          phone: clientInfo.phone,
          email: clientInfo.email,
          conversation: conversationLog.join('\n')
        })
      })
      .then(response => response.ok ? response.json() : Promise.reject())
      .then(data => {
        if (data.success) {
          messagesDiv.innerHTML = `<div class="aina-message">Thank you for sharing your details! Our team will contact you soon.</div>`;
          playBotSound();
          conversationLog = [];
          clientInfo = { name: '', phone: '', email: '' };
        } else {
          botReply("Sorry, something went wrong. Please try again later.");
          sendBtn.disabled = false;
          inputEl.disabled = false;
          currentStep = 'email';
        }
      })
      .catch(() => {
        botReply("Sorry, an error occurred while sending your details.");
        sendBtn.disabled = false;
        inputEl.disabled = false;
        currentStep = 'email';
      });
    }
  }

  sendBtn.addEventListener("click", sendMessage);
  inputEl.addEventListener("keydown", e => e.key === "Enter" && sendMessage());

  if (minimizeBtn && chatInputContainer && messagesDiv) {
    minimizeBtn.addEventListener("click", () => {
      const hidden = messagesDiv.style.display === "none";
      messagesDiv.style.display = hidden ? "block" : "none";
      chatInputContainer.style.display = hidden ? "flex" : "none";
      quickRepliesDiv.style.display = hidden ? "flex" : "none";
      minimizeBtn.innerHTML = hidden ? "–" : "▲";
    });
  }

  if (closeBtn && chatContainer) {
    closeBtn.addEventListener("click", () => {
      chatContainer.style.display = "none";
      const chatOpenBtn = document.getElementById("chat-open-btn");
      if (chatOpenBtn) chatOpenBtn.style.display = "block";
    });
  }

  const chatOpenBtn = document.getElementById("chat-open-btn");
  if (chatOpenBtn && chatContainer) {
    chatOpenBtn.addEventListener("click", () => {
      chatContainer.style.display = "flex";
      chatOpenBtn.style.display = "none";
      if (currentStep === 'chat') renderQuickReplies();
    });
  }

  chatContainer.style.display = "flex";
  messagesDiv.innerHTML += `<div class="aina-message">Hello! How can I assist you today with Ace Education’s services?</div>`;
  playBotSound();
  renderQuickReplies();
});
