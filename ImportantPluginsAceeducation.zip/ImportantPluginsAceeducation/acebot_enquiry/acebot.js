document.addEventListener("DOMContentLoaded", () => {
  let clientInfo = { name: '', phone: '', email: '' };
  let enquiryData = {
    studentName: '',
    subjects: '',
    level: '',
    syllabus: '',
    days: '',
    timings: '',
    duration: '',
    frequency: '',
    platform: '',
    examSchedule: '',
    startTopic: '',
    startingDate: '',
    remarks: ''
  };
  let currentStep = 'chat'; // chat -> enquiry_start -> student_name -> subjects -> level -> etc. -> name -> phone -> email -> done
  let conversationLog = [];
  let enquiryStarted = false;

  const messagesDiv = document.getElementById("chat-messages");
  const inputEl = document.getElementById("chat-input");
  const sendBtn = document.getElementById("send-button");
  const chatContainer = document.getElementById("chat-container");
  const minimizeBtn = document.getElementById("chat-minimize-btn");
  const closeBtn = document.getElementById("chat-close-btn");
  const chatInputContainer = document.getElementById("chat-input-container");
  const quickRepliesDiv = document.getElementById("quick-replies");

  if (!messagesDiv || !inputEl || !sendBtn || !quickRepliesDiv) {
    console.error("Chatbot required elements not found.");
    return;
  }

  let botSound = new Audio('https://interactive-examples.mdn.mozilla.net/media/examples/t-rex-roar.mp3');

  document.body.addEventListener('click', () => {
    botSound.play().catch(e => console.log('Audio unlock attempt failed:', e));
  }, { once: true });

  function playBotSound() {
    botSound.currentTime = 0;
    botSound.play().catch(e => console.log('Playback blocked:', e));
  }

  const GREETING_TRIGGERS = /\b(hi|hello|hey|good (morning|afternoon|evening))\b/i;
  const THANKS_TRIGGERS = /\b(thank|thanks|thank you)\b/i;
  const NEGATIVE_PHRASES = /(i (don't|do not) (want|wish) (to )?(talk|continue|ask|chat)|leave me alone|i hate this)/i;
  const END_CONVERSATION_TRIGGERS = /\b(bye|goodbye|finish|done|nothing|no)\b/i;
  const TUTOR_ENQUIRY_TRIGGERS = /\b(find (a |me )?tutor|need (a )?tutor|looking for (a )?tutor|arrange (a )?tutor|get (a )?tutor|want (a )?tutor|hire (a )?tutor|book (a )?tutor)\b/i;
  const INFO_QUERY_TRIGGERS = /\b(price|pricing|cost|fee|how much|tell me about|information about|what is|what are|do you offer|provide information)\b/i;

  const quickReplies = [
    { label: "Find a Tutor", question: "I need help finding a tutor for my child", isEnquiry: true },
    { label: "Test Preparation", question: "Tell me about Test Preparation like SAT, ACT, IELTS, TOEFL, PTE, GRE, GMAT, LNAT, UCAT" },
    { label: "Academic Tutoring", question: "Provide information on Academic Tutoring like IGCSE, IB, CBSE, A-Levels" },
    { label: "Languages", question: "Do you offer language courses?" },
    { label: "Pricing", question: "What are your course prices?" },
    { label: "Enrollment", question: "What is the enrollment procedure?" }
  ];

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function renderQuickReplies() {
    quickRepliesDiv.innerHTML = '';
    quickReplies.forEach(reply => {
      const btn = document.createElement('button');
      btn.className = 'quick-reply-btn';
      btn.textContent = reply.label;
      btn.dataset.question = reply.question;
      btn.dataset.isEnquiry = reply.isEnquiry || 'false';
      btn.addEventListener('click', () => {
        if (reply.isEnquiry) {
          // Directly start enquiry flow
          enquiryStarted = true;
          currentStep = 'enquiry_start';
          messagesDiv.innerHTML += `<div class="user-message">${escapeHtml(reply.question)}</div>`;
          conversationLog.push(`You: ${reply.question}`);
          messagesDiv.scrollTop = messagesDiv.scrollHeight;
          quickRepliesDiv.style.display = 'none';
          botReply(enquiryQuestions.enquiry_start.question);
          currentStep = enquiryQuestions.enquiry_start.next;
        } else {
          // Normal AI response
          inputEl.value = reply.question;
          sendMessage();
        }
      });
      quickRepliesDiv.appendChild(btn);
    });
    quickRepliesDiv.style.display = 'flex';
  }

  const botReply = (text) => {
    messagesDiv.innerHTML += `<div class="aina-message">${escapeHtml(text)}</div>`;
    conversationLog.push(`Aina: ${text}`);
    playBotSound();
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  };

  const enquiryQuestions = {
    'enquiry_start': { 
      question: "Great! I'd be happy to help arrange a tutor. To start, could you please provide your child's name?",
      next: 'student_name',
      field: null
    },
    'student_name': { 
      question: "Thank you! What subject(s) are you looking for a tutor for? (e.g., Math, Science, English)",
      next: 'subjects',
      field: 'studentName'
    },
    'subjects': { 
      question: "Understood. What level is the student currently studying? (e.g., Year 6, Grade 9)",
      next: 'level',
      field: 'subjects'
    },
    'level': { 
      question: "Got it. What syllabus are you following? (e.g., IGCSE, IB, CBSE, A-Levels)",
      next: 'syllabus',
      field: 'level'
    },
    'syllabus': { 
      question: "Thanks! Which days of the week do you prefer for tutoring sessions? (e.g., Mondays and Wednesdays)",
      next: 'days',
      field: 'syllabus'
    },
    'days': { 
      question: "Great. What timings work best for you? (e.g., 4:00 PM)",
      next: 'timings',
      field: 'days'
    },
    'timings': { 
      question: "Thank you. What duration would you like for each session? Note: Minimum 90 minutes for physical sessions, 60 minutes for online sessions.",
      next: 'duration',
      field: 'timings'
    },
    'duration': { 
      question: "Perfect. How many sessions per week are you looking for? (e.g., 2 sessions per week)",
      next: 'frequency',
      field: 'duration'
    },
    'frequency': { 
      question: "Noted. Would you prefer the sessions to be Physical (at home or at our centre in Plaza Mont Kiara/USJ) or Online?",
      next: 'platform',
      field: 'frequency'
    },
    'platform': { 
      question: "Understood. Is there an expected exam schedule we should be aware of? (e.g., June 2026, or 'No specific exam')",
      next: 'examSchedule',
      field: 'platform'
    },
    'examSchedule': { 
      question: "Thank you. What topics would you like to start with? (e.g., Basic algebra for Math)",
      next: 'startTopic',
      field: 'examSchedule'
    },
    'startTopic': { 
      question: "Got it. When would you like to start the tutoring sessions? (e.g., Next week, ASAP, specific date)",
      next: 'startingDate',
      field: 'startTopic'
    },
    'startingDate': { 
      question: "Perfect. Is there any other information or special requests we should know about? (Type 'No' if nothing else)",
      next: 'remarks',
      field: 'startingDate'
    },
    'remarks': { 
      question: null,
      next: 'complete',
      field: 'remarks'
    }
  };

  async function sendMessage() {
    if (currentStep === 'done') return;

    const input = inputEl.value.trim();
    if (!input) return;

    messagesDiv.innerHTML += `<div class="user-message">${escapeHtml(input)}</div>`;
    conversationLog.push(`You: ${input}`);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;

    inputEl.value = "";
    quickRepliesDiv.style.display = 'none';

    const cleanedInput = input.toLowerCase();

    // Handle greetings
    if (currentStep === 'chat' && GREETING_TRIGGERS.test(cleanedInput)) {
      botReply("Hello! How can I assist you today with ACE Education's services?");
      renderQuickReplies();
      return;
    }

    // Handle thanks
    if (currentStep === 'chat' && THANKS_TRIGGERS.test(cleanedInput)) {
      botReply("You're welcome! Is there anything else you'd like to know about ACE Education?");
      renderQuickReplies();
      return;
    }

    // Handle Yes/Sure/Okay responses - likely they want to proceed with enquiry
    if (currentStep === 'chat' && /^(yes|yeah|yep|sure|ok|okay|definitely|absolutely)$/i.test(cleanedInput)) {
      enquiryStarted = true;
      currentStep = 'enquiry_start';
      botReply(enquiryQuestions.enquiry_start.question);
      currentStep = enquiryQuestions.enquiry_start.next;
      return;
    }

    // Check if user wants to start tutoring enquiry (must be explicit)
    // Skip this check if it's an informational query
    if (currentStep === 'chat' && 
        TUTOR_ENQUIRY_TRIGGERS.test(cleanedInput) && 
        !INFO_QUERY_TRIGGERS.test(cleanedInput)) {
      enquiryStarted = true;
      currentStep = 'enquiry_start';
      botReply(enquiryQuestions.enquiry_start.question);
      currentStep = enquiryQuestions.enquiry_start.next;
      return;
    }

    // Handle negative phrases or end conversation
    if (currentStep === 'chat' && (NEGATIVE_PHRASES.test(cleanedInput) || END_CONVERSATION_TRIGGERS.test(cleanedInput))) {
      currentStep = 'name';
      setTimeout(() => botReply("Before you go, could you please share your name so we can assist you better in the future?"), 500);
      return;
    }

    // Process enquiry flow
    if (enquiryStarted && Object.keys(enquiryQuestions).includes(currentStep)) {
      const currentQuestion = enquiryQuestions[currentStep];
      
      if (currentQuestion.field) {
        enquiryData[currentQuestion.field] = input;
      }

      if (currentQuestion.next === 'complete') {
        // Enquiry complete, now ask for contact details
        enquiryStarted = false;
        botReply("Thank you for providing all the information! We'll review this and arrange a perfect matching tutor for you. To proceed, could you please share your name?");
        currentStep = 'name';
        return;
      } else {
        const nextQuestion = enquiryQuestions[currentQuestion.next];
        botReply(nextQuestion.question);
        currentStep = nextQuestion.next;
        return;
      }
    }

    // Regular chat with AI
    if (currentStep === 'chat') {
      try {
        const businessPrompt = `You are ACE Education AI assistant. 
                                Answer questions about languages, courses, prices, enrollment and services clearly and politely. 
                                Our services include:
                                - Test Preparation (SAT, ACT, IELTS, TOEFL, PTE, GRE, GMAT, LNAT, UCAT)
                                - Academic Tutoring (IGCSE, IB, CBSE, A-Levels)
                                - Language courses
                                - Online and Physical sessions
                                
                                Our contact info:
                                Phone: +6016477738
                                Email: info@usj.aceeducation.com.my
                                Address: Subang Jaya Branch : C7, USJ10/1J, Taipan Business Centre, 47610, Selangor, Malaysia.
                                
                                If someone asks about tutoring or finding a tutor, encourage them to start the enquiry process.`;
        
        const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyD6hEVD__EXoN7PhQV7gF2D_25wNKHyN9A", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: `${businessPrompt}\nUser question: ${input}` }] }]
          })
        });

        if (!response.ok) throw new Error('API response not OK');
        const data = await response.json();
        let replyText = "Sorry, I couldn't understand. Please try asking differently.";
        if (data.candidates?.[0]?.content?.parts?.[0]?.text) {
          replyText = data.candidates[0].content.parts[0].text;
        }

        botReply(replyText);
        renderQuickReplies();
      } catch (error) {
        console.error("Error fetching bot reply:", error);
        botReply("Sorry, I am having trouble responding right now.");
      }
    } 
    // Collect contact information
    else if (currentStep === 'name') {
      clientInfo.name = input;
      currentStep = 'phone';
      botReply(`Thank you, ${escapeHtml(clientInfo.name)}! Could you provide your phone number?`);
    } else if (currentStep === 'phone') {
      clientInfo.phone = input;
      currentStep = 'email';
      botReply("Great! Lastly, what's your email address?");
    } else if (currentStep === 'email') {
      clientInfo.email = input;
      currentStep = 'done';

      // Show processing message
      botReply("Thank you! Processing your information...");

      sendBtn.disabled = true;
      inputEl.disabled = true;

      // Prepare enquiry data summary
      let enquirySummary = '';
      if (enquiryData.studentName) {
        enquirySummary = `
Student Name: ${enquiryData.studentName}
Subject(s): ${enquiryData.subjects}
Level: ${enquiryData.level}
Syllabus: ${enquiryData.syllabus}
Day(s): ${enquiryData.days}
Timings: ${enquiryData.timings}
Duration: ${enquiryData.duration}
Frequency: ${enquiryData.frequency}
Platform: ${enquiryData.platform}
Expected Exam Schedule: ${enquiryData.examSchedule}
Topic to Start With: ${enquiryData.startTopic}
Expected Starting Date: ${enquiryData.startingDate}
Remarks: ${enquiryData.remarks}
        `.trim();
      }

      console.log('Sending data to:', acebot_ajax.ajax_url);
      console.log('Data:', { name: clientInfo.name, phone: clientInfo.phone, email: clientInfo.email });

      fetch(acebot_ajax.ajax_url + '?action=acebot_send_lead', {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          name: clientInfo.name,
          phone: clientInfo.phone,
          email: clientInfo.email,
          conversation: conversationLog.join('\n'),
          enquiry_data: enquirySummary
        })
      })
      .then(response => {
        console.log('Response status:', response.status);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        console.log('Response data:', data);
        if (data.success) {
          setTimeout(() => {
            messagesDiv.innerHTML += `<div class="aina-message">Thank you for sharing your details! We'll review your requirements and get back to you shortly with the tutor's profile and schedule.<br><br><strong>Process:</strong><br>✓ Gathering Information<br>→ Confirming Tutor and Schedule<br>→ Making Payment<br>→ Start Session<br><br>Our team will contact you soon at ${escapeHtml(clientInfo.email)} or ${escapeHtml(clientInfo.phone)}!</div>`;
            playBotSound();
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
          }, 500);
          
          // Reset after 3 seconds
          setTimeout(() => {
            conversationLog = [];
            clientInfo = { name: '', phone: '', email: '' };
            enquiryData = {
              studentName: '', subjects: '', level: '', syllabus: '', days: '',
              timings: '', duration: '', frequency: '', platform: '',
              examSchedule: '', startTopic: '', startingDate: '', remarks: ''
            };
            currentStep = 'chat';
            sendBtn.disabled = false;
            inputEl.disabled = false;
          }, 3000);
        } else {
          setTimeout(() => {
            botReply("Sorry, something went wrong. Please try again later.");
            sendBtn.disabled = false;
            inputEl.disabled = false;
            currentStep = 'email';
          }, 500);
        }
      })
      .catch((error) => {
        console.error('Fetch error:', error);
        setTimeout(() => {
          botReply("Sorry, an error occurred while sending your details. Please try contacting us directly at +6016477738 or info@usj.aceeducation.com.my");
          sendBtn.disabled = false;
          inputEl.disabled = false;
          currentStep = 'email';
        }, 500);
      });
    }
  }

  sendBtn.addEventListener("click", sendMessage);
  inputEl.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      e.preventDefault();
      sendMessage();
    }
  });

  if (minimizeBtn && chatInputContainer && messagesDiv) {
    minimizeBtn.addEventListener("click", () => {
      const hidden = messagesDiv.style.display === "none";
      messagesDiv.style.display = hidden ? "block" : "none";
      chatInputContainer.style.display = hidden ? "flex" : "none";
      quickRepliesDiv.style.display = hidden && currentStep === 'chat' ? "flex" : "none";
      minimizeBtn.innerHTML = hidden ? "&#8211;" : "&#9650;";
    });
  }

  if (closeBtn && chatContainer) {
    closeBtn.addEventListener("click", () => {
      chatContainer.style.display = "none";
      const chatOpenBtn = document.getElementById("chat-open-btn");
      if (chatOpenBtn) chatOpenBtn.style.display = "block";
    });
  }

  const chatOpenBtn = document.getElementById("chat-open-btn");
  if (chatOpenBtn && chatContainer) {
    chatOpenBtn.addEventListener("click", () => {
      chatContainer.style.display = "flex";
      chatOpenBtn.style.display = "none";
      if (currentStep === 'chat') renderQuickReplies();
    });
  }

  chatContainer.style.display = "flex";
  messagesDiv.innerHTML += `<div class="aina-message">Hello! Welcome to ACE Education! How can I assist you today?</div>`;
  playBotSound();
  renderQuickReplies();
});