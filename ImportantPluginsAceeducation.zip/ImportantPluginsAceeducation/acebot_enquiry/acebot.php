<?php
/*
Plugin Name: AceBot Enquiry
Description: An AI chatbot for Ace Education with automatic lead capture, enquiry flow, and quick reply buttons.
Version: 2.0
Author: Adina Pervaiz
*/

// Enqueue chatbot script and styles, and localize AJAX URL
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('acebot-chat', plugin_dir_url(__FILE__) . 'acebot.js', [], '2.0', true);
    wp_enqueue_style('acebot-style', plugin_dir_url(__FILE__) . 'acebot.css', [], '2.0');

    wp_localize_script('acebot-chat', 'acebot_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
    ]);

    wp_add_inline_script('acebot-chat', 'console.log("AceBot AJAX URL:", acebot_ajax.ajax_url);');
});

// Add chatbot container and open button to footer
add_action('wp_footer', function () {
    echo '
    <button id="chat-open-btn" class="chat-open-btn">
      Chat With Us
    </button>

    <div id="chat-container" class="chat-container" style="display: none; flex-direction: column;">
      <div id="chat-header" class="chat-header">
        <div class="chat-header-left">
          <img src="https://cdn-icons-png.flaticon.com/512/4086/4086699.png" alt="Chatbot Avatar" class="chat-avatar">
          <span>Aina - AI Agent</span>
        </div>
        <div class="chat-header-right">
          <button id="chat-minimize-btn" class="chat-header-btn" title="Minimize">&#8211;</button>
          <button id="chat-close-btn" class="chat-header-btn" title="Close">&times;</button>
        </div>
      </div>

      <div id="chat-messages" class="chat-messages"></div>

      <div id="quick-replies" class="quick-replies" style="display:none;"></div>

      <div id="chat-input-container" class="chat-input-container">
        <input type="text" id="chat-input" class="chat-input" placeholder="Type your message..." />
        <button id="send-button" class="send-button">Send</button>
      </div>
    </div>
    ';
});

// AJAX handler to email the lead with enquiry details
add_action('wp_ajax_acebot_send_lead', 'acebot_send_lead');
add_action('wp_ajax_nopriv_acebot_send_lead', 'acebot_send_lead');

function acebot_send_lead() {
    error_log("=== AceBot Lead Submission Started ===");
    error_log("POST data: " . print_r($_POST, true));
    
    $name = sanitize_text_field($_POST['name'] ?? '');
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    $conversation = sanitize_textarea_field($_POST['conversation'] ?? '');
    $enquiry_data = sanitize_textarea_field($_POST['enquiry_data'] ?? '');

    error_log("Sanitized - Name: $name, Phone: $phone, Email: $email");

    // Validate required fields
    if (empty($name) || empty($phone) || empty($email)) {
        error_log("ERROR: Missing required fields");
        wp_send_json_error(['message' => 'Please provide all required information.']);
        wp_die();
    }

    $to = ['info@aceeducation.com.my', 'aceducationmarketing@gmail.com'];
    $subject = 'New Tutoring Enquiry from Website - ' . $name;
    
    $message = "New tutoring enquiry from website:\n\n"
             . "=== CONTACT INFORMATION ===\n"
             . "Name: $name\n"
             . "Phone: $phone\n"
             . "Email: $email\n\n";
    
    if (!empty($enquiry_data)) {
        $message .= "=== ENQUIRY DETAILS ===\n$enquiry_data\n\n";
    }
    
    $message .= "=== FULL CONVERSATION ===\n$conversation\n\n"
              . "---\n"
              . "Process: Gathering Information → Confirming Tutor and Schedule → Making Payment → Start Session\n\n"
              . "Please respond to this enquiry within 24 hours.";

    $headers = [
        'From: AceBot <no-reply@aceeducation.com.my>',
        'Reply-To: ' . $email,
        'Content-Type: text/plain; charset=UTF-8'
    ];

    error_log("Attempting to send email to: " . implode(', ', $to));
    $sent = wp_mail($to, $subject, $message, $headers);

    error_log("wp_mail result: " . ($sent ? "SUCCESS" : "FAILURE"));

    if ($sent) {
        error_log("=== Email sent successfully ===");
        wp_send_json_success([
            'message' => 'Enquiry sent successfully.',
            'data' => [
                'name' => $name,
                'email' => $email
            ]
        ]);
    } else {
        error_log("=== Email failed to send ===");
        // Still return success to user but log the failure
        wp_send_json_success([
            'message' => 'Your enquiry has been received.',
            'data' => [
                'name' => $name,
                'email' => $email
            ]
        ]);
    }

    wp_die();
}