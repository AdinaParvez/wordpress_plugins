<?php
/**
 * Plugin Name: Preload Google Fonts
 * Description: Preloads Google Fonts to improve LCP and reduce render-blocking.
 * Version: 1.0
 * Author: Adina Pervaiz
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Add preload link in the <head>
add_action('wp_head', 'pgf_preload_fonts');
function pgf_preload_fonts() {
    ?>
    <link rel="preload" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@400;500&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@400;500&display=swap">
    </noscript>
    <?php
}
