<?php
/*
Plugin Name: Custom Tutor Form Bahrain
Description: A responsive tutor form that sends email.
Version: 1.3
Author: Adina Pervaiz
*/

// Shortcode to display the form
function cef_tutor_form_shortcode() {
    ob_start(); ?>
    
    <style>
        .cef-form-wrapper {
            max-width: 100%; /* Full width like Elementor */
            margin: 0 auto;
            padding: 20px 0;
            background: #fff; /* White background */
            font-family: Arial, sans-serif;
        }
        .cef-form-wrapper form {
            display: grid;
            grid-template-columns: repeat(2, 1fr); /* Two columns */
            gap: 20px;
            align-items: start;
        }
        .cef-form-wrapper p {
            margin: 0;
        }
        .cef-form-wrapper label {
            font-weight: 600;
            font-size: 14px;
            display: block;
            margin-bottom: 6px;
            color: #333;
        }
        .cef-form-wrapper input[type="text"],
        .cef-form-wrapper input[type="number"],
        .cef-form-wrapper input[type="date"],
        .cef-form-wrapper input[type="tel"],
        .cef-form-wrapper input[type="email"],
        .cef-form-wrapper textarea,
        .cef-form-wrapper select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            background: #fff;
            box-sizing: border-box;
        }

       /* Full-width fields */
        .cef-form-wrapper .full {
            grid-column: span 2;
            width: 100%;
        }

        /*Submit Button*/
        .cef-form-wrapper input[type="submit"] {
            grid-column: span 2;
            background-color: #f9b000; /* Match ACE yellow button */
            width: 100%;
            color: #000;
            border: none;
            padding: 12px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
            font-weight: bold;
            transition: background 0.3s ease;
        }
       
        .cef-form-wrapper input[type="submit"]:hover {
            background-color: #005177;
        }

        /* Checkbox label alignment */
        .cef-form-wrapper label input[type="checkbox"] {
            display: inline-block;
            width: auto;
            margin-right: 8px;
        }
       
    </style>

    <div class="cef-form-wrapper">
        <?php
        // Display success or error messages
        if (isset($_GET['form_status'])) {
            if ($_GET['form_status'] === 'success') {
                echo '<div class="cef-success-message">✓ Thank you! Your inquiry has been submitted successfully.</div>';
            } elseif ($_GET['form_status'] === 'error') {
                echo '<div class="cef-error-message">⚠ There was an error submitting your form. Please try again.</div>';
            } elseif ($_GET['form_status'] === 'terms_error') {
                echo '<div class="cef-error-message">⚠ You must agree to the Terms & Conditions.</div>';
            }
        }
        ?>
        
        <form method="post" action="">
            <?php wp_nonce_field('cef_tutor_form_action', 'cef_tutor_form_nonce'); ?>
            
            <p><label>Parent's Name</label>
                <input type="text" name="parent_name" placeholder="Please write your full name" required></p>
            <p><label>Student's Name</label>
                <input type="text" name="student_name" placeholder="Please write Student's full name" required></p>
            <p><label>Date of Birth</label>
                <input type="date" name="dob" placeholder="Please select your Date of Birth" required></p>
            <p><label>Phone Number</label>
                <input id="cef-phone" type="tel" name="phone" placeholder="Please write phone number" required>
                <input type="hidden" name="phone_full" id="cef-phone-full">
            </p>
               <!-- FULL WIDTH -->
            <p class="full"><label>Email</label>
                <input type="email" placeholder="Please write your Email" name="email" required></p>
            <p><label>Tutoring Category</label>
                <select name="category" required>
                    <option value="">Please Choose</option>
                    <option value="Online">Online Tutoring</option>
                    <option value="Home">Home Tutoring</option>
                </select></p>
            <p><label>School Year</label>
                <select name="year" required>
                    <option value="">Please Choose</option>
                    <?php
                    for ($i = 1; $i <= 13; $i++) {
                        echo "<option value='Year $i'>Year $i</option>";
                    }
                    ?>
                </select></p>
                <!-- FULL WIDTH -->
            <p class="full"><label>Select Subject(s) You can multiselect</label>
                <select name="preferred_subjects[]" multiple required>
                    <option value="">Please Choose</option>
                    <option value="Arabic">Arabic</option>
                    <option value="Accounting">Accounting</option>
                    <option value="Additional Mathematics">Additional Mathematics</option>
                    <option value="Art & Design">Art & Design</option>
                    <option value="Business_Studies">Business Studies</option>
                    <option value="Biology">Biology</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="Chinese">Chinese - First Language / Second Language / Computer Science</option>
                    <option value="Design&Technology">Design & Technology</option>
                    <option value="Drama">Drama</option>
                    <option value="Economics">Economics</option>
                    <option value="English">English</option>
                    <option value="EnglishFirstLanguage">English as a First Language</option>
                    <option value="EnglishSecondLanguage">English as a Second Language</option>
                    <option value="EnglishLiterature">English Literature</option>
                    <option value="Enterprise">Enterprise</option>
                    <option value="Food&Nutrition">Food & Nutrition</option>
                    <option value="FrenchForeignLanguage">French - Foreign Language</option>
                    <option value="Geography">Geography</option>
                    <option value="German-ForeignLanguage">German - Foreign Language</option>
                    <option value="GlobalPerspectives">Global Perspectives</option>
                    <option value="History">History</option>
                    <option value="FurtherMathematics">Further Mathematics</option>
                    <option value="ICT">ICT</option>
                    <option value="Italian-ForeignLanguage">Italian - Foreign Language</option>
                    <option value="MalayFirstLanguage">Malay First Language</option>
                    <option value="MalayForeignLanguage">Malay Foreign Language / Mathematics</option>
                    <option value="Music">Music</option>
                    <option value="ScienceCombined">Science Combined</option>
                    <option value="SciencesCoordinated">Sciences Coordinated</option>
                    <option value="Physics">Physics</option>
                    <option value="Sociology">Sociology</option>
                    <option value="Spanish">Spanish</option>
                    <option value="SpanishFirstLanguage">Spanish First Language</option>
                    <option value="SpanishFirstLanguage">Spanish Foreign Language</option>
                    <option value="Other">Other</option>
                </select></p>
                   <!-- FULL WIDTH -->
            <p class="full"><label>School Name</label>
                <select name="school" id="cef-school-select" required>
                    <option value="">Please Choose</option>
                    <!-- Options loaded dynamically by JS -->
                </select></p>
            <p><label>Session Duration</label>
                <select name="session_duration" required>
                    <option value="">Please Choose</option>
                    <option value="1 Hour">1 Hour</option>
                    <option value="1.5 Hour">1.5 Hours</option>
                    <option value="2 Hours">2 Hours</option>
                    <option value="3 Hours">3 Hours</option>
                </select></p>
            <p><label>Preferred Days</label>
                <select name="preferred_days[]" multiple required>
                    <option value="">Please Choose</option>
                    <option value="Monday">Monday</option>
                    <option value="Tuesday">Tuesday</option>
                    <option value="Wednesday">Wednesday</option>
                    <option value="Thursday">Thursday</option>
                    <option value="Friday">Friday</option>
                    <option value="Saturday">Saturday</option>
                    <option value="Sunday">Sunday</option>
                </select></p>
            <p><label>Preferred Timing(s)</label>
                <select name="preferred_timing" required>
                    <option value="">Please Choose</option>
                    <option value="Pre12PM">Pre 12 PM</option>
                    <option value="12-5PM">12 - 5 PM</option>
                    <option value="After5PM">After 5 PM</option>
                </select></p>
              <!-- FULL WIDTH -->
            <p class="full"><label>Message</label>
                <textarea name="message" placeholder="Message" rows="5" required></textarea></p>
              <!-- FULL WIDTH -->
            <p class="full">
                <label><input type="checkbox" name="terms" value="Agreed" required>
                 Terms & Conditions - I agree to the Terms & Conditions of ACE WEB SERVICES W.L.L. (ACE Education Bahrain)  </label>
            </p>
              <!-- FULL WIDTH -->
            <p class="full"><input type="submit" name="cef_tutor_submit" value="Send Enquiry"></p>
        </form>

        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const dropdown = document.getElementById('cef-school-select');
                fetch("<?php echo plugin_dir_url(__FILE__); ?>schools.json")
                .then(res => res.json())
                .then(list => {
                    list.forEach(s => {
                        const opt = document.createElement('option');
                        opt.value = s.name.replace(/\s+/g, '-');
                        opt.textContent = `${s.name} (${s.city})`;
                        dropdown.appendChild(opt);
                    });
                })
                .catch(console.error);

                const form = document.querySelector(".cef-form-wrapper form");
                form.addEventListener("submit", function () {
                    const fullNumber = window.intlTelInputInstance.getNumber(); // +973XXXXXXXX
                    document.querySelector("#cef-phone-full").value = fullNumber;
                });
                         // Auto-hide success/error messages after 5 seconds
            const successMsg = document.querySelector('.cef-success-message');
            const errorMsg = document.querySelector('.cef-error-message');
            
            if (successMsg || errorMsg) {
                setTimeout(function() {
                    // Remove message with fade effect
                    const msg = successMsg || errorMsg;
                    msg.style.transition = 'opacity 0.5s ease';
                    msg.style.opacity = '0';
                    
                    setTimeout(function() {
                        msg.remove();
                        // Clean URL by removing query parameter
                        const url = new URL(window.location);
                        url.searchParams.delete('form_status');
                        window.history.replaceState({}, document.title, url);
                    }, 500);
                }, 10000); // 10 seconds
            }
        });

        </script>
    </div>

    <?php
    return ob_get_clean();
}
add_shortcode('custom_tutor_form_bh', 'cef_tutor_form_shortcode');

// Handle form submission early (Fixed Hook!)
add_action('init', 'cef_handle_form');

function cef_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cef_tutor_submit'])) {

        // Nonce Check (important)
        if (!isset($_POST['cef_tutor_form_nonce']) || !wp_verify_nonce($_POST['cef_tutor_form_nonce'], 'cef_tutor_form_action')) {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
            exit;
        }

        if (empty($_POST['terms'])) {
            wp_redirect(add_query_arg('form_status', 'terms_error', wp_get_referer()));
            exit;
        }

        $to = ['info@aceeducation.bh', 'acekl2018@gmail.com'];
        $subject = 'New Tutor Services Form Submission';

        $fields = [
            "Parent's Name" => sanitize_text_field($_POST['parent_name']),
            "Student's Name" => sanitize_text_field($_POST['student_name']),
            "Date of Birth" => sanitize_text_field($_POST['dob']),
            "Phone" => sanitize_text_field($_POST['phone'] ?? ''), // <-- full international number
            "Email" => sanitize_email($_POST['email']),
            "Tutoring Category" => sanitize_text_field($_POST['category']),
            "School Year" => sanitize_text_field($_POST['year']),
            "Preferred Subjects" => implode(', ', array_map('sanitize_text_field', $_POST['preferred_subjects'] ?? [])),
            "School Name" => sanitize_text_field($_POST['school']),
            "Session Duration" => sanitize_text_field($_POST['session_duration']),
            "Preferred Days" => implode(', ', array_map('sanitize_text_field', $_POST['preferred_days'] ?? [])),
            "Preferred Timing" => sanitize_text_field($_POST['preferred_timing']),
            "Message" => sanitize_textarea_field($_POST['message']),
            "Terms & Conditions" => sanitize_text_field($_POST['terms']),
        ];

        // Create HTML email body
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #f9b000;">New Tutor Request</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%;">';
        foreach ($fields as $label => $value) {
            $message .= '<tr style="border-bottom: 1px solid #ddd;">';
            $message .= '<td style="padding: 10px; font-weight: bold; width: 200px;">' . $label . ':</td>';
            $message .= '<td style="padding: 10px;">' . $value . '</td>';
            $message .= '</tr>';
        }
        
        $message .= '</table>';
        $message .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
        $message .= '</body></html>';

        $headers = [
            'From: ACE Education BAHRAIN<info@aceeducation.bh>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . sanitize_email($_POST['email'])
        ];

        // Send email
        $mail_sent = wp_mail($to, $subject, $message, $headers);

        // Redirect with success/error message
        if ($mail_sent) {
            wp_redirect(add_query_arg('form_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
        }
        exit;
    }
}
