<?php
/**
 * Plugin Name: AceEdu Core Web Vitals Optimizer
 * Description: Defers render-blocking CSS/JS and preloads fonts for faster LCP and FCP.
 * Version: 1.0
 * Author: Adina Pervaiz
 */

if (!defined('ABSPATH')) exit;

// 1️⃣ Preload Google Fonts for faster paint
add_action('wp_head', function() {
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
    echo '<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">' . "\n";
    echo '<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" media="print" onload="this.media=\'all\'">' . "\n";
    echo '<noscript><link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet"></noscript>' . "\n";
}, 1);

// 2️⃣ Inline a small critical CSS block (replace with your own later)
add_action('wp_head', function() {
    echo '<style>
        body{margin:0;font-family:"Poppins",sans-serif;}
        header, .hero, .main-banner{visibility:visible;}
        .hero,.main-banner{min-height:60vh;background-size:cover;background-position:center;}
    </style>';
}, 2);

// 3️⃣ Async load non-critical CSS
add_filter('style_loader_tag', function($html, $handle, $href, $media) {
    $async_styles = [
        'owl-carousel', 'magnific-popup', 'edubin-core', 'main-css',
        'zenantiquesoft', 'swiper-min', 'acebot_css', 'woocommerce',
        'frontend-events', 'jquery-countdown', 'style-css'
    ];
    if (in_array($handle, $async_styles)) {
        $preload = "<link rel='preload' href='" . esc_url($href) . "' as='style' onload=\"this.rel='stylesheet'\">";
        $noscript = "<noscript><link rel='stylesheet' href='" . esc_url($href) . "'></noscript>";
        return $preload . $noscript;
    }
    return $html;
}, 10, 4);

// 4️⃣ Defer heavy JS
add_filter('script_loader_tag', function($tag, $handle, $src) {
    $defer_scripts = [
        'jquery-migrate', 'js-cookie', 'jquery-blockui',
        'acebot-js', 'swiper', 'owl-carousel'
    ];
    if (in_array($handle, $defer_scripts)) {
        return '<script src="' . esc_url($src) . '" defer></script>' . "\n";
    }
    return $tag;
}, 10, 3);

// 5️⃣ Remove unneeded WooCommerce & slider CSS/JS from non-shop pages
add_action('wp_enqueue_scripts', function() {
    if (!is_woocommerce() && !is_cart() && !is_checkout()) {
        wp_dequeue_style('woocommerce');
        wp_dequeue_style('woocommerce-layout');
        wp_dequeue_style('woocommerce-smallscreen');
    }
    if (!is_front_page()) {
        wp_dequeue_style('owl-carousel');
        wp_dequeue_script('owl-carousel');
    }
}, 99);

// 6️⃣ Add font-display:swap globally
add_action('wp_enqueue_scripts', function() {
    echo "<style>@font-face{font-display:swap;}</style>";
});
