# Recent Blog Posts Display - Bootstrap Edition

A WordPress plugin that displays recent blog posts in Bootstrap card layout, perfectly matching your theme's design.

## Installation Instructions

### Method 1: Manual Installation

1. **Create Plugin Folder Structure:**
   ```
   wp-content/
   └── plugins/
       └── recent-blog-posts/
           ├── recent-blog-posts.php
           ├── assets/
           │   ├── css/
           │   │   └── bootstrap-styles.css
           │   └── img/
           │       └── default-post.png (optional)
           └── README.txt
   ```

2. **Upload Files:**
   - Upload `recent-blog-posts.php` to `wp-content/plugins/recent-blog-posts/`
   - Upload `bootstrap-styles.css` to `wp-content/plugins/recent-blog-posts/assets/css/`

3. **Activate Plugin:**
   - Go to WordPress Admin Dashboard
   - Navigate to Plugins > Installed Plugins
   - Find "Recent Blog Posts Display - Bootstrap Edition"
   - Click "Activate"

### Method 2: ZIP Upload

1. Create a ZIP file with the folder structure above
2. Go to WordPress Admin > Plugins > Add New
3. Click "Upload Plugin"
4. Choose your ZIP file
5. Click "Install Now"
6. Click "Activate Plugin"

## Usage

### Replace Your Existing Code

**BEFORE (Your current code):**
```php
<section class="pt-0">
    <div class="container">
        <!-- Your hardcoded blog posts HTML -->
    </div>
</section>
```

**AFTER (Using the plugin):**
```php
<?php echo do_shortcode('[recent_blog_posts]'); ?>
```

That's it! The plugin will automatically:
- Fetch your latest posts from WordPress
- Display them in the exact same Bootstrap card layout
- Show featured images
- Display categories with color-coded badges
- Show post dates
- Link to full articles

### Shortcode Parameters

**Basic Usage:**
```
[recent_blog_posts]
```

**Show 4 posts:**
```
[recent_blog_posts posts_per_page="4"]
```

**Show 12 posts:**
```
[recent_blog_posts posts_per_page="12"]
```

**Hide the header:**
```
[recent_blog_posts show_header="no"]
```

**Custom column layout (2 columns on large screens):**
```
[recent_blog_posts columns="col-sm-6 col-md-6 col-lg-6"]
```

**Filter by category:**
```
[recent_blog_posts category="art"]
```

**Combined example:**
```
[recent_blog_posts posts_per_page="6" show_header="yes" columns="col-sm-6 col-md-4 col-lg-4"]
```

### Available Column Layouts

- **4 columns (default):** `columns="col-sm-6 col-md-4 col-lg-3"`
- **3 columns:** `columns="col-sm-6 col-md-4 col-lg-4"`
- **2 columns:** `columns="col-sm-6 col-md-6 col-lg-6"`
- **1 column:** `columns="col-12"`

### Using in PHP Templates

Add to your theme files:
```php
<?php echo do_shortcode('[recent_blog_posts]'); ?>
```

Or with parameters:
```php
<?php echo do_shortcode('[recent_blog_posts posts_per_page="8"]'); ?>
```

### Using with Page Builders

**Elementor:**
1. Add a "Shortcode" widget
2. Paste: `[recent_blog_posts]`

**Gutenberg:**
1. Add a "Shortcode" block
2. Paste: `[recent_blog_posts]`

**WPBakery:**
1. Add "Raw HTML" element
2. Paste the shortcode

## Features

✅ **100% Bootstrap Compatible** - Uses your theme's existing Bootstrap classes
✅ **Exact HTML Structure Match** - Matches your original code perfectly
✅ **Automatic Post Fetching** - Pulls from your WordPress database
✅ **Featured Images** - Displays post thumbnails automatically
✅ **Category Badges** - Color-coded category badges
✅ **Responsive Design** - Works on all devices (mobile, tablet, desktop)
✅ **Hover Effects** - Cards lift and images zoom on hover
✅ **Stretched Links** - Entire card is clickable
✅ **Customizable** - Multiple shortcode parameters
✅ **No React/JavaScript** - Pure PHP and Bootstrap
✅ **Lightweight** - Minimal CSS, no heavy frameworks

## Category Badge Colors

The plugin automatically assigns colors to categories:

- **Art** → Blue (Info)
- **Info.Tech / Technology** → Cyan (Info)
- **Mathematics** → Blue (Info)
- **Design** → Orange (Warning)
- **Education** → Green (Success)
- **Business** → Blue (Primary)

You can customize these colors in `bootstrap-styles.css`.

## Styling Customization

### Change Header Style

Edit `bootstrap-styles.css` and find:
```css
.recent-blog-posts-section .header-title.display-4.header {
    -webkit-text-stroke: 2px #0d6efd;
}
```

Change the color to match your brand.

### Change Card Hover Effects

Edit the `.card:hover` section in `bootstrap-styles.css`:
```css
.recent-blog-posts-section .card:hover {
    transform: translateY(-5px); /* Change lift amount */
}
```

### Add Custom Category Colors

In `recent-blog-posts.php`, find the `get_category_badge_class()` function and add:
```php
'Your Category' => 'bg-soft-danger text-danger',
```

## Requirements

- WordPress 5.0 or higher
- PHP 7.0 or higher
- Bootstrap-based theme (Bootstrap 4 or 5)

## Troubleshooting

### Posts Not Showing?

1. **Verify posts exist:** Check WordPress Admin > Posts
2. **Check featured images:** Make sure posts have featured images set
3. **Clear cache:** Clear site cache and browser cache
4. **Check shortcode:** Ensure it's exactly `[recent_blog_posts]`

### Images Not Appearing?

1. **Set featured images:** Go to each post and set a featured image
2. **Add default image:** Place a `default-post.png` in `/assets/img/` folder
3. **Check image path:** Verify the plugin folder name is correct

### Styling Looks Different?

1. **Check Bootstrap version:** Plugin works with Bootstrap 4 & 5
2. **Theme conflicts:** Your theme might override styles
3. **Add !important:** Use `!important` in CSS if needed
4. **Check browser console:** Look for CSS conflicts

### Cards Have Different Heights?

The plugin uses `h-100` class for equal height cards. If still uneven:
```css
.recent-blog-posts-section .card {
    min-height: 450px;
}
```

## Where to Place the Shortcode

### In Your Theme File (index.php, front-page.php, etc.):

**Replace this entire section:**
```php
<section class="pt-0">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <!-- Your old hardcoded HTML -->
            </div>
        </div>
    </div>
</section>
```

**With:**
```php
<?php echo do_shortcode('[recent_blog_posts]'); ?>
```

### In a Page or Post:

Just add the shortcode in the editor:
```
[recent_blog_posts]
```

### In a Widget:

1. Go to Appearance > Widgets
2. Add a "Text" or "HTML" widget
3. Paste: `[recent_blog_posts]`

## Support

For support or questions, please contact: [your-email@example.com]

## Changelog

### Version 1.0.0
- Initial release
- Bootstrap card-based layout
- Exact HTML structure match
- Multiple shortcode parameters
- Category filtering
- Responsive design
- Hover effects

## License

GPL v2 or later

## Credits

Designed to integrate seamlessly with Bootstrap-based WordPress themes.