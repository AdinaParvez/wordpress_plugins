<?php
/**
 * Plugin Name: Recent Blog Posts Display - Bootstrap Edition
 * Plugin URI: https://github.com/AdinaParvez/recent_blog_posts
 * Description: Displays recent blog posts in Bootstrap card layout matching your theme design
 * Version: 1.0.0
 * Author: Adina Pervaiz
 * Author URI: https://adinapervaiz.weebly.com
 * License: GPL v2 or later
 * Text Domain: recent-blog-posts
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('RBP_VERSION', '1.0.0');
define('RBP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('RBP_PLUGIN_URL', plugin_dir_url(__FILE__));

class Recent_Blog_Posts_Bootstrap {
    
    public function __construct() {
        // Register shortcode
        add_shortcode('recent_blog_posts', array($this, 'render_shortcode'));
        
        // Enqueue styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
    }
    
    /**
     * Enqueue plugin assets
     */
    public function enqueue_assets() {
        // Enqueue custom styles for the header
        wp_enqueue_style(
            'rbp-bootstrap-styles',
            RBP_PLUGIN_URL . 'assets/css/bootstrap-styles.css',
            array(),
            RBP_VERSION
        );
    }
    
    /**
     * Get category badge color class
     */
    private function get_category_badge_class($category_name) {
        $category_colors = array(
            'Art' => 'bg-soft-info text-info',
            'Info.Tech' => 'bg-soft-info text-info',
            'Technology' => 'bg-soft-info text-info',
            'Mathmatics' => 'bg-soft-info text-info',
            'Mathematics' => 'bg-soft-info text-info',
            'Design' => 'bg-soft-warning text-warning',
            'Education' => 'bg-soft-success text-success',
            'Business' => 'bg-soft-primary text-primary'
        );
        
        return isset($category_colors[$category_name]) ? $category_colors[$category_name] : 'bg-soft-info text-info';
    }
    
    /**
     * Render shortcode
     */
    public function render_shortcode($atts) {
        $atts = shortcode_atts(array(
            'posts_per_page' => 8,
            'columns' => 'col-sm-6 col-md-4 col-lg-3',
            'show_header' => 'yes',
            'category' => '' // Optional: filter by category
        ), $atts);
        
        // Query arguments
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => intval($atts['posts_per_page']),
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'DESC'
        );
        
        // Add category filter if specified
        if (!empty($atts['category'])) {
            $args['category_name'] = $atts['category'];
        }
        
        $query = new WP_Query($args);
        
        // Start output buffering
        ob_start();
        
        if ($query->have_posts()) :
        ?>
        <section class="pt-0 recent-blog-posts-section">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <?php if ($atts['show_header'] === 'yes') : ?>
                        <div class="mb-6">
                            <h1 class="header-title display-4 header text-center">RECENT BLOGPOST</h1>
                        </div>
                        <?php endif; ?>
                        
                        <div class="row">
                            <?php while ($query->have_posts()) : $query->the_post(); 
                                // Get post data
                                $post_id = get_the_ID();
                                $post_title = get_the_title();
                                $post_link = get_permalink();
                                $post_date = get_the_date('d M Y');
                                
                                // Get category
                                $categories = get_the_category($post_id);
                                $category_name = !empty($categories) ? $categories[0]->name : 'Uncategorized';
                                
                                // Get featured image
                                $thumbnail_url = get_the_post_thumbnail_url($post_id, 'medium');
                                if (!$thumbnail_url) {
                                    $thumbnail_url = RBP_PLUGIN_URL . 'assets/img/default-post.png';
                                }
                                
                                // Get badge class
                                $badge_class = $this->get_category_badge_class($category_name);
                            ?>
                            
                            <div class="<?php echo esc_attr($atts['columns']); ?> mb-4">
                                <div class="card border-100 h-100 shadow">
                                    <div class="card-body p-4 h-100">
                                        <img class="w-100" src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr($post_title); ?>" />
                                        
                                        <div class="d-flex justify-content-between mt-3 border-bottom border-100 py-2">
                                            <span class="badge <?php echo esc_attr($badge_class); ?> rounded-1 fw-normal p-2">
                                                <?php echo esc_html($category_name); ?>
                                            </span>
                                            <p class="mb-0 text-500"><?php echo esc_html($post_date); ?></p>
                                        </div>
                                        
                                        <h3 class="fw-normal fs-lg-1 fs-xxl-2 lh-sm mt-3">
                                            <?php echo esc_html($post_title); ?>
                                        </h3>
                                        
                                        <a class="text-secondary stretched-link" href="<?php echo esc_url($post_link); ?>">
                                            Full Article
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
        else :
            echo '<p class="text-center">No posts found.</p>';
        endif;
        
        // Reset post data
        wp_reset_postdata();
        
        return ob_get_clean();
    }
}

// Initialize the plugin
new Recent_Blog_Posts_Bootstrap();

/**
 * Activation hook
 */
register_activation_hook(__FILE__, 'rbp_bootstrap_plugin_activate');
function rbp_bootstrap_plugin_activate() {
    flush_rewrite_rules();
}

/**
 * Deactivation hook
 */
register_deactivation_hook(__FILE__, 'rbp_bootstrap_plugin_deactivate');
function rbp_bootstrap_plugin_deactivate() {
    flush_rewrite_rules();
}