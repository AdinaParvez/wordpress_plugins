<?php
/**
 * Plugin Name: WebP Auto Converter
 * Description: Automatically converts uploaded images to WebP and serves them on the frontend. Includes on-demand WebP regeneration.
 * Version: 1.1
 * Author: Adina Pervaiz
 */

if (!defined('ABSPATH')) exit;

/**
 * 🖼️ Convert uploaded images to WebP format automatically
 */
add_filter('wp_generate_attachment_metadata', function($metadata, $attachment_id) {
    $upload_dir = wp_upload_dir();
    $base_path = trailingslashit($upload_dir['basedir']);
    $file = get_attached_file($attachment_id);

    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png'])) {
        return $metadata;
    }

    $image = wp_get_image_editor($file);
    if (is_wp_error($image)) {
        return $metadata;
    }

    $webp_path = preg_replace('/\.(jpe?g|png)$/i', '.webp', $file);
    $result = $image->save($webp_path, 'image/webp');

    if (!is_wp_error($result)) {
        $metadata['webp_file'] = str_replace($base_path, '', $webp_path);
    }

    return $metadata;
}, 10, 2);

/**
 * 🚀 Serve WebP versions on the frontend automatically
 */
add_filter('the_content', function($content) {
    return preg_replace_callback('/<img[^>]+src=["\']([^"\']+\.(jpg|jpeg|png))["\'][^>]*>/i', function($matches) {
        $original = $matches[1];
        $webp = preg_replace('/\.(jpe?g|png)$/i', '.webp', $original);
        $webp_path = str_replace(trailingslashit(site_url('/')), trailingslashit(ABSPATH), $webp);

        if (file_exists($webp_path)) {
            return str_replace($original, $webp, $matches[0]);
        }
        return $matches[0];
    }, $content);
});

/**
 * 🎨 Replace inline background-image URLs (for hero banners, sliders, etc.)
 */
add_action('template_redirect', function() {
    ob_start(function($html) {
        return preg_replace_callback('/background-image\s*:\s*url\((["\']?)(https?:\/\/[^"\')]+)\1\)/i', function($match) {
            $original = $match[2];
            $webp = preg_replace('/\.(jpe?g|png)$/i', '.webp', $original);
            $webp_path = str_replace(trailingslashit(site_url('/')), trailingslashit(ABSPATH), $webp);

            if (file_exists($webp_path)) {
                return sprintf('background-image:url("%s")', esc_url($webp));
            }
            return $match[0];
        }, $html);
    });
});

/**
 * ⚙️ Admin Button: Regenerate WebP for All Images
 */
add_action('admin_menu', function() {
    add_media_page(
        'Regenerate WebP',
        'Regenerate WebP',
        'manage_options',
        'regenerate-webp',
        'webp_auto_converter_admin_page'
    );
});

function webp_auto_converter_admin_page() {
    if (!current_user_can('manage_options')) return;

    if (isset($_POST['regenerate_webp'])) {
        $count = webp_auto_converter_regenerate_all();
        echo '<div class="updated notice"><p><strong>' . esc_html($count) . ' WebP images generated successfully.</strong></p></div>';
    }

    echo '<div class="wrap">';
    echo '<h1>Regenerate WebP Images</h1>';
    echo '<p>Click below to generate WebP versions of all existing JPG and PNG images in your Media Library.</p>';
    echo '<form method="post">';
    echo '<input type="hidden" name="regenerate_webp" value="1">';
    submit_button('Regenerate All WebP Images');
    echo '</form></div>';
}

/**
 * 🔁 Regenerate WebP for all attachments
 */
function webp_auto_converter_regenerate_all() {
    $args = array(
        'post_type' => 'attachment',
        'post_mime_type' => array('image/jpeg', 'image/png'),
        'posts_per_page' => -1,
    );

    $query = new WP_Query($args);
    $count = 0;

    foreach ($query->posts as $post) {
        $file = get_attached_file($post->ID);
        if (!file_exists($file)) continue;

        $webp_path = preg_replace('/\.(jpe?g|png)$/i', '.webp', $file);
        if (file_exists($webp_path)) continue; // skip if already exists

        $image = wp_get_image_editor($file);
        if (is_wp_error($image)) continue;

        $result = $image->save($webp_path, 'image/webp');
        if (!is_wp_error($result)) {
            $count++;
        }
    }

    return $count;
}
