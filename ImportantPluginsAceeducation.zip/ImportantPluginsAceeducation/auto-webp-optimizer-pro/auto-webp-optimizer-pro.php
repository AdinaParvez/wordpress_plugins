<?php
/*
Plugin Name: Auto WebP Optimizer Pro
Description: Converts all JPG/PNG uploads to WebP, batch converts existing images, and serves WebP site-wide with revert on deactivation.
Version: 1.1
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

// ================= Convert image to WebP on upload =================
add_filter('wp_handle_upload', function ($upload) {
    $file = $upload['file'];
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png'])) return $upload;

    $webp_file = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', $file);

    switch ($ext) {
        case 'jpg':
        case 'jpeg':
            $img = @imagecreatefromjpeg($file);
            break;
        case 'png':
            $img = @imagecreatefrompng($file);
            imagepalettetotruecolor($img);
            imagealphablending($img, true);
            imagesavealpha($img, true);
            break;
        default:
            return $upload;
    }

    if ($img) {
        imagewebp($img, $webp_file, 80);
        imagedestroy($img);
    }

    return $upload;
});

// ================= Serve .webp globally via output buffer =================
function awo_start_buffer() {
    if (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'image/webp') !== false) {
        ob_start('awo_rewrite_images_to_webp');
    }
}
add_action('template_redirect', 'awo_start_buffer');

function awo_rewrite_images_to_webp($html) {
    $upload_dir = wp_get_upload_dir();
    $base_url = preg_quote($upload_dir['baseurl'], '/');
    $base_dir = $upload_dir['basedir'];

    return preg_replace_callback(
        '/(' . $base_url . '\/[^\s"\'<>]+\.(?:jpg|jpeg|png))/',
        function ($matches) use ($upload_dir) {
            $orig_url = $matches[1];
            $webp_url = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', $orig_url);
            $webp_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $webp_url);
            if (file_exists($webp_path)) {
                return $webp_url;
            }
            return $orig_url;
        },
        $html
    );
}

// ================= Deactivation hook (revert behavior) =================
register_deactivation_hook(__FILE__, function () {
    if (ob_get_length()) {
        @ob_end_clean();
    }
});

// ================= Admin Page for Batch Conversion =================
add_action('admin_menu', function () {
    add_submenu_page(
        'tools.php',
        'WebP Batch Converter',
        'WebP Batch Converter',
        'manage_options',
        'webp-batch-converter-pro',
        'awo_batch_converter_page'
    );
});

function awo_batch_converter_page() {
    if (!current_user_can('manage_options')) return;

    echo '<div class="wrap"><h1>WebP Batch Converter Pro</h1>';
    $upload_dir = wp_get_upload_dir();
    $base_dir = $upload_dir['basedir'];
    $batch_size = 50;

    $all_images = awo_scan_folder($base_dir);
    $total_images = count($all_images);
    if ($total_images === 0) {
        echo '<p>No JPG/PNG images found.</p></div>';
        return;
    }

    $batch_num = isset($_GET['batch']) ? intval($_GET['batch']) : 0;
    $stop = isset($_GET['stop']) ? intval($_GET['stop']) : 0;

    echo '<form method="get" action="">
            <input type="hidden" name="page" value="webp-batch-converter-pro">
            <button class="button button-primary" name="batch" value="1">▶️ Start Conversion</button>
            <button class="button" name="stop" value="1">⏸️ Stop Conversion</button>
          </form><br>';

    if ($stop) {
        echo '<p>Conversion paused.</p></div>';
        return;
    }
    if ($batch_num <= 0) {
        echo '</div>';
        return;
    }

    $start_index = ($batch_num - 1) * $batch_size;
    $end_index = min($start_index + $batch_size, $total_images);
    $progress = round(($end_index / $total_images) * 100);

    echo '<div style="border:1px solid #ccc; width:100%; height:25px; margin-bottom:10px;">
            <div style="background:#0073aa; width:' . $progress . '%; height:100%; color:#fff; text-align:center; line-height:25px;">' . $progress . '%</div>
          </div>';

    echo '<p>Processing batch ' . $batch_num . ': images ' . ($start_index + 1) . ' to ' . $end_index . ' of ' . $total_images . '</p><pre>';

    $batch_images = array_slice($all_images, $start_index, $batch_size);
    foreach ($batch_images as $file) {
        $webp_file = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', $file);
        if (file_exists($webp_file)) {
            echo "Skipped (exists): $webp_file\n";
            continue;
        }

        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        switch ($ext) {
            case 'jpg':
            case 'jpeg':
                $img = @imagecreatefromjpeg($file);
                break;
            case 'png':
                $img = @imagecreatefrompng($file);
                imagepalettetotruecolor($img);
                imagealphablending($img, true);
                imagesavealpha($img, true);
                break;
            default:
                continue 2;
        }

        if ($img) {
            imagewebp($img, $webp_file, 80);
            imagedestroy($img);
            echo "Converted: $file → $webp_file\n";
        }
    }
    echo '</pre>';

    if ($end_index < $total_images && !$stop) {
        $next_batch = $batch_num + 1;
        echo '<script>setTimeout(function(){ window.location.href="' . admin_url('tools.php?page=webp-batch-converter-pro&batch=' . $next_batch) . '"; }, 1000);</script>';
    } else {
        echo '<p>✅ All images processed!</p>';
    }
    echo '</div>';
}

// ================= Recursive Scan Function =================
function awo_scan_folder($dir) {
    $files = [];
    foreach (scandir($dir) as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $dir . '/' . $item;
        if (is_dir($path)) {
            $files = array_merge($files, awo_scan_folder($path));
        } elseif (is_file($path)) {
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png'])) $files[] = $path;
        }
    }
    return $files;
}
