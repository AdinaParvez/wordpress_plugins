# ACE Education Smart Chat - AI Coding Instructions

## Project Overview
A WordPress plugin that embeds an intelligent chat widget for ACE Education (Malaysia tutoring center). The widget implements a **multi-agent knowledge base system** with no external API dependencies—all responses are generated from a structured PHP array indexed by agent type and keyword patterns.

**Version**: 2.0.0 | **License**: GPL v2 or later

---

## Architecture & Data Flow

### Component Structure
- **`ace-education-smart-chat.php`** - WordPress plugin main file (384 lines)
  - `ACE_Education_Smart_Chat` class manages all plugin lifecycle
  - Single-class, object-oriented design (no separate files)
  
- **`script.js`** - Client-side widget interaction (229 lines)
  - jQuery-dependent (WP-bundled jQuery assumed)
  - Manages UI state, agent selection, message history
  
- **`style.css`** - Complete widget styling (388 lines)
  - Fixed position bottom-right widget with gradient headers
  - Mobile-responsive (480px and 360px breakpoints)

### Data Flow
```
User Input (textarea) → JS sendMessage() 
  ↓ AJAX POST to admin-ajax.php
PHP handle_chat_message() → get_smart_response() 
  ↓ Pattern matching on $knowledge_base[$agent]
Response string → JSON success response
  ↓ JS addMessage() renders in chat
```

### Knowledge Base Architecture
The `$knowledge_base` array (lines 28-291) is the **core logic**:
```php
$knowledge_base = [
    'agent_type' => [
        'greeting' => "Initial message",
        'keywords' => [
            'pattern|alternative|regex' => [
                "Response option 1",
                "Response option 2"  // Randomly selected
            ]
        ],
        'default' => "Fallback response"
    ]
]
```
- **4 agents**: `admissions`, `tuition`, `support`, `exams`
- **Pattern matching** via regex—uses longest match wins strategy (lines 266-274)
- **Random selection** from response arrays for variety (line 279)
- **Special handling** for greetings, thank-yous, goodbyes (lines 260-271)

---

## Critical Workflows

### Adding New Agent Responses
1. **Locate agent** in `$knowledge_base` array (e.g., line 77 for `tuition`)
2. **Add keyword pattern** to `'keywords'` array with pipe-separated alternatives
3. **Provide response array** with 1+ strings (randomly selected)
4. **Update `'greeting'` and `'default'`** for that agent
5. **Test via chat UI** - patterns are case-insensitive (`strtolower()` on line 257)

**Example**: Adding mathematics prep support to exams agent:
```php
'calculus|derivatives|integrals' => array(
    "Our calculus tutors specialize in AP/IB advanced topics...",
    "Yes, we cover all calculus topics including..."
)
```

### Frontend Message Flow
1. User types in textarea → `keydown` event (Enter sends, Shift+Enter newlines)
2. `sendMessage()` validates, shows "Agent is typing..." typing indicator
3. AJAX payload includes: `message`, `agent`, `history` (stringified), nonce
4. Response appends to `#ace-chat-messages` with auto-scroll
5. XSS protection: all user input escaped before rendering (line 203)

### Security & Nonce Validation
- **Nonce required**: `check_ajax_referer()` on line 243—blocks CSRF
- **Localized via wp_localize_script** (line 238): nonce passed to JS
- **Both logged-in & anonymous**: `wp_ajax_nopriv_ace_chat_message` hook registered (line 26)
- **Input sanitization**: `sanitize_text_field()` on lines 244-245

---

## Project-Specific Conventions

### Naming Patterns
- **CSS IDs**: `#ace-{component}` prefix (e.g., `#ace-chat-window`, `#ace-chat-messages`)
- **jQuery callbacks**: `function() {}` style (not arrow functions—older jQuery compatibility)
- **Agent keys**: lowercase single word (`admissions`, `tuition`, `support`, `exams`)
- **Message templates**: Use `\n` for line breaks (rendered via `white-space: pre-line` in CSS)

### Styling Conventions
- **Primary gradient**: `#667eea → #240690` or `#667eea → #764ba2` (purple theme)
- **Neutral background**: `#f8f9fa` for UI sections
- **Border color**: `#e9ecef` for subtle dividers
- **Mobile breakpoints**: 480px (tablet), 360px (small phone)
- **Z-index**: 9999 for widget (top layer)

### WordPress Integration
- **Plugin activation**: No activation hooks needed (instantiates class on include)
- **Script loading**: Uses `wp_enqueue_script()` with `wp_localize_script()` pattern (lines 235-241)
- **AJAX endpoints**: Action = `ace_chat_message` (both authenticated & nopriv)
- **No database**: All data is hardcoded in PHP array (no tables, post types, or options)

---

## Edge Cases & Constraints

### Response Generation Rules
1. **Greeting check first** (line 261)—if user says "hi/hello/salam", return greeting regardless of keywords
2. **Longest pattern match wins** (lines 266-274)—prevents "teach" matching before "teach english"
3. **Random response selection** (line 279)—responses array index randomized each time
4. **Fallback to default** (line 281)—if no keywords match
5. **Pattern matching is case-insensitive** (line 257: `strtolower()`)

### UI State Management
- Chat window **open by default** (line 313 displays minimized button as hidden)
- Changing agents **requires confirmation** (line 67)—resets conversation history
- Closing chat **warns user** (line 63)—conversation is lost
- Input disabled during AJAX request (lines 154-155)—prevents duplicate sends

### Mobile Responsiveness
- Below 480px: widget full-screen (`100vw × 100vh`)
- Below 360px: reduced font sizes and padding
- No horizontal scrolling on any viewport

---

## Integration Points & External Dependencies

### WordPress Hooks Used
- `wp_footer` - Renders chat widget HTML on every page
- `wp_enqueue_scripts` - Loads CSS/JS with dependencies
- `wp_ajax_ace_chat_message` - Authenticated AJAX handler
- `wp_ajax_nopriv_ace_chat_message` - Non-authenticated AJAX handler

### jQuery Assumptions
- `$()` selectors, `.on()`, `.ajax()`, `.val()`, `.css()`, `.prop()` methods
- WP bundles jQuery by default; no additional dependencies required
- Textarea auto-resize via `scrollHeight` manipulation (line 207)

### No External APIs
- **No ChatGPT/AI API calls**—all responses pre-built in `$knowledge_base`
- **No external data sources**—contact info, locations, services hardcoded
- **No third-party libraries**—CSS is vanilla, JS uses only jQuery (WP-bundled)

---

## Testing & Debugging Tips

### Common Issues
1. **Chat not responding** → Check nonce validation (line 243), verify AJAX endpoint
2. **Patterns not matching** → Regex syntax in `keywords` keys, remember pipe separator
3. **Mobile layout broken** → Verify CSS media queries; check z-index conflicts with other plugins
4. **XSS errors** → Ensure `escapeHtml()` is called before appending to DOM (line 199-201)

### Quick Debugging
- Open browser DevTools → Network tab → filter by `admin-ajax.php`
- Verify `action=ace_chat_message` and `nonce` values in request payload
- Check PHP error logs if `wp_send_json_error()` fires (line 247)
- Test regex patterns in PHP: `preg_match('/pattern/i', strtolower($message))`

---

## When Modifying Code

### Adding Features
- **New agent**: Add entry to `$knowledge_base` array, update `agentInfo` object in JS, add agent button HTML
- **New keywords**: Only modify `'keywords'` sub-array for target agent; don't alter `'greeting'` or `'default'` unintentionally
- **Styling changes**: Prefer CSS variables or adjust existing gradient/color values; maintain mobile breakpoints

### Preserving Compatibility
- Keep class name `ACE_Education_Smart_Chat` (referenced on line 381)
- Maintain AJAX action name `ace_chat_message` (frontend expects this)
- Don't rename element IDs (`#ace-chat-*`)—CSS/JS depend on exact selectors
- Preserve `escapeHtml()` XSS protection on all user input rendering

---

## File Structure
```
ace-education-smart-chat/
├── ace-education-smart-chat.php     # Main plugin file (class, KB, AJAX handler)
├── script.js                        # Frontend chat logic & event handlers
├── style.css                        # Complete widget UI styling
└── .github/
    └── copilot-instructions.md      # This file
```
