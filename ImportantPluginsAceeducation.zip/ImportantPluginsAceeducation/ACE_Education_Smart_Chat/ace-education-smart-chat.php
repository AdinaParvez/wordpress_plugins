<?php
/**
 * Plugin Name: ACE Education Smart Chat
 * Plugin URI: https://adinapervaiz.weebly.com
 * Description: Smart chat widget with knowledge base 
 * Version: 2.0.0
 * Author: Adina Pervaiz
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

class ACE_Education_Smart_Chat {
    
    private $knowledge_base;
    
    public function __construct() {
        $this->init_knowledge_base();
        
        add_action('wp_footer', array($this, 'render_chat_widget'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_ace_chat_message', array($this, 'handle_chat_message'));
        add_action('wp_ajax_nopriv_ace_chat_message', array($this, 'handle_chat_message'));
    }
    
    private function init_knowledge_base() {
        $this->knowledge_base = array(
            'admissions' => array(
                'greeting' => "Hello! I'm your Admissions Officer at ACE Education Malaysia. I can help you with enrollment, registration, and admission requirements. How can I assist you today?",
                
                'keywords' => array(
                    'enroll|enrollment|register|registration|join|admission|apply|application' => array(
                        "To enroll at ACE Education, simply contact us at +60164777167 (Mont Kiara) or +60162477738 (Subang Jaya). You can also email us at [info@aceeducation.com.my]",
                        "We offer enrollment for students from Grade 3 to Grade 12 across IGCSE, A-Level, IB, CBSE, and CIMP curricula. Contact us to discuss your needs!"
                    ),
                    
                    'location|address|branch|center|centre|where|find' => array(
                        "We have 2 branches in Malaysia:\n📍 Mont Kiara: D-05-08 Plaza Mont Kiara, Jalan Kiara, 50480 Kuala Lumpur\n📍 Subang Jaya: C7, USJ10/1J, Taipan Business Centre, 47610 Selangor",
                        "Find us at Mont Kiara (Plaza Mont Kiara, +60164777167) or Subang Jaya (Taipan Business Centre, +60162477738)"
                    ),
                    
                    'contact|phone|email|reach|call|number' => array(
                        "You can reach us at:\n📞 Mont Kiara: +60164777167\n📞 Subang Jaya: +60162477738\n📧 Email: [email protected]",
                        "Contact us at +60164777167 (Mont Kiara) or +60162477738 (Subang Jaya), or email [email protected]"
                    ),
                    
                    'requirements|qualification|need|documents|eligible' => array(
                        "We accept students from Grade 3 to Grade 12 for various curricula including IGCSE, A-Level, IB, CBSE, and CIMP. Contact us at [email protected] for specific requirements.",
                        "Requirements vary by program. Please reach out to us at +60164777167 to discuss your specific needs."
                    ),
                    
                    'age|grade|level|year|class' => array(
                        "We tutor students from Grade 3 to Grade 12 (Year 3 to Year 13), covering primary through pre-university levels across international curricula.",
                        "ACE Education accepts students aged 8-18 years, from Grade 3 to Grade 12, for IGCSE, A-Level, IB, and other programs."
                    ),
                    
                    'start|begin|when can|schedule' => array(
                        "You can start anytime! We offer flexible scheduling. Contact us at +60164777167 to arrange your first session.",
                        "Classes can begin as soon as you're ready. Reach out to us to discuss scheduling and availability."
                    )
                ),
                
                'default' => "I can help you with enrollment, admission requirements, and registration at ACE Education. Contact us at +60164777167 (Mont Kiara), +60162477738 (Subang Jaya), or email [email protected]"
            ),
            
            'tuition' => array(
                'greeting' => "Hi! I'm your Tuition Advisor at ACE Education Malaysia. I can provide information about our tutoring programs, subjects, and teaching methods. What would you like to know?",
                
                'keywords' => array(
                    'subject|subjects|teach|course|courses|curriculum|what do you offer' => array(
                        "We offer tutoring in:\n📚 Mathematics\n🔬 Sciences (Physics, Chemistry, Biology)\n🌍 Languages (English, Bahasa Malaysia, Mandarin, French, German, Spanish)\n📖 Humanities (History, Geography, Psychology, Sociology)\n💼 Business Studies & Economics",
                        "ACE Education covers all major subjects across IGCSE, A-Level, IB, CBSE, and CIMP curricula - from Maths and Sciences to Languages and Humanities."
                    ),
                    
                    'math|maths|mathematics|calculus|algebra|geometry' => array(
                        "Yes! We have expert Mathematics tutors covering all levels from basic arithmetic to advanced calculus for IGCSE, A-Level, and IB programs.",
                        "Our Maths tutors are highly qualified and have helped hundreds of students improve their grades significantly!"
                    ),
                    
                    'science|physics|chemistry|biology' => array(
                        "We offer specialized tutoring in Physics, Chemistry, and Biology for IGCSE, A-Level, IB, and CBSE by subject experts.",
                        "Our Science tutors are experienced professionals who make complex concepts easy to understand!"
                    ),
                    
                    'online|remote|virtual|zoom|home' => array(
                        "Yes! We offer flexible online tutoring sessions. Our expert tutors deliver engaging one-on-one lessons through interactive virtual platforms.",
                        "ACE Education provides both online and in-person tutoring. Our online sessions are just as effective as face-to-face learning!"
                    ),
                    
                    'tutor|teacher|educator|instructor|who teaches' => array(
                        "Our tutors are highly qualified professionals with specialized subject expertise. We hand-pick only 1 out of 10 applicants, ensuring world-class educators from Malaysia, UK, USA, and other countries.",
                        "ACE Education employs experienced, qualified tutors who are experts in their subjects. Many hold degrees from top universities!"
                    ),
                    
                    'one.on.one|1.on.1|private|individual|personalized|personal' => array(
                        "Yes! We specialize in personalized one-on-one tutoring tailored to each student's learning style, pace, and goals.",
                        "All our tutoring is one-on-one, giving your child focused, personalized support designed to unlock their full potential."
                    ),
                    
                    'price|cost|fee|rates|affordable|expensive|how much|payment' => array(
                        "Our tutoring rates vary depending on subject, level, and tutor experience. Please contact us at +60164777167 or [email protected] for detailed pricing.",
                        "For pricing information, please reach out to our team at +60164777167 (Mont Kiara) or +60162477738 (Subang Jaya)."
                    ),
                    
                    'igcse|gcse|cambridge|edexcel' => array(
                        "We offer expert IGCSE tutoring across all subjects with tutors who know Cambridge and Edexcel requirements inside-out!",
                        "Yes! ACE Education specializes in IGCSE preparation. Our students consistently achieve A* grades!"
                    ),
                    
                    'a.level|as.level|alevel|a2' => array(
                        "We provide comprehensive A-Level tutoring in Sciences, Mathematics, Humanities, and Languages with expert subject specialists.",
                        "Our A-Level tutors are subject experts who deliver personalized coaching to help students excel in AS and A2 exams."
                    ),
                    
                    'ib|ibdp|international baccalaureate|diploma' => array(
                        "We offer complete IB Diploma support including all subject groups, TOK, Extended Essay guidance, and CAS reflections!",
                        "ACE Education's IB specialists help with all six subject groups plus TOK, EE, and CAS - preparing you for top IB scores."
                    ),
                    
                    'cbse|cimp|national|local' => array(
                        "Yes! We provide tutoring for CBSE, CIMP, and the Malaysian national curriculum for all grade levels.",
                        "ACE Education covers local curricula including CBSE and CIMP alongside international programs."
                    ),
                    
                    'experience|qualified|results|success' => array(
                        "Since 2019, ACE Education has helped thousands of students achieve top grades. Our students consistently outperform expectations!",
                        "We have a proven track record of success with students achieving A* grades and gaining admission to top universities worldwide."
                    )
                ),
                
                'default' => "We offer personalized one-on-one tutoring across all subjects for IGCSE, A-Level, IB, and more. Contact us at +60164777167 or [email protected] to learn more!"
            ),
            
            'support' => array(
                'greeting' => "Welcome to ACE Education Malaysia! I'm here to help with any general inquiries about our services, locations, and contact information. How can I assist you?",
                
                'keywords' => array(
                    'about|who|what is ace|tell me about|information' => array(
                        "ACE Education is a trusted tutoring provider in Kuala Lumpur since 2019. We offer personalized one-on-one support for IGCSE, A-Level, IB, and more, helping students achieve academic excellence.",
                        "Since 2019, ACE Education has helped thousands of students thrive through expert tutoring, test prep, language learning, and study abroad guidance!"
                    ),
                    
                    'hours|time|schedule|timing|when|open|available' => array(
                        "We offer flexible scheduling for both online and in-person sessions. Contact us at +60164777167 to arrange lessons at times that suit your needs.",
                        "Our tutoring sessions are scheduled based on your availability - 7 days a week! Reach out to discuss timing."
                    ),
                    
                    'location|address|branch|where|find|directions' => array(
                        "We have 2 convenient locations:\n📍 Mont Kiara: Plaza Mont Kiara, Jalan Kiara, 50480 KL\n📍 Subang Jaya: Taipan Business Centre, 47610 Selangor",
                        "Find us at Mont Kiara (Plaza Mont Kiara, +60164777167) or Subang Jaya (Taipan Business Centre, +60162477738)"
                    ),
                    
                    'contact|phone|email|call|reach|number' => array(
                        "📞 Mont Kiara: +60164777167\n📞 Subang Jaya: +60162477738\n📧 [email protected]\n\nWe also have a branch in Bahrain: +973 6667 7180",
                        "Reach us at +60164777167 (Mont Kiara), +60162477738 (Subang Jaya), or email [email protected]"
                    ),
                    
                    'language|languages|learn|french|german|spanish|mandarin|arabic|english|bahasa' => array(
                        "Our ACE Language Centre offers English, Bahasa Malaysia, Mandarin, French, German, Spanish, Arabic, Japanese, and Korean - taught by native speakers!",
                        "Yes! We offer comprehensive language courses in multiple languages taught by qualified native-speaking instructors."
                    ),
                    
                    'writing|essay|statement|personal statement|university|sop' => array(
                        "We provide expert writing support including IB IAs, Extended Essays, TOK Essays, personal statements (SOPs), and CAS reflections!",
                        "ACE Education helps with academic writing for IB, university applications, personal statements, and study abroad preparation."
                    ),
                    
                    'study abroad|university|admission|uk|us|usa|canada|australia|overseas' => array(
                        "We offer comprehensive study abroad support including university selection, application assistance, and admission guidance for top universities in the UK, US, Canada, Australia, and Malaysia!",
                        "Yes! Our career counselors help you choose the right university and guide you through applications for UK, US, Canadian, Australian, and Malaysian universities."
                    ),
                    
                    'career|counseling|counselling|guidance|advice' => array(
                        "ACE Education offers career counseling to help you choose the right curriculum, university, and career path with expert advisors.",
                        "Our career counselors provide personalized guidance on university selection, course choices, and future career planning."
                    ),
                    
                    'why ace|why choose|better|best' => array(
                        "ACE Education combines future-focused learning, results-oriented teaching, holistic growth, and premium professional standards. We prepare students for life, not just exams!",
                        "We hand-pick the best tutors (1 out of 10 applicants), offer personalized one-on-one sessions, and have a proven track record since 2019!"
                    )
                ),
                
                'default' => "ACE Education offers tutoring, test prep, language learning, and study abroad support across Malaysia. Contact us at +60164777167 (Mont Kiara) or [email protected] for more information!"
            ),
            
            'exams' => array(
                'greeting' => "Hello! I'm your Exam Specialist at ACE Education. I can help you with test preparation for SAT, ACT, IELTS, TOEFL, IGCSE, A-Level, and IB exams. What exam are you preparing for?",
                
                'keywords' => array(
                    'sat|standardized test' => array(
                        "We offer comprehensive SAT preparation with personalized instruction, strategic test-taking techniques, and full-length mock exams to help you achieve top scores!",
                        "ACE Education provides expert SAT prep courses designed to boost your scores through targeted practice and proven strategies."
                    ),
                    
                    'act' => array(
                        "Yes! Our ACT prep program includes expert tutoring, practice tests, and strategic coaching to maximize your score.",
                        "We offer specialized ACT preparation with experienced instructors who know the test inside-out!"
                    ),
                    
                    'ielts|english test|language test' => array(
                        "We prepare students for IELTS with expert instruction, practice tests, and proven techniques to achieve your target band score!",
                        "Yes! Our IELTS prep courses include personalized coaching, mock tests, and strategic guidance from experienced instructors."
                    ),
                    
                    'toefl|pte' => array(
                        "ACE Education offers TOEFL and PTE preparation with comprehensive practice materials and expert coaching!",
                        "We provide specialized TOEFL/PTE prep to help you achieve the scores needed for university admission or immigration."
                    ),
                    
                    'gre|gmat|graduate|postgraduate' => array(
                        "ACE Education offers specialized GRE and GMAT preparation for graduate school applicants, with tailored lessons and comprehensive practice materials!",
                        "We provide expert GRE and GMAT prep to help you excel in graduate admissions. Contact us for personalized coaching plans."
                    ),
                    
                    'igcse|gcse|o level|cambridge' => array(
                        "We specialize in IGCSE/O-Level exam preparation across all subjects with experienced tutors who know Cambridge and Edexcel requirements!",
                        "Our IGCSE tutors have helped hundreds of students achieve A* grades through focused, results-driven preparation!"
                    ),
                    
                    'a level|as level|alevel' => array(
                        "ACE Education provides comprehensive A-Level exam preparation in Sciences, Mathematics, Humanities, and Languages with expert subject specialists!",
                        "Our A-Level tutors deliver personalized coaching to help students excel in their AS and A2 exams across all subjects."
                    ),
                    
                    'ib|ibdp|international baccalaureate' => array(
                        "We offer complete IB Diploma exam preparation including subject tutoring, TOK, Extended Essay guidance, and CAS reflections!",
                        "ACE Education's IB specialists help with all six subject groups plus TOK and EE - preparing you for top IB scores!"
                    ),
                    
                    'study tips|how to study|exam tips|preparation|prepare' => array(
                        "Our tutors teach effective study techniques, time management, exam strategies, and subject-specific methods to maximize your performance!",
                        "We provide proven study strategies, personalized coaching, and exam techniques to help you prepare efficiently and perform confidently!"
                    ),
                    
                    'mock exam|practice test|sample papers|trial' => array(
                        "Yes! We provide full-length mock exams and practice tests as part of our preparation courses, with detailed feedback!",
                        "Mock exams are essential to our prep courses. We use full-length practice tests with real exam conditions to build confidence!"
                    ),
                    
                    'score|grade|result|improve' => array(
                        "Our students consistently achieve top scores! We provide targeted coaching to help you improve your grades significantly.",
                        "ACE Education has a proven track record of helping students achieve A* grades and high test scores through personalized support!"
                    )
                ),
                
                'default' => "We prepare students for SAT, ACT, IELTS, TOEFL, GRE, GMAT, IGCSE, A-Level, and IB exams with expert instruction and proven strategies. Contact +60164777167 or [email protected] to start your prep!"
            )
        );
    }
    
    public function enqueue_scripts() {
        wp_enqueue_style('ace-chat-style', plugin_dir_url(__FILE__) . 'style.css', array(), '2.0.0');
        wp_enqueue_script('jquery');
        wp_enqueue_script('ace-chat-script', plugin_dir_url(__FILE__) . 'script.js', array('jquery'), '2.0.0', true);
        
        wp_localize_script('ace-chat-script', 'aceChat', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ace_chat_nonce')
        ));
    }
    
    public function render_chat_widget() {
        ?>
        <div id="ace-chat-widget">
            <div id="ace-chat-button">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z" fill="white"/>
                </svg>
            </div>
            
            <div id="ace-chat-window">
                <div id="ace-chat-header">
                    <h3>ACE Education Chat</h3>
                    <button id="ace-chat-minimize" aria-label="Minimize">&minus;</button>
                    <button id="ace-chat-close" aria-label="Close">&times;</button>
                </div>
                
                <div id="ace-agent-selection">
                    <p>Please select an agent to chat with:</p>
                    <div class="ace-agent-grid">
                        <button class="ace-agent-btn" data-agent="admissions">
                            <span class="agent-icon">📚</span>
                            <span class="agent-name">Admissions Officer</span>
                            <span class="agent-desc">Course enrollment & registration</span>
                        </button>
                        <button class="ace-agent-btn" data-agent="tuition">
                            <span class="agent-icon">👨‍🏫</span>
                            <span class="agent-name">Tuition Advisor</span>
                            <span class="agent-desc">Program details & tutoring</span>
                        </button>
                        <button class="ace-agent-btn" data-agent="support">
                            <span class="agent-icon">💬</span>
                            <span class="agent-name">Customer Support</span>
                            <span class="agent-desc">General inquiries & help</span>
                        </button>
                        <button class="ace-agent-btn" data-agent="exams">
                            <span class="agent-icon">📝</span>
                            <span class="agent-name">Exam Specialist</span>
                            <span class="agent-desc">Test prep & IGCSE guidance</span>
                        </button>
                    </div>
                </div>
                
                <div id="ace-chat-container" style="display: none;">
                    <div id="ace-chat-agent-info">
                        <span id="ace-current-agent-icon"></span>
                        <span id="ace-current-agent-name"></span>
                        <button id="ace-change-agent">Change Agent</button>
                    </div>
                    <div id="ace-chat-messages"></div>
                    <div id="ace-chat-input-container">
                        <textarea id="ace-chat-input" placeholder="Type your message..." rows="2"></textarea>
                        <button id="ace-chat-send">Send</button>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    public function handle_chat_message() {
        if (!check_ajax_referer('ace_chat_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => 'Security check failed.'));
            return;
        }
        
        $message = isset($_POST['message']) ? sanitize_text_field($_POST['message']) : '';
        $agent = isset($_POST['agent']) ? sanitize_text_field($_POST['agent']) : 'support';
        
        if (empty($message)) {
            wp_send_json_error(array('message' => 'Please enter a message.'));
            return;
        }
        
        // Get response from knowledge base
        $response = $this->get_smart_response($message, $agent);
        
        wp_send_json_success(array('message' => $response));
    }
    
    private function get_smart_response($message, $agent) {
        $message_lower = strtolower($message);
        $agent_kb = $this->knowledge_base[$agent];
        
        // Check for greetings
        if (preg_match('/^(hi|hello|hey|good morning|good afternoon|good evening|greetings|salam)/i', $message)) {
            return $agent_kb['greeting'];
        }
        
        // Check for thank you
        if (preg_match('/(thank|thanks|appreciate|tq)/i', $message)) {
            return "You're very welcome! Is there anything else I can help you with regarding ACE Education? 😊";
        }
        
        // Check for goodbye
        if (preg_match('/(bye|goodbye|see you|thanks bye)/i', $message)) {
            return "Thank you for chatting with ACE Education! Feel free to reach out anytime. Have a great day! 👋";
        }
        
        // Search keywords - give priority to longer matches
        $best_match = null;
        $best_match_length = 0;
        
        foreach ($agent_kb['keywords'] as $pattern => $responses) {
            if (preg_match('/(' . $pattern . ')/i', $message_lower, $matches)) {
                if (strlen($matches[0]) > $best_match_length) {
                    $best_match = $responses;
                    $best_match_length = strlen($matches[0]);
                }
            }
        }
        
        if ($best_match) {
            return $best_match[array_rand($best_match)];
        }
        
        // No match found - return default
        return $agent_kb['default'];
    }
}

new ACE_Education_Smart_Chat();