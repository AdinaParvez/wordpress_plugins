jQuery(document).ready(function($) {
    let currentAgent = null;
    let conversationHistory = [];
    let isMinimized = false;
    
    const agentInfo = {
        'admissions': {
            icon: '📚',
            name: 'Admissions Officer'
        },
        'tuition': {
            icon: '👨‍🏫',
            name: 'Tuition Advisor'
        },
        'support': {
            icon: '💬',
            name: 'Customer Support'
        },
        'exams': {
            icon: '📝',
            name: 'Exam Specialist'
        }
    };
    
    // Initialize chat window visibility
    $('#ace-chat-window').show();
    $('#ace-chat-button').hide();
    $('#ace-chat-container').hide();
    
    // Toggle chat window when button is clicked (restore from minimized state)
    $(document).on('click', '#ace-chat-button', function() {
        $('#ace-chat-window').slideDown(300);
        $('#ace-chat-button').fadeOut(200);
        isMinimized = false;
    });
    
    // Close chat window (hides completely)
    $(document).on('click', '#ace-chat-close', function() {
        if (confirm('Are you sure you want to close the chat? Your conversation will be cleared.')) {
            $('#ace-chat-window').slideUp(300);
            $('#ace-chat-button').fadeIn(200);
            resetChat();
            isMinimized = true;
        }
    });

    // Minimize chat window (hide window but keep button visible)
    $(document).on('click', '#ace-chat-minimize', function() {
        $('#ace-chat-window').slideUp(300);
        $('#ace-chat-button').fadeIn(200);
        isMinimized = true;
    });
    
    // Agent selection - using event delegation
    $(document).on('click', '.ace-agent-btn', function() {
        currentAgent = $(this).data('agent');
        startChat(currentAgent);
    });
    
    // Change agent - using event delegation
    $(document).on('click', '#ace-change-agent', function() {
        if (confirm('Are you sure you want to change agent? This will start a new conversation.')) {
            resetChat();
        }
    });
    
    // Start chat with selected agent
    function startChat(agent) {
        currentAgent = agent;
        conversationHistory = [];
        
        // Update UI
        $('#ace-agent-selection').hide();
        $('#ace-chat-container').show();
        $('#ace-current-agent-icon').text(agentInfo[agent].icon);
        $('#ace-current-agent-name').text(agentInfo[agent].name);
        
        // Clear messages
        $('#ace-chat-messages').empty();
        
        // Welcome message
        const welcomeMessages = {
            'admissions': 'Hello! I\'m your Admissions Officer. How can I help you with enrollment or registration at ACE Education today?',
            'tuition': 'Hi there! I\'m your Tuition Advisor. What would you like to know about our tutoring programs?',
            'support': 'Welcome! I\'m here to help with any questions about ACE Education. How can I assist you?',
            'exams': 'Hello! I\'m your Exam Specialist. How can I help you with test preparation or exam guidance?'
        };
        
        addMessage(welcomeMessages[agent], 'agent');
    }
    
    // Reset chat
    function resetChat() {
        currentAgent = null;
        conversationHistory = [];
        $('#ace-chat-container').hide();
        $('#ace-agent-selection').show();
        $('#ace-chat-messages').empty();
        $('#ace-chat-input').val('');
    }
    
    // Send message on button click - using event delegation
    $(document).on('click', '#ace-chat-send', function() {
        sendMessage();
    });
    
    // Send message on Enter key (Shift+Enter for new line)
    $(document).on('keydown', '#ace-chat-input', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Send message function
    function sendMessage() {
        const message = $('#ace-chat-input').val().trim();
        
        if (message === '' || !currentAgent) {
            return;
        }
        
        // Add user message to chat
        addMessage(message, 'user');
        
        // Clear input
        $('#ace-chat-input').val('');
        
        // Reset textarea height
        $('#ace-chat-input').css('height', 'auto');
        
        // Add to conversation history
        conversationHistory.push({
            role: 'user',
            content: message
        });
        
        // Show typing indicator
        const typingId = addMessage('Agent is typing...', 'typing');
        
        // Disable input while waiting
        $('#ace-chat-input').prop('disabled', true);
        $('#ace-chat-send').prop('disabled', true);
        
        // Send AJAX request
        $.ajax({
            url: aceChat.ajaxurl,
            type: 'POST',
            data: {
                action: 'ace_chat_message',
                nonce: aceChat.nonce,
                message: message,
                agent: currentAgent,
                history: JSON.stringify(conversationHistory)
            },
            success: function(response) {
                // Remove typing indicator
                $('#' + typingId).remove();
                
                if (response.success) {
                    // Add agent response
                    addMessage(response.data.message, 'agent');
                    
                    // Add to conversation history
                    conversationHistory.push({
                        role: 'assistant',
                        content: response.data.message
                    });
                } else {
                    addMessage('Sorry, something went wrong. Please try again.', 'agent');
                }
            },
            error: function() {
                // Remove typing indicator
                $('#' + typingId).remove();
                addMessage('Sorry, I\'m having trouble connecting. Please try again.', 'agent');
            },
            complete: function() {
                // Re-enable input
                $('#ace-chat-input').prop('disabled', false);
                $('#ace-chat-send').prop('disabled', false);
                $('#ace-chat-input').focus();
            }
        });
    }
    
    // Add message to chat
    function addMessage(text, type) {
        const messageId = 'msg-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        const messageClass = type === 'user' ? 'ace-message user' : 
                           type === 'typing' ? 'ace-message typing' : 
                           'ace-message agent';
        
        const messageHtml = '<div class="' + messageClass + '" id="' + messageId + '">' + escapeHtml(text) + '</div>';
        
        $('#ace-chat-messages').append(messageHtml);
        scrollToBottom();
        
        return messageId;
    }
    
    // Scroll to bottom of messages
    function scrollToBottom() {
        const messagesContainer = $('#ace-chat-messages');
        messagesContainer.scrollTop(messagesContainer[0].scrollHeight);
    }
    
    // Escape HTML to prevent XSS
    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }
    
    // Auto-resize textarea - using event delegation
    $(document).on('input', '#ace-chat-input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 100) + 'px';
    });
    
    // Ready check - ensure jQuery and elements are available
    if (!$('#ace-chat-window').length) {
        console.warn('ACE Chat widget HTML not found. Ensure widget is rendered in wp_footer.');
    }
});