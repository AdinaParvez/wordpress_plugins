<?php
/*
Plugin Name: Ace Popup Form
Description: A responsive popup form that sends email.
Version: 1.4
Author: Adina Pervaiz
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue jQuery if not already loaded
add_action('wp_enqueue_scripts', 'ace_popup_enqueue_scripts');
function ace_popup_enqueue_scripts() {
    wp_enqueue_script('jquery');
}

// Add popup to footer automatically on all pages
add_action('wp_footer', 'ace_popup_form');

function ace_popup_form() {
    ?>
    
  <style>
    /* Overlay background */
    #ace-popup-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0, 45, 98, 0.9); /* Deep navy transparent overlay */
        z-index: 9999;
    }

    /* Popup container */
    #ace-popup {
        background: #ffffff; /* White popup background */
        color: #002D62; /* Main text color */
        padding: 25px;
        border-radius: 15px;
        max-width: 400px;
        width: 90%;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        box-shadow: 0 10px 25px rgba(0, 45, 98, 0.3);
        text-align: center;
        border: 2px solid #dcb225;
    }

    #ace-popup h2 {
        margin-bottom: 15px;
        color: #002D62;
    }

    #ace-popup form {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    #ace-popup input,
    #ace-popup select {
        padding: 10px;
        border: 1px solid #dcb225;
        border-radius: 8px;
        font-size: 15px;
        color: #002D62;
        background: #f8f8f8; /* Softer light background for readability */
        transition: background 0.3s ease, border-color 0.3s ease;
    }

    #ace-popup input:focus,
    #ace-popup select:focus {
        background: #ffffff;
        border-color: #002D62;
        outline: none;
    }

    .ace-submit-btn {
        background: #dcb225;
        color: #002D62;
        font-weight: bold;
        border: none;
        cursor: pointer;
        padding: 10px;
        border-radius: 8px;
        transition: background 0.3s ease, color 0.3s ease;
    }

    .ace-submit-btn:hover {
        background: #002D62;
        color: #ffffff;
    }

    #ace-popup-close {
        position: absolute;
        top: 8px;
        right: 12px;
        background: transparent;
        color: #002D62;
        font-size: 24px;
        border: none;
        cursor: pointer;
        line-height: 1;
        transition: transform 0.2s ease, color 0.3s ease;
    }

    #ace-popup-close:hover {
        transform: scale(1.2);
        color: #dcb225;
    }

    #ace-popup label {
        display: flex;
        align-items: center;
        gap: 8px;
        margin: 10px 0;
        text-align: left;
        color: #002D62;
    }

    #ace-popup label span {
        font-size: 13px;
    }

    .ace-success-message {
        background: #28a745;
        color: #ffffff;
        padding: 15px;
        border-radius: 8px;
        margin: 10px 0;
        text-align: center;
    }

    .ace-error-message {
        background: #dc3545;
        color: #ffffff;
        padding: 15px;
        border-radius: 8px;
        margin: 10px 0;
        text-align: center;
    }

    @media (max-width: 600px) {
        #ace-popup {
            width: 95%;
            padding: 20px;
        }
        
        #ace-popup h2 {
            font-size: 20px;
        }
    }
  </style>



    <div id="ace-popup-overlay">
        <div id="ace-popup">
            <button id="ace-popup-close">&times;</button>
            
            <?php
            // Display success/error messages
            if (isset($_GET['ace_popup_status'])) {
                if ($_GET['ace_popup_status'] === 'success') {
                    echo '<div class="ace-success-message">Thank you! Your inquiry has been submitted.</div>';
                } elseif ($_GET['ace_popup_status'] === 'error') {
                    echo '<div class="ace-error-message">Something went wrong. Please try again.</div>';
                } elseif ($_GET['ace_popup_status'] === 'terms_error') {
                    echo '<div class="ace-error-message">You must agree to the Terms & Conditions.</div>';
                } elseif ($_GET['ace_popup_status'] === 'nonce_error') {
                    echo '<div class="ace-error-message">Security check failed. Please reload the page.</div>';
                }
            }
            ?>
            
            <form id="ace-popup-form" method="post" action="">
                <?php wp_nonce_field('ace_popup_form_action', 'ace_popup_form_nonce'); ?>
                
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input type="text" name="whatsapp" placeholder="WhatsApp Number" required>
                <select name="iam" required>
                    <option value="">I am...</option>
                    <option value="Student">A Student</option>
                    <option value="Parent">A Parent</option>
                    <option value="Other">Other</option>
                </select>
                <input type="text" name="subject" placeholder="Subject(s)" required>
                <input type="text" name="grade" placeholder="Grade" required>
                <input type="text" name="curriculum" placeholder="Curriculum" required>
                
                <label>
                    <input type="checkbox" name="terms" value="1" required>
                    <span>I agree to the Terms & Conditions</span>
                </label>
                
                <button type="submit" name="ace_popup_submit" class="ace-submit-btn">Submit</button>
            </form>
        </div>
    </div>

    <script>
        jQuery(document).ready(function ($) {
            // Auto show after 3 seconds
            setTimeout(() => {
                if (!sessionStorage.getItem('acePopupClosed')) {
                    $('#ace-popup-overlay').fadeIn();
                }
            }, 3000);

            // Close popup when clicking outside
            $('#ace-popup-overlay').on('click', function (e) {
                if ($(e.target).is('#ace-popup-overlay')) {
                    $('#ace-popup-overlay').fadeOut();
                    sessionStorage.setItem('acePopupClosed', 'true');
                }
            });

            // Close popup on X button
            $('#ace-popup-close').on('click', function () {
                $('#ace-popup-overlay').fadeOut();
                sessionStorage.setItem('acePopupClosed', 'true');
            });

            // Show popup if there's a status message
            <?php if (isset($_GET['ace_popup_status'])): ?>
            $('#ace-popup-overlay').fadeIn();
            sessionStorage.removeItem('acePopupClosed');
            <?php endif; ?>
        });
    </script>

    <?php
}

// Handle form submission
add_action('init', 'ace_popup_handle_form');

function ace_popup_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ace_popup_submit'])) {

        // Nonce verification
        if (!isset($_POST['ace_popup_form_nonce']) || !wp_verify_nonce($_POST['ace_popup_form_nonce'], 'ace_popup_form_action')) {
            wp_redirect(add_query_arg('ace_popup_status', 'nonce_error', wp_get_referer()));
            exit;
        }

        // Terms & Conditions check
        if (empty($_POST['terms'])) {
            wp_redirect(add_query_arg('ace_popup_status', 'terms_error', wp_get_referer()));
            exit;
        }

        // Sanitize inputs
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $whatsapp = sanitize_text_field($_POST['whatsapp']);
        $iam = sanitize_text_field($_POST['iam']);
        $subject_field = sanitize_text_field($_POST['subject']);
        $grade = sanitize_text_field($_POST['grade']);
        $curriculum = sanitize_text_field($_POST['curriculum']);

        // Email configuration
        $to = ['info@aceeducation.com.my', 'acekl2018@gmail.com'];
        $subject = 'New Enquiry Form Submission';

        // Create HTML email body
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #002D62;">New Enquiry from ACE Education Website</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%; max-width: 600px;">';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Name:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . esc_html($name) . '</td></tr>';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Email:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . esc_html($email) . '</td></tr>';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>WhatsApp:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . esc_html($whatsapp) . '</td></tr>';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>I am:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . esc_html($iam) . '</td></tr>';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Subject(s):</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . esc_html($subject_field) . '</td></tr>';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Grade:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . esc_html($grade) . '</td></tr>';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Curriculum:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . esc_html($curriculum) . '</td></tr>';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Terms Accepted:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">Yes</td></tr>';
        $message .= '</table>';
        $message .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
        $message .= '</body></html>';

        // Email headers
        $headers = [
            'From: ACE Education Malaysia <info@aceeducation.com.my>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . $email
        ];

        // Send email and redirect
        $sent = wp_mail($to, $subject, $message, $headers);
        
        if ($sent) {
            wp_redirect(add_query_arg('ace_popup_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('ace_popup_status', 'error', wp_get_referer()));
        }
        exit;
    }
}