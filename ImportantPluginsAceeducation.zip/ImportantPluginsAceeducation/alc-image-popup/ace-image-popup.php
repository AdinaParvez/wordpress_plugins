<?php
/**
 * Plugin Name: ACE Simple Image Popup
 * Plugin URI: https://acelanguagecentre.my
 * Description: Lightweight automatic image popup with cookie control. Core Web Vitals optimized.
 * Version: 1.0.0
 * Author: ACE Education
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) exit;

class ACE_Simple_Image_Popup {

    private $version = '1.0.0';

    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue']);
        add_action('wp_footer', [$this, 'popup_html']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function enqueue() {
        if (is_admin()) return;

        $settings = get_option('ace_simple_popup', []);

        if (($settings['enabled'] ?? 'yes') !== 'yes') return;

        wp_enqueue_style(
            'ace-simple-popup-css',
            plugin_dir_url(__FILE__) . 'assets/css/popup.css',
            [],
            $this->version
        );

        wp_enqueue_script(
            'ace-simple-popup-js',
            plugin_dir_url(__FILE__) . 'assets/js/popup.js',
            [],
            $this->version,
            true
        );

        wp_localize_script('ace-simple-popup-js', 'acePopup', [
            'delay'  => intval($settings['delay'] ?? 3000),
            'expiry' => intval($settings['expiry'] ?? 1),
            'enabled'=> true
        ]);
    }

    public function popup_html() {
        $s = get_option('ace_simple_popup', []);
        if (($s['enabled'] ?? 'yes') !== 'yes') return;

        $img = esc_url($s['image'] ?? '');
        if (!$img) return;
        ?>
        <div class="ace-popup-overlay" id="acePopup">
            <div class="ace-popup-box">
                <button class="ace-popup-close" aria-label="Close">&times;</button>
                <img src="<?= $img ?>" alt="Popup Image" width="800" height="1000" loading="eager">
            </div>
        </div>
        <?php
    }

    public function admin_menu() {
        add_options_page(
            'ACE Image Popup',
            'ACE Image Popup',
            'manage_options',
            'ace-simple-popup',
            [$this, 'settings_page']
        );
    }

    public function register_settings() {
        register_setting('ace_simple_popup_group', 'ace_simple_popup');
    }

    public function settings_page() {
        $s = get_option('ace_simple_popup', []);
        ?>
        <div class="wrap">
            <h1>ACE Simple Image Popup</h1>

            <form method="post" action="options.php">
                <?php settings_fields('ace_simple_popup_group'); ?>

                <table class="form-table">
                    <tr>
                        <th>Enable Popup</th>
                        <td>
                            <input type="checkbox" name="ace_simple_popup[enabled]" value="yes"
                                <?= checked($s['enabled'] ?? 'yes', 'yes', false) ?>>
                        </td>
                    </tr>

                    <tr>
                        <th>Popup Image URL</th>
                        <td>
                            <input type="url" class="regular-text"
                                name="ace_simple_popup[image]"
                                value="<?= esc_url($s['image'] ?? '') ?>">
                        </td>
                    </tr>

                    <tr>
                        <th>Delay (ms)</th>
                        <td>
                            <input type="number" name="ace_simple_popup[delay]"
                                value="<?= intval($s['delay'] ?? 3000) ?>">
                        </td>
                    </tr>

                    <tr>
                        <th>Show Again After (Days)</th>
                        <td>
                            <input type="number" name="ace_simple_popup[expiry]"
                                value="<?= intval($s['expiry'] ?? 1) ?>">
                        </td>
                    </tr>
                </table>

                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}

new ACE_Simple_Image_Popup();
