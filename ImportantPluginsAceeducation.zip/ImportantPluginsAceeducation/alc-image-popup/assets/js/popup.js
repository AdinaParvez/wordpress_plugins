document.addEventListener('DOMContentLoaded', function () {
    if (!window.acePopup?.enabled) return;

    const popup = document.getElementById('acePopup');
    if (!popup) return;

    const close = popup.querySelector('.ace-popup-close');

    const cookieName = 'ace_simple_popup';
    const days = acePopup.expiry;

    function hasCookie() {
        return document.cookie.includes(cookieName + '=1');
    }

    function setCookie() {
        const d = new Date();
        d.setTime(d.getTime() + days * 86400000);
        document.cookie = cookieName + "=1;expires=" + d.toUTCString() + ";path=/";
    }

    function show() {
        popup.classList.add('active');
        setTimeout(setCookie, 300);
    }

    setTimeout(() => {
        if (!hasCookie()) show();
    }, acePopup.delay);

    close.onclick = () => popup.classList.remove('active');

    popup.onclick = e => {
        if (e.target === popup) popup.classList.remove('active');
    };

    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') popup.classList.remove('active');
    });
});
