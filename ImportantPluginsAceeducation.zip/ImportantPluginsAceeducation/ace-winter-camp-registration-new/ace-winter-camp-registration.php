<?php
/**
 * Plugin Name: ACE Winter Camp Registration
 * Plugin URI: https://acelanguagecentre.my
 * Description: Custom registration form for Winter Camp with email notifications and database storage
 * Version: 1.0.0
 * Author: ACE Language Centre
 * Author URI: https://acelanguagecentre.my
 * License: GPL v2 or later
 * Text Domain: ace-winter-camp
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class ACE_Winter_Camp_Registration {
    
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'ace_winter_camp_registrations';
        
        // Hooks
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate_plugin'));
        
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_ace_winter_camp_submit', array($this, 'handle_form_submission'));
        add_action('wp_ajax_nopriv_ace_winter_camp_submit', array($this, 'handle_form_submission'));
        add_shortcode('ace_winter_camp_form', array($this, 'render_form'));
        
        // Admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
    }
    
    /**
     * Create database table on plugin activation
     */
    public function activate_plugin() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            phone varchar(50) NOT NULL,
            location varchar(100) NOT NULL,
            ip_address varchar(100),
            user_agent text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Cleanup on plugin deactivation (optional)
     */
    public function deactivate_plugin() {
        // Optional: You can add cleanup code here
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        wp_enqueue_style(
            'ace-winter-camp-style',
            plugin_dir_url(__FILE__) . 'assets/style.css',
            array(),
            '1.0.0'
        );
        
        wp_enqueue_script(
            'ace-winter-camp-script',
            plugin_dir_url(__FILE__) . 'assets/script.js',
            array('jquery'),
            '1.0.0',
            true
        );
        
        wp_localize_script('ace-winter-camp-script', 'aceWinterCamp', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ace_winter_camp_nonce')
        ));
    }
    
    /**
     * Handle form submission
     */
    public function handle_form_submission() {
        global $wpdb;
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ace_winter_camp_nonce')) {
            wp_send_json_error('Security check failed');
            return;
        }
        
        // Sanitize input data
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $location = sanitize_text_field($_POST['location']);
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        
        // Validate
        if (empty($name) || empty($email) || empty($phone) || empty($location)) {
            wp_send_json_error('All fields are required');
            return;
        }
        
        if (!is_email($email)) {
            wp_send_json_error('Invalid email address');
            return;
        }
        
        // Insert into database
        $inserted = $wpdb->insert(
            $this->table_name,
            array(
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'location' => $location,
                'ip_address' => $ip_address,
                'user_agent' => $user_agent
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        if ($inserted === false) {
            wp_send_json_error('Failed to save registration. Please try again.');
            return;
        }
        
        // Send email to admin
        $this->send_admin_email($name, $email, $phone, $location);
        
        // Send confirmation email to user
        $this->send_user_email($name, $email, $phone, $location);
        
        wp_send_json_success('Thank you for registering! Check your email for confirmation.');
    }
    
    /**
     * Send email to admin
     */
    private function send_admin_email($name, $email, $phone, $location) {
        $to = 'info@aceeducation.com.my';
        $subject = 'New Winter Camp Registration - ' . $name;
        
        $message = '<html><body>';
        $message .= '<h2>New Winter Camp Registration</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%;">';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Name:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . esc_html($name) . '</td></tr>';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Email:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . esc_html($email) . '</td></tr>';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Phone:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . esc_html($phone) . '</td></tr>';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Location:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . esc_html($location) . '</td></tr>';
        $message .= '<tr><td style="padding: 10px; border: 1px solid #ddd;"><strong>Date:</strong></td><td style="padding: 10px; border: 1px solid #ddd;">' . current_time('mysql') . '</td></tr>';
        $message .= '</table>';
        $message .= '</body></html>';
        
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ACE Language Centre <noreply@aceeducation.com.my>',
            'Reply-To: ' . $email
        );
        
        wp_mail($to, $subject, $message, $headers);
    }
    
    /**
     * Send confirmation email to user
     */
    private function send_user_email($name, $email, $phone, $location) {
        $subject = 'Thank You for Registering - Winter Camp 2026';
        
        $message = '<html><body>';
        $message .= '<h2>Dear ' . esc_html($name) . ',</h2>';
        $message .= '<p>Thank you for registering for the <strong>Winter Camp 2026</strong> at ACE Language Centre!</p>';
        $message .= '<p>We have received your application and will contact you shortly.</p>';
        $message .= '<h3>Registration Details:</h3>';
        $message .= '<ul>';
        $message .= '<li><strong>Name:</strong> ' . esc_html($name) . '</li>';
        $message .= '<li><strong>Email:</strong> ' . esc_html($email) . '</li>';
        $message .= '<li><strong>Phone:</strong> ' . esc_html($phone) . '</li>';
        $message .= '<li><strong>Location:</strong> ' . esc_html($location) . '</li>';
        $message .= '</ul>';
        $message .= '<p>If you have any questions, please contact us at <a href="mailto:info@aceeducation.com.my">info@aceeducation.com.my</a></p>';
        $message .= '<p><strong>Best regards,</strong><br>ACE Language Centre Team</p>';
        $message .= '</body></html>';
        
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ACE Language Centre <noreply@aceeducation.com.my>'
        );
        
        wp_mail($email, $subject, $message, $headers);
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            'Winter Camp Registrations',
            'Winter Camp',
            'manage_options',
            'ace-winter-camp',
            array($this, 'admin_page'),
            'dashicons-clipboard',
            30
        );
    }
    
    /**
     * Admin page to view registrations
     */
    public function admin_page() {
        global $wpdb;
        
        // Handle delete action
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $wpdb->delete($this->table_name, array('id' => $id), array('%d'));
            echo '<div class="notice notice-success"><p>Registration deleted successfully!</p></div>';
        }
        
        // Get all registrations
        $registrations = $wpdb->get_results("SELECT * FROM {$this->table_name} ORDER BY created_at DESC");
        
        ?>
        <div class="wrap">
            <h1>Winter Camp Registrations</h1>
            <p>Total Registrations: <strong><?php echo count($registrations); ?></strong></p>
            
            <?php if (empty($registrations)): ?>
                <p>No registrations yet.</p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Location</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($registrations as $reg): ?>
                        <tr>
                            <td><?php echo esc_html($reg->id); ?></td>
                            <td><?php echo esc_html($reg->name); ?></td>
                            <td><?php echo esc_html($reg->email); ?></td>
                            <td><?php echo esc_html($reg->phone); ?></td>
                            <td><?php echo esc_html($reg->location); ?></td>
                            <td><?php echo esc_html($reg->created_at); ?></td>
                            <td>
                                <a href="?page=ace-winter-camp&action=delete&id=<?php echo $reg->id; ?>" 
                                   onclick="return confirm('Are you sure you want to delete this registration?');"
                                   class="button button-small">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render the form shortcode
     */
    public function render_form($atts) {
        $atts = shortcode_atts(array(
            'image' => plugin_dir_url(__FILE__) . 'assets/winter-camp-image.jpeg'
        ), $atts);
        
        ob_start();
        ?>
        <div class="ace-winter-camp-wrapper">
            <div class="ace-winter-camp-container">
                <div class="ace-winter-camp-content">
                    <div class="ace-winter-camp-form-section">
                        <h1>Join The <span class="ace-highlight">Winter Camp</span></h1>
                        <p class="ace-subtitle">Multicultural And English language center in Kuala Lumpur</p>
                        <p class="ace-cta-text">Apply for this Winter Today!</p>
                        
                        <div class="ace-message" id="aceWinterCampMessage"></div>

                        <form id="aceWinterCampForm" class="ace-winter-camp-form">
                            <div class="ace-form-grid">
                                <div class="ace-form-group">
                                    <input type="text" name="name" placeholder="Your Name*" required>
                                </div>
                                <div class="ace-form-group">
                                    <input type="email" name="email" placeholder="Your Email*" required>
                                </div>
                                <div class="ace-form-group">
                                    <input type="tel" name="phone" placeholder="Phone Number*" required>
                                </div>
                                <div class="ace-form-group">
                                    <select name="location" required>
                                        <option value="">Where do you live?*</option>
                                        <option value="Kuala Lumpur">Kuala Lumpur</option>
                                        <option value="Selangor">Selangor</option>
                                        <option value="Penang">Penang</option>
                                        <option value="Johor">Johor</option>
                                        <option value="Melaka">Melaka</option>
                                        <option value="Negeri Sembilan">Negeri Sembilan</option>
                                        <option value="Pahang">Pahang</option>
                                        <option value="Perak">Perak</option>
                                        <option value="Perlis">Perlis</option>
                                        <option value="Kedah">Kedah</option>
                                        <option value="Kelantan">Kelantan</option>
                                        <option value="Terengganu">Terengganu</option>
                                        <option value="Sabah">Sabah</option>
                                        <option value="Sarawak">Sarawak</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                            </div>
                            <button type="submit" class="ace-submit-btn">Submit</button>
                        </form>
                    </div>

                    <div class="ace-image-section">
                        <div class="ace-camp-poster" style="background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('<?php echo esc_url($atts['image']); ?>');">
                            <div class="ace-decorative-elements"></div>
                            <div class="ace-decorative-elements"></div>
                            <div class="ace-poster-header">ACE LANGUAGE CENTRE</div>
                            <div class="ace-poster-title">WINTER CAMP</div>
                            <div class="ace-poster-year">2026</div>
                            <div class="ace-poster-location">Kuala Lumpur, Malaysia</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}

// Initialize the plugin
new ACE_Winter_Camp_Registration();