jQuery(document).ready(function($) {
    'use strict';
    
    // Handle form submission
    $('#aceWinterCampForm').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const submitBtn = form.find('.ace-submit-btn');
        const messageDiv = $('#aceWinterCampMessage');
        const originalBtnText = submitBtn.text();
        
        // Disable submit button
        submitBtn.prop('disabled', true).text('Submitting...');
        
        // Hide any previous messages
        messageDiv.removeClass('ace-success ace-error').hide();
        
        // Get form data
        const formData = {
            action: 'ace_winter_camp_submit',
            nonce: aceWinterCamp.nonce,
            name: form.find('input[name="name"]').val().trim(),
            email: form.find('input[name="email"]').val().trim(),
            phone: form.find('input[name="phone"]').val().trim(),
            location: form.find('select[name="location"]').val()
        };
        
        // Basic validation
        if (!formData.name || !formData.email || !formData.phone || !formData.location) {
            showMessage('Please fill in all required fields', 'error');
            submitBtn.prop('disabled', false).text(originalBtnText);
            return;
        }
        
        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(formData.email)) {
            showMessage('Please enter a valid email address', 'error');
            submitBtn.prop('disabled', false).text(originalBtnText);
            return;
        }
        
        // Submit via AJAX
        $.ajax({
            url: aceWinterCamp.ajax_url,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    showMessage('✓ ' + response.data, 'success');
                    form[0].reset();
                    
                    // Auto-hide success message after 5 seconds
                    setTimeout(function() {
                        messageDiv.removeClass('ace-success').fadeOut();
                    }, 5000);
                } else {
                    showMessage('✗ ' + response.data, 'error');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                showMessage('✗ An error occurred. Please try again later.', 'error');
            },
            complete: function() {
                submitBtn.prop('disabled', false).text(originalBtnText);
            }
        });
    });
    
    // Show message function
    function showMessage(text, type) {
        const messageDiv = $('#aceWinterCampMessage');
        messageDiv.removeClass('ace-success ace-error')
                  .addClass('ace-' + type)
                  .text(text)
                  .fadeIn();
        
        // Scroll to message
        $('html, body').animate({
            scrollTop: messageDiv.offset().top - 100
        }, 500);
    }
    
    // Add input animations
    $('.ace-form-group input, .ace-form-group select').on('focus', function() {
        $(this).parent().css('transform', 'scale(1.02)');
    }).on('blur', function() {
        $(this).parent().css('transform', 'scale(1)');
    });
    
    // Phone number formatting (optional)
    $('.ace-form-group input[name="phone"]').on('input', function() {
        let value = $(this).val().replace(/\D/g, '');
        if (value.length > 10) {
            value = value.substring(0, 10);
        }
        $(this).val(value);
    });
});