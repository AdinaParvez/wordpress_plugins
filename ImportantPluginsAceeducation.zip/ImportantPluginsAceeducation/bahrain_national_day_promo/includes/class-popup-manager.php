<?php
class BNDP_Popup_Manager {
    
    public function __construct() {
        add_action('wp_footer', [$this, 'render_popup']);
        add_action('wp_ajax_bndp_close_popup', [$this, 'handle_popup_close']);
        add_action('wp_ajax_nopriv_bndp_close_popup', [$this, 'handle_popup_close']);
        add_action('wp_ajax_bndp_submit_interest', [$this, 'handle_interest_submission']);
        add_action('wp_ajax_nopriv_bndp_submit_interest', [$this, 'handle_interest_submission']);
    }
    
    public function render_popup() {
        if (!$this->should_display_popup()) {
            return;
        }
        
        include BNDP_PLUGIN_PATH . 'templates/popup-template.php';
    }
    
    private function should_display_popup() {
        $settings = get_option('bndp_settings', []);
        
        // Check if popup is enabled
        if (empty($settings['popup_enabled']) || !$settings['popup_enabled']) {
            return false;
        }
        
        // Check date range
        if (isset($settings['popup_duration'])) {
            list($start, $end) = explode('_', $settings['popup_duration']);
            $current_date = current_time('Y-m-d');
            
            if ($current_date < $start || $current_date > $end) {
                return false;
            }
        }
        
        // Check country targeting (simplified - you'd use a geolocation service)
        $user_country = $this->get_user_country();
        if (!empty($settings['target_country']) && $user_country !== $settings['target_country']) {
            return false;
        }
        
        // Check if user has already closed the popup
        if (isset($_COOKIE['bndp_popup_closed']) && $_COOKIE['bndp_popup_closed'] === 'true') {
            return false;
        }
        
        return true;
    }
    
    private function get_user_country() {
        // This is a simplified version. In production, use a service like ipinfo.io or MaxMind
        // You would make an API call to get the user's country based on IP
        return 'BH'; // Default to Bahrain for testing
    }
    
    public function handle_popup_close() {
        check_ajax_referer('bndp_nonce', 'nonce');
        
        // Set a cookie to prevent showing popup again for 24 hours
        setcookie('bndp_popup_closed', 'true', time() + 86400, '/');
        
        wp_send_json_success(['message' => 'Popup closed']);
    }
    
    public function handle_interest_submission() {
        check_ajax_referer('bndp_nonce', 'nonce');
        
        $name = sanitize_text_field($_POST['name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        
        // Save to database or send email
        $this->save_enquiry($name, $email, $phone);
        
        // Send email notification
        $this->send_notification_email($name, $email, $phone);
        
        wp_send_json_success([
            'message' => __('Thank you for your interest! We will contact you soon.', 'bndp')
        ]);
    }
    
    private function save_enquiry($name, $email, $phone) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'bndp_enquiries';
        
        $wpdb->insert($table_name, [
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'created_at' => current_time('mysql'),
            'status' => 'new'
        ]);
    }
    
    private function send_notification_email($name, $email, $phone) {
        $to = get_option('admin_email');
        $subject = __('New National Day Promotion Enquiry', 'bndp');
        $message = sprintf(
            __('New enquiry received from National Day promotion:%sName: %s%sEmail: %s%sPhone: %s', 'bndp'),
            "\n\n", $name, "\n", $email, "\n", $phone
        );
        
        wp_mail($to, $subject, $message);
    }
}