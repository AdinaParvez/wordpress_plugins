<?php
class BNDP_Slider_Manager {
    
    private $slider_content = [];
    
    public function __construct() {
        add_shortcode('bahrain_national_day_slider', [$this, 'render_slider_shortcode']);
        add_action('init', [$this, 'init_slider_content']);
    }
    
    public function init_slider_content() {
        $this->slider_content = [
            [
                'title' => __('National Day Special Offer', 'bndp'),
                'description' => __('Celebrate Bahrain National Day with 50% off registration fees!', 'bndp'),
                'image' => BNDP_PLUGIN_URL . 'images/arabic-students.png',
                'link' => get_permalink(get_option('page_on_front')),
                'button_text' => __('Enroll Now', 'bndp')
            ],
            [
                'title' => __('Quality Education', 'bndp'),
                'description' => __('Join ACE Education for academic excellence and success.', 'bndp'),
                'image' => BNDP_PLUGIN_URL . 'images/education-bahrain.jpg',
                'link' => get_permalink(wc_get_page_id('shop')),
                'button_text' => __('View Courses', 'bndp')
            ]
        ];
    }
    
    public function render_slider_shortcode($atts) {
        if (!$this->should_display_slider()) {
            return '';
        }
        
        ob_start();
        include BNDP_PLUGIN_PATH . 'templates/slider-template.php';
        return ob_get_clean();
    }
    
    private function should_display_slider() {
        $settings = get_option('bndp_settings', []);
        
        // Check if slider is enabled
        if (empty($settings['slider_enabled']) || !$settings['slider_enabled']) {
            return false;
        }
        
        // Check date range
        if (isset($settings['popup_duration'])) {
            list($start, $end) = explode('_', $settings['popup_duration']);
            $current_date = current_time('Y-m-d');
            
            if ($current_date < $start || $current_date > $end) {
                return false;
            }
        }
        
        return true;
    }
    
    public function get_slides() {
        return apply_filters('bndp_slider_slides', $this->slider_content);
    }
}