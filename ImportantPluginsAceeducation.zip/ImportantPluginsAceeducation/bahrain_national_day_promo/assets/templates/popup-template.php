<div id="bndp-popup" class="bndp-popup" style="display: none;">
    <div class="bndp-popup-overlay"></div>
    <div class="bndp-popup-content">
        <button class="bndp-close-popup" aria-label="<?php esc_attr_e('Close popup', 'bndp'); ?>">×</button>
        
        <div class="bndp-popup-header">
            <img src="<?php echo BNDP_PLUGIN_URL . 'images/bahrain-flag.png'; ?>" 
                 alt="<?php esc_attr_e('Bahrain Flag', 'bndp'); ?>" 
                 class="bndp-flag">
            <h2><?php _e('Bahrain National Day Celebration!', 'bndp'); ?></h2>
        </div>
        
        <div class="bndp-popup-body">
            <div class="bndp-students-image">
                <img src="<?php echo BNDP_PLUGIN_URL . 'images/arabic-students.png'; ?>" 
                     alt="<?php esc_attr_e('Arabic Students', 'bndp'); ?>">
            </div>
            
            <div class="bndp-offer-content">
                <div class="bndp-discount-badge">
                    <span class="bndp-discount-percentage">
                        <?php 
                        $settings = get_option('bndp_settings', []);
                        echo esc_html($settings['discount_percentage'] ?? 50); 
                        ?>%
                    </span>
                    <span class="bndp-discount-text"><?php _e('OFF', 'bndp'); ?></span>
                </div>
                
                <h3><?php _e('Special National Day Offer', 'bndp'); ?></h3>
                <p><?php _e('Register during Bahrain National Day and get', 'bndp'); ?> 
                   <strong><?php echo esc_html($settings['discount_percentage'] ?? 50); ?>%</strong> 
                   <?php _e('discount on all courses!', 'bndp'); ?></p>
                
                <div class="bndp-features">
                    <p>✓ <?php _e('Limited time offer', 'bndp'); ?></p>
                    <p>✓ <?php _e('Valid until December 31st', 'bndp'); ?></p>
                    <p>✓ <?php _e('For all new registrations', 'bndp'); ?></p>
                </div>
            </div>
        </div>
        
        <div class="bndp-popup-footer">
            <form id="bndp-interest-form" class="bndp-interest-form">
                <div class="bndp-form-group">
                    <input type="text" name="name" placeholder="<?php esc_attr_e('Your Name', 'bndp'); ?>" required>
                </div>
                <div class="bndp-form-group">
                    <input type="email" name="email" placeholder="<?php esc_attr_e('Email Address', 'bndp'); ?>" required>
                </div>
                <div class="bndp-form-group">
                    <input type="tel" name="phone" placeholder="<?php esc_attr_e('Phone Number', 'bndp'); ?>" required>
                </div>
                <button type="submit" class="bndp-submit-btn">
                    <?php _e('Claim Your 50% Discount', 'bndp'); ?>
                </button>
            </form>
            <p class="bndp-terms">
                <?php _e('Limited time offer. Terms and conditions apply.', 'bndp'); ?>
            </p>
        </div>
    </div>
</div>