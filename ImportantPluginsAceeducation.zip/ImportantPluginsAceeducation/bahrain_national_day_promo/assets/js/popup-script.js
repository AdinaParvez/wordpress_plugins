jQuery(document).ready(function($) {
    'use strict';
    
    const BNDP = {
        init: function() {
            this.setupPopup();
            this.setupForm();
        },
        
        setupPopup: function() {
            const $popup = $('#bndp-popup');
            const settings = window.bndp_settings || {};
            const delay = settings.popup_delay || 2000;
            
            // Show popup after delay
            setTimeout(function() {
                $popup.fadeIn(400);
                
                // Add entrance animation
                $popup.find('.bndp-popup-content').addClass('bndp-popup-visible');
                
                // Track popup display
                $.ajax({
                    url: bndp_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'bndp_track_display',
                        nonce: bndp_ajax.nonce
                    }
                });
            }, delay);
            
            // Close button functionality
            $('.bndp-close-popup').on('click', function(e) {
                e.preventDefault();
                BNDP.closePopup();
            });
            
            // Close on overlay click
            $('.bndp-popup-overlay').on('click', function() {
                BNDP.closePopup();
            });
            
            // Escape key to close
            $(document).on('keyup', function(e) {
                if (e.key === 'Escape') {
                    BNDP.closePopup();
                }
            });
        },
        
        closePopup: function() {
            const $popup = $('#bndp-popup');
            
            // Animate close
            $popup.find('.bndp-popup-content').animate({
                opacity: 0,
                top: '45%'
            }, 300, function() {
                $popup.fadeOut(200);
            });
            
            // Set cookie to prevent showing again for 24 hours
            document.cookie = "bndp_popup_closed=true; max-age=86400; path=/";
            
            // Notify server
            $.ajax({
                url: bndp_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'bndp_close_popup',
                    nonce: bndp_ajax.nonce
                }
            });
        },
        
        setupForm: function() {
            $('#bndp-interest-form').on('submit', function(e) {
                e.preventDefault();
                
                const $form = $(this);
                const $submitBtn = $form.find('.bndp-submit-btn');
                const originalText = $submitBtn.text();
                
                // Disable button and show loading
                $submitBtn.prop('disabled', true).text(bndp_ajax.loading_text || 'Submitting...');
                
                // Get form data
                const formData = {
                    name: $form.find('input[name="name"]').val(),
                    email: $form.find('input[name="email"]').val(),
                    phone: $form.find('input[name="phone"]').val()
                };
                
                // Submit via AJAX
                $.ajax({
                    url: bndp_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'bndp_submit_interest',
                        nonce: bndp_ajax.nonce,
                        ...formData
                    },
                    success: function(response) {
                        if (response.success) {
                            // Show success message
                            $form.html(
                                '<div class="bndp-success-message">' +
                                '<h3>' + (bndp_ajax.success_title || 'Thank You!') + '</h3>' +
                                '<p>' + response.data.message + '</p>' +
                                '</div>'
                            );
                            
                            // Close popup after 3 seconds
                            setTimeout(function() {
                                BNDP.closePopup();
                            }, 3000);
                        } else {
                            alert(response.data.message || 'An error occurred. Please try again.');
                            $submitBtn.prop('disabled', false).text(originalText);
                        }
                    },
                    error: function() {
                        alert('Network error. Please try again.');
                        $submitBtn.prop('disabled', false).text(originalText);
                    }
                });
            });
        }
    };
    
    // Initialize
    BNDP.init();
});