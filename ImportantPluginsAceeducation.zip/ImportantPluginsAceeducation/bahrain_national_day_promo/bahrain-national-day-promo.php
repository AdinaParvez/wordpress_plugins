<?php
/**
 * Plugin Name: Bahrain National Day Promotion
 * Plugin URI: https://ace-education.bh/
 * Description: National Day promotion with popup and slider for Bahrain visitors
 * Version: 1.0.0
 * Author: ACE Education Bahrain
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('BNDP_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('BNDP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BNDP_VERSION', '1.0.0');

// Include required files
require_once BNDP_PLUGIN_PATH . 'includes/class-popup-manager.php';
require_once BNDP_PLUGIN_PATH . 'includes/class-slider-manager.php';
require_once BNDP_PLUGIN_PATH . 'includes/class-settings-manager.php';

class Bahrain_National_Day_Promotion {
    
    private $popup_manager;
    private $slider_manager;
    private $settings_manager;
    
    public function __construct() {
        $this->init_components();
        $this->register_hooks();
    }
    
    private function init_components() {
        $this->popup_manager = new BNDP_Popup_Manager();
        $this->slider_manager = new BNDP_Slider_Manager();
        $this->settings_manager = new BNDP_Settings_Manager();
    }
    
    private function register_hooks() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('init', [$this, 'load_textdomain']);
    }
    
    public function enqueue_frontend_assets() {
        // CSS
        wp_enqueue_style('bndp-popup-css', BNDP_PLUGIN_URL . 'assets/css/popup-styles.css', [], BNDP_VERSION);
        wp_enqueue_style('bndp-slider-css', BNDP_PLUGIN_URL . 'assets/css/slider-styles.css', [], BNDP_VERSION);
        
        // JavaScript
        wp_enqueue_script('bndp-popup-js', BNDP_PLUGIN_URL . 'assets/js/popup-script.js', ['jquery'], BNDP_VERSION, true);
        wp_enqueue_script('bndp-slider-js', BNDP_PLUGIN_URL . 'assets/js/slider-script.js', ['jquery'], BNDP_VERSION, true);
        
        // Localize script for AJAX
        wp_localize_script('bndp-popup-js', 'bndp_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bndp_nonce')
        ]);
    }
    
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'bahrain-national-day') !== false) {
            wp_enqueue_style('bndp-admin-css', BNDP_PLUGIN_URL . 'assets/css/admin-styles.css', [], BNDP_VERSION);
            wp_enqueue_script('bndp-admin-js', BNDP_PLUGIN_URL . 'assets/js/admin-script.js', ['jquery', 'wp-color-picker'], BNDP_VERSION, true);
            wp_enqueue_style('wp-color-picker');
        }
    }
    
    public function load_textdomain() {
        load_plugin_textdomain('bndp', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }
    
    public static function activate() {
        // Set default options on activation
        $defaults = [
            'popup_enabled' => true,
            'slider_enabled' => true,
            'popup_delay' => 2000,
            'popup_duration' => '2023-12-01_2023-12-31',
            'discount_percentage' => 50,
            'target_country' => 'BH',
            'popup_animation' => 'fadeIn',
            'slider_animation' => 'slide'
        ];
        
        add_option('bndp_settings', $defaults);
        add_option('bndp_activation_date', current_time('mysql'));
    }
    
    public static function deactivate() {
        // Clean up on deactivation
        wp_clear_scheduled_hook('bndp_daily_check');
    }
    
    public static function uninstall() {
        // Remove options on uninstall
        delete_option('bndp_settings');
        delete_option('bndp_activation_date');
        delete_option('bndp_display_count');
    }
}

// Initialize plugin
$bahrain_national_day_promotion = new Bahrain_National_Day_Promotion();

// Register activation/deactivation hooks
register_activation_hook(__FILE__, ['Bahrain_National_Day_Promotion', 'activate']);
register_deactivation_hook(__FILE__, ['Bahrain_National_Day_Promotion', 'deactivate']);
register_uninstall_hook(__FILE__, ['Bahrain_National_Day_Promotion', 'uninstall']);