<?php
/*
Plugin Name: ACE Popup Enquiry Form
Description: A responsive popup enquiry form that appears automatically after 3 seconds on page load with close button functionality.
Version: 1.2
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

function ace_popup_enqueue_assets() {
    wp_enqueue_style(
        'ace-popup-style',
        plugin_dir_url(__FILE__) . 'style.css',
        array(),
        filemtime(plugin_dir_path(__FILE__) . 'style.css')
    );

    wp_enqueue_script(
        'ace-popup-script',
        plugin_dir_url(__FILE__) . 'popup.js',
        array('jquery'),
        filemtime(plugin_dir_path(__FILE__) . 'popup.js'),
        true
    );

    wp_localize_script('ace-popup-script', 'acePopup', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('ace_popup_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'ace_popup_enqueue_assets', 99);

function ace_popup_html() {
    ?>
    <div id="ace-popup-overlay">
        <div id="ace-popup">
            <button id="ace-popup-close">&times;</button>
            <h2>🎓 Enquire Now!</h2>
            <form id="ace-popup-form" method="post" action="">
                <input type="hidden" name="action" value="ace_handle_popup_form">
                
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input type="text" name="whatsapp" placeholder="WhatsApp Number" required>
                <select name="iam" required>
                    <option value="">I am...</option>
                    <option value="Student">A Student</option>
                    <option value="Parent">A Parent</option>
                    <option value="Other">Other</option>
                </select>
                <input type="text" name="subject" placeholder="Subject(s)" required>
                <input type="text" name="grade" placeholder="Grade" required>
                <input type="text" name="curriculum" placeholder="Curriculum" required>
                
                <label style="display: flex; align-items: center; gap: 8px; margin: 10px 0;">
                    <input type="checkbox" name="terms" value="1" required>
                    <span style="font-size: 13px;">I agree to the Terms & Conditions</span>
                </label>
                
                <button type="submit" class="ace-submit-btn">Submit</button>
            </form>
        </div>
    </div>
    <?php
}
add_action('wp_footer', 'ace_popup_html');

// AJAX Handler for logged-in users
add_action('wp_ajax_ace_handle_popup_form', 'ace_handle_popup_form');

// AJAX Handler for non-logged-in users (CRITICAL!)
add_action('wp_ajax_nopriv_ace_handle_popup_form', 'ace_handle_popup_form');

function ace_handle_popup_form() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ace_popup_nonce')) {
        wp_send_json_error('Security check failed. Please reload the page and try again.');
        return;
    }

    // Check terms agreement
    if (empty($_POST['terms'])) {
        wp_send_json_error('You must agree to the Terms & Conditions.');
        return;
    }

    // Sanitize inputs
    $fields = [
        "Name" => sanitize_text_field($_POST['name']),
        "Email" => sanitize_email($_POST['email']),
        "WhatsApp" => sanitize_text_field($_POST['whatsapp']),
        "I am" => sanitize_text_field($_POST['iam']),
        "Subject" => sanitize_text_field($_POST['subject']),
        "Grade" => sanitize_text_field($_POST['grade']),
        "Curriculum" => sanitize_text_field($_POST['curriculum']),
    ];

    // Validate email
    if (!is_email($fields['Email'])) {
        wp_send_json_error('Please provide a valid email address.');
        return;
    }

    // Create email
    $to = ['info@aceeducation.com.my', 'acekl2018@gmail.com'];
    $subject = 'New Enquiry from ACE Popup Form';

    $message = '<html><body><h2>New Enquiry</h2><table border="1" cellpadding="10">';
    foreach ($fields as $label => $value) {
        $message .= "<tr><td><strong>{$label}:</strong></td><td>{$value}</td></tr>";
    }
    $message .= '</table></body></html>';

    $headers = [
        'From: ACE Education Malaysia <no-reply@aceeducation.com.my>',
        'Content-Type: text/html; charset=UTF-8',
        'Reply-To: ' . $fields['Email']
    ];

    // Send email
    $sent = wp_mail($to, $subject, $message, $headers);

    if ($sent) {
        wp_send_json_success('Thank you! Your inquiry has been submitted.');
    } else {
        wp_send_json_error('Failed to send email. Please try again or contact us directly.');
    }
}
?>