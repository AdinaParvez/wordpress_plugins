<?php
/*
Plugin Name: Fix Broken Slider Revolution Sliders
Description: Automatically blocks missing sliders and hides empty slider sections to remove 404 and JS errors.
Version: 1.0
Author: Adina Pervaiz
*/

// 1. Block missing slider AJAX requests
add_filter('revslider_ajax_request', function($return, $request) {

    if (class_exists('RevSliderSlider')) {
        $sliders = new RevSliderSlider();
        $all_sliders = $sliders->getArrSliders();
        $valid_ids = array();

        foreach ($all_sliders as $slider) {
            if (isset($slider->id)) {
                $valid_ids[] = (int)$slider->id;
            }
        }

        if (isset($request['sliderid']) && !in_array((int)$request['sliderid'], $valid_ids)) {
            wp_send_json_error(array(
                'message' => 'Slider not found or disabled'
            ));
        }
    }

    return $return;

}, 10, 2);

// 2. Hide broken sliders on front-end
add_action('wp_footer', function() {
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const sliders = document.querySelectorAll('.rev_slider_wrapper');
        sliders.forEach(slider => {
            if (!slider.querySelectorAll('.tp-revslider-slidesli').length) {
                slider.style.display = 'none';
                console.warn('A broken or missing slider has been hidden.');
            }
        });
    });
    </script>
    <?php
});
