<?php
/*
Plugin Name: ALC Popup Form Full
Description: Popup form (always on load), unique email check, DB storage, and WhatsApp notification with admin-configurable settings.
Version: 1.1.0
Author: ACE Language Centre
*/

if ( ! defined( 'ABSPATH' ) ) exit;

// DB table name
global $alc_pf_table;
$alc_pf_table = isset($wpdb) ? $wpdb->prefix . 'alc_popup_submissions' : 'wp_alc_popup_submissions';

// Activation hook: create DB table
register_activation_hook(__FILE__, 'alc_pf_activate');
function alc_pf_activate() {
    global $wpdb;
    $table = $wpdb->prefix . 'alc_popup_submissions';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
      id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
      name varchar(191) NOT NULL,
      email varchar(191) NOT NULL,
      phone varchar(50) DEFAULT '',
      message text DEFAULT '',
      created_at datetime DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY  (id),
      UNIQUE KEY email_unique (email)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Enqueue assets
function alc_pf_enqueue() {
    wp_enqueue_style('alc-pf-style', plugin_dir_url(__FILE__) . 'assets/form.css');
    wp_enqueue_script('alc-pf-script', plugin_dir_url(__FILE__) . 'assets/form.js', array('jquery'), null, true);
    wp_localize_script('alc-pf-script', 'ALC_PF', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'successMessage' => 'Thanks! We received your message. Redirecting...',
        'duplicateMessage' => 'Your record is already with us, one of our team will contact you. Kindly continue viewing our website.',
        'errorMessage' => 'Sorry, something went wrong. Please try again later.',
        'redirectUrl' => home_url('/thank-you/')
    ));
}
add_action('wp_enqueue_scripts', 'alc_pf_enqueue');

// Shortcode to print popup HTML
function alc_pf_shortcode() {
    ob_start(); ?>
    <div class="alc-pf-overlay" data-alc-overlay aria-hidden="true">
      <div class="alc-pf-modal" role="dialog" aria-modal="true" aria-labelledby="alc-pf-title">
        <button class="alc-pf-close" type="button" aria-label="Close" data-alc-close>&times;</button>
        <h2 id="alc-pf-title">Contact ACE Language Centre</h2>
        <form class="alc-pf-form">
          <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('alc_pf_nonce'); ?>">
          <label class="alc-label">Name*</label>
          <input type="text" name="name" required maxlength="100">
          <label class="alc-label">Email*</label>
          <input type="email" name="email" required maxlength="191">
          <label class="alc-label">Phone</label>
          <input type="tel" name="phone" maxlength="50">
          <label class="alc-label">Message*</label>
          <textarea name="message" rows="4" required maxlength="1000"></textarea>
          <button type="submit" class="alc-pf-submit">Submit</button>
          <div class="alc-pf-status" aria-live="polite"></div>
        </form>
      </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('alc_popup_form', 'alc_pf_shortcode');

// AJAX handler
add_action('wp_ajax_alc_pf_submit', 'alc_pf_handle_submit');
add_action('wp_ajax_nopriv_alc_pf_submit', 'alc_pf_handle_submit');
function alc_pf_handle_submit() {
    global $wpdb;
    $table = $wpdb->prefix . 'alc_popup_submissions';

    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'alc_pf_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'), 403);
    }

    $name = sanitize_text_field($_POST['name'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    $message = sanitize_textarea_field($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($message)) {
        wp_send_json_error(array('message' => 'Please fill in required fields.'), 400);
    }
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Please enter a valid email address.'), 400);
    }

    $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE email = %s LIMIT 1", $email));
    if ($existing) {
        alc_pf_send_whatsapp($name, $email, $phone, $message, true);
        wp_send_json_success(array('status' => 'duplicate', 'message' => 'duplicate'));
    }

    $inserted = $wpdb->insert($table, array(
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'message' => $message,
        'created_at' => current_time('mysql', 1)
    ), array('%s','%s','%s','%s','%s'));

    alc_pf_send_whatsapp($name, $email, $phone, $message, false);

    if ($inserted !== false) {
        wp_send_json_success(array('status' => 'ok', 'message' => 'saved'));
    } else {
        wp_send_json_error(array('message' => 'Unable to save submission.'), 500);
    }
}

// WhatsApp sender
function alc_pf_send_whatsapp($name, $email, $phone, $message, $is_duplicate = false) {
    $team = get_option('alc_pf_whatsapp_number', '');
    $token = get_option('alc_pf_whatsapp_token', '');
    $phone_id = get_option('alc_pf_whatsapp_phone_id', '');

    $type = $is_duplicate ? 'Duplicate submission' : 'New submission';
    $body = "{$type}\nName: {$name}\nEmail: {$email}\nPhone: {$phone}\nMessage: {$message}";

    if (!empty($token) && !empty($phone_id) && !empty($team)) {
        $endpoint = "https://graph.facebook.com/v15.0/{$phone_id}/messages";
        $payload = array(
            'messaging_product' => 'whatsapp',
            'to' => $team,
            'type' => 'text',
            'text' => array('body' => $body)
        );
        $args = array(
            'body' => json_encode($payload),
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token
            ),
            'timeout' => 15
        );
        wp_remote_post($endpoint, $args);
    } else {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('ALC PF WhatsApp message skipped (no settings): ' . $body);
        }
    }
}

// Admin settings page
add_action('admin_menu', 'alc_pf_add_admin_menu');
add_action('admin_init', 'alc_pf_settings_init');

function alc_pf_add_admin_menu() {
    add_options_page('ALC Popup Form Settings', 'ALC Popup Form', 'manage_options', 'alc-pf', 'alc_pf_options_page');
}

function alc_pf_settings_init() {
    register_setting('alcPf', 'alc_pf_whatsapp_number');
    register_setting('alcPf', 'alc_pf_whatsapp_token');
    register_setting('alcPf', 'alc_pf_whatsapp_phone_id');

    add_settings_section('alc_pf_section', __('WhatsApp Settings', 'alcPf'), null, 'alcPf');

    add_settings_field('alc_pf_whatsapp_number', __('WhatsApp Number', 'alcPf'), 'alc_pf_number_render', 'alcPf', 'alc_pf_section');
    add_settings_field('alc_pf_whatsapp_token', __('API Token', 'alcPf'), 'alc_pf_token_render', 'alcPf', 'alc_pf_section');
    add_settings_field('alc_pf_whatsapp_phone_id', __('Phone ID', 'alcPf'), 'alc_pf_phoneid_render', 'alcPf', 'alc_pf_section');
}

function alc_pf_number_render() {
    $value = get_option('alc_pf_whatsapp_number', '');
    echo "<input type='text' name='alc_pf_whatsapp_number' value='" . esc_attr($value) . "' placeholder='e.g. 923001234567' />";
}

function alc_pf_token_render() {
    $value = get_option('alc_pf_whatsapp_token', '');
    echo "<input type='text' name='alc_pf_whatsapp_token' value='" . esc_attr($value) . "' style='width:400px;' />";
}

function alc_pf_phoneid_render() {
    $value = get_option('alc_pf_whatsapp_phone_id', '');
    echo "<input type='text' name='alc_pf_whatsapp_phone_id' value='" . esc_attr($value) . "' />";
}

function alc_pf_options_page() { ?>
    <form action="options.php" method="post">
        <h2>ALC Popup Form Settings</h2>
        <?php
        settings_fields('alcPf');
        do_settings_sections('alcPf');
        submit_button();
        ?>
    </form>
<?php }
