jQuery(document).ready(function ($) {
  const overlay = $(".alc-pf-overlay");
  const modal = $(".alc-pf-modal");
  const closeBtn = $("[data-alc-close]");
  const form = $(".alc-pf-form");
  const statusBox = $(".alc-pf-status");

  // --- Show popup on page load ---
  overlay.attr("aria-hidden", "false").fadeIn(200);

  // --- Close popup ---
  closeBtn.on("click", function () {
    overlay.fadeOut(200).attr("aria-hidden", "true");
  });

  // --- Close when clicking outside modal ---
  overlay.on("click", function (e) {
    if ($(e.target).is(overlay)) {
      overlay.fadeOut(200).attr("aria-hidden", "true");
    }
  });

  // --- Handle form submission ---
  form.on("submit", function (e) {
    e.preventDefault();

    statusBox.removeClass("success error").text("Submitting...");

    const formData = form.serialize() + "&action=alc_pf_submit";

    $.post(ALC_PF.ajaxurl, formData, function (response) {
      if (response.success) {
        if (response.data.status === "duplicate") {
          statusBox.addClass("success").text(ALC_PF.duplicateMessage);
        } else {
          statusBox.addClass("success").text(ALC_PF.successMessage);

          // Redirect after short delay
          setTimeout(function () {
            window.location.href = ALC_PF.redirectUrl;
          }, 2000);
        }
      } else {
        statusBox.addClass("error").text(ALC_PF.errorMessage);
      }
    }).fail(function () {
      statusBox.addClass("error").text("Network error. Please try again.");
    });
  });
});
