<?php
/*
Plugin Name: ALC Instructors
Description: Custom Post Type for Instructors with Designation + Social Links + Shortcode (Grid + Carousel)
Version: 1.3
Author: Adina Pervaiz
*/

// ===== Step 1: Register CPT =====
function alc_register_instructors_cpt() {
    $labels = array(
        'name'          => __('Instructors', 'alc'),
        'singular_name' => __('Instructor', 'alc'),
        'menu_name'     => __('Instructors', 'alc'),
        'add_new_item'  => __('Add New Instructor', 'alc'),
        'edit_item'     => __('Edit Instructor', 'alc'),
    );

    $args = array(
        'labels'       => $labels,
        'public'       => true,
        'menu_icon'    => 'dashicons-groups',
        'supports'     => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest' => true, // Elementor / Gutenberg
        'rewrite'      => array('slug' => 'instructors'),
    );

    register_post_type('alc_instructors', $args);
}
add_action('init', 'alc_register_instructors_cpt');

// ===== Step 2: Meta Boxes (Designation + Socials) =====
function alc_instructors_meta_boxes() {
    add_meta_box(
        'alc_instructor_details',
        __('Instructor Details', 'alc'),
        'alc_instructors_meta_callback',
        'alc_instructors',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'alc_instructors_meta_boxes');

// --- Instructor Categories Taxonomy ---
function alc_register_instructor_category() {
    $labels = array(
        'name'              => __('Instructor Categories', 'alc'),
        'singular_name'     => __('Instructor Category', 'alc'),
        'search_items'      => __('Search Categories'),
        'all_items'         => __('All Categories'),
        'edit_item'         => __('Edit Category'),
        'update_item'       => __('Update Category'),
        'add_new_item'      => __('Add New Category'),
        'new_item_name'     => __('New Category Name'),
        'menu_name'         => __('Instructor Categories'),
    );

    register_taxonomy('instructor_category', array('alc_instructors'), array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'instructor-category'),
    ));
}
add_action('init', 'alc_register_instructor_category');


// --- Admin Notice for Shortcode Helper ---
function alc_instructors_shortcode_helper() {
    global $pagenow;

    // Show only in Elementor pages & posts
    if (in_array($pagenow, ['post.php', 'post-new.php'])) {
        $screen = get_current_screen();
        if ($screen && $screen->is_block_editor) return; // skip block editor

        // Get all instructor categories
        $terms = get_terms([
            'taxonomy'   => 'instructor_category',
            'hide_empty' => false,
        ]);

        if (!empty($terms)) {
            echo '<div class="notice notice-info"><p><strong>ALC Instructors Shortcode Helper:</strong><br>';
            echo 'Use <code>[alc_instructors layout="grid" category="your-category-slug"]</code><br>';
            echo 'Available Categories: ';
            foreach ($terms as $term) {
                echo '<code>' . esc_html($term->slug) . '</code> ';
            }
            echo '</p></div>';
        } else {
            echo '<div class="notice notice-info"><p><strong>ALC Instructors Shortcode Helper:</strong><br>';
            echo 'No instructor categories yet. Create them under <em>Instructors → Categories</em>.</p></div>';
        }
    }
}
add_action('admin_notices', 'alc_instructors_shortcode_helper');


function alc_instructors_meta_callback($post) {
    // Nonce for security
    wp_nonce_field('alc_instructors_meta', 'alc_instructors_meta_nonce');

    $designation = get_post_meta($post->ID, '_alc_designation', true);
    $facebook    = get_post_meta($post->ID, '_alc_facebook', true);
    $linkedin    = get_post_meta($post->ID, '_alc_linkedin', true);
    $instagram   = get_post_meta($post->ID, '_alc_instagram', true);
    ?>
    <p><label><strong><?php esc_html_e('Designation', 'alc'); ?>:</strong></label><br/>
    <input type="text" name="alc_designation" value="<?php echo esc_attr($designation); ?>" style="width:100%;"/></p>

    <p><label><strong><?php esc_html_e('Facebook', 'alc'); ?>:</strong></label><br/>
    <input type="url" name="alc_facebook" value="<?php echo esc_attr($facebook); ?>" style="width:100%;"/></p>

    <p><label><strong><?php esc_html_e('LinkedIn', 'alc'); ?>:</strong></label><br/>
    <input type="url" name="alc_linkedin" value="<?php echo esc_attr($linkedin); ?>" style="width:100%;"/></p>

    <p><label><strong><?php esc_html_e('Instagram', 'alc'); ?>:</strong></label><br/>
    <input type="url" name="alc_instagram" value="<?php echo esc_attr($instagram); ?>" style="width:100%;"/></p>
    <?php
}

function alc_save_instructors_meta($post_id) {
    // Autosave?
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    // Valid nonce?
    if (!isset($_POST['alc_instructors_meta_nonce']) ||
        !wp_verify_nonce($_POST['alc_instructors_meta_nonce'], 'alc_instructors_meta')) {
        return;
    }

    // Permissions?
    $post_type = get_post_type($post_id);
    if ($post_type !== 'alc_instructors') return;
    if (!current_user_can('edit_post', $post_id)) return;

    // Save
    $map = array(
        'alc_designation' => '_alc_designation',
        'alc_facebook'    => '_alc_facebook',
        'alc_linkedin'    => '_alc_linkedin',
        'alc_instagram'   => '_alc_instagram',
    );

    foreach ($map as $form => $meta) {
        if (isset($_POST[$form])) {
            $val = ($form === 'alc_designation') ? sanitize_text_field($_POST[$form]) : esc_url_raw($_POST[$form]);
            update_post_meta($post_id, $meta, $val);
        }
    }
}
add_action('save_post', 'alc_save_instructors_meta');

// ===== Step 3: Shortcode ([alc_instructors layout="grid|carousel" columns="3"]) =====
function alc_instructors_shortcode($atts = array()) {
    $atts = shortcode_atts(array(
        'layout'  => 'grid',  // grid | carousel
        'columns' => '3',     // 1..6 (grid only)
    ), $atts, 'alc_instructors');

    // Enqueue assets only when shortcode is used
    // FontAwesome (load only if not already)
    if (!wp_style_is('font-awesome', 'enqueued')) {
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css', array(), '6.5.2');
    }

    // Swiper only for carousel layout
    if ($atts['layout'] === 'carousel') {
        wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css', array(), null);
        wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js', array(), null, true);
    }

    $args  = array(
        'post_type'      => 'alc_instructors',
        'posts_per_page' => -1,
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
    );
    $query = new WP_Query($args);

    ob_start();

    if (!$query->have_posts()) {
        echo '<p>' . esc_html__('No instructors found.', 'alc') . '</p>';
        return ob_get_clean();
    }

    // Prepare grid col class
    $cols = max(1, min(6, intval($atts['columns'])));
    $col_width = (12 % $cols === 0) ? 12 / $cols : 4; // fallback to 3-col if not divisible
    $col_class = 'col-md-' . $col_width . ' col-sm-6 instructor-card text-center mb-4';

    if ($atts['layout'] === 'carousel') {
        // Unique container per shortcode instance
        $uid = uniqid('alc-swiper-');
        echo '<div class="swiper-container ' . esc_attr($uid) . '"><div class="swiper-wrapper">';
    } else {
        echo '<div class="row instructors-grid">';
    }

    while ($query->have_posts()) {
        $query->the_post();
        $designation = get_post_meta(get_the_ID(), '_alc_designation', true);
        $facebook    = get_post_meta(get_the_ID(), '_alc_facebook', true);
        $linkedin    = get_post_meta(get_the_ID(), '_alc_linkedin', true);
        $instagram   = get_post_meta(get_the_ID(), '_alc_instagram', true);

        if ($atts['layout'] === 'carousel') {
            echo '<div class="swiper-slide">';
        } else {
            echo '<div class="' . esc_attr($col_class) . '">';
        }
        ?>
        <div class="card shadow-sm p-3 h-100 text-center">
            <?php if (has_post_thumbnail()) : ?>
                <div class="instructor-img mb-3">
                    <?php the_post_thumbnail('medium', array('class' => 'rounded-circle img-fluid')); ?>
                </div>
            <?php endif; ?>
            <h5 class="mb-1"><?php the_title(); ?></h5>
            <?php if ($designation): ?>
                <p class="text-muted mb-2"><?php echo esc_html($designation); ?></p>
            <?php endif; ?>
            <div class="instructor-bio mb-2"><?php the_excerpt(); ?></div>
            <div class="instructor-social" style="gap:10px; display:flex; justify-content:center;">
                <?php if ($facebook): ?><a aria-label="Facebook" href="<?php echo esc_url($facebook); ?>" target="_blank" rel="noopener"><i class="fab fa-facebook"></i></a><?php endif; ?>
                <?php if ($linkedin): ?><a aria-label="LinkedIn" href="<?php echo esc_url($linkedin); ?>" target="_blank" rel="noopener"><i class="fab fa-linkedin"></i></a><?php endif; ?>
                <?php if ($instagram): ?><a aria-label="Instagram" href="<?php echo esc_url($instagram); ?>" target="_blank" rel="noopener"><i class="fab fa-instagram"></i></a><?php endif; ?>
            </div>
        </div>
        <?php
        echo ($atts['layout'] === 'carousel') ? '</div>' : '</div>';
    }

    wp_reset_postdata();

    if ($atts['layout'] === 'carousel') {
        echo '<div class="swiper-pagination"></div><div class="swiper-button-next"></div><div class="swiper-button-prev"></div></div>';

        // Init only this instance
        $init = "
            document.addEventListener('DOMContentLoaded', function() {
                var el = document.querySelector('." . $uid . "');
                if (!el) return;
                new Swiper(el, {
                    slidesPerView: 3,
                    spaceBetween: 30,
                    loop: true,
                    autoplay: { delay: 3000 },
                    navigation: { nextEl: el.querySelector('.swiper-button-next'), prevEl: el.querySelector('.swiper-button-prev') },
                    pagination: { el: el.querySelector('.swiper-pagination'), clickable: true },
                    breakpoints: {
                        1024: { slidesPerView: 3 },
                        768:  { slidesPerView: 2 },
                        0:    { slidesPerView: 1 }
                    }
                });
            });
        ";
        // Ensure script is enqueued before adding inline init
        wp_add_inline_script('swiper-js', $init);
    } else {
        echo '</div>';
    }

    return ob_get_clean();
}
add_shortcode('alc_instructors', 'alc_instructors_shortcode');

// ===== Step 4: Elementor Support =====
function alc_enable_elementor_for_instructors($post_types) {
    $post_types[] = 'alc_instructors';
    return $post_types;
}
add_filter('elementor/editor/allowed_post_types', 'alc_enable_elementor_for_instructors');
