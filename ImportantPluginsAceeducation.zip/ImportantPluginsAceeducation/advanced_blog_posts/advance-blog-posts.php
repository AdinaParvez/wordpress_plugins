<?php
/**
 * Plugin Name: Advanced Blog Posts Shortcode
 * Description: Display blog posts anywhere using shortcode with featured image, pagination, and category filtering.
 * Version: 1.1
 * Author: Adina Pervaiz
 * License: GPL2
 */

if (!defined('ABSPATH')) exit;

/* Register Styles */
function abps_register_styles() {
    wp_register_style(
        'abps-style',
        false
    );
}
add_action('wp_enqueue_scripts', 'abps_register_styles');

/* Shortcode */
function abps_blog_posts_shortcode($atts) {

    $atts = shortcode_atts([
        'posts'    => 6,
        'category' => '',
        'paged'    => 1,
    ], $atts);

    $paged = get_query_var('paged') ? get_query_var('paged') : 1;

    $args = [
        'post_type'      => 'post',
        'posts_per_page' => intval($atts['posts']),
        'paged'          => $paged,
        'post_status'    => 'publish',
    ];

    if (!empty($atts['category'])) {
        $args['category_name'] = sanitize_text_field($atts['category']);
    }

    $query = new WP_Query($args);

    ob_start();
    ?>

    <style>
        .abps-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
        }
        .abps-card {
            background: #fff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 6px 18px rgba(0,0,0,0.08);
            transition: 0.3s ease;
        }
        .abps-card:hover {
            transform: translateY(-6px);
        }
        .abps-thumb img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .abps-content {
            padding: 18px;
        }
        .abps-content h3 {
            font-size: 18px;
            margin-bottom: 10px;
        }
        .abps-content p {
            font-size: 14px;
            color: #555;
        }
        .abps-readmore {
            display: inline-block;
            margin-top: 12px;
            padding: 8px 14px;
            background: #0057ff;
            color: #fff;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
        }
        .abps-readmore:hover {
            background: #003bbd;
        }
        .abps-pagination {
            margin-top: 30px;
            text-align: center;
        }
        .abps-pagination a {
            margin: 0 6px;
            text-decoration: none;
            color: #0057ff;
            font-weight: 600;
        }
    </style>

    <?php if ($query->have_posts()) : ?>
        <div class="abps-grid">
            <?php while ($query->have_posts()) : $query->the_post(); ?>
                <article class="abps-card">
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="abps-thumb">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_post_thumbnail('medium'); ?>
                            </a>
                        </div>
                    <?php endif; ?>

                    <div class="abps-content">
                        <h3>
                            <a href="<?php the_permalink(); ?>">
                                <?php the_title(); ?>
                            </a>
                        </h3>
                        <p><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                        <a class="abps-readmore" href="<?php the_permalink(); ?>">
                            Read More
                        </a>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>

        <div class="abps-pagination">
            <?php
            echo paginate_links([
                'total' => $query->max_num_pages
            ]);
            ?>
        </div>

    <?php else : ?>
        <p>No posts found.</p>
    <?php endif;

    wp_reset_postdata();
    return ob_get_clean();
}

add_shortcode('advanced_blog_posts', 'abps_blog_posts_shortcode');
