/**
 * ACE Image Popup JavaScript
 * Core Web Vitals Optimized
 * Supports multiple images (random or slideshow)
 */

(function() {
    'use strict';

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        if (typeof acePopupSettings === 'undefined' || !acePopupSettings.enabled || !acePopupSettings.imageUrls || !acePopupSettings.imageUrls.length) {
            return;
        }

        const config = {
            delayAfterEnquiry: acePopupSettings.delay || 2000,
            cookieName: 'ace_image_popup_shown',
            cookieExpiry: acePopupSettings.cookieExpiry || 1,
            imageUrls: acePopupSettings.imageUrls
        };

        const popup = document.getElementById('aceImagePopup');
        const closeBtn = document.getElementById('acePopupClose');
        const popupImage = document.querySelector('.ace-popup-image');

        if (!popup || !closeBtn || !popupImage) return;

        // Preload all images
        config.imageUrls.forEach(preloadImage);

        function shouldShowPopup() {
            const cookies = document.cookie.split(';');
            for (let cookie of cookies) {
                const [name, value] = cookie.trim().split('=');
                if (name === config.cookieName && value === 'true') return false;
            }
            return true;
        }

        function setCookie() {
            const date = new Date();
            date.setTime(date.getTime() + (config.cookieExpiry * 24 * 60 * 60 * 1000));
            const expires = "expires=" + date.toUTCString();
            document.cookie = config.cookieName + "=true;" + expires + ";path=/;SameSite=Lax";
        }

        function preloadImage(url) {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.as = 'image';
            link.href = url;
            document.head.appendChild(link);
        }

        // Pick random image or rotate through images
        let currentIndex = 0;

        function showPopup() {
            if (!shouldShowPopup()) return;

            // Set initial image (random)
            currentIndex = Math.floor(Math.random() * config.imageUrls.length);
            popupImage.src = config.imageUrls[currentIndex];

            // Display popup
            if (popupImage.complete) displayPopup();
            else popupImage.onload = displayPopup;
        }

       let intervalId = null;

        function displayPopup() {
            requestAnimationFrame(function() {
                popup.classList.add('active');
                document.body.classList.add('ace-popup-open');
                setCookie();
                closeBtn.focus();

                if (config.imageUrls.length > 1) {
                    intervalId = setInterval(function() {
                        currentIndex = (currentIndex + 1) % config.imageUrls.length;
                        popupImage.src = config.imageUrls[currentIndex].url;
                        popupImage.alt = config.imageUrls[currentIndex].alt || '';
                    }, 3000);
                }
            });
        }

        function hidePopup() {
            popup.classList.remove('active');
            document.body.classList.remove('ace-popup-open');
            if (intervalId) clearInterval(intervalId);
        }


        closeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            hidePopup();
        });

        popup.addEventListener('click', function(e) {
            if (e.target === popup) hidePopup();
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && popup.classList.contains('active')) hidePopup();
        });

        // Detect enquiry form popup (existing logic)
        function detectEnquiryForm() {
            const enquirySelectors = [
                '.popup-form',
                '.enquiry-popup',
                '.contact-popup',
                '.modal.show',
                '.modal.fade.show',
                '[class*="popup"][style*="display: block"]',
                '[class*="modal"][style*="display: block"]',
                '.elementor-popup-modal.elementor-popup-modal--active',
                '.pum-active',
                '.pum-open',
                '.mfp-ready',
                '.fancybox-opened',
                '[data-popup-visible="true"]',
                '.wp-block-contact-form-7',
                '.wpcf7',
                '#enquiry-form',
                '#contact-form-popup'
            ];

            let formDetected = false;

            const observer = new MutationObserver(function(mutations) {
                if (formDetected) return;
                mutations.forEach(function(mutation) {
                    if (mutation.type === 'attributes' || mutation.type === 'childList') {
                        for (let selector of enquirySelectors) {
                            const forms = document.querySelectorAll(selector);
                            for (let form of forms) {
                                if (isElementVisible(form)) {
                                    formDetected = true;
                                    setTimeout(showPopup, config.delayAfterEnquiry);
                                    observer.disconnect();
                                    return;
                                }
                            }
                        }
                    }
                });
            });

            function isElementVisible(el) {
                if (!el) return false;
                const style = window.getComputedStyle(el);
                return style.display !== 'none' &&
                       style.visibility !== 'hidden' &&
                       style.opacity !== '0' &&
                       el.offsetParent !== null;
            }

            observer.observe(document.body, {
                attributes: true,
                childList: true,
                subtree: true,
                attributeFilter: ['style', 'class', 'data-popup-visible']
            });

            // Initial check
            setTimeout(function() {
                if (formDetected) return;
                for (let selector of enquirySelectors) {
                    const forms = document.querySelectorAll(selector);
                    for (let form of forms) {
                        if (isElementVisible(form)) {
                            formDetected = true;
                            setTimeout(showPopup, config.delayAfterEnquiry);
                            observer.disconnect();
                            return;
                        }
                    }
                }
            }, 1000);

            // Fallback after 10s
            setTimeout(function() {
                if (formDetected) return;
                for (let selector of enquirySelectors) {
                    const forms = document.querySelectorAll(selector);
                    for (let form of forms) {
                        if (isElementVisible(form)) {
                            setTimeout(showPopup, config.delayAfterEnquiry);
                            observer.disconnect();
                            return;
                        }
                    }
                }
            }, 10000);
        }

        detectEnquiryForm();
    }
})();
