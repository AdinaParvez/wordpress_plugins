<?php
/*
Plugin Name: ACE Core Web Vitals Smart
Description: Combined smart optimizer for LCP, FCP, CLS and accessibility-safe deferring. Preloads hero+logo, async CSS, defer scripts (with allowlist), lazy-loads images and stabilizes layout.
Version: 1.0
Author: GSTech / Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

/**
 * -------------------------
 * Default options
 * -------------------------
 */
function acvs_get_defaults() {
    return array(
        'enable_defer_js'     => 1,
        'enable_async_css'    => 1,
        'enable_lazy_images'  => 1,
        'enable_hero_preload' => 1,
        'hero_manual_url'     => '', // if set, plugin will use this instead of auto-detect
        'preload_fonts'       => 1,
        'font_urls'           => '', // comma-separated font woff2 URLs
        'reserve_css'         => 1,
        'cache_control_days'  => 30,
        'script_allowlist'    => "wp-emoji-release,wp-polyfill", // comma-separated handles
    );
}

function acvs_get_option($key) {
    $opts = get_option('acvs_options', array());
    $defaults = acvs_get_defaults();
    return isset($opts[$key]) ? $opts[$key] : $defaults[$key];
}

/**
 * -------------------------
 * Admin menu + settings
 * -------------------------
 */
add_action('admin_menu', function() {
    add_options_page('Core Web Vitals Smart', 'Core Web Vitals Smart', 'manage_options', 'acvs-settings', 'acvs_settings_page');
});

function acvs_settings_page() {
    if (!current_user_can('manage_options')) return;
    $defaults = acvs_get_defaults();
    $opts = get_option('acvs_options', $defaults);

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('acvs_save','acvs_nonce')) {
        foreach ($defaults as $k => $v) {
            if (isset($_POST[$k])) $opts[$k] = is_numeric($v) ? intval($_POST[$k]) : sanitize_text_field($_POST[$k]);
            else if (is_numeric($v)) $opts[$k] = 0;
        }
        update_option('acvs_options', $opts);
        echo '<div class="updated"><p>Settings saved.</p></div>';
    }

    // Render form
    $opts = wp_parse_args($opts, $defaults);
    ?>
    <div class="wrap">
      <h1>ACE Core Web Vitals Smart</h1>
      <form method="post">
        <?php wp_nonce_field('acvs_save','acvs_nonce'); ?>
        <table class="form-table">
          <tr>
            <th>Enable JS deferring</th>
            <td><input type="checkbox" name="enable_defer_js" value="1" <?php checked(1, $opts['enable_defer_js']); ?>></td>
          </tr>
          <tr>
            <th>Enable async CSS (media=print onload)</th>
            <td><input type="checkbox" name="enable_async_css" value="1" <?php checked(1, $opts['enable_async_css']); ?>></td>
          </tr>
          <tr>
            <th>Enable lazy-loading of images</th>
            <td><input type="checkbox" name="enable_lazy_images" value="1" <?php checked(1, $opts['enable_lazy_images']); ?>></td>
          </tr>
          <tr>
            <th>Auto preload hero image (detect from page)</th>
            <td><input type="checkbox" name="enable_hero_preload" value="1" <?php checked(1, $opts['enable_hero_preload']); ?>></td>
          </tr>
          <tr>
            <th>Manual hero image URL (optional)</th>
            <td><input type="text" name="hero_manual_url" value="<?php echo esc_attr($opts['hero_manual_url']); ?>" style="width:100%;"></td>
          </tr>
          <tr>
            <th>Preload fonts</th>
            <td><input type="checkbox" name="preload_fonts" value="1" <?php checked(1, $opts['preload_fonts']); ?>><br>
                Font WOFF2 URLs (comma separated):<br>
                <input type="text" name="font_urls" value="<?php echo esc_attr($opts['font_urls']); ?>" style="width:100%;">
            </td>
          </tr>
          <tr>
            <th>Reserve CSS for header/logo/slider</th>
            <td><input type="checkbox" name="reserve_css" value="1" <?php checked(1, $opts['reserve_css']); ?>></td>
          </tr>
          <tr>
            <th>Static cache days</th>
            <td><input type="number" name="cache_control_days" value="<?php echo intval($opts['cache_control_days']); ?>" min="1" max="365"></td>
          </tr>
          <tr>
            <th>Script allowlist (handles, comma separated)</th>
            <td><input type="text" name="script_allowlist" value="<?php echo esc_attr($opts['script_allowlist']); ?>" style="width:100%;"></td>
          </tr>
        </table>
        <p><input type="submit" class="button button-primary" value="Save Settings"></p>
      </form>
      <p>Important: deactivate any other performance plugins that modify script/style tags to avoid conflicts.</p>
    </div>
    <?php
}

/**
 * -------------------------
 * Core optimizations
 * -------------------------
 */

/* Accessibility keywords to skip deferring */
function acvs_get_a11y_keywords() {
    return array('aria-', 'accessibility', 'a11y', 'screenreader', 'voiceover', 'skip-link');
}

/* Helper: allowlist array */
function acvs_get_allowlist() {
    $raw = acvs_get_option('script_allowlist');
    $arr = array();
    foreach (explode(',', $raw) as $h) {
        $h = trim($h);
        if ($h) $arr[] = $h;
    }
    return $arr;
}

/* 1) Defer non-critical JS with accessibility safe checks */
if (acvs_get_option('enable_defer_js')) {
    add_filter('script_loader_tag', function($tag, $handle, $src) {
        if (is_admin()) return $tag;
        if (empty($src)) return $tag;

        // allowlist handles
        $allowlist = acvs_get_allowlist();
        foreach ($allowlist as $a) {
            if (stripos($handle, $a) !== false) return $tag;
        }

        // accessibility keywords - do not defer if found
        foreach (acvs_get_a11y_keywords() as $kw) {
            if (stripos($handle, $kw) !== false || stripos($src, $kw) !== false) {
                return $tag;
            }
        }

        // do not defer admin scripts or inline scripts
        if (stripos($src, '/wp-admin/') !== false) return $tag;

        // If script tag already contains defer/async, skip
        if (stripos($tag, ' defer') !== false || stripos($tag, ' async') !== false) return $tag;

        // jQuery special handling: ensure it's in footer — WordPress core path check
        if (strpos($src, 'jquery') !== false && strpos($src, 'jquery.min.js') !== false) {
            // keep it registered where it is but add defer attribute (safe for footer registration)
            return str_replace(' src', ' defer src', $tag);
        }

        // Default: add defer
        return str_replace(' src', ' defer src', $tag);
    }, 10, 3);
}

/* 2) Async CSS using media=print trick and preload font styles if needed */
if (acvs_get_option('enable_async_css')) {
    add_filter('style_loader_tag', function($html, $handle, $href, $media) {
        if (is_admin()) return $html;
        // If this style is explicitly a font stylesheet (user provided) keep it preloaded style
        $lc = strtolower($handle . ' ' . $href);
        if (stripos($lc, 'font') !== false || stripos($lc, 'googleapis') !== false) {
            return "<link rel='preload' as='style' href='" . esc_url($href) . "' onload=\"this.onload=null;this.rel='stylesheet'\">\n<noscript><link rel='stylesheet' href='" . esc_url($href) . "'></noscript>";
        }
        return str_replace("rel='stylesheet'", "rel='stylesheet' media='print' onload=\"this.media='all'\"", $html);
    }, 10, 4);
}

/* 3) Lazy loading images (native) */
if (acvs_get_option('enable_lazy_images')) {
    add_filter('wp_lazy_loading_enabled', '__return_true');
    // also add loading="lazy" to inline <img> occurrences if not present in content output
    add_filter('the_content', function($content) {
        return preg_replace('/<img(?![^>]+loading=)/i', '<img loading="lazy"', $content);
    }, 20);
}

/* 4) Cache-control header for static-like requests (best-effort) */
add_action('send_headers', function() {
    if (is_admin()) return;
    $days = intval(acvs_get_option('cache_control_days'));
    if ($days < 1) $days = 30;
    $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    if (preg_match('/\\.(?:css|js|jpg|jpeg|png|gif|webp|woff2|woff|ttf)$/i', $uri)) {
        header('Cache-Control: public, max-age=' . ($days * 86400) . ', immutable');
    }
});

/* 5) Small inline CSS to reserve space & reduce CLS (configurable) */
if (acvs_get_option('reserve_css')) {
    add_action('wp_head', function() {
        echo "<style id='acvs-reserve-space'>
            /* Adjust these selectors to match your theme as needed */
            header.site-header img, .site-logo img { width:250px; height:60px; display:block; }
            .swiper-slide .shape-1, .edubin-slider .slide { min-height: 360px; }
            img { max-width:100%; height:auto; }
        </style>\n";
    }, 3);
}

/**
 * 6) Auto-detect hero/background image and inject preload link (so LCP image is discoverable)
 *
 * Mechanism:
 * - We buffer the final HTML on frontend (template_redirect) and look for the first occurrence of
 *   background-image: url(...) or inline <img> that appears within typical hero/slide selectors.
 * - If found, we inject a preload <link as="image" fetchpriority="high"> before </head>.
 *
 * This is safer than requiring the user to paste the URL — but admin can still set a manual URL.
 */
if (acvs_get_option('enable_hero_preload')) {
    add_action('template_redirect', function() {
        if (is_admin()) return;
        ob_start('acvs_detect_and_preload_lcp');
    });
}

function acvs_detect_and_preload_lcp($buffer) {
    // If manual hero URL specified, use it
    $manual = trim(acvs_get_option('hero_manual_url'));
    $preload_links = '';

    if (!empty($manual) && filter_var($manual, FILTER_VALIDATE_URL)) {
        $preload_links .= '<link rel="preload" as="image" href="' . esc_url($manual) . '" fetchpriority="high">' . "\n";
    } else {
        // scan for background-image occurrences in markup typical for hero/slide
        // look for inline style background-image: url('...')
        if (preg_match('/<div[^>]+class=["\'][^"\']*(hero|slide|swiper-slide|edubin-slider)[^"\']*["\'][^>]*style=["\'][^"\']*background-image\s*:\s*url\(([^)]+)\)/i', $buffer, $m)) {
            $url_raw = trim($m[2]);
            $url = acvs_trim_url_quotes($url_raw);
            if (filter_var($url, FILTER_VALIDATE_URL)) {
                $preload_links .= '<link rel="preload" as="image" href="' . esc_url($url) . '" fetchpriority="high">' . "\n";
            }
        } else {
            // fallback: find first background-image anywhere
            if (preg_match('/background-image\s*:\s*url\(([^)]+)\)/i', $buffer, $m2)) {
                $url = acvs_trim_url_quotes(trim($m2[1]));
                if (filter_var($url, FILTER_VALIDATE_URL)) {
                    $preload_links .= '<link rel="preload" as="image" href="' . esc_url($url) . '" fetchpriority="high">' . "\n";
                }
            } else {
                // fallback: search for first <img> likely to be LCP (large images)
                if (preg_match('/<img[^>]+src=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*(hero|slide|logo|attachment-large)[^"\']*["\'][^>]*>/i', $buffer, $m3)) {
                    $url = $m3[1];
                    if (filter_var($url, FILTER_VALIDATE_URL)) {
                        $preload_links .= '<link rel="preload" as="image" href="' . esc_url($url) . '" fetchpriority="high">' . "\n";
                    }
                }
            }
        }
    }

    // Inject preload links before </head>
    if (!empty($preload_links)) {
        // Insert just before closing head
        $buffer = preg_replace('/<\/head>/i', $preload_links . '</head>', $buffer, 1);
    }

    return $buffer;
}

function acvs_trim_url_quotes($s) {
    return trim($s, " \t\n\r\0\x0B'\"");
}

/* 7) Preload logo if registered */
add_action('wp_head', function() {
    $logo_id = get_theme_mod('custom_logo');
    if ($logo_id) {
        $logo = wp_get_attachment_image_src($logo_id, 'full');
        if ($logo && !empty($logo[0])) {
            echo '<link rel="preload" as="image" href="' . esc_url($logo[0]) . '" fetchpriority="high">' . "\n";
        }
    }
}, 2);

/* 8) Preload fonts (from settings) */
if (acvs_get_option('preload_fonts')) {
    add_action('wp_head', function() {
        $urls = acvs_get_option('font_urls');
        if (!empty($urls)) {
            $list = array_map('trim', explode(',', $urls));
            foreach ($list as $u) {
                if (filter_var($u, FILTER_VALIDATE_URL)) {
                    echo "<link rel='preload' href='" . esc_url($u) . "' as='font' type='font/woff2' crossorigin>\n";
                }
            }
        }
    }, 1);
}

/* 9) JS helper to add width/height attributes to images missing them (prevents CLS) */
add_action('wp_footer', function() {
    ?>
    <script>
    (function(){
        try {
            document.querySelectorAll('img:not([width]):not([height])').forEach(function(img){
                if (img.naturalWidth && img.naturalHeight) {
                    img.setAttribute('width', img.naturalWidth);
                    img.setAttribute('height', img.naturalHeight);
                }
            });
        } catch(e){ console && console.log(e); }
    })();
    </script>
    <?php
}, 999);

/* 10) Admin notice to avoid duplicated performance plugins */
add_action('admin_notices', function() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="notice notice-info is-dismissible"><p><strong>ACE Core Web Vitals Smart:</strong> active. If you previously used other Booster plugins, please <strong>deactivate</strong> them to avoid conflicts.</p></div>';
});

/* Clean up on deactivation: remove option if needed and ensure no buffers left open */
register_deactivation_hook(__FILE__, function() {
    if (ob_get_length()) {
        @ob_end_clean();
    }
});
