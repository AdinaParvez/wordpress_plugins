<?php
/*
Plugin Name: ACEEducation Popup Form
Description: A responsive popup form that sends email and saves to database.
Version: 2.0
Author: Adina Pervaiz
*/

// Create database table on plugin activation
register_activation_hook(__FILE__, 'ace_popup_create_table');

function ace_popup_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ace_popup_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        whatsapp varchar(50) NOT NULL,
        iam varchar(50) NOT NULL,
        subject varchar(255) NOT NULL,
        grade varchar(100) NOT NULL,
        curriculum varchar(100) NOT NULL,
        terms_accepted tinyint(1) DEFAULT 1,
        submitted_at datetime DEFAULT CURRENT_TIMESTAMP,
        ip_address varchar(100) DEFAULT '',
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

function ace_popup_form() {
    ob_start(); ?>
    
    <style>
            #ace-popup-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.6);
            z-index: 9999;
            }

            #ace-popup-overlay::before {
            content: '';
            display: inline-block;
            height: 100%;
            vertical-align: middle;
            }

            #ace-popup {
            background: #002D62;
            color: #fff;
            padding: 25px;
            border-radius: 15px;
            max-width: 400px;
            width: 90%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
            text-align: center;
            }

            #ace-popup h2 {
            margin-bottom: 15px;
            color: #dcb225;
            }

            #ace-popup form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            }

            #ace-popup input,
            #ace-popup select {
            padding: 10px;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            }

            #ace-popup input:focus,
            #ace-popup select:focus {
            outline: 2px solid #dcb225;
            }

            .ace-submit-btn {
            background: #fff;
            color: #002D62;
            font-weight: bold;
            border: none;
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: background 0.3s ease;
            }

            .ace-submit-btn:hover {
            background: #ffe0c2;
            }

            #ace-popup-close {
            position: absolute;
            top: 8px;
            right: 12px;
            background: transparent;
            color: #fff;
            font-size: 24px;
            border: none;
            cursor: pointer;
            line-height: 1;
            transition: transform 0.2s ease;
            }

            #ace-popup-close:hover {
            transform: scale(1.2);
            }

            #ace-popup label {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 10px 0;
            text-align: left;
            }

            #ace-popup label input[type="checkbox"] {
            width: auto;
            margin: 0;
            }

            #ace-popup label span {
            font-size: 13px;
            }

            .cef-success-message,
            .cef-error-message {
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            }

            .cef-success-message {
            background: #4CAF50;
            color: #fff;
            border: 1px solid #45a049;
            }

            .cef-error-message {
            background: #f44336;
            color: #fff;
            border: 1px solid #da190b;
            }

            @media (max-width: 600px) {
            #ace-popup {
                width: 95%;
                padding: 20px;
            }
            
            #ace-popup h2 {
                font-size: 20px;
            }
            }
    </style>

    <div id="ace-popup-overlay">
        <div id="ace-popup">
            <button id="ace-popup-close">&times;</button>
            
            <?php
                if (isset($_GET['form_status'])) {
                    if ($_GET['form_status'] === 'success') {
                        echo '<div class="cef-success-message">✓ Thank you! Your inquiry has been submitted successfully.</div>';
                    } elseif ($_GET['form_status'] === 'error') {
                        echo '<div class="cef-error-message">⚠ There was an error submitting your form. Please try again.</div>';
                    } elseif ($_GET['form_status'] === 'terms_error') {
                        echo '<div class="cef-error-message">⚠ You must agree to the Terms & Conditions.</div>';
                    }
                }
            ?>
            
            <h2>Get in Touch</h2>
            
            <form id="ace-popup-form" method="post" action="">
                <?php wp_nonce_field('ace_popup_form_action', 'ace_popup_form_nonce'); ?>
                        
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input type="text" name="whatsapp" placeholder="WhatsApp Number" required>
                <select name="iam" required>
                    <option value="">I am...</option>
                    <option value="Student">A Student</option>
                    <option value="Parent">A Parent</option>
                    <option value="Other">Other</option>
                </select>
                <input type="text" name="subject" placeholder="Subject(s)" required>
                <input type="text" name="grade" placeholder="Grade" required>
                <input type="text" name="curriculum" placeholder="Curriculum" required>
                
                <label>
                    <input type="checkbox" name="terms" value="1" required>
                    <span>I agree to the Terms & Conditions</span>
                </label>
                
                <button type="submit" name="ace_popup_submit" class="ace-submit-btn">Submit</button>
            </form>

            <script>
                jQuery(document).ready(function ($) {
                    console.log('Ace Popup: Script loaded');
                    
                    // Auto show after 3 seconds
                    setTimeout(() => {
                        console.log('Ace Popup: Checking if should show');
                        if (!sessionStorage.getItem('acePopupClosed')) {
                            console.log('Ace Popup: Showing popup');
                            $('#ace-popup-overlay').fadeIn();
                        } else {
                            console.log('Ace Popup: Already closed in this session');
                        }
                    }, 3000);

                    $('#ace-popup-overlay').on('click', function (e) {
                        if ($(e.target).is('#ace-popup-overlay')) {
                            $('#ace-popup-overlay').fadeOut();
                            sessionStorage.setItem('acePopupClosed', 'true');
                        }
                    });

                    $('#ace-popup-close').on('click', function () {
                        $('#ace-popup-overlay').fadeOut();
                        sessionStorage.setItem('acePopupClosed', 'true');
                    });

                    const successMsg = document.querySelector('.cef-success-message');
                    const errorMsg = document.querySelector('.cef-error-message');
                    
                    if (successMsg || errorMsg) {
                        setTimeout(function() {
                            const msg = successMsg || errorMsg;
                            msg.style.transition = 'opacity 0.5s ease';
                            msg.style.opacity = '0';
                            
                            setTimeout(function() {
                                msg.remove();
                                const url = new URL(window.location);
                                url.searchParams.delete('form_status');
                                window.history.replaceState({}, document.title, url);
                            }, 500);
                        }, 10000);
                    }
                });
            </script>
        </div>
    </div>

    <?php
    return ob_get_clean();
}

// Enqueue jQuery
add_action('wp_enqueue_scripts', 'ace_popup_enqueue_scripts');

function ace_popup_enqueue_scripts() {
    wp_enqueue_script('jquery');
}

// Auto-load popup on all pages
add_action('wp_footer', 'ace_popup_form');

// Handle form submission
add_action('init', 'ace_popup_handle_form');

function ace_popup_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ace_popup_submit'])) {

        // Nonce verification
        if (!isset($_POST['ace_popup_form_nonce']) || !wp_verify_nonce($_POST['ace_popup_form_nonce'], 'ace_popup_form_action')) {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
            exit;
        }

        // Check terms checkbox
        if (empty($_POST['terms'])) {
            wp_redirect(add_query_arg('form_status', 'terms_error', wp_get_referer()));
            exit;
        }

        // Sanitize input
        $data = [
            'name' => sanitize_text_field($_POST['name']),
            'email' => sanitize_email($_POST['email']),
            'whatsapp' => sanitize_text_field($_POST['whatsapp']),
            'iam' => sanitize_text_field($_POST['iam']),
            'subject' => sanitize_text_field($_POST['subject']),
            'grade' => sanitize_text_field($_POST['grade']),
            'curriculum' => sanitize_text_field($_POST['curriculum']),
            'ip_address' => $_SERVER['REMOTE_ADDR']
        ];

        // 1. SAVE TO DATABASE (Primary - Most Reliable)
        global $wpdb;
        $table_name = $wpdb->prefix . 'ace_popup_submissions';
        
        $db_saved = $wpdb->insert(
            $table_name,
            [
                'name' => $data['name'],
                'email' => $data['email'],
                'whatsapp' => $data['whatsapp'],
                'iam' => $data['iam'],
                'subject' => $data['subject'],
                'grade' => $data['grade'],
                'curriculum' => $data['curriculum'],
                'terms_accepted' => 1,
                'ip_address' => $data['ip_address'],
                'submitted_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s']
        );

        // 2. SEND EMAIL (Secondary - Backup notification)
        if ($db_saved) {
            $to = ['info@aceeducation.com.my', 'acekl2018@gmail.com']; 
            $subject = 'New Enquiry Form Submission';

            $message = '<html><body style="font-family: Arial, sans-serif;">';
            $message .= '<h2 style="color: #002D62;">New Enquiry from ACE Education Website</h2>';
            $message .= '<table style="border-collapse: collapse; width: 100%; max-width: 600px;">';
            
            $fields = [
                "Name" => $data['name'],
                "Email" => $data['email'],
                "WhatsApp" => $data['whatsapp'],
                "I am" => $data['iam'],
                "Subject" => $data['subject'],
                "Grade" => $data['grade'],
                "Curriculum" => $data['curriculum'],
            ];

            foreach ($fields as $label => $value) {
                $message .= '<tr style="border-bottom: 1px solid #ddd;">';
                $message .= '<td style="padding: 10px; font-weight: bold; width: 200px; background: #f5f5f5;">' . esc_html($label) . ':</td>';
                $message .= '<td style="padding: 10px;">' . esc_html($value) . '</td>';
                $message .= '</tr>';
            }
            
            $message .= '</table>';
            $message .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
            $message .= '<p style="color: #999; font-size: 12px;">Entry ID: ' . $wpdb->insert_id . '</p>';
            $message .= '</body></html>';

            $headers = [
                'From: ACE Education Malaysia <info@aceeducation.com.my>',
                'Content-Type: text/html; charset=UTF-8',
                'Reply-To: ' . $data['email']
            ];
            
            // Try to send email (but don't fail if it doesn't work)
            wp_mail($to, $subject, $message, $headers);
        }

        // Redirect based on database save result
        if ($db_saved) {
            wp_redirect(add_query_arg('form_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
        }
        exit;
    }
}

// Add admin menu to view submissions
add_action('admin_menu', 'ace_popup_admin_menu');

function ace_popup_admin_menu() {
    add_menu_page(
        'Form Submissions',
        'Popup Forms',
        'manage_options',
        'ace-popup-submissions',
        'ace_popup_submissions_page',
        'dashicons-email-alt',
        30
    );
}

function ace_popup_submissions_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ace_popup_submissions';
    
    // Handle delete action
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $wpdb->delete($table_name, ['id' => $id], ['%d']);
        echo '<div class="notice notice-success"><p>Entry deleted successfully.</p></div>';
    }
    
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC");
    $total = count($submissions);
    
    ?>
    <div class="wrap">
        <h1>Popup Form Submissions (<?php echo $total; ?>)</h1>
        
        <?php if ($submissions): ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>WhatsApp</th>
                        <th>I am</th>
                        <th>Subject</th>
                        <th>Grade</th>
                        <th>Curriculum</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $sub): ?>
                        <tr>
                            <td><?php echo esc_html($sub->id); ?></td>
                            <td><strong><?php echo esc_html($sub->name); ?></strong></td>
                            <td><a href="mailto:<?php echo esc_attr($sub->email); ?>"><?php echo esc_html($sub->email); ?></a></td>
                            <td><?php echo esc_html($sub->whatsapp); ?></td>
                            <td><?php echo esc_html($sub->iam); ?></td>
                            <td><?php echo esc_html($sub->subject); ?></td>
                            <td><?php echo esc_html($sub->grade); ?></td>
                            <td><?php echo esc_html($sub->curriculum); ?></td>
                            <td><?php echo date('M j, Y g:i A', strtotime($sub->submitted_at)); ?></td>
                            <td>
                                <a href="?page=ace-popup-submissions&action=delete&id=<?php echo $sub->id; ?>" 
                                   onclick="return confirm('Are you sure you want to delete this entry?');"
                                   class="button button-small">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No submissions yet.</p>
        <?php endif; ?>
    </div>
    <?php
}