<?php
/**
 * Plugin Name: ACE Table of Contents
 * Plugin URI: https://acelanguagecentre.my
 * Description: Dynamic Table of Contents generator for ACE Language Centre educational content. Automatically generates TOC with SEO schema markup.
 * Version: 1.0.0
 * Author: Adina, ACE Language Centre
 * License: GPL v2 or later
 * Text Domain: ace-toc
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('ACE_TOC_VERSION', '1.0.0');
define('ACE_TOC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ACE_TOC_PLUGIN_PATH', plugin_dir_path(__FILE__));

class ACE_Table_Of_Contents {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    public function init() {
        // Admin hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'init_settings'));
        add_action('add_meta_boxes', array($this, 'add_meta_box'));
        add_action('save_post', array($this, 'save_meta_box'));
        
        // Frontend hooks
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_filter('the_content', array($this, 'add_toc_to_content'));
        add_shortcode('ace_toc', array($this, 'toc_shortcode'));
    }
    
    public function activate() {
        // Set default options
        add_option('ace_toc_settings', array(
            'auto_insert' => 'after_first_heading',
            'heading_levels' => array('h1','h2', 'h3', 'h4', 'h5', 'h6'),
            'show_numbering' => true,
            'smooth_scroll' => true,
            'sticky_position' => true,
            'mobile_collapse' => true,
            'color_scheme' => 'default',
            'exclude_pages' => array(),
            'exclude_posts' => array()
        ));
    }
    
    public function deactivate() {
        // Clean up if needed
    }
    
    public function add_admin_menu() {
        add_options_page(
            'ACE Table of Contents',
            'ACE TOC',
            'manage_options',
            'ace-toc-settings',
            array($this, 'admin_page')
        );
    }
    
    public function init_settings() {
        register_setting('ace_toc_settings_group', 'ace_toc_settings');
    }
    
public function admin_page() {
    $settings = get_option('ace_toc_settings');
    ?>
    <div class="wrap">
        <h1>🎯 ACE Table of Contents Settings</h1>

        <form method="post" action="options.php">
            <?php settings_fields('ace_toc_settings_group'); ?>
            <div class="ace-toc-admin" style="max-width: 800px;">

                <table class="form-table">
                    <tr>
                        <th scope="row">Auto Insert</th>
                        <td>
                            <select name="ace_toc_settings[auto_insert]">
                                <option value="before" <?php selected($settings['auto_insert'], 'before'); ?>>Before Content</option>
                                <option value="after_first_heading" <?php selected($settings['auto_insert'], 'after_first_heading'); ?>>After First Heading</option>
                                <option value="disabled" <?php selected($settings['auto_insert'], 'disabled'); ?>>Disabled</option>
                            </select>
                        </td>
                    </tr>

                 <tr>
                    <th scope="row">Heading Levels</th>
                    <td>
                        <label><input type="checkbox" name="ace_toc_settings[heading_levels][]" value="h1" <?php checked(in_array('h1', $settings['heading_levels'])); ?>> H1</label><br>
                        <label><input type="checkbox" name="ace_toc_settings[heading_levels][]" value="h2" <?php checked(in_array('h2', $settings['heading_levels'])); ?>> H2</label><br>
                        <label><input type="checkbox" name="ace_toc_settings[heading_levels][]" value="h3" <?php checked(in_array('h3', $settings['heading_levels'])); ?>> H3</label><br>
                        <label><input type="checkbox" name="ace_toc_settings[heading_levels][]" value="h4" <?php checked(in_array('h4', $settings['heading_levels'])); ?>> H4</label><br>
                        <label><input type="checkbox" name="ace_toc_settings[heading_levels][]" value="h5" <?php checked(in_array('h5', $settings['heading_levels'])); ?>> H5</label><br>
                        <label><input type="checkbox" name="ace_toc_settings[heading_levels][]" value="h6" <?php checked(in_array('h6', $settings['heading_levels'])); ?>> H6</label>
                    </td>
                </tr>


                    <tr>
                        <th scope="row">Numbering</th>
                        <td>
                            <input type="checkbox" name="ace_toc_settings[show_numbering]" value="1" <?php checked($settings['show_numbering'], true); ?>>
                            Show numbering
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Smooth Scroll</th>
                        <td>
                            <input type="checkbox" name="ace_toc_settings[smooth_scroll]" value="1" <?php checked($settings['smooth_scroll'], true); ?>>
                            Enable smooth scroll
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Sticky TOC</th>
                        <td>
                            <input type="checkbox" name="ace_toc_settings[sticky_position]" value="1" <?php checked($settings['sticky_position'], true); ?>>
                            Enable sticky position
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Color Scheme</th>
                        <td>
                            <select name="ace_toc_settings[color_scheme]">
                                <option value="default" <?php selected($settings['color_scheme'], 'default'); ?>>Default</option>
                                <option value="dark" <?php selected($settings['color_scheme'], 'dark'); ?>>Dark</option>
                                <option value="light" <?php selected($settings['color_scheme'], 'light'); ?>>Light</option>
                            </select>
                        </td>
                    </tr>
                </table>

            </div>
            <?php submit_button('💾 Save Settings'); ?>
        </form>

        <!-- ✅ Documentation / Help Section -->
        <hr>
        <h2>📖 How to Use ACE TOC</h2>
        <p>This plugin automatically generates a Table of Contents for your posts/pages based on your settings.</p>

        <h3>Shortcode</h3>
        <p>You can manually insert a TOC anywhere using:</p>
        <pre><code>[ace_toc]</code></pre>

        <p>You can also customize it with attributes:</p>
        <pre><code>[ace_toc title="Contents" levels="h2,h3" numbering="false"]</code></pre>

        <ul>
            <li><strong>title</strong> → Set custom TOC title (default: "Table of Contents")</li>
            <li><strong>levels</strong> → Comma-separated list of headings (e.g. h2,h3,h4)</li>
            <li><strong>numbering</strong> → true / false (show numbering)</li>
            <li><strong>position</strong> → before | after_first | shortcode (default uses global settings)</li>
        </ul>

        <h3>Assets Location</h3>
        <ul>
            <li>JS: <code><?php echo ACE_TOC_PLUGIN_URL . 'assets/ace-toc.js'; ?></code></li>
            <li>CSS: <code><?php echo ACE_TOC_PLUGIN_URL . 'assets/ace-toc.css'; ?></code></li>
        </ul>

        <h3>Notes</h3>
        <ul>
            <li>TOC can be enabled/disabled per post using the meta box in the editor.</li>
            <li>Mobile view starts collapsed by default, toggle with 📋 Show/Hide button.</li>
            <li>Desktop view can collapse/expand with + / − toggle.</li>
        </ul>
    </div>
    <?php
}


    
    public function add_meta_box() {
        $post_types = get_post_types(array('public' => true));
        foreach ($post_types as $post_type) {
            add_meta_box(
                'ace-toc-settings',
                '🎯 TOC Settings',
                array($this, 'meta_box_callback'),
                $post_type,
                'side',
                'default'
            );
        }
    }
    
    public function meta_box_callback($post) {
        wp_nonce_field('ace_toc_meta_box', 'ace_toc_meta_box_nonce');
        
        $toc_enabled = get_post_meta($post->ID, '_ace_toc_enabled', true);
        $toc_position = get_post_meta($post->ID, '_ace_toc_position', true);
        $toc_title = get_post_meta($post->ID, '_ace_toc_title', true);
        ?>
        <table class="form-table">
            <tr>
                <td>
                    <label>
                        <input type="checkbox" name="ace_toc_enabled" value="1" <?php checked($toc_enabled, '1'); ?>>
                        Enable TOC for this post
                    </label>
                </td>
            </tr>
            <tr>
                <td>
                    <label>TOC Title:</label><br>
                    <input type="text" name="ace_toc_title" value="<?php echo esc_attr($toc_title ?: 'Table of Contents'); ?>" style="width: 100%;">
                </td>
            </tr>
            <tr>
                <td>
                    <label>Position:</label><br>
                    <select name="ace_toc_position" style="width: 80%;">
                        <option value="auto" <?php selected($toc_position, 'auto'); ?>>Auto (Global Setting)</option>
                        <option value="before" <?php selected($toc_position, 'before'); ?>>Before Content</option>
                        <option value="after_first" <?php selected($toc_position, 'after_first'); ?>>After First Heading</option>
                        <option value="shortcode" <?php selected($toc_position, 'shortcode'); ?>>Manual (Shortcode Only)</option>
                    </select>
                </td>
            </tr>
        </table>
        <?php
    }
    
    public function save_meta_box($post_id) {
        if (!isset($_POST['ace_toc_meta_box_nonce']) || !wp_verify_nonce($_POST['ace_toc_meta_box_nonce'], 'ace_toc_meta_box')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        update_post_meta($post_id, '_ace_toc_enabled', isset($_POST['ace_toc_enabled']) ? '1' : '0');
        update_post_meta($post_id, '_ace_toc_position', sanitize_text_field($_POST['ace_toc_position'] ?? 'auto'));
        update_post_meta($post_id, '_ace_toc_title', sanitize_text_field($_POST['ace_toc_title'] ?? ''));
    }
    
    public function enqueue_scripts() {
        wp_enqueue_style('ace-toc-style', ACE_TOC_PLUGIN_URL . 'assets/ace-toc.css', array(), ACE_TOC_VERSION);
        wp_enqueue_script('ace-toc-script', ACE_TOC_PLUGIN_URL . 'assets/ace-toc.js', array('jquery'), ACE_TOC_VERSION, true);

        // ✅ Removed wp_localize_script with ajax_url + nonce
    }
    
    public function add_toc_to_content($content) {
        if (!is_singular() || !is_main_query()) {
            return $content;
        }

        global $post;
        $toc_enabled = get_post_meta($post->ID, '_ace_toc_enabled', true);
        $settings = get_option('ace_toc_settings');

        if ($toc_enabled !== '1' && $settings['auto_insert'] === 'disabled') {
            return $content;
        }

        if (in_array($post->post_type, $settings['exclude_post_types'] ?? array())) {
            return $content;
        }

        // Collect headings
        $heading_levels = $settings['heading_levels'] ?? array('h2', 'h3', 'h4');
        $pattern = '/<(' . implode('|', $heading_levels) . ')[^>]*>(.*?)<\/(' . implode('|', $heading_levels) . ')>/i';
        preg_match_all($pattern, $content, $matches, PREG_SET_ORDER);

        if (empty($matches)) {
            return $content;
        }

        // Build TOC
        $toc_html = $this->generate_toc($content);

        // Inject IDs into headings
        $content = $this->inject_heading_ids($content, $matches);

        $position = get_post_meta($post->ID, '_ace_toc_position', true) ?: $settings['auto_insert'];

        switch ($position) {
            case 'before':
            case 'before_content':
                return $toc_html . $content;

            case 'after_first':
            case 'after_first_heading':
                return preg_replace('/(<h[1-6][^>]*>.*?<\/h[1-6]>)/', '$1' . $toc_html, $content, 1);

            case 'after_first_paragraph':
                return preg_replace('/(<p>.*?<\/p>)/', '$1' . $toc_html, $content, 1);

            default:
                return $content;
        }
    }
    
    public function toc_shortcode($atts) {
        $atts = shortcode_atts(array(
            'title' => 'Table of Contents',
            'levels' => 'h2,h3,h4',
            'position' => 'default',
            'numbering' => 'true'
        ), $atts);
        
        global $post;
        if (!$post) return '';
        
        return $this->generate_toc($post->post_content, $atts);
    }
    
    private function inject_heading_ids($content, $matches) {
        foreach ($matches as $index => $match) {
            $text = strip_tags($match[2]);
            $id   = 'ace-toc-' . sanitize_title($text) . '-' . $index;

            $heading_tag = $match[0];
            $new_heading = preg_replace(
                '/<(h[1-6])(.*?)>/i',
                '<$1$2 id="' . esc_attr($id) . '">',
                $heading_tag,
                1
            );

            $content = preg_replace('/' . preg_quote($heading_tag, '/') . '/', $new_heading, $content, 1);
        }
        return $content;
    }

  private function generate_toc($content, $custom_atts = array()) {
    $settings = get_option('ace_toc_settings');
    
    $heading_levels = !empty($custom_atts['levels']) ? 
        explode(',', $custom_atts['levels']) : 
        ($settings['heading_levels'] ?? array('h1','h2','h3','h4','h5','h6'));
    
    $pattern = '/<(' . implode('|', $heading_levels) . ')[^>]*>(.*?)<\/(' . implode('|', $heading_levels) . ')>/i';
    preg_match_all($pattern, $content, $matches, PREG_SET_ORDER);
    
    if (empty($matches)) {
        return '';
    }
    
    $title = $custom_atts['title'] ?? get_post_meta(get_the_ID(), '_ace_toc_title', true) ?: 'Table of Contents';
    $show_numbering = ($custom_atts['numbering'] ?? 'true') === 'true' && ($settings['show_numbering'] ?? true);
    $color_scheme = $settings['color_scheme'] ?? 'default';

    // ✅ NEW STRUCTURE
    $toc_html  = '<div class="ace-toc-container ace-toc-' . $color_scheme . '" id="ace-table-of-contents">';

    // Desktop TOC
    $toc_html .= '<div class="ace-toc-desktop">';
    $toc_html .= '  <div class="ace-toc-header">';
    $toc_html .= '    <h3 class="ace-toc-title">📋 ' . esc_html($title) . '</h3>';
    $toc_html .= '    <button class="ace-toc-toggle" id="ace-toc-toggle" aria-expanded="true">−</button>';
    $toc_html .= '  </div>';
    $toc_html .= '  <div class="ace-toc-content" id="ace-toc-content">';
    $toc_html .= '    <ul class="ace-toc-list" id="ace-toc-list">';
    foreach ($matches as $index => $match) {
        $level = strtolower($match[1]);
        $text = strip_tags($match[2]);
        $id = 'ace-toc-' . sanitize_title($text) . '-' . $index;
        $number = $show_numbering ? ($index + 1) . '. ' : '';
        $toc_html .= '<li class="ace-toc-item ace-toc-' . $level . '">';
        $toc_html .= '<a href="#' . $id . '" class="ace-toc-link" data-target="' . $id . '">' . $number . esc_html($text) . '</a>';
        $toc_html .= '</li>';
    }
    $toc_html .= '    </ul>';
    $toc_html .= '  </div>';
    $toc_html .= '</div>';

    // Mobile TOC
    $toc_html .= '<div class="ace-toc-mobile">';
    $toc_html .= '  <button class="ace-toc-mobile-toggle" id="ace-toc-mobile-toggle" aria-expanded="false">📋 Show ' . esc_html($title) . '</button>';
    $toc_html .= '  <div class="ace-toc-mobile-content" id="ace-toc-mobile-content" style="display:none;">';
    $toc_html .= '    <ul class="ace-toc-list" id="ace-toc-mobile-list">';
    foreach ($matches as $index => $match) {
        $level = strtolower($match[1]);
        $text = strip_tags($match[2]);
        $id = 'ace-toc-' . sanitize_title($text) . '-' . $index;
        $number = $show_numbering ? ($index + 1) . '. ' : '';
        $toc_html .= '<li class="ace-toc-item ace-toc-' . $level . '">';
        $toc_html .= '<a href="#' . $id . '" class="ace-toc-link" data-target="' . $id . '">' . $number . esc_html($text) . '</a>';
        $toc_html .= '</li>';
    }
    $toc_html .= '    </ul>';
    $toc_html .= '  </div>';
    $toc_html .= '</div>';

    $toc_html .= '</div>';

    // Schema
    $toc_html .= $this->generate_schema_markup($matches);
    
    return $toc_html;
}

    
    private function generate_schema_markup($headings) {
        $items = array();
        
        foreach ($headings as $index => $heading) {
            $items[] = array(
                '@type' => 'ListItem',
                'position' => $index + 1,
                'name' => strip_tags($heading[2]),
                'url' => get_permalink() . '#ace-toc-' . sanitize_title(strip_tags($heading[2])) . '-' . $index
            );
        }
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'ItemList',
            'name' => 'Table of Contents',
            'itemListElement' => $items
        );
        
        return '<script type="application/ld+json">' . json_encode($schema) . '</script>';
    }
}

// Initialize the plugin
new ACE_Table_Of_Contents();
