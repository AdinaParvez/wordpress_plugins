/**
 * ACE Table of Contents Script
 * Handles expand/collapse, mobile toggle, smooth scrolling, and scroll spy
 * Version: 1.1.1 (fixed delegation, defaults, instance assignment, mobile toggle consistency)
 */
(function ($) {
    'use strict';

    class ACE_TableOfContents {
        constructor() {
            this.settings = window.aceTocSettings || {};
            this.tocContainer = null;
            this.tocList = null;
            this.tocToggle = null;
            this.tocMobileToggle = null;
            this.tocContent = null;
            this.headings = [];
            this.observer = null;
            this.resizeTimeout = null;

            this.init();
        }

        init() {
            $(document).ready(() => {
                this.setupElements();
                if (this.tocContainer) {
                    // ensure we get heading IDs and update links
                    this.generateHeadingIDs();
                    // create (re)mapping of headings after IDs are injected
                    this.mapHeadingsFromLinks();
                    this.setupEventListeners();
                    this.setupScrollSpy();
                    this.setupSmoothScrolling();
                    this.generateSchemaMarkup();
                }
            });
        }

        setupElements() {
            this.tocContainer = document.getElementById('ace-table-of-contents');
            if (!this.tocContainer) return;

            this.tocList = this.tocContainer.querySelector('#ace-toc-list') || document.getElementById('ace-toc-list');
            this.tocToggle = this.tocContainer.querySelector('#ace-toc-toggle') || document.getElementById('ace-toc-toggle');
            this.tocMobileToggle = this.tocContainer.querySelector('#ace-toc-mobile-toggle') || document.getElementById('ace-toc-mobile-toggle');
            // prefer content inside container; fallback to global id
            this.tocContent = this.tocContainer.querySelector('#ace-toc-content') || document.getElementById('ace-toc-content');

            // initially map headings by looking at existing links (if any)
            this.mapHeadingsFromLinks();
        }

        // Map headings array based on data-target of links
        mapHeadingsFromLinks() {
            const links = this.tocContainer ? Array.from(this.tocContainer.querySelectorAll('.ace-toc-link')) : Array.from(document.querySelectorAll('.ace-toc-link'));
            this.headings = links.map(link => {
                const id = link.getAttribute('data-target') || (link.getAttribute('href') || '').replace(/^#/, '');
                return id ? document.getElementById(id) : null;
            }).filter(Boolean);
        }

        // Inject IDs into headings (default: H1-H6)
        generateHeadingIDs() {
            const contentArea = document.querySelector('.entry-content, .post-content, .content, main, article') || document.body;
            // default to H1-H6 if settings not present
            const headingLevels = Array.isArray(this.settings.heading_levels) && this.settings.heading_levels.length
                ? this.settings.heading_levels
                : ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];

            const selector = headingLevels.join(', ');
            const headings = contentArea.querySelectorAll(selector);

            headings.forEach((heading, index) => {
                // create stable slug base from text
                const text = (heading.textContent || heading.innerText || '').trim();
                if (!text) return; // skip empty headings

                if (!heading.id) {
                    // ensure unique id — include index to avoid duplicates
                    const id = 'ace-toc-' + this.slugify(text) + '-' + index;
                    heading.id = id;
                }

                // Update TOC links that match this heading text (if server generated text matches)
                const tocLinks = this.tocContainer ? this.tocContainer.querySelectorAll('.ace-toc-link') : document.querySelectorAll('.ace-toc-link');
                tocLinks.forEach(link => {
                    // remove numbering prefix for comparison
                    const linkText = (link.textContent || '').replace(/^\d+\.\s*/, '').trim();
                    const headingText = (heading.textContent || heading.innerText || '').trim();

                    if (linkText && linkText === headingText) {
                        link.setAttribute('href', '#' + heading.id);
                        link.setAttribute('data-target', heading.id);
                    }
                });
            });

            // refresh mapped headings array
            this.mapHeadingsFromLinks();
        }

        slugify(text) {
            return text.toLowerCase()
                .replace(/[^\w\s-]/g, '')   // remove non-word chars
                .replace(/[\s_-]+/g, '-')   // collapse spaces and underscores
                .replace(/^-+|-+$/g, '');   // trim dashes
        }

        setupEventListeners() {
            // collapse toggle (desktop)
            if (this.tocToggle) {
                this.tocToggle.addEventListener('click', this.toggleTOC.bind(this));
            }

            // mobile toggle
            if (this.tocMobileToggle) {
                this.tocMobileToggle.addEventListener('click', this.toggleMobileTOC.bind(this));
            }

            // delegation for clicks inside the TOC list
            if (this.tocList) {
                this.tocList.addEventListener('click', (e) => {
                    const link = e.target.closest ? e.target.closest('.ace-toc-link') : null;
                    if (link && this.tocList.contains(link)) {
                        e.preventDefault();
                        this.handleTOCClick(link);
                    }
                });

                // keyboard nav
                this.tocList.addEventListener('keydown', (e) => this.handleKeyboardNavigation(e));
            }

            window.addEventListener('resize', this.throttledResize.bind(this));

            // Restore collapsed state (use same string values as set in toggle)
            const collapsed = localStorage.getItem('ace-toc-collapsed');
            if (collapsed === 'true' || collapsed === 'false') {
                // we stored 'true' when collapsed, 'false' when expanded
                if (collapsed === 'true') {
                    this.tocContainer.classList.add('ace-toc-collapsed');
                    if (this.tocToggle) {
                        this.tocToggle.textContent = '+';
                        this.tocToggle.setAttribute('aria-expanded', 'false');
                    }
                    // ensure mobile content hidden if using tocContent toggling
                    if (this.tocContent && this.tocContent.classList) {
                        this.tocContent.classList.remove('show');
                    }
                } else {
                    // expanded
                    if (this.tocToggle) {
                        this.tocToggle.textContent = '−';
                        this.tocToggle.setAttribute('aria-expanded', 'true');
                    }
                }
            }
        }

     toggleTOC() {
    if (!this.tocContainer || !this.tocToggle || !this.tocContent) return;

    const isCollapsed = this.tocContainer.classList.toggle('ace-toc-collapsed');

    if (isCollapsed) {
        jQuery(this.tocContent).slideUp();
        this.tocToggle.textContent = '+';
        this.tocToggle.setAttribute('aria-expanded', 'false');
    } else {
        jQuery(this.tocContent).slideDown();
        this.tocToggle.textContent = '−';
        this.tocToggle.setAttribute('aria-expanded', 'true');
    }

    localStorage.setItem('ace-toc-collapsed', String(isCollapsed));
}

toggleMobileTOC() {
    if (!this.tocContent || !this.tocMobileToggle) return;

    const $content = jQuery(this.tocContent);
    const isVisible = this.tocContent.classList.toggle('show');

    if (isVisible) {
        $content.slideDown();
        this.tocMobileToggle.textContent = '📋 Hide Table of Contents';
        this.tocMobileToggle.setAttribute('aria-expanded', 'true');
    } else {
        $content.slideUp();
        this.tocMobileToggle.textContent = '📋 Show Table of Contents';
        this.tocMobileToggle.setAttribute('aria-expanded', 'false');
    }
}

        // throttled window resize
        throttledResize() {
            clearTimeout(this.resizeTimeout);
            this.resizeTimeout = setTimeout(() => this.handleResize(), 200);
        }

        handleResize() {
            // On small screens, ensure desktop collapse isn't left applied
            if (window.innerWidth <= 768) {
                this.tocContainer?.classList.remove('ace-toc-collapsed');
                if (this.tocMobileToggle) {
                    this.tocMobileToggle.textContent = '📋 Show Table of Contents';
                    this.tocMobileToggle.setAttribute('aria-expanded', 'false');
                }
            } else {
                // ensure mobile content hidden on desktop
                this.tocContent?.classList.remove('show');
                if (this.tocToggle) {
                    this.tocToggle.textContent = '−';
                    this.tocToggle.setAttribute('aria-expanded', 'true');
                }
            }
        }

        // When a TOC link is clicked (we pass the <a> element)
        handleTOCClick(link) {
            if (!link || !link.classList.contains('ace-toc-link')) return;
            const targetId = link.getAttribute('data-target') || (link.getAttribute('href') || '').replace(/^#/, '');
            const targetElement = document.getElementById(targetId);

            if (targetElement) {
                if (this.settings.smooth_scroll !== false) {
                    this.smoothScrollTo(targetElement);
                } else {
                    targetElement.scrollIntoView();
                }

                this.updateActiveLink(link);

                // close mobile TOC after click (if visible)
                if (this.tocContent && this.tocContent.classList.contains('show')) {
                    this.tocContent.classList.remove('show');
                    if (this.tocMobileToggle) {
                        this.tocMobileToggle.textContent = '📋 Show Table of Contents';
                        this.tocMobileToggle.setAttribute('aria-expanded', 'false');
                    }
                }

                // focus the heading for accessibility
                targetElement.setAttribute('tabindex', '-1');
                targetElement.focus();

                this.trackTOCInteraction('click', targetId);
            }
        }

        smoothScrollTo(element) {
            const headerOffset = this.getHeaderOffset();
            const elementPosition = element.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
            window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
        }

        getHeaderOffset() {
            // look for common sticky header selectors
            const stickyHeader = document.querySelector('.sticky-header, .fixed-header, header[style*="fixed"], header[style*="sticky"]');
            return stickyHeader ? (stickyHeader.offsetHeight + 20) : 20;
        }

        // Scroll spy using IntersectionObserver
        setupScrollSpy() {
            if (!('IntersectionObserver' in window) || !this.headings.length) return;

            const options = { rootMargin: `-${this.getHeaderOffset()}px 0px -70% 0px`, threshold: 0 };
            this.observer = new IntersectionObserver((entries) => {
                let activeHeading = null;
                entries.forEach(entry => {
                    if (entry.isIntersecting) activeHeading = entry.target;
                });
                if (activeHeading) {
                    const correspondingLink = this.tocList?.querySelector(`[data-target="${activeHeading.id}"]`);
                    if (correspondingLink) this.updateActiveLink(correspondingLink);
                }
            }, options);

            this.headings.forEach(heading => {
                if (heading) this.observer.observe(heading);
            });
        }

        updateActiveLink(activeLink) {
            if (!this.tocList) return;
            this.tocList.querySelectorAll('.ace-toc-link').forEach(link => {
                link.classList.remove('active');
                link.setAttribute('aria-current', 'false');
            });
            if (activeLink) {
                activeLink.classList.add('active');
                activeLink.setAttribute('aria-current', 'true');
            }
        }

        setupSmoothScrolling() {
            if (!CSS.supports('scroll-behavior', 'smooth')) {
                const style = document.createElement('style');
                style.textContent = 'html { scroll-behavior: smooth; }';
                document.head.appendChild(style);
            }
        }

        handleKeyboardNavigation(e) {
            if (!this.tocList) return;
            const tocLinks = Array.from(this.tocList.querySelectorAll('.ace-toc-link'));
            if (!tocLinks.length) return;

            const focusedElement = document.activeElement;
            const currentIndex = tocLinks.indexOf(focusedElement);

            switch (e.key) {
                case 'ArrowDown':
                    e.preventDefault();
                    tocLinks[(currentIndex + 1) % tocLinks.length]?.focus();
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    tocLinks[(currentIndex - 1 + tocLinks.length) % tocLinks.length]?.focus();
                    break;
                case 'Home':
                    e.preventDefault();
                    tocLinks[0]?.focus();
                    break;
                case 'End':
                    e.preventDefault();
                    tocLinks[tocLinks.length - 1]?.focus();
                    break;
                case 'Enter':
                case ' ':
                    e.preventDefault();
                    if (focusedElement && focusedElement.classList.contains('ace-toc-link')) {
                        this.handleTOCClick(focusedElement);
                    }
                    break;
            }
        }

        generateSchemaMarkup() {
            if (!this.headings.length || !document.head) return;

            const items = this.headings.map((heading, index) => ({
                '@type': 'ListItem',
                'position': index + 1,
                'name': heading.textContent || heading.innerText,
                'url': `${window.location.href.split('#')[0]}#${heading.id}`
            }));

            const schema = {
                '@context': 'https://schema.org',
                '@type': 'ItemList',
                'name': 'Table of Contents',
                'numberOfItems': items.length,
                'itemListElement': items
            };

            const existingSchema = document.querySelector('script[data-ace-toc-schema]');
            if (existingSchema) existingSchema.remove();

            const script = document.createElement('script');
            script.type = 'application/ld+json';
            script.setAttribute('data-ace-toc-schema', '1');
            script.textContent = JSON.stringify(schema);
            document.head.appendChild(script);
        }

        trackTOCInteraction(action, target) {
            if (typeof gtag !== 'undefined') {
                gtag('event', 'toc_interaction', {
                    'event_category': 'Table of Contents',
                    'event_label': target,
                    'action': action
                });
            }
            if (typeof ga !== 'undefined') {
                ga('send', 'event', 'Table of Contents', action, target);
            }
        }

        destroy() {
            if (this.observer) {
                this.observer.disconnect();
            }
            // you could remove listeners here if you attach references
        }

        // Public API
        refresh() {
            this.destroy();
            this.init();
        }

        scrollToHeading(headingId) {
            const heading = document.getElementById(headingId);
            if (heading) {
                const offset = 20; // adjust for sticky headers
                const top = heading.getBoundingClientRect().top + window.pageYOffset - offset;
                window.scrollTo({ top, behavior: 'smooth' });
            }
        }

        getProgress() {
            if (!this.headings.length) return 0;
            const activeLink = this.tocList?.querySelector('.ace-toc-link.active');
            if (!activeLink) return 0;
            const allLinks = Array.from(this.tocList.querySelectorAll('.ace-toc-link'));
            const activeIndex = allLinks.indexOf(activeLink);
            return Math.round((activeIndex + 1) / allLinks.length * 100);
        }
    }

    // Init
    let aceTableOfContents = null;

    function initACETOC() {
        const container = document.querySelector('#ace-table-of-contents');
        if (container) {
            aceTableOfContents = new ACE_TableOfContents();
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initACETOC);
    } else {
        initACETOC();
    }

    window.ACETOC = {
        init: initACETOC,
        instance: () => aceTableOfContents,
        refresh: () => aceTableOfContents?.refresh(),
        scrollTo: (headingId) => aceTableOfContents?.scrollToHeading(headingId),
        getProgress: () => aceTableOfContents?.getProgress() || 0
    };

    // Gutenberg
    if (typeof wp !== 'undefined' && wp.domReady) {
        wp.domReady(initACETOC);
    }

    // Elementor compatibility
    $(window).on('elementor/frontend/init', function () {
        setTimeout(initACETOC, 500);
    });

})(jQuery);


// jQuery(document).ready(function ($) {
//     // Desktop toggle
//     $('#ace-toc-toggle').on('click', function () {
//         let $content = $('#ace-toc-content');
//         let expanded = $(this).attr('aria-expanded') === 'true';

//         if (expanded) {
//             $content.slideUp();
//             $(this).text('+').attr('aria-expanded', 'false');
//         } else {
//             $content.slideDown();
//             $(this).text('−').attr('aria-expanded', 'true');
//         }
//     });

//     // Mobile toggle
//     $('#ace-toc-mobile-toggle').on('click', function () {
//         let $mobileContent = $('#ace-toc-mobile-content');
//         let expanded = $(this).attr('aria-expanded') === 'true';

//         if (expanded) {
//             $mobileContent.slideUp();
//             $(this).attr('aria-expanded', 'false').text('📋 Show Table of Contents');
//         } else {
//             $mobileContent.slideDown();
//             $(this).attr('aria-expanded', 'true').text('📋 Hide Table of Contents');
//         }
//     });

//     // Smooth scroll
//     $('.ace-toc-link').on('click', function (e) {
//         e.preventDefault();
//         let target = $(this).attr('href');
//         if ($(target).length) {
//             $('html, body').animate({ scrollTop: $(target).offset().top - 80 }, 500);
//         }
//     });
// });
