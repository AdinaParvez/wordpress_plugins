<?php
/*
Plugin Name: Simple Quiz Plugin
Description: A responsive quiz plugin with multiple-choice questions, instant feedback, and score calculation.
Version: 2.5
Author: Adina Pervaiz, ACE Web Services
*/

if (!defined('ABSPATH')) exit;

// ================= Frontend CSS & JS =================
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('simple-quiz-style', plugin_dir_url(__FILE__) . 'style.css');
    wp_enqueue_script('simple-quiz-script', plugin_dir_url(__FILE__) . 'script.js', array('jquery'), null, true);

    // Fetch questions from admin panel
    $questions = get_option('simple_quiz_questions', []);
    $levelQuestions = [];
    foreach ($questions as $i => $q) {
        $level = $q['level'] ?? 'generalEnglish';
        $qId = $level . '-q' . ($i + 1);
        $levelQuestions[$level][] = [
            'qid' => $qId,
            'question' => $q['question'],
            'options' => $q['options'],
            'correct' => $q['correct'],
            'image' => $q['image'] ?? ''
        ];
    }

    wp_localize_script('simple-quiz-script', 'quizData', $levelQuestions);
});

// ================= Shortcode =================
add_shortcode('quiz_buttons', function() {
    $questions = get_option('simple_quiz_questions', []);
    if (empty($questions)) return '<p>No quizzes found.</p>';

    $levelQuestions = [];
    foreach ($questions as $q) {
        $level = $q['level'] ?? 'generalEnglish';
        $levelQuestions[$level][] = $q;
    }

    $output = '<div id="quiz-container">';
    $output .= '<div class="quiz-buttons">';
    foreach ($levelQuestions as $level => $qs) {
        $label = ucfirst($level) . ' Level Test';
        $output .= '<button class="quiz-btn" data-level="' . esc_attr($level) . '">' . esc_html($label) . '</button>';
    }
    $output .= '</div>';

    $output .= '<div id="quiz-content" style="margin-top:20px;"></div>'; // Quiz will render here
    $output .= '</div>';

    return $output;
});

// ================= Admin Settings =================
function simple_quiz_admin_page() {
    if (!current_user_can('manage_options')) return;

    // Save quiz questions
    if (isset($_POST['save_quiz'])) {
        $questions = [];
        foreach ($_POST['question'] as $i => $q) {
            if (empty($q)) continue;
            $questions[] = [
                'question' => sanitize_text_field($q),
                'options' => [
                    'a' => sanitize_text_field($_POST['option_a'][$i]),
                    'b' => sanitize_text_field($_POST['option_b'][$i]),
                    'c' => sanitize_text_field($_POST['option_c'][$i]),
                ],
                'correct' => sanitize_text_field($_POST['correct'][$i]),
                'level' => sanitize_text_field($_POST['level'][$i]),
                'image' => sanitize_text_field($_POST['image'][$i] ?? ''),
            ];
        }
        update_option('simple_quiz_questions', $questions);
        echo '<div class="updated"><p>Quiz saved!</p></div>';
    }

    $questions = get_option('simple_quiz_questions', []);
    $levels = [
        'generalEnglish' => 'General English',
        'businessEnglish' => 'Business English',
        'youngLearners' => 'Young Learners'
    ];
    ?>
    <div class="wrap">
        <h1>Simple Quiz Settings</h1>
        <form method="post" id="quiz-admin-form">
            <table class="form-table" id="quiz-table">
                <?php foreach ($questions as $i => $q): ?>
                    <tr class="quiz-row">
                        <th>Question <?php echo $i + 1; ?></th>
                        <td>
                            <input type="text" name="question[]" value="<?php echo esc_attr($q['question']); ?>" style="width:100%" placeholder="Enter question">
                            <p><b>Options:</b></p>
                            A: <input type="text" name="option_a[]" value="<?php echo esc_attr($q['options']['a']); ?>"><br>
                            B: <input type="text" name="option_b[]" value="<?php echo esc_attr($q['options']['b']); ?>"><br>
                            C: <input type="text" name="option_c[]" value="<?php echo esc_attr($q['options']['c']); ?>"><br>
                            Correct Answer:
                            <select name="correct[]">
                                <option value="a" <?php selected($q['correct'], 'a'); ?>>A</option>
                                <option value="b" <?php selected($q['correct'], 'b'); ?>>B</option>
                                <option value="c" <?php selected($q['correct'], 'c'); ?>>C</option>
                            </select><br><br>
                            Level:
                            <select name="level[]">
                                <?php foreach ($levels as $key => $label): ?>
                                    <option value="<?php echo esc_attr($key); ?>" <?php selected($q['level'], $key); ?>>
                                        <?php echo esc_html($label); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select><br><br>
                            Image URL (optional):
                            <input type="text" name="image[]" value="<?php echo esc_attr($q['image'] ?? ''); ?>" placeholder="https://example.com/image.jpg">
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
            <p><button type="button" class="button" id="add-question">+ Add New Question</button></p>
            <p><input type="submit" name="save_quiz" class="button button-primary" value="Save Quiz"></p>
        </form>
    </div>
    <?php
}

add_action('admin_enqueue_scripts', function($hook) {
    // Only load on our plugin settings page
    if ($hook !== 'settings_page_simple-quiz-settings') return;

    wp_enqueue_script(
        'simple-quiz-admin-script', 
        plugin_dir_url(__FILE__) . 'admin.js', 
        array('jquery'), 
        null, 
        true
    );
});


add_action('admin_menu', function() {
    add_options_page('Simple Quiz Settings', 'Simple Quiz', 'manage_options', 'simple-quiz-settings', 'simple_quiz_admin_page');
});

