jQuery(document).ready(function($){
    let currentLevel = '';
    let currentQuestion = 0;
    let score = 0;
    let answers = {};

    $('.quiz-btn').click(function(){
        currentLevel = $(this).data('level');
        currentQuestion = 0;
        score = 0;
        answers = {};
        showQuestion();
    });

    function showQuestion() {
        const questions = quizData[currentLevel];
        if(!questions) return;

        if(currentQuestion >= questions.length){
            score = 0;
            questions.forEach((q) => {
                if(answers[q.qid] === q.correct) score++;
            });
            $('#quiz-content').html('<h3>Quiz finished! Score: ' + score + ' / ' + questions.length + '</h3><button id="quiz-reset">Reset Quiz</button>');
            return;
        }

        const q = questions[currentQuestion];
        let html = '<div class="quiz-question">';
        const percent = Math.round(((currentQuestion) / questions.length) * 100);
        html += '<div class="quiz-progress-bar"><div class="quiz-progress-fill" style="width:' + percent + '%;"></div></div>';
        html += '<div class="quiz-progress-text">Page ' + (currentQuestion + 1) + ' of ' + questions.length + '</div>';
        html += '<h4>' + q.question + '</h4>';
        if(q.image) html += '<img src="'+q.image+'" style="width:100%; margin-bottom:15px;">';
        html += '<div class="quiz-options">';
        $.each(q.options, function(key, val){
            html += '<button class="answer-btn" data-key="'+key+'">'+val+'</button>';
        });
        html += '</div>';
        html += '<div class="quiz-feedback" style="margin-top:10px; font-weight:bold;"></div>'; // Feedback text
        html += '<div class="quiz-nav" style="margin-top:15px;">';
        if(currentQuestion > 0) html += '<button id="quiz-prev">Previous</button>';
        html += '</div></div>';

        $('#quiz-content').html(html);

        // Highlight previously selected answer
        const selected = answers[q.qid];
        if(selected) {
            $('#quiz-content .answer-btn').each(function(){
                if($(this).data('key') === selected) $(this).addClass('selected');
            });
        }
    }

    $('#quiz-content').on('click', '.answer-btn', function(){
        const key = $(this).data('key');
        const q = quizData[currentLevel][currentQuestion];
        answers[q.qid] = key;

        // Disable all options
        $('#quiz-content .answer-btn').prop('disabled', true);

        // Remove previous classes
        $('#quiz-content .answer-btn').removeClass('correct wrong selected');

        if(key === q.correct){
            $(this).addClass('correct selected');
            $('.quiz-feedback').text('Correct!').css('color','green');
        } else {
            $(this).addClass('wrong selected');
            $('#quiz-content .answer-btn').each(function(){
                if($(this).data('key') === q.correct) $(this).addClass('correct');
            });
            $('.quiz-feedback').text('Wrong!').css('color','red');
        }

        if($('#quiz-next').length === 0){
            $('#quiz-content .quiz-nav').append('<button id="quiz-next">Next</button>');
        }
    });

    $('#quiz-content').on('click', '#quiz-next', function(){
        currentQuestion++;
        showQuestion();
    });

    $('#quiz-content').on('click', '#quiz-prev', function(){
        currentQuestion--;
        showQuestion();
    });

    $('#quiz-content').on('click', '#quiz-reset', function(){
        currentQuestion = 0;
        score = 0;
        answers = {};
        showQuestion();
    });
});
