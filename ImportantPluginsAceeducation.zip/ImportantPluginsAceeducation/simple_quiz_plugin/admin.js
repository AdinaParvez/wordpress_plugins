jQuery(document).ready(function($){
    let questionCount = $('#quiz-table .quiz-row').length;

    $('#add-question').click(function(){
        questionCount++;
        const newRow = `
        <tr class="quiz-row">
            <th>Question ${questionCount}</th>
            <td>
                <input type="text" name="question[]" style="width:100%" placeholder="Enter question">
                <p><b>Options:</b></p>
                A: <input type="text" name="option_a[]"><br>
                B: <input type="text" name="option_b[]"><br>
                C: <input type="text" name="option_c[]"><br>
                Correct Answer:
                <select name="correct[]">
                    <option value="a">A</option>
                    <option value="b">B</option>
                    <option value="c">C</option>
                </select><br><br>
                Level:
                <select name="level[]">
                    <option value="generalEnglish">General English</option>
                    <option value="businessEnglish">Business English</option>
                    <option value="youngLearners">Young Learners</option>
                </select><br><br>
                Image URL (optional):
                <input type="text" name="image[]" placeholder="https://example.com/image.jpg">
            </td>
        </tr>`;
        $('#quiz-table').append(newRow);
    });
});
