document.addEventListener('DOMContentLoaded', function() {

    // ===== Animate job cards on scroll =====
    const cards = document.querySelectorAll('.job-card');
    const cardObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                cardObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    cards.forEach(card => cardObserver.observe(card));

    // ===== Lazy-load logos with smooth placeholder =====
    const lazyImgs = document.querySelectorAll('.job-card img[data-src]');

    lazyImgs.forEach(img => {
        // Set placeholder first
        const placeholder = img.src;

        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const realSrc = img.dataset.src;

                        if (realSrc && realSrc !== placeholder) {
                            img.src = realSrc;
                            img.onload = () => img.classList.add('loaded');
                        } else {
                            img.classList.add('loaded');
                        }

                        observer.unobserve(img);
                    }
                });
            }, { threshold: 0.1 });

            observer.observe(img);
        } else {
            // Fallback for older browsers
            const realSrc = img.dataset.src;
            if (realSrc && realSrc !== placeholder) {
                img.src = realSrc;
                img.onload = () => img.classList.add('loaded');
            } else {
                img.classList.add('loaded');
            }
        }
    });

});
/* End of script.js */