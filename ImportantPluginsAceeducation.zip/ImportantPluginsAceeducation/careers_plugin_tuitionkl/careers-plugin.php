<?php
/**
 * Plugin Name: Careers Section Optimized
 * Description: Fully responsive Careers Section with animations, lazy-load logos, and admin panel.
 * Version: 2.2
 * Author: Adina Pervaiz
 */

if (!defined('ABSPATH')) exit;

class CareersSectionOptimized {

    private $post_type = 'career_job';
    private $custom_login_url = 'https://tuitionkl.com/tutor-login-page/';
    private $custom_register_url = 'https://tuitionkl.com/tutor-login-page/?action=register';

    public function __construct() {
        add_action('init', [$this, 'create_application_page']);
        add_action('init', [$this, 'register_custom_post_type']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_shortcode('careers_section', [$this, 'render_careers_section']);
        add_shortcode('application_form', [$this, 'render_application_form']);
        
        if (is_admin()) {
            add_action('admin_menu', [$this, 'add_admin_menu']);
        }
        
        add_action('admin_init', [$this, 'register_settings']);
        
        // AJAX handler for application submission
        add_action('wp_ajax_submit_career_application', [$this, 'submit_application']);
        add_action('wp_ajax_nopriv_submit_career_application', [$this, 'submit_application']);
        
        // Handle job application redirection
        add_action('template_redirect', [$this, 'handle_application_redirect']);
    }

    // Register custom post type (hidden from main menu)
    public function register_custom_post_type() {
        $args = array(
            'public' => true,
            'label'  => 'Career Jobs',
            'show_ui' => true,
            'show_in_menu' => false,
            'supports' => array('title', 'editor', 'thumbnail'),
            'has_archive' => true,
            'rewrite' => array('slug' => 'career-jobs'),
        );
        register_post_type($this->post_type, $args);
    }

    // Create application page on plugin activation
    public function create_application_page() {
        // Check if page already exists
        $page_exists = get_page_by_path('apply-now');
        
        if (!$page_exists) {
            $page_content = '<!-- This page uses the [application_form] shortcode -->';
            $page_content .= '[application_form]';
            
            $page_data = array(
                'post_title'    => 'Apply Now',
                'post_name'     => 'apply-now',
                'post_content'  => $page_content,
                'post_status'   => 'publish',
                'post_type'     => 'page',
                'post_author'   => 1,
            );
            
            $page_id = wp_insert_post($page_data);
            update_option('careers_application_page_id', $page_id);
        }
    }

    // Enqueue CSS and JS
    public function enqueue_assets() {
        // CSS
        wp_enqueue_style(
            'careers-style',
            plugin_dir_url(__FILE__) . 'assets/style.css',
            [],
            '2.2'
        );

        // JS
        wp_enqueue_script(
            'careers-js',
            plugin_dir_url(__FILE__) . 'assets/script.js',
            ['jquery'],
            '2.2',
            true
        );

        // Localize script for AJAX
        wp_localize_script('careers-js', 'careers_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('careers_apply_nonce'),
            'login_url' => $this->custom_login_url,
            'register_url' => $this->custom_register_url,
            'is_user_logged_in' => is_user_logged_in() ? '1' : '0',
        ]);
    }

    // Handle application page redirection
    public function handle_application_redirect() {
        if (is_page('apply-now') && isset($_GET['job_id'])) {
            if (!session_id()) {
                session_start();
            }
            $_SESSION['careers_applying_job_id'] = intval($_GET['job_id']);
        }
    }

    // Shortcode for careers section
    public function render_careers_section($atts) {
        $jobs = get_option('careers_jobs', []);

        // Default jobs
        if (empty($jobs)) {
            $jobs = [
                [
                    'id' => 1,
                    'title' => 'English Language Tutor',
                    'location' => 'Kuala Lumpur',
                    'department' => 'Academics',
                    'description' => 'Teach students using modern English learning methodologies.',
                    'logo' => 'https://thumbs.dreamstime.com/b/avatar-profile-icon-flat-style-female-user-vector-illustration-isolated-background-women-sign-business-concept-321407993.jpg'
                ],
                [
                    'id' => 2,
                    'title' => 'Academic Coordinator',
                    'location' => 'Onsite',
                    'department' => 'Management',
                    'description' => 'Coordinate academic planning and manage teaching staff.',
                    'logo' => 'https://img.freepik.com/premium-vector/portrait-business-woman_505024-2799.jpg'
                ],
                [
                    'id' => 3,
                    'title' => 'Mathematics Teacher',
                    'location' => 'Online',
                    'department' => 'STEM',
                    'description' => 'Deliver engaging math lessons aligned with international syllabi.',
                    'logo' => 'https://thumbs.dreamstime.com/b/male-avatar-realistic-face-man-suit-shirt-necktie-businessman-head-shoulder-icon-vector-186025729.jpg'
                ]
            ];
        }

        // Get application page URL
        $application_page = get_page_by_path('apply-now');
        $apply_page_url = $application_page ? get_permalink($application_page) : home_url('/apply-now/');

        ob_start(); ?>
        <section class="careers-section">
            <div class="container">
                <h2>Join Our Team</h2>
                <div class="jobs-grid">
                    <?php foreach($jobs as $index => $job): 
                        $job_id = isset($job['id']) ? $job['id'] : ($index + 1);
                        $apply_link = add_query_arg('job_id', $job_id, $apply_page_url);
                    ?>
                        <div class="job-card">
                            <div class="job-header">
                                <img 
                                    src="<?php echo esc_url($job['logo'] ?? plugin_dir_url(__FILE__) . 'assets/placeholder.webp'); ?>" 
                                    data-src="<?php echo esc_url($job['logo'] ?? plugin_dir_url(__FILE__) . 'assets/placeholder.webp'); ?>" 
                                    alt="<?php echo esc_attr($job['title']); ?> logo" 
                                    loading="lazy" 
                                    class="lazy-logo" 
                                    width="80" 
                                    height="80"
                                    onerror="this.onerror=null;this.src='<?php echo plugin_dir_url(__FILE__); ?>assets/placeholder.webp';"
                                >
                                <h3><?php echo esc_html($job['title']); ?></h3>
                            </div>
                            
                            <div class="job-details">
                                <p><strong>📍 Location:</strong> <?php echo esc_html($job['location']); ?></p>
                                <p><strong>🏢 Department:</strong> <?php echo esc_html($job['department']); ?></p>
                                <p class="job-description"><?php echo esc_html($job['description']); ?></p>
                            </div>
                            
                            <div class="job-actions">
                                <a href="<?php echo esc_url($apply_link); ?>" class="apply-btn" 
                                   data-job-id="<?php echo esc_attr($job_id); ?>"
                                   data-job-title="<?php echo esc_attr($job['title']); ?>">
                                    Apply Now
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    // Shortcode for application form
    public function render_application_form($atts) {
        $atts = shortcode_atts(['job_id' => 0], $atts);
        $job_id = intval($atts['job_id']);
        
        if (!$job_id && isset($_GET['job_id'])) {
            $job_id = intval($_GET['job_id']);
        }
        
        if (!session_id()) {
            session_start();
        }
        
        if (!$job_id && isset($_SESSION['careers_applying_job_id'])) {
            $job_id = intval($_SESSION['careers_applying_job_id']);
            unset($_SESSION['careers_applying_job_id']);
        }
        
        ob_start();
        $this->render_application_form_html($job_id);
        return ob_get_clean();
    }

    // Render application form HTML
    private function render_application_form_html($job_id = 0) {
        // Get job details
        $job_title = 'Position';
        $jobs = get_option('careers_jobs', []);
        
        if ($job_id > 0) {
            foreach ($jobs as $job) {
                $current_job_id = isset($job['id']) ? $job['id'] : 0;
                if ($current_job_id == $job_id) {
                    $job_title = $job['title'];
                    break;
                }
            }
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            
            // Use custom login URL with redirect parameter
            $redirect_url = $this->custom_login_url;
            if (strpos($redirect_url, '?') !== false) {
                $redirect_url .= '&redirect_to=' . urlencode($current_url);
            } else {
                $redirect_url .= '?redirect_to=' . urlencode($current_url);
            }
            
            // Use custom register URL
            $register_url = $this->custom_register_url;
            if (strpos($register_url, '?') !== false) {
                $register_url .= '&redirect_to=' . urlencode($current_url);
            } else {
                $register_url .= '?redirect_to=' . urlencode($current_url);
            }
            ?>
            <div class="careers-login-prompt">
                <h3>Apply for: <?php echo esc_html($job_title); ?></h3>
                <p>You need to login or register to apply for this job.</p>
                <div class="auth-buttons">
                    <a href="<?php echo esc_url($redirect_url); ?>" class="btn-login">
                        Login to Apply
                    </a>
                    <a href="<?php echo esc_url($register_url); ?>" class="btn-register">
                        Create Account
                    </a>
                </div>
                <p class="register-note">Registration is quick and free!</p>
            </div>
            <?php
            return;
        }
        
        // Get current user data
        $current_user = wp_get_current_user();
        ?>
        <div class="application-form-container">
            <h3>Apply for: <?php echo esc_html($job_title); ?></h3>
            
            <?php if ($job_id > 0): ?>
            <input type="hidden" id="application_job_id" value="<?php echo esc_attr($job_id); ?>">
            <?php endif; ?>
            
            <form id="careers-application-form" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action" value="submit_career_application">
                <input type="hidden" name="job_id" value="<?php echo esc_attr($job_id); ?>">
                <?php wp_nonce_field('careers_apply_action', 'careers_nonce'); ?>
                
                <div class="form-group">
                    <label for="applicant_name">Full Name *</label>
                    <input type="text" id="applicant_name" name="applicant_name" required 
                           value="<?php echo esc_attr($current_user->display_name); ?>">
                </div>
                
                <div class="form-group">
                    <label for="applicant_email">Email Address *</label>
                    <input type="email" id="applicant_email" name="applicant_email" required 
                           value="<?php echo esc_attr($current_user->user_email); ?>">
                </div>
                
                <div class="form-group">
                    <label for="applicant_phone">Phone Number *</label>
                    <input type="tel" id="applicant_phone" name="applicant_phone" required
                           placeholder="+60 12-345 6789">
                </div>
                
                <div class="form-group">
                    <label for="applicant_experience">Previous Experience *</label>
                    <textarea id="applicant_experience" name="applicant_experience" rows="5" required 
                              placeholder="Describe your relevant work experience..."></textarea>
                </div>
                
                <div class="form-group">
                    <label for="cover_letter">Cover Letter (Optional)</label>
                    <textarea id="cover_letter" name="cover_letter" rows="5" 
                              placeholder="Why are you interested in this position?"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="cv_file">Upload CV (PDF, DOC, DOCX) *</label>
                    <input type="file" id="cv_file" name="cv_file" 
                           accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                           required>
                    <small>Maximum file size: 5MB</small>
                </div>
                
                <div class="form-group consent-group">
                    <input type="checkbox" id="data_consent" name="data_consent" required>
                    <label for="data_consent">
                        I consent to the collection and processing of my personal data for recruitment purposes.
                    </label>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="submit-application-btn">
                        Submit Application
                    </button>
                    <span class="loading-spinner" style="display:none;">
                        <span class="spinner"></span> Processing...
                    </span>
                </div>
                
                <div id="application-response" class="response-message"></div>
            </form>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Form submission
            $('#careers-application-form').on('submit', function(e) {
                e.preventDefault();
                
                var form = $(this);
                var submitBtn = form.find('.submit-application-btn');
                var spinner = form.find('.loading-spinner');
                var responseDiv = $('#application-response');
                
                // Show loading
                submitBtn.hide();
                spinner.show();
                responseDiv.removeClass().html('');
                
                // Validate file
                var fileInput = $('#cv_file')[0];
                if (fileInput.files.length === 0) {
                    showError('Please upload your CV');
                    resetButtons();
                    return;
                }
                
                // Create FormData
                var formData = new FormData(form[0]);
                
                // AJAX submission
                $.ajax({
                    url: '<?php echo admin_url("admin-ajax.php"); ?>',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            showSuccess(response.data.message);
                            form[0].reset();
                        } else {
                            showError(response.data.message || 'An error occurred.');
                        }
                    },
                    error: function() {
                        showError('Network error. Please try again.');
                    },
                    complete: function() {
                        resetButtons();
                    }
                });
                
                function showError(message) {
                    responseDiv.html('<div class="error-message">' + message + '</div>');
                    responseDiv.slideDown();
                }
                
                function showSuccess(message) {
                    responseDiv.html('<div class="success-message">' + message + '</div>');
                    responseDiv.slideDown();
                    
                    // Redirect to thank you page after 3 seconds
                    setTimeout(function() {
                        window.location.href = '<?php echo home_url("/thank-you/"); ?>';
                    }, 3000);
                }
                
                function resetButtons() {
                    submitBtn.show();
                    spinner.hide();
                }
            });
            
            // File validation
            $('#cv_file').on('change', function() {
                var file = this.files[0];
                if (!file) return;
                
                var allowedTypes = ['pdf', 'doc', 'docx'];
                var fileExt = file.name.split('.').pop().toLowerCase();
                var maxSize = 5 * 1024 * 1024; // 5MB
                
                $(this).removeClass('error');
                $('.file-error').remove();
                
                if ($.inArray(fileExt, allowedTypes) === -1) {
                    $(this).addClass('error');
                    $(this).after('<small class="file-error">Invalid file type. Use PDF, DOC, or DOCX.</small>');
                    $(this).val('');
                } else if (file.size > maxSize) {
                    $(this).addClass('error');
                    $(this).after('<small class="file-error">File too large. Max 5MB.</small>');
                    $(this).val('');
                }
            });
        });
        </script>
        <?php
    }

    // AJAX handler for submitting application
    public function submit_application() {
        // Verify nonce
        if (!isset($_POST['careers_nonce']) || 
            !wp_verify_nonce($_POST['careers_nonce'], 'careers_apply_action')) {
            wp_send_json_error(['message' => 'Security check failed.']);
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Please login to submit an application.']);
        }
        
        // Validate required fields
        $errors = [];
        $required_fields = [
            'applicant_name' => 'Full name',
            'applicant_email' => 'Email address',
            'applicant_phone' => 'Phone number',
            'applicant_experience' => 'Previous experience',
        ];
        
        foreach ($required_fields as $field => $label) {
            if (empty($_POST[$field])) {
                $errors[] = $label . ' is required.';
            }
        }
        
        // Validate email
        if (!empty($_POST['applicant_email']) && !is_email($_POST['applicant_email'])) {
            $errors[] = 'Please enter a valid email address.';
        }
        
        // Validate file upload
        if (empty($_FILES['cv_file']['name'])) {
            $errors[] = 'Please upload your CV.';
        } else {
            $file = $_FILES['cv_file'];
            $allowed_types = array('pdf', 'doc', 'docx');
            $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            
            if (!in_array($file_ext, $allowed_types)) {
                $errors[] = 'Only PDF, DOC, and DOCX files are allowed.';
            }
            
            if ($file['size'] > 5 * 1024 * 1024) {
                $errors[] = 'File size must be less than 5MB.';
            }
        }
        
        if (!empty($errors)) {
            wp_send_json_error(['message' => implode('<br>', $errors)]);
        }
        
        // Process file upload
        $upload_dir = wp_upload_dir();
        $cv_dir = $upload_dir['basedir'] . '/career-applications/';
        
        // Create directory if it doesn't exist
        if (!file_exists($cv_dir)) {
            wp_mkdir_p($cv_dir);
            file_put_contents($cv_dir . '.htaccess', 'Options -Indexes' . PHP_EOL . 'Deny from all');
            file_put_contents($cv_dir . 'index.php', '<?php // Silence is golden');
        }
        
        $cv_filename = uniqid() . '_' . sanitize_file_name($_FILES['cv_file']['name']);
        $cv_path = $cv_dir . $cv_filename;
        
        if (!move_uploaded_file($_FILES['cv_file']['tmp_name'], $cv_path)) {
            wp_send_json_error(['message' => 'Failed to upload CV. Please try again.']);
        }
        
        // Save application to database
        global $wpdb;
        $table_name = $wpdb->prefix . 'career_applications';
        
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            job_id int(11) NOT NULL,
            user_id int(11) NOT NULL,
            applicant_name varchar(255) NOT NULL,
            applicant_email varchar(255) NOT NULL,
            applicant_phone varchar(50) NOT NULL,
            experience text NOT NULL,
            cover_letter text,
            cv_file varchar(255) NOT NULL,
            status varchar(50) DEFAULT 'pending',
            applied_date datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        
        // Insert application
        $data = [
            'job_id' => intval($_POST['job_id']),
            'user_id' => get_current_user_id(),
            'applicant_name' => sanitize_text_field($_POST['applicant_name']),
            'applicant_email' => sanitize_email($_POST['applicant_email']),
            'applicant_phone' => sanitize_text_field($_POST['applicant_phone']),
            'experience' => wp_kses_post($_POST['applicant_experience']),
            'cover_letter' => wp_kses_post($_POST['cover_letter']),
            'cv_file' => $cv_filename,
        ];
        
        $result = $wpdb->insert($table_name, $data);
        
        if ($result) {
            // Send email notifications
            $this->send_notification_emails($data);
            
            wp_send_json_success([
                'message' => 'Application submitted successfully! We will contact you soon.'
            ]);
        } else {
            wp_send_json_error(['message' => 'Failed to save application. Please try again.']);
        }
    }
    
    private function send_notification_emails($data) {
        // Get job title
        $job_title = 'Position';
        $jobs = get_option('careers_jobs', []);
        foreach ($jobs as $job) {
            $job_id = isset($job['id']) ? $job['id'] : 0;
            if ($job_id == $data['job_id']) {
                $job_title = $job['title'];
                break;
            }
        }
        
        // Send to admin
        $admin_email = get_option('admin_email');
        $subject = 'New Job Application: ' . $job_title;
        $message = "A new application has been submitted:\n\n";
        $message .= "Job: " . $job_title . "\n";
        $message .= "Applicant: " . $data['applicant_name'] . "\n";
        $message .= "Email: " . $data['applicant_email'] . "\n";
        $message .= "Phone: " . $data['applicant_phone'] . "\n";
        $message .= "Application Date: " . date('F j, Y g:i a') . "\n";
        
        wp_mail($admin_email, $subject, $message);
        
        // Send confirmation to applicant
        $applicant_subject = 'Application Received: ' . $job_title;
        $applicant_message = "Dear " . $data['applicant_name'] . ",\n\n";
        $applicant_message .= "Thank you for applying for the position of " . $job_title . ".\n\n";
        $applicant_message .= "We have received your application and will review it shortly. ";
        $applicant_message .= "If your qualifications match our requirements, we will contact you for the next steps.\n\n";
        $applicant_message .= "Best regards,\n";
        $applicant_message .= get_bloginfo('name') . " Team";
        
        wp_mail($data['applicant_email'], $applicant_subject, $applicant_message);
    }

    // Admin menu
    public function add_admin_menu() {
        // Main menu
        add_menu_page(
            'Careers', 
            'Careers', 
            'manage_options', 
            'careers-section', 
            [$this, 'admin_page'], 
            'dashicons-businessman', 
            30
        );
        
        // Submenu: Jobs
        add_submenu_page(
            'careers-section',
            'All Jobs',
            'All Jobs',
            'manage_options',
            'edit.php?post_type=' . $this->post_type
        );
        
        // Submenu: Add New Job
        add_submenu_page(
            'careers-section',
            'Add New Job',
            'Add New Job',
            'manage_options',
            'post-new.php?post_type=' . $this->post_type
        );
        
        // Submenu: Applications
        add_submenu_page(
            'careers-section',
            'Applications',
            'Applications',
            'manage_options',
            'careers-applications',
            [$this, 'applications_page']
        );
        
        // Submenu: Settings
        add_submenu_page(
            'careers-section',
            'Settings',
            'Settings',
            'manage_options',
            'careers-settings',
            [$this, 'settings_page']
        );
        
        // Remove duplicate submenu
        remove_submenu_page('careers-section', 'careers-section');
    }

    // Settings page
    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>Careers Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('careers_settings_group');
                do_settings_sections('careers-settings');
                ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">Application Page</th>
                        <td>
                            <?php 
                            $application_page = get_page_by_path('apply-now');
                            if ($application_page) {
                                echo '<p>Application page: <a href="' . get_permalink($application_page) . '" target="_blank">' . get_permalink($application_page) . '</a></p>';
                            } else {
                                echo '<p style="color: #dc3232;">Application page not found. Please deactivate and reactivate the plugin.</p>';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Custom Login URL</th>
                        <td>
                            <input type="text" class="regular-text" value="<?php echo esc_url($this->custom_login_url); ?>" readonly>
                            <p class="description">Users will be redirected to this URL for login.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Custom Register URL</th>
                        <td>
                            <input type="text" class="regular-text" value="<?php echo esc_url($this->custom_register_url); ?>" readonly>
                            <p class="description">Users will be redirected to this URL for registration.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    // Applications page
    public function applications_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'career_applications';
        $applications = $wpdb->get_results("SELECT * FROM $table_name ORDER BY applied_date DESC");
        ?>
        <div class="wrap">
            <h1>Job Applications</h1>
            
            <?php if (empty($applications)): ?>
            <p>No applications found.</p>
            <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Applicant</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Job ID</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>CV</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $app): ?>
                    <tr>
                        <td><?php echo $app->id; ?></td>
                        <td><?php echo esc_html($app->applicant_name); ?></td>
                        <td><?php echo esc_html($app->applicant_email); ?></td>
                        <td><?php echo esc_html($app->applicant_phone); ?></td>
                        <td><?php echo $app->job_id; ?></td>
                        <td>
                            <select class="application-status" data-id="<?php echo $app->id; ?>">
                                <option value="pending" <?php selected($app->status, 'pending'); ?>>Pending</option>
                                <option value="reviewed" <?php selected($app->status, 'reviewed'); ?>>Reviewed</option>
                                <option value="shortlisted" <?php selected($app->status, 'shortlisted'); ?>>Shortlisted</option>
                                <option value="rejected" <?php selected($app->status, 'rejected'); ?>>Rejected</option>
                                <option value="hired" <?php selected($app->status, 'hired'); ?>>Hired</option>
                            </select>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($app->applied_date)); ?></td>
                        <td>
                            <?php 
                            $upload_dir = wp_upload_dir();
                            $cv_url = $upload_dir['baseurl'] . '/career-applications/' . $app->cv_file;
                            ?>
                            <a href="<?php echo esc_url($cv_url); ?>" target="_blank">View CV</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <script>
            jQuery(document).ready(function($) {
                $('.application-status').on('change', function() {
                    var appId = $(this).data('id');
                    var status = $(this).val();
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'update_application_status',
                            app_id: appId,
                            status: status,
                            nonce: '<?php echo wp_create_nonce("update_application_status"); ?>'
                        }
                    });
                });
            });
            </script>
            <?php endif; ?>
        </div>
        <?php
    }

    // Register settings
    public function register_settings() {
        register_setting('careers_section_group', 'careers_jobs');
        register_setting('careers_settings_group', 'careers_settings');
    }

    // Admin page
    public function admin_page() {
        $jobs = get_option('careers_jobs', []); ?>
        <div class="wrap">
            <h1>Careers Section</h1>
            <p>Add job positions below. Each job will automatically get an Apply Now button that links to the application form.</p>
            
            <div class="notice notice-info">
                <p><strong>Application Page:</strong> <a href="<?php echo home_url('/apply-now/'); ?>" target="_blank"><?php echo home_url('/apply-now/'); ?></a></p>
                <p><strong>Login Page:</strong> <a href="<?php echo $this->custom_login_url; ?>" target="_blank"><?php echo $this->custom_login_url; ?></a></p>
                <p><strong>Shortcodes:</strong> Use <code>[careers_section]</code> to display jobs and <code>[application_form]</code> for the application form.</p>
            </div>
            
            <form method="post" action="options.php">
                <?php settings_fields('careers_section_group'); ?>
                <table class="form-table" id="jobs-table">
                    <thead>
                        <tr>
                            <th>Job ID</th>
                            <th>Title</th>
                            <th>Location</th>
                            <th>Department</th>
                            <th>Description</th>
                            <th>Logo URL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $job_counter = 1;
                        foreach($jobs as $i => $job): 
                            $job_id = isset($job['id']) ? $job['id'] : $job_counter;
                        ?>
                        <tr>
                            <td>
                                <input type="hidden" name="careers_jobs[<?php echo $i; ?>][id]" value="<?php echo esc_attr($job_id); ?>">
                                <strong>#<?php echo $job_id; ?></strong>
                            </td>
                            <td><input type="text" name="careers_jobs[<?php echo $i; ?>][title]" value="<?php echo esc_attr($job['title']); ?>" class="regular-text"></td>
                            <td><input type="text" name="careers_jobs[<?php echo $i; ?>][location]" value="<?php echo esc_attr($job['location']); ?>" class="regular-text"></td>
                            <td><input type="text" name="careers_jobs[<?php echo $i; ?>][department]" value="<?php echo esc_attr($job['department']); ?>" class="regular-text"></td>
                            <td><textarea name="careers_jobs[<?php echo $i; ?>][description]" rows="3" class="large-text"><?php echo esc_textarea($job['description']); ?></textarea></td>
                            <td><input type="text" name="careers_jobs[<?php echo $i; ?>][logo]" value="<?php echo esc_url($job['logo'] ?? ''); ?>" class="regular-text"></td>
                        </tr>
                        <?php 
                        $job_counter++;
                        endforeach; ?>
                    </tbody>
                </table>
                <button type="button" class="button" id="add-job">Add New Job</button>
                <?php submit_button(); ?>
            </form>
        </div>
        <script>
        jQuery(document).ready(function($){
            var index = <?php echo count($jobs); ?>;
            var jobCounter = <?php echo $job_counter; ?>;
            
            $('#add-job').click(function(){
                $('#jobs-table tbody').append('<tr>'+
                    '<td><input type="hidden" name="careers_jobs['+index+'][id]" value="'+jobCounter+'">'+
                    '<strong>#'+jobCounter+'</strong></td>'+
                    '<td><input type="text" name="careers_jobs['+index+'][title]" class="regular-text" /></td>'+
                    '<td><input type="text" name="careers_jobs['+index+'][location]" class="regular-text" /></td>'+
                    '<td><input type="text" name="careers_jobs['+index+'][department]" class="regular-text" /></td>'+
                    '<td><textarea name="careers_jobs['+index+'][description]" rows="3" class="large-text"></textarea></td>'+
                    '<td><input type="text" name="careers_jobs['+index+'][logo]" class="regular-text" /></td>'+
                '</tr>');
                index++;
                jobCounter++;
            });
        });
        </script>
        <?php
    }
}

new CareersSectionOptimized();

// Add status update AJAX handler
add_action('wp_ajax_update_application_status', function() {
    check_ajax_referer('update_application_status', 'nonce');
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'career_applications';
    
    $wpdb->update(
        $table_name,
        ['status' => sanitize_text_field($_POST['status'])],
        ['id' => intval($_POST['app_id'])]
    );
    
    wp_die();
});