// careers-plugin/assets/js/frontend.js

jQuery(document).ready(function($) {
    
    // Debug log
    console.log('Careers Plugin JS loaded');
    console.log('AJAX URL:', careers_ajax.ajax_url);
    
    // Application form submission
    $('#careers-application-form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var submitBtn = form.find('.submit-application-btn');
        var responseDiv = $('#application-response');
        
        // Show loading
        submitBtn.prop('disabled', true).html('<span class="careers-loading"></span> Submitting...');
        responseDiv.removeClass().html('');
        
        // Validate required fields
        var isValid = true;
        $('input[required], textarea[required]', form).each(function() {
            if (!$(this).val().trim()) {
                $(this).addClass('error');
                isValid = false;
            } else {
                $(this).removeClass('error');
            }
        });
        
        if (!isValid) {
            responseDiv.html('<div class="careers-alert careers-alert-error">Please fill in all required fields.</div>');
            submitBtn.prop('disabled', false).text('Submit Application');
            return;
        }
        
        // Validate file
        var fileInput = $('#cv_file')[0];
        if (fileInput.files.length === 0) {
            responseDiv.html('<div class="careers-alert careers-alert-error">Please upload your CV.</div>');
            submitBtn.prop('disabled', false).text('Submit Application');
            return;
        }
        
        // Prepare form data
        var formData = new FormData(form[0]);
        
        // Add nonce if not already in form
        if (!formData.has('security')) {
            formData.append('security', careers_ajax.nonce);
        }
        
        // AJAX request
        $.ajax({
            url: careers_ajax.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json'
        })
        .done(function(response) {
            console.log('Response:', response);
            
            if (response.success) {
                // Success
                responseDiv.html(
                    '<div class="careers-alert careers-alert-success">' +
                    '<strong>Success!</strong> ' + response.data.message +
                    '</div>'
                );
                
                // Reset form
                form[0].reset();
                
                // Optionally redirect or hide form
                setTimeout(function() {
                    // form.slideUp();
                }, 3000);
                
            } else {
                // Error
                var errorHtml = '<div class="careers-alert careers-alert-error"><ul>';
                $.each(response.data.errors, function(index, error) {
                    errorHtml += '<li>' + error + '</li>';
                });
                errorHtml += '</ul></div>';
                
                responseDiv.html(errorHtml);
            }
        })
        .fail(function(xhr, status, error) {
            console.error('AJAX Error:', error);
            responseDiv.html(
                '<div class="careers-alert careers-alert-error">' +
                'An error occurred. Please try again.' +
                '</div>'
            );
        })
        .always(function() {
            submitBtn.prop('disabled', false).text('Submit Application');
        });
    });
    
    // File validation
    $('#cv_file').on('change', function() {
        var file = this.files[0];
        if (!file) return;
        
        var allowedTypes = ['pdf', 'doc', 'docx'];
        var fileExt = file.name.split('.').pop().toLowerCase();
        var maxSize = 5 * 1024 * 1024; // 5MB
        
        $(this).removeClass('error');
        $('.file-error').remove();
        
        if ($.inArray(fileExt, allowedTypes) === -1) {
            $(this).addClass('error');
            $(this).after('<small class="file-error" style="color:#ff3860;">Invalid file type. Use PDF, DOC, or DOCX.</small>');
            $(this).val('');
        } else if (file.size > maxSize) {
            $(this).addClass('error');
            $(this).after('<small class="file-error" style="color:#ff3860;">File too large. Max 5MB.</small>');
            $(this).val('');
        }
    });
    
    // Remove error class on input
    $('input, textarea').on('input', function() {
        $(this).removeClass('error');
    });
    
    // Job card animations
    $('.job-card').hover(
        function() {
            $(this).css('transform', 'translateY(-5px)');
        },
        function() {
            $(this).css('transform', 'translateY(0)');
        }
    );
});