<div class="careers-container">
    <?php if ($atts['show_filters'] === 'yes'): ?>
    <div class="careers-filters">
        <!-- Filter form here -->
    </div>
    <?php endif; ?>
    
    <div class="jobs-grid">
        <?php if ($jobs_query->have_posts()): ?>
            <?php while ($jobs_query->have_posts()): $jobs_query->the_post(); ?>
            <div class="job-card">
                <h3><?php the_title(); ?></h3>
                <div class="job-meta">
                    <?php
                    $terms = get_the_terms(get_the_ID(), 'job_location');
                    if ($terms): ?>
                        <span class="job-location">
                            📍 <?php echo esc_html($terms[0]->name); ?>
                        </span>
                    <?php endif; ?>
                    
                    <?php
                    $terms = get_the_terms(get_the_ID(), 'job_type');
                    if ($terms): ?>
                        <span class="job-type">
                            ⏱ <?php echo esc_html($terms[0]->name); ?>
                        </span>
                    <?php endif; ?>
                </div>
                
                <div class="job-excerpt">
                    <?php echo wp_trim_words(get_the_excerpt(), 30); ?>
                </div>
                
                <div class="job-details">
                    <?php
                    $salary = get_post_meta(get_the_ID(), '_job_salary', true);
                    if ($salary): ?>
                        <p><strong>Salary:</strong> <?php echo esc_html($salary); ?></p>
                    <?php endif; ?>
                    
                    <?php
                    $experience = get_post_meta(get_the_ID(), '_job_experience', true);
                    if ($experience): ?>
                        <p><strong>Experience:</strong> <?php echo esc_html($experience); ?></p>
                    <?php endif; ?>
                </div>
                
                <div class="job-actions">
                    <a href="<?php the_permalink(); ?>" class="view-job-btn">
                        View Details
                    </a>
                    <?php if (is_user_logged_in()): ?>
                        <a href="<?php echo add_query_arg('apply', '1', get_permalink()); ?>" 
                           class="apply-job-btn">
                            Apply Now
                        </a>
                    <?php else: ?>
                        <a href="<?php echo wp_login_url(get_permalink()); ?>" 
                           class="apply-job-btn">
                            Login to Apply
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No job openings at the moment.</p>
        <?php endif; ?>
    </div>
</div>