<div class="login-prompt">
    <h3>Apply for This Position</h3>
    <p>You need to be logged in to apply for this job.</p>
    
    <div class="auth-buttons">
        <a href="<?php echo $redirect_url; ?>" class="btn-login">
            Login
        </a>
        
        <?php if (get_option('users_can_register')): ?>
        <a href="<?php echo $register_url; ?>" class="btn-register">
            Register
        </a>
        <?php endif; ?>
    </div>
    
    <p class="register-note">
        Don't have an account? Registration is quick and easy!
    </p>
</div>