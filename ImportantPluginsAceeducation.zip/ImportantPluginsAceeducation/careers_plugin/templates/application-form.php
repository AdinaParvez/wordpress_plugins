<div class="application-form-container">
    <h3>Apply for: <?php echo get_the_title($job_id); ?></h3>
    
    <form id="careers-application-form" enctype="multipart/form-data">
        <input type="hidden" name="job_id" value="<?php echo $job_id; ?>">
        <?php wp_nonce_field('careers_apply_nonce', 'security'); ?>
        
        <div class="form-group">
            <label for="name">Full Name *</label>
            <input type="text" id="name" name="name" required 
                   value="<?php echo esc_attr(wp_get_current_user()->display_name); ?>">
        </div>
        
        <div class="form-group">
            <label for="email">Email Address *</label>
            <input type="email" id="email" name="email" required 
                   value="<?php echo esc_attr(wp_get_current_user()->user_email); ?>">
        </div>
        
        <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" name="phone">
        </div>
        
        <div class="form-group">
            <label for="experience">Previous Experience *</label>
            <textarea id="experience" name="experience" rows="5" required 
                      placeholder="Describe your relevant work experience..."></textarea>
        </div>
        
        <div class="form-group">
            <label for="cover_letter">Cover Letter</label>
            <textarea id="cover_letter" name="cover_letter" rows="5" 
                      placeholder="Why are you interested in this position?"></textarea>
        </div>
        
        <div class="form-group">
            <label for="cv_file">Upload CV (PDF, DOC, DOCX) *</label>
            <input type="file" id="cv_file" name="cv_file" accept=".pdf,.doc,.docx" required>
            <small>Maximum file size: 5MB</small>
        </div>
        
        <div class="form-group">
            <button type="submit" class="submit-application-btn">
                Submit Application
            </button>
        </div>
        
        <div id="application-response"></div>
    </form>
</div>