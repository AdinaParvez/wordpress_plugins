<?php
class Careers_Database {
    
    public static function init() {
        // Add hooks if needed
    }
    
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        $table_name = $wpdb->prefix . 'career_applications';
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id INT(11) NOT NULL AUTO_INCREMENT,
            job_id INT(11) NOT NULL,
            user_id INT(11),
            applicant_name VARCHAR(255) NOT NULL,
            applicant_email VARCHAR(255) NOT NULL,
            applicant_phone VARCHAR(50),
            experience TEXT,
            cv_file VARCHAR(255),
            cover_letter TEXT,
            status VARCHAR(50) DEFAULT 'pending',
            applied_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            ip_address VARCHAR(45),
            PRIMARY KEY (id),
            INDEX job_id_index (job_id),
            INDEX user_id_index (user_id),
            INDEX email_index (applicant_email),
            INDEX status_index (status)
        ) $charset_collate;";
        
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }
}