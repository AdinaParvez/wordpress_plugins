<?php
class Careers_Post_Type {
    
    public static function init() {
        add_action('init', array(__CLASS__, 'register_post_type'));
        add_action('add_meta_boxes', array(__CLASS__, 'add_meta_boxes'));
        add_action('save_post', array(__CLASS__, 'save_meta_boxes'));
    }
    
    public static function register_post_type() {
        $labels = array(
            'name'               => __('Jobs', 'careers-plugin'),
            'singular_name'      => __('Job', 'careers-plugin'),
            'menu_name'          => __('Careers', 'careers-plugin'),
            'name_admin_bar'     => __('Job', 'careers-plugin'),
            'add_new'            => __('Add New Job', 'careers-plugin'),
            'add_new_item'       => __('Add New Job', 'careers-plugin'),
            'new_item'           => __('New Job', 'careers-plugin'),
            'edit_item'          => __('Edit Job', 'careers-plugin'),
            'view_item'          => __('View Job', 'careers-plugin'),
            'all_items'          => __('All Jobs', 'careers-plugin'),
            'search_items'       => __('Search Jobs', 'careers-plugin'),
            'not_found'          => __('No jobs found.', 'careers-plugin'),
            'not_found_in_trash' => __('No jobs found in Trash.', 'careers-plugin')
        );
        
        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => 'careers'),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 30,
            'menu_icon'          => 'dashicons-businessman',
            'supports'           => array('title', 'editor', 'thumbnail'),
            'taxonomies'         => array('job_category', 'job_location', 'job_type')
        );
        
        register_post_type('job', $args);
        
        // Register taxonomies
        self::register_taxonomies();
    }
    
    private static function register_taxonomies() {
        // Job Category
        register_taxonomy('job_category', 'job', array(
            'labels' => array(
                'name' => __('Categories', 'careers-plugin'),
                'singular_name' => __('Category', 'careers-plugin')
            ),
            'hierarchical' => true,
            'show_admin_column' => true,
            'rewrite' => array('slug' => 'job-category')
        ));
        
        // Job Location
        register_taxonomy('job_location', 'job', array(
            'labels' => array(
                'name' => __('Locations', 'careers-plugin'),
                'singular_name' => __('Location', 'careers-plugin')
            ),
            'hierarchical' => true,
            'show_admin_column' => true,
            'rewrite' => array('slug' => 'job-location')
        ));
        
        // Job Type
        register_taxonomy('job_type', 'job', array(
            'labels' => array(
                'name' => __('Job Types', 'careers-plugin'),
                'singular_name' => __('Job Type', 'careers-plugin')
            ),
            'hierarchical' => true,
            'show_admin_column' => true,
            'rewrite' => array('slug' => 'job-type')
        ));
    }
    
    public static function add_meta_boxes() {
        add_meta_box(
            'job_details',
            __('Job Details', 'careers-plugin'),
            array(__CLASS__, 'render_meta_box'),
            'job',
            'side',
            'high'
        );
        
        add_meta_box(
            'applications',
            __('Applications', 'careers-plugin'),
            array(__CLASS__, 'render_applications_box'),
            'job',
            'normal',
            'high'
        );
    }
    
    public static function render_meta_box($post) {
        wp_nonce_field('save_job_details', 'job_details_nonce');
        
        $salary = get_post_meta($post->ID, '_job_salary', true);
        $deadline = get_post_meta($post->ID, '_job_deadline', true);
        $experience = get_post_meta($post->ID, '_job_experience', true);
        ?>
        <p>
            <label for="job_salary"><?php _e('Salary:', 'careers-plugin'); ?></label>
            <input type="text" id="job_salary" name="job_salary" 
                   value="<?php echo esc_attr($salary); ?>" 
                   class="widefat">
        </p>
        <p>
            <label for="job_deadline"><?php _e('Application Deadline:', 'careers-plugin'); ?></label>
            <input type="date" id="job_deadline" name="job_deadline" 
                   value="<?php echo esc_attr($deadline); ?>" 
                   class="widefat">
        </p>
        <p>
            <label for="job_experience"><?php _e('Required Experience:', 'careers-plugin'); ?></label>
            <input type="text" id="job_experience" name="job_experience" 
                   value="<?php echo esc_attr($experience); ?>" 
                   class="widefat" 
                   placeholder="e.g., 2-3 years">
        </p>
        <?php
    }
    
    public static function render_applications_box($post) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'career_applications';
        
        $applications = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE job_id = %d ORDER BY applied_date DESC",
            $post->ID
        ));
        
        if (empty($applications)) {
            echo '<p>' . __('No applications yet.', 'careers-plugin') . '</p>';
            return;
        }
        ?>
        <table class="widefat fixed" cellspacing="0">
            <thead>
                <tr>
                    <th><?php _e('Name', 'careers-plugin'); ?></th>
                    <th><?php _e('Email', 'careers-plugin'); ?></th>
                    <th><?php _e('Phone', 'careers-plugin'); ?></th>
                    <th><?php _e('Experience', 'careers-plugin'); ?></th>
                    <th><?php _e('CV', 'careers-plugin'); ?></th>
                    <th><?php _e('Status', 'careers-plugin'); ?></th>
                    <th><?php _e('Date', 'careers-plugin'); ?></th>
                    <th><?php _e('Actions', 'careers-plugin'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($applications as $application): ?>
                <tr>
                    <td><?php echo esc_html($application->applicant_name); ?></td>
                    <td><?php echo esc_html($application->applicant_email); ?></td>
                    <td><?php echo esc_html($application->applicant_phone); ?></td>
                    <td><?php echo esc_html(wp_trim_words($application->experience, 10)); ?></td>
                    <td>
                        <?php if ($application->cv_file): ?>
                            <a href="<?php echo esc_url(CAREERS_UPLOAD_URL . $application->cv_file); ?>" 
                               target="_blank"><?php _e('View CV', 'careers-plugin'); ?></a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <select name="application_status[<?php echo $application->id; ?>]" 
                                class="application-status">
                            <option value="pending" <?php selected($application->status, 'pending'); ?>>
                                <?php _e('Pending', 'careers-plugin'); ?>
                            </option>
                            <option value="reviewed" <?php selected($application->status, 'reviewed'); ?>>
                                <?php _e('Reviewed', 'careers-plugin'); ?>
                            </option>
                            <option value="shortlisted" <?php selected($application->status, 'shortlisted'); ?>>
                                <?php _e('Shortlisted', 'careers-plugin'); ?>
                            </option>
                            <option value="rejected" <?php selected($application->status, 'rejected'); ?>>
                                <?php _e('Rejected', 'careers-plugin'); ?>
                            </option>
                            <option value="hired" <?php selected($application->status, 'hired'); ?>>
                                <?php _e('Hired', 'careers-plugin'); ?>
                            </option>
                        </select>
                    </td>
                    <td><?php echo date_i18n(get_option('date_format'), strtotime($application->applied_date)); ?></td>
                    <td>
                        <a href="#" class="button view-application" 
                           data-id="<?php echo $application->id; ?>">
                            <?php _e('View Details', 'careers-plugin'); ?>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }
    
    public static function save_meta_boxes($post_id) {
        if (!isset($_POST['job_details_nonce']) || 
            !wp_verify_nonce($_POST['job_details_nonce'], 'save_job_details')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save job details
        $fields = array('salary', 'deadline', 'experience');
        foreach ($fields as $field) {
            if (isset($_POST['job_' . $field])) {
                update_post_meta($post_id, '_job_' . $field, sanitize_text_field($_POST['job_' . $field]));
            }
        }
        
        // Update application statuses
        if (isset($_POST['application_status'])) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'career_applications';
            
            foreach ($_POST['application_status'] as $app_id => $status) {
                $wpdb->update(
                    $table_name,
                    array('status' => sanitize_text_field($status)),
                    array('id' => intval($app_id)),
                    array('%s'),
                    array('%d')
                );
            }
        }
    }
}