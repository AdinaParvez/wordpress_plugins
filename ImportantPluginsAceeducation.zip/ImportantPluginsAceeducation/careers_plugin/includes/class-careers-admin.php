<?php
class Careers_Admin {
    
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_admin_scripts'));
        add_action('wp_dashboard_setup', array(__CLASS__, 'add_dashboard_widget'));
    }
    
    public static function add_admin_menu() {
        add_submenu_page(
            'edit.php?post_type=job',
            __('Applications', 'careers-plugin'),
            __('All Applications', 'careers-plugin'),
            'manage_options',
            'careers-applications',
            array(__CLASS__, 'render_applications_page')
        );
        
        add_submenu_page(
            'edit.php?post_type=job',
            __('Settings', 'careers-plugin'),
            __('Settings', 'careers-plugin'),
            'manage_options',
            'careers-settings',
            array(__CLASS__, 'render_settings_page')
        );
    }
    
    public static function render_applications_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'career_applications';
        
        // Handle bulk actions
        if (isset($_POST['bulk_action']) && isset($_POST['applications'])) {
            $action = sanitize_text_field($_POST['bulk_action']);
            $applications = array_map('intval', $_POST['applications']);
            
            if ($action === 'delete') {
                foreach ($applications as $app_id) {
                    $wpdb->delete($table_name, array('id' => $app_id), array('%d'));
                }
                echo '<div class="updated"><p>' . __('Selected applications deleted.', 'careers-plugin') . '</p></div>';
            } elseif (in_array($action, array('pending', 'reviewed', 'shortlisted', 'rejected', 'hired'))) {
                foreach ($applications as $app_id) {
                    $wpdb->update(
                        $table_name,
                        array('status' => $action),
                        array('id' => $app_id),
                        array('%s'),
                        array('%d')
                    );
                }
                echo '<div class="updated"><p>' . __('Status updated.', 'careers-plugin') . '</p></div>';
            }
        }
        
        // Get applications
        $applications = $wpdb->get_results("SELECT * FROM $table_name ORDER BY applied_date DESC");
        
        include CAREERS_PLUGIN_DIR . 'templates/admin/applications.php';
    }
    
    public static function render_settings_page() {
        if (isset($_POST['save_settings'])) {
            update_option('careers_notification_email', sanitize_email($_POST['notification_email']));
            update_option('careers_require_login', isset($_POST['require_login']) ? 1 : 0);
            update_option('careers_allowed_file_types', sanitize_text_field($_POST['allowed_file_types']));
            update_option('careers_max_file_size', intval($_POST['max_file_size']));
            
            echo '<div class="updated"><p>' . __('Settings saved.', 'careers-plugin') . '</p></div>';
        }
        
        include CAREERS_PLUGIN_DIR . 'templates/admin/settings.php';
    }
    
    public static function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'careers') !== false || $hook === 'edit.php') {
            wp_enqueue_style('careers-admin', 
                CAREERS_PLUGIN_URL . 'assets/css/admin.css', 
                array(), 
                '1.0.0'
            );
            
            wp_enqueue_script('careers-admin', 
                CAREERS_PLUGIN_URL . 'assets/js/admin.js', 
                array('jquery'), 
                '1.0.0', 
                true
            );
        }
    }
    
    public static function add_dashboard_widget() {
        wp_add_dashboard_widget(
            'careers_dashboard_widget',
            __('Recent Job Applications', 'careers-plugin'),
            array(__CLASS__, 'render_dashboard_widget')
        );
    }
    
    public static function render_dashboard_widget() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'career_applications';
        
        $recent_applications = $wpdb->get_results(
            "SELECT * FROM $table_name ORDER BY applied_date DESC LIMIT 5"
        );
        
        $total_applications = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        $pending_applications = $wpdb->get_var(
            "SELECT COUNT(*) FROM $table_name WHERE status = 'pending'"
        );
        
        echo '<div class="careers-dashboard-stats">';
        echo '<p><strong>' . __('Total Applications:', 'careers-plugin') . '</strong> ' . $total_applications . '</p>';
        echo '<p><strong>' . __('Pending Review:', 'careers-plugin') . '</strong> ' . $pending_applications . '</p>';
        echo '</div>';
        
        if ($recent_applications) {
            echo '<table class="widefat">';
            echo '<thead><tr><th>' . __('Applicant', 'careers-plugin') . '</th><th>' . __('Job', 'careers-plugin') . '</th><th>' . __('Date', 'careers-plugin') . '</th></tr></thead>';
            echo '<tbody>';
            foreach ($recent_applications as $app) {
                echo '<tr>';
                echo '<td>' . esc_html($app->applicant_name) . '</td>';
                echo '<td>' . get_the_title($app->job_id) . '</td>';
                echo '<td>' . date_i18n('M j', strtotime($app->applied_date)) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        }
    }
}