<?php
class Careers_Apply {
    
    public static function init() {
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_scripts'));
        add_filter('the_content', array(__CLASS__, 'add_apply_button'));
    }
    
    public static function enqueue_scripts() {
        global $post;
        
        // Check if we should load careers scripts
        $load_scripts = false;
        
        // Check post type
        if (is_singular('job')) {
            $load_scripts = true;
        }
        
        // Check for shortcodes
        if (is_a($post, 'WP_Post')) {
            $post_content = $post->post_content;
            if (has_shortcode($post_content, 'display_careers') || 
                has_shortcode($post_content, 'apply_form') || 
                has_shortcode($post_content, 'my_applications')) {
                $load_scripts = true;
            }
        }
        
        // Check if we're on careers archive
        if (is_post_type_archive('job') || is_tax('job_category') || is_tax('job_location') || is_tax('job_type')) {
            $load_scripts = true;
        }
        
        if ($load_scripts) {
            // Enqueue CSS
            $css_path = CAREERS_PLUGIN_DIR . 'assets/css/frontend.css';
            if (file_exists($css_path)) {
                wp_enqueue_style('careers-frontend', 
                    CAREERS_CSS_URL . 'frontend.css',
                    array(),
                    filemtime($css_path)
                );
            } else {
                // Fallback inline styles if CSS file is missing
                self::add_inline_fallback_styles();
            }
            
            // Enqueue JavaScript
            $js_path = CAREERS_PLUGIN_DIR . 'assets/js/frontend.js';
            if (file_exists($js_path)) {
                wp_enqueue_script('careers-frontend', 
                    CAREERS_JS_URL . 'frontend.js',
                    array('jquery'),
                    filemtime($js_path),
                    true
                );
                
                // Localize script
                self::localize_script();
            }
        }
    }
    
    private static function add_inline_fallback_styles() {
        $fallback_css = '
        /* Careers Plugin Fallback Styles */
        .careers-container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .jobs-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; margin-top: 30px; }
        .job-card { background: white; border: 1px solid #e0e0e0; border-radius: 8px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .job-card h3 { margin-top: 0; color: #333; }
        .job-meta { display: flex; gap: 10px; margin: 10px 0; color: #666; font-size: 0.9em; }
        .job-excerpt { color: #555; line-height: 1.6; margin: 15px 0; }
        .job-details { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .job-actions { display: flex; gap: 10px; margin-top: 20px; }
        .view-job-btn, .apply-job-btn { padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: 500; }
        .view-job-btn { background: #f8f9fa; color: #333; border: 1px solid #ddd; }
        .apply-job-btn { background: #0073aa; color: white; border: 1px solid #006391; }
        .apply-job-btn:hover { background: #006391; }
        .application-form-container { max-width: 600px; margin: 40px auto; padding: 30px; background: white; border-radius: 8px; box-shadow: 0 2px 20px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; color: #333; }
        .form-group input, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }
        .submit-application-btn { background: #27ae60; color: white; border: none; padding: 12px 30px; font-size: 16px; border-radius: 5px; cursor: pointer; }
        .submit-application-btn:hover { background: #219653; }
        @media (max-width: 768px) { .jobs-grid { grid-template-columns: 1fr; } .job-actions { flex-direction: column; } }
        ';
        
        wp_add_inline_style('careers-basic', $fallback_css);
    }
    
    private static function localize_script() {
        wp_localize_script('careers-frontend', 'careers_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('careers_apply_nonce'),
            'current_user_id' => get_current_user_id(),
            'is_user_logged_in' => is_user_logged_in(),
            'site_url' => site_url(),
            'login_url' => wp_login_url(),
            'register_url' => wp_registration_url(),
            'plugin_url' => CAREERS_PLUGIN_URL
        ));
    }
    
    public static function add_apply_button($content) {
        if (is_singular('job') && in_the_loop() && is_main_query()) {
            $apply_button = '[apply_form job_id="' . get_the_ID() . '"]';
            $content .= do_shortcode($apply_button);
        }
        return $content;
    }
}