<?php
class Careers_Shortcodes {
    
    public static function init() {
        add_shortcode('display_careers', array(__CLASS__, 'display_careers'));
        add_shortcode('apply_form', array(__CLASS__, 'apply_form'));
        add_shortcode('my_applications', array(__CLASS__, 'my_applications'));
        
        // AJAX handlers
        add_action('wp_ajax_submit_application', array(__CLASS__, 'submit_application'));
        add_action('wp_ajax_nopriv_submit_application', array(__CLASS__, 'submit_application'));
    }
    
    public static function display_careers($atts) {
        $atts = shortcode_atts(array(
            'category' => '',
            'location' => '',
            'type' => '',
            'posts_per_page' => 10,
            'show_filters' => 'yes'
        ), $atts);
        
        ob_start();
        
        // Query jobs
        $args = array(
            'post_type' => 'job',
            'post_status' => 'publish',
            'posts_per_page' => intval($atts['posts_per_page']),
            'orderby' => 'date',
            'order' => 'DESC'
        );
        
        // Add tax queries if needed
        $tax_queries = array();
        if (!empty($atts['category'])) {
            $tax_queries[] = array(
                'taxonomy' => 'job_category',
                'field' => 'slug',
                'terms' => $atts['category']
            );
        }
        
        if (!empty($atts['location'])) {
            $tax_queries[] = array(
                'taxonomy' => 'job_location',
                'field' => 'slug',
                'terms' => $atts['location']
            );
        }
        
        if (!empty($atts['type'])) {
            $tax_queries[] = array(
                'taxonomy' => 'job_type',
                'field' => 'slug',
                'terms' => $atts['type']
            );
        }
        
        if (!empty($tax_queries)) {
            $args['tax_query'] = $tax_queries;
        }
        
        $jobs_query = new WP_Query($args);
        
        // Load template
        include CAREERS_PLUGIN_DIR . 'templates/jobs-listing.php';
        
        wp_reset_postdata();
        return ob_get_clean();
    }
    
    public static function apply_form($atts) {
        if (!is_user_logged_in()) {
            // Redirect to login/register page
            $redirect_url = add_query_arg('redirect_to', urlencode(get_permalink()), wp_login_url());
            $register_url = add_query_arg('redirect_to', urlencode(get_permalink()), wp_registration_url());
            
            ob_start();
            include CAREERS_PLUGIN_DIR . 'templates/login-prompt.php';
            return ob_get_clean();
        }
        
        $atts = shortcode_atts(array(
            'job_id' => get_the_ID()
        ), $atts);
        
        $job_id = intval($atts['job_id']);
        
        // Check if already applied
        if (self::has_applied(get_current_user_id(), $job_id)) {
            return '<div class="careers-alert careers-alert-info">' . 
                   __('You have already applied for this position.', 'careers-plugin') . 
                   '</div>';
        }
        
        ob_start();
        include CAREERS_PLUGIN_DIR . 'templates/application-form.php';
        return ob_get_clean();
    }
    
    public static function my_applications() {
        if (!is_user_logged_in()) {
            return '<p>' . __('Please login to view your applications.', 'careers-plugin') . '</p>';
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'career_applications';
        $user_id = get_current_user_id();
        
        $applications = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_id = %d ORDER BY applied_date DESC",
            $user_id
        ));
        
        ob_start();
        include CAREERS_PLUGIN_DIR . 'templates/my-applications.php';
        return ob_get_clean();
    }
    
    public static function submit_application() {
        check_ajax_referer('careers_apply_nonce', 'security');
        
        // Validate fields
        $errors = array();
        $required = array('name', 'email', 'job_id');
        
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                $errors[] = sprintf(__('%s is required.', 'careers-plugin'), ucfirst($field));
            }
        }
        
        // Validate email
        if (!empty($_POST['email']) && !is_email($_POST['email'])) {
            $errors[] = __('Invalid email address.', 'careers-plugin');
        }
        
        // Validate file upload
        if (!empty($_FILES['cv_file']['name'])) {
            $allowed_types = array('pdf', 'doc', 'docx');
            $file_ext = strtolower(pathinfo($_FILES['cv_file']['name'], PATHINFO_EXTENSION));
            
            if (!in_array($file_ext, $allowed_types)) {
                $errors[] = __('Only PDF, DOC, and DOCX files are allowed.', 'careers-plugin');
            }
            
            if ($_FILES['cv_file']['size'] > 5 * 1024 * 1024) { // 5MB limit
                $errors[] = __('File size must be less than 5MB.', 'careers-plugin');
            }
        }
        
        if (!empty($errors)) {
            wp_send_json_error(array('errors' => $errors));
        }
        
        // Process file upload
        $cv_filename = '';
        if (!empty($_FILES['cv_file']['name'])) {
            $cv_filename = self::upload_cv_file($_FILES['cv_file']);
            if (is_wp_error($cv_filename)) {
                wp_send_json_error(array('errors' => array($cv_filename->get_error_message())));
            }
        }
        
        // Save application
        global $wpdb;
        $table_name = $wpdb->prefix . 'career_applications';
        
        $data = array(
            'job_id' => intval($_POST['job_id']),
            'user_id' => get_current_user_id() ?: 0,
            'applicant_name' => sanitize_text_field($_POST['name']),
            'applicant_email' => sanitize_email($_POST['email']),
            'applicant_phone' => sanitize_text_field($_POST['phone']),
            'experience' => wp_kses_post($_POST['experience']),
            'cover_letter' => wp_kses_post($_POST['cover_letter']),
            'cv_file' => $cv_filename,
            'ip_address' => $_SERVER['REMOTE_ADDR'],
            'applied_date' => current_time('mysql')
        );
        
        $result = $wpdb->insert($table_name, $data);
        
        if ($result) {
            // Send notification emails
            self::send_notification_emails($data);
            
            wp_send_json_success(array(
                'message' => __('Application submitted successfully!', 'careers-plugin')
            ));
        } else {
            wp_send_json_error(array(
                'errors' => array(__('Failed to submit application. Please try again.', 'careers-plugin'))
            ));
        }
    }
    
    private static function upload_cv_file($file) {
        $file_name = uniqid() . '_' . sanitize_file_name($file['name']);
        $upload_file = CAREERS_UPLOAD_DIR . $file_name;
        
        if (move_uploaded_file($file['tmp_name'], $upload_file)) {
            return $file_name;
        }
        
        return new WP_Error('upload_failed', __('File upload failed.', 'careers-plugin'));
    }
    
    private static function send_notification_emails($data) {
        // Send to admin
        $admin_email = get_option('admin_email');
        $subject = sprintf(__('New Job Application: %s', 'careers-plugin'), get_the_title($data['job_id']));
        
        $message = sprintf(__('A new application has been submitted for: %s', 'careers-plugin'), get_the_title($data['job_id'])) . "\n\n";
        $message .= sprintf(__('Applicant: %s', 'careers-plugin'), $data['applicant_name']) . "\n";
        $message .= sprintf(__('Email: %s', 'careers-plugin'), $data['applicant_email']) . "\n";
        $message .= sprintf(__('Phone: %s', 'careers-plugin'), $data['applicant_phone']) . "\n";
        $message .= __('View application in admin panel.', 'careers-plugin') . "\n";
        
        wp_mail($admin_email, $subject, $message);
        
        // Send confirmation to applicant
        $applicant_subject = __('Application Received', 'careers-plugin');
        $applicant_message = sprintf(__('Dear %s,', 'careers-plugin'), $data['applicant_name']) . "\n\n";
        $applicant_message .= __('Thank you for applying to our position. We have received your application and will review it shortly.', 'careers-plugin') . "\n\n";
        $applicant_message .= __('Best regards,', 'careers-plugin') . "\n";
        $applicant_message .= get_bloginfo('name');
        
        wp_mail($data['applicant_email'], $applicant_subject, $applicant_message);
    }
    
    private static function has_applied($user_id, $job_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'career_applications';
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE user_id = %d AND job_id = %d",
            $user_id, $job_id
        ));
        
        return $count > 0;
    }
}