<?php
/**
 * Plugin Name: Careers Management System
 * Plugin URI: https://adinapervaiz.weebly.com
 * Description: Complete career/job management system with applications, user registration, and file uploads
 * Version: 2.0
 * Author: Adina Pervaiz
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants with CORRECT PATHS
define('CAREERS_PLUGIN_VERSION', '2.0');
define('CAREERS_PLUGIN_DIR', plugin_dir_path(__FILE__));  // Ends with: /wp-content/plugins/careers-plugin/
define('CAREERS_PLUGIN_URL', plugin_dir_url(__FILE__));   // Ends with: https://yoursite.com/wp-content/plugins/careers-plugin/
define('CAREERS_ASSETS_URL', CAREERS_PLUGIN_URL . 'assets/');
define('CAREERS_CSS_URL', CAREERS_ASSETS_URL . 'css/');
define('CAREERS_JS_URL', CAREERS_ASSETS_URL . 'js/');
define('CAREERS_UPLOAD_DIR', wp_upload_dir()['basedir'] . '/career-applications/');
define('CAREERS_UPLOAD_URL', wp_upload_dir()['baseurl'] . '/career-applications/');

// Include required files
require_once CAREERS_PLUGIN_DIR . 'includes/class-careers-database.php';
require_once CAREERS_PLUGIN_DIR . 'includes/class-careers-post-type.php';
require_once CAREERS_PLUGIN_DIR . 'includes/class-careers-shortcodes.php';
require_once CAREERS_PLUGIN_DIR . 'includes/class-careers-apply.php';
require_once CAREERS_PLUGIN_DIR . 'includes/class-careers-admin.php';

// Main plugin class
class CareersManagementSystem {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Initialize components
        add_action('init', array($this, 'init'));
        
        // Debug: Add this temporarily to check if styles are loading
        add_action('wp_head', array($this, 'debug_output'), 999);
    }
    
    public function debug_output() {
        if (current_user_can('administrator')) {
            echo '<!-- Careers Plugin Debug: ';
            echo 'CAREERS_PLUGIN_URL: ' . CAREERS_PLUGIN_URL . ' | ';
            echo 'CAREERS_CSS_URL: ' . CAREERS_CSS_URL . ' | ';
            echo 'Current Post Type: ' . get_post_type() . ' -->';
        }
    }
    
    public function init() {
        // Initialize all components
        Careers_Database::init();
        Careers_Post_Type::init();
        Careers_Shortcodes::init();
        Careers_Apply::init();
        Careers_Admin::init();
        
        // Load text domain for translations
        load_plugin_textdomain('careers-plugin', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Create upload directory
        $this->create_upload_dir();
        
        // Add basic styles always (optional)
        add_action('wp_enqueue_scripts', array($this, 'enqueue_basic_styles'));
    }
    
    public function enqueue_basic_styles() {
        // Always load basic styles
        wp_enqueue_style('careers-basic', 
            CAREERS_CSS_URL . 'basic.css',
            array(),
            filemtime(CAREERS_PLUGIN_DIR . 'assets/css/basic.css')
        );
    }
    
    public function activate() {
        Careers_Database::create_tables();
        $this->create_upload_dir();
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    private function create_upload_dir() {
        if (!file_exists(CAREERS_UPLOAD_DIR)) {
            wp_mkdir_p(CAREERS_UPLOAD_DIR);
            
            // Add .htaccess for security
            $htaccess = CAREERS_UPLOAD_DIR . '.htaccess';
            if (!file_exists($htaccess)) {
                file_put_contents($htaccess, 'Options -Indexes' . PHP_EOL . 'Deny from all');
            }
            
            // Add index.php for extra security
            $index = CAREERS_UPLOAD_DIR . 'index.php';
            if (!file_exists($index)) {
                file_put_contents($index, '<?php // Silence is golden');
            }
        }
    }
}

// Initialize the plugin
CareersManagementSystem::get_instance();