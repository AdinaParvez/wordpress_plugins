<?php
/*
Plugin Name: Become Tutor Form
Description: A responsive tutor application form that sends email and saves to database.
Version: 1.0
Author: Adina Pervaiz
*/

// Create database table on plugin activation
register_activation_hook(__FILE__, 'btf_create_table');
function btf_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'become_tutor_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        tutor_name varchar(255) NOT NULL,
        qualification varchar(255) NOT NULL,
        subjects text NOT NULL,
        work_experience varchar(100) NOT NULL,
        current_workplace varchar(255) NOT NULL,
        preferred_time varchar(100) NOT NULL,
        hours_per_week varchar(50) NOT NULL,
        phone varchar(50) NOT NULL,
        email varchar(255) NOT NULL,
        country varchar(100) NOT NULL,
        city varchar(100) NOT NULL,
        message text NOT NULL,
        terms varchar(50) NOT NULL,
        email_sent tinyint(1) DEFAULT 0,
        submitted_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Extend nonce lifetime to 7 days
add_filter('nonce_life', 'btf_extend_nonce_lifetime');
function btf_extend_nonce_lifetime() {
    return 7 * DAY_IN_SECONDS;
}

// Add admin menu to view submissions
add_action('admin_menu', 'btf_add_admin_menu');
function btf_add_admin_menu() {
    add_menu_page(
        'Tutor Applications',
        'Tutor Applications',
        'manage_options',
        'become-tutor-submissions',
        'btf_display_submissions',
        'dashicons-welcome-learn-more',
        31
    );
}

// Display submissions in admin
function btf_display_submissions() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'become_tutor_submissions';
    
    // Handle delete action
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $wpdb->delete($table_name, ['id' => $id]);
        echo '<div class="notice notice-success"><p>Application deleted successfully.</p></div>';
    }
    
    // Handle export action
    if (isset($_GET['action']) && $_GET['action'] === 'export') {
        btf_export_to_csv();
        exit;
    }
    
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC");
    
    ?>
    <div class="wrap">
        <h1>Tutor Applications</h1>
        <p>
            <a href="<?php echo admin_url('admin.php?page=become-tutor-submissions&action=export'); ?>" class="button button-primary">Export to CSV</a>
        </p>
        
        <?php if (empty($submissions)): ?>
            <p>No applications found.</p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tutor Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Qualification</th>
                        <th>Country</th>
                        <th>Email Sent</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $submission): ?>
                        <tr>
                            <td><?php echo $submission->id; ?></td>
                            <td><?php echo esc_html($submission->tutor_name); ?></td>
                            <td><?php echo esc_html($submission->email); ?></td>
                            <td><?php echo esc_html($submission->phone); ?></td>
                            <td><?php echo esc_html($submission->qualification); ?></td>
                            <td><?php echo esc_html($submission->country); ?></td>
                            <td><?php echo $submission->email_sent ? '✓ Yes' : '✗ No'; ?></td>
                            <td><?php echo date('M j, Y g:i a', strtotime($submission->submitted_at)); ?></td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=become-tutor-submissions&action=view&id=' . $submission->id); ?>" class="button button-small">View</a>
                                <a href="<?php echo admin_url('admin.php?page=become-tutor-submissions&action=delete&id=' . $submission->id); ?>" class="button button-small" onclick="return confirm('Are you sure you want to delete this application?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
        <?php
        // Display full details if viewing a specific submission
        if (isset($_GET['action']) && $_GET['action'] === 'view' && isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $submission = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
            
            if ($submission) {
                ?>
                <div style="margin-top: 30px; padding: 20px; background: #fff; border: 1px solid #ccc;">
                    <h2>Application Details - #<?php echo $submission->id; ?></h2>
                    <table class="form-table">
                        <tr><th>Tutor Name:</th><td><?php echo esc_html($submission->tutor_name); ?></td></tr>
                        <tr><th>Qualification:</th><td><?php echo esc_html($submission->qualification); ?></td></tr>
                        <tr><th>Subjects:</th><td><?php echo esc_html($submission->subjects); ?></td></tr>
                        <tr><th>Work Experience:</th><td><?php echo esc_html($submission->work_experience); ?></td></tr>
                        <tr><th>Current Workplace:</th><td><?php echo esc_html($submission->current_workplace); ?></td></tr>
                        <tr><th>Preferred Time:</th><td><?php echo esc_html($submission->preferred_time); ?></td></tr>
                        <tr><th>Hours Per Week:</th><td><?php echo esc_html($submission->hours_per_week); ?></td></tr>
                        <tr><th>Phone:</th><td><?php echo esc_html($submission->phone); ?></td></tr>
                        <tr><th>Email:</th><td><?php echo esc_html($submission->email); ?></td></tr>
                        <tr><th>Country:</th><td><?php echo esc_html($submission->country); ?></td></tr>
                        <tr><th>City:</th><td><?php echo esc_html($submission->city); ?></td></tr>
                        <tr><th>Message:</th><td><?php echo nl2br(esc_html($submission->message)); ?></td></tr>
                        <tr><th>Terms Agreed:</th><td><?php echo esc_html($submission->terms); ?></td></tr>
                        <tr><th>Email Sent:</th><td><?php echo $submission->email_sent ? 'Yes' : 'No'; ?></td></tr>
                        <tr><th>Submitted:</th><td><?php echo date('F j, Y, g:i a', strtotime($submission->submitted_at)); ?></td></tr>
                    </table>
                    <p><a href="<?php echo admin_url('admin.php?page=become-tutor-submissions'); ?>" class="button">Back to List</a></p>
                </div>
                <?php
            }
        }
        ?>
    </div>
    <?php
}

// Export to CSV
function btf_export_to_csv(){
    global $wpdb;

    if (ob_get_length()) ob_clean();

    $table_name = $wpdb->prefix . 'become_tutor_submissions';
    $submissions = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    if (empty($submissions)) {
        wp_die(__('No data available to export.', 'btf'));
    }

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=tutor_applications-' . date('Y-m-d') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');
    fputs($output, "\xEF\xBB\xBF");
    fputcsv($output, array_keys($submissions[0]));

    foreach ($submissions as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
    exit;
}

// Shortcode to display the form
function btf_tutor_form_shortcode() {
    ob_start(); ?>
    
<style>
    .btf-form-wrapper {
        max-width: 100%;
        margin: 0 auto;
        padding: 20px 0;
        background: #fff;
        font-family: Arial, sans-serif;
    }
    .btf-form-wrapper form {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        align-items: start;
    }
    .btf-form-wrapper p {
        margin: 0;
    }
    .btf-form-wrapper label {
        font-weight: 600;
        font-size: 14px;
        display: block;
        margin-bottom: 6px;
        color: #333;
    }
    .btf-form-wrapper input[type="text"],
    .btf-form-wrapper input[type="number"],
    .btf-form-wrapper input[type="tel"],
    .btf-form-wrapper input[type="email"],
    .btf-form-wrapper textarea,
    .btf-form-wrapper select {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        background: #fff;
        box-sizing: border-box;
    }
    .btf-form-wrapper .full {
        grid-column: span 2;
        width: 100%;
    }
    .btf-form-wrapper input[type="submit"] {
        grid-column: span 2;
        background-color: #f9b000;
        width: 100%;
        color: #000;
        border: none;
        padding: 12px;
        cursor: pointer;
        border-radius: 4px;
        font-size: 16px;
        font-weight: bold;
        transition: background 0.3s ease;
    }
    .btf-form-wrapper input[type="submit"]:hover {
        background-color: #005177;
        color: #fff;
    }
    .btf-form-wrapper label input[type="checkbox"] {
        display: inline-block;
        width: auto;
        margin-right: 8px;
    }
    .btf-success-message {
        background: #d4edda;
        color: #155724;
        padding: 15px;
        border: 1px solid #c3e6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }
    .btf-error-message {
        background: #f8d7da;
        color: #721c24;
        padding: 15px;
        border: 1px solid #f5c6cb;
        border-radius: 4px;
        margin-bottom: 20px;
        text-align: center;
    }
    
    @media (max-width: 768px) {
        .btf-form-wrapper form {
            grid-template-columns: 1fr;
        }
        .btf-form-wrapper .full {
            grid-column: span 1;
        }
        .btf-form-wrapper input,
        .btf-form-wrapper select,
        .btf-form-wrapper textarea {
            font-size: 16px;
        }
        .btf-form-wrapper input[type="submit"] {
            font-size: 18px;
            padding: 14px;
        }
    }
</style>

<div class="btf-form-wrapper">
    <?php
    if (isset($_GET['form_status'])) {
        if ($_GET['form_status'] === 'success') {
            echo '<div class="btf-success-message">✓ Thank you! Your application has been submitted successfully.</div>';
        } elseif ($_GET['form_status'] === 'error') {
            echo '<div class="btf-error-message">⚠ There was an error submitting your application. Please try again.</div>';
        } elseif ($_GET['form_status'] === 'terms_error') {
            echo '<div class="btf-error-message">⚠ You must agree to the Terms & Conditions.</div>';
        }
    }
    ?>
    
    <form method="post" action="">
        <?php wp_nonce_field('btf_tutor_form_action', 'btf_tutor_form_nonce'); ?>
       
        <p><label>Full Name</label>
            <input type="text" placeholder="Enter your full name" name="tutor_name" required></p>
        
        <p><label>Qualification</label>
            <input type="text" placeholder="e.g., Bachelor's Degree, Master's, PhD" name="qualification" required></p>
        
        <p class="full"><label>Subjects You Can Teach - You can multiselect</label>
            <select name="subjects[]" multiple required>
                <option value="">Please Choose</option>
                <option value="Arabic">Arabic</option>
                <option value="Accounting">Accounting</option>
                <option value="Additional Mathematics">Additional Mathematics</option>
                <option value="Art & Design">Art & Design</option>
                <option value="Business Studies">Business Studies</option>
                <option value="Biology">Biology</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Chinese">Chinese - First Language / Second Language</option>
                <option value="Computer Science">Computer Science</option>
                <option value="Design & Technology">Design & Technology</option>
                <option value="Drama">Drama</option>
                <option value="Economics">Economics</option>
                <option value="English">English</option>
                <option value="English as a First Language">English as a First Language</option>
                <option value="English as a Second Language">English as a Second Language</option>
                <option value="English Literature">English Literature</option>
                <option value="Enterprise">Enterprise</option>
                <option value="Food & Nutrition">Food & Nutrition</option>
                <option value="French - Foreign Language">French - Foreign Language</option>
                <option value="Geography">Geography</option>
                <option value="German - Foreign Language">German - Foreign Language</option>
                <option value="Global Perspectives">Global Perspectives</option>
                <option value="History">History</option>
                <option value="Further Mathematics">Further Mathematics</option>
                <option value="ICT">ICT</option>
                <option value="Italian - Foreign Language">Italian - Foreign Language</option>
                <option value="Malay First Language">Malay First Language</option>
                <option value="Malay Foreign Language">Malay Foreign Language</option>
                <option value="Mathematics">Mathematics</option>
                <option value="Music">Music</option>
                <option value="Science Combined">Science Combined</option>
                <option value="Sciences Coordinated">Sciences Coordinated</option>
                <option value="Physics">Physics</option>
                <option value="Sociology">Sociology</option>
                <option value="Spanish">Spanish</option>
                <option value="Spanish First Language">Spanish First Language</option>
                <option value="Other">Other</option>
            </select></p>
        
        <p><label>Work Experience</label>
            <select name="work_experience" required>
                <option value="">Please Choose</option>
                <option value="Less than 1 year">Less than 1 year</option>
                <option value="1-2 years">1-2 years</option>
                <option value="3-5 years">3-5 years</option>
                <option value="5-10 years">5-10 years</option>
                <option value="More than 10 years">More than 10 years</option>
            </select></p>
        
        <p><label>Current Workplace / Institution</label>
            <input type="text" placeholder="Where are you currently working?" name="current_workplace" required></p>
        
        <p><label>Preferred Working Time</label>
            <select name="preferred_time" required>
                <option value="">Please Choose</option>
                <option value="Morning (Before 12 PM)">Morning (Before 12 PM)</option>
                <option value="Afternoon (12 PM - 5 PM)">Afternoon (12 PM - 5 PM)</option>
                <option value="Evening (After 5 PM)">Evening (After 5 PM)</option>
                <option value="Weekends Only">Weekends Only</option>
                <option value="Flexible">Flexible</option>
            </select></p>
        
        <p><label>Available Hours Per Week</label>
            <select name="hours_per_week" required>
                <option value="">Please Choose</option>
                <option value="Less than 5 hours">Less than 5 hours</option>
                <option value="5-10 hours">5-10 hours</option>
                <option value="10-20 hours">10-20 hours</option>
                <option value="20-30 hours">20-30 hours</option>
                <option value="More than 30 hours">More than 30 hours</option>
            </select></p>
        
        <p><label>Phone Number</label>
            <input type="tel" placeholder="Enter your phone number" name="phone" required></p>
        
        <p><label>Email Address</label>
            <input type="email" placeholder="Enter your email address" name="email" required></p>
        
        <p><label>Country</label>
            <input type="text" placeholder="Enter your country" name="country" required></p>
        
        <p><label>City</label>
            <input type="text" placeholder="Enter your city" name="city" required></p>
        
        <p class="full"><label>Additional Information / Message</label>
            <textarea name="message" placeholder="Tell us more about yourself and why you'd like to become a tutor with us" rows="5" required></textarea></p>
        
        <p class="full">
            <label>
                <input type="checkbox" name="terms" value="Agreed" required>
                Terms & Conditions - I agree to the Terms & Conditions of World Best Services Malaysia Sdn Bhd (ACE Education)
            </label>
        </p>
        
        <p class="full"><input type="submit" name="btf_tutor_submit" value="Submit Application"></p>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Auto-hide success/error messages after 10 seconds
            const successMsg = document.querySelector('.btf-success-message');
            const errorMsg = document.querySelector('.btf-error-message');
            
            if (successMsg || errorMsg) {
                setTimeout(function() {
                    const msg = successMsg || errorMsg;
                    msg.style.transition = 'opacity 0.5s ease';
                    msg.style.opacity = '0';
                    
                    setTimeout(function() {
                        msg.remove();
                        const url = new URL(window.location);
                        url.searchParams.delete('form_status');
                        window.history.replaceState({}, document.title, url);
                    }, 500);
                }, 10000);
            }
        });
    </script>
</div>

<?php
    return ob_get_clean();
}
add_shortcode('become_tutor_form', 'btf_tutor_form_shortcode');

// Handle form submission
add_action('init', 'btf_handle_form');

function btf_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['btf_tutor_submit'])) {

        // Verify nonce
        if (!isset($_POST['btf_tutor_form_nonce']) || !wp_verify_nonce($_POST['btf_tutor_form_nonce'], 'btf_tutor_form_action')) {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
            exit;
        }

        // Check terms agreement
        if (empty($_POST['terms'])) {
            wp_redirect(add_query_arg('form_status', 'terms_error', wp_get_referer()));
            exit;
        }

        // Sanitize and prepare data
        $data = [
            'tutor_name' => sanitize_text_field($_POST['tutor_name']),
            'qualification' => sanitize_text_field($_POST['qualification']),
            'subjects' => implode(', ', array_map('sanitize_text_field', $_POST['subjects'] ?? [])),
            'work_experience' => sanitize_text_field($_POST['work_experience']),
            'current_workplace' => sanitize_text_field($_POST['current_workplace']),
            'preferred_time' => sanitize_text_field($_POST['preferred_time']),
            'hours_per_week' => sanitize_text_field($_POST['hours_per_week']),
            'phone' => sanitize_text_field($_POST['phone']),
            'email' => sanitize_email($_POST['email']),
            'country' => sanitize_text_field($_POST['country']),
            'city' => sanitize_text_field($_POST['city']),
            'message' => sanitize_textarea_field($_POST['message']),
            'terms' => sanitize_text_field($_POST['terms']),
        ];

        // Email recipients
        $to = ['info@aceeducation.com.my', 'acekl2018@gmail.com']; 
        $subject = 'New Tutor Application - ' . $data['tutor_name'];

        // Create HTML email body
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #f9b000;">New Tutor Application</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%;">';
        
        $email_fields = [
            "Tutor Name" => $data['tutor_name'],
            "Qualification" => $data['qualification'],
            "Subjects" => $data['subjects'],
            "Work Experience" => $data['work_experience'],
            "Current Workplace" => $data['current_workplace'],
            "Preferred Time" => $data['preferred_time'],
            "Hours Per Week" => $data['hours_per_week'],
            "Phone" => $data['phone'],
            "Email" => $data['email'],
            "Country" => $data['country'],
            "City" => $data['city'],
            "Message" => nl2br($data['message']),
            "Terms & Conditions" => $data['terms'],
        ];
        
        foreach ($email_fields as $label => $value) {
            $message .= '<tr style="border-bottom: 1px solid #ddd;">';
            $message .= '<td style="padding: 10px; font-weight: bold; width: 200px;">' . $label . ':</td>';
            $message .= '<td style="padding: 10px;">' . $value . '</td>';
            $message .= '</tr>';
        }
        
        $message .= '</table>';
        $message .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
        $message .= '</body></html>';

        // Email headers
        $headers = [
            'From: ACE Education Malaysia <info@aceeducation.com.my>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . $data['email']
        ];

        // Send email
        $mail_sent = wp_mail($to, $subject, $message, $headers);

        // Save to database
        global $wpdb;
        $table_name = $wpdb->prefix . 'become_tutor_submissions';
        
        $data['email_sent'] = $mail_sent ? 1 : 0;
        
        $inserted = $wpdb->insert($table_name, $data);

        // Redirect with success message
        if ($inserted) {
            wp_redirect(add_query_arg('form_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
        }
        exit;
    }
}