<?php
/*
Plugin Name: Ace Popup Form
Description: A responsive popup form that sends email.
Version: 1.4
Author: Adina Pervaiz
*/


function ace_popup_form() {
    ob_start(); ?>
    
    <style>
            #ace-popup-overlay {
            display: none; /* jQuery fadeIn/fadeOut will handle this */
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.6);
            z-index: 9999;
            }

            /* Center the popup */
            #ace-popup-overlay::before {
            content: '';
            display: inline-block;
            height: 100%;
            vertical-align: middle;
            }

            #ace-popup {
            background: #002D62;
            color: #fff;
            padding: 25px;
            border-radius: 15px;
            max-width: 400px;
            width: 90%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
            text-align: center;
            }

            #ace-popup h2 {
            margin-bottom: 15px;
            color: #dcb225;
            }

            #ace-popup form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            }

            #ace-popup input,
            #ace-popup select {
            padding: 10px;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            }

            #ace-popup input:focus,
            #ace-popup select:focus {
            outline: 2px solid #dcb225;
            }

            .ace-submit-btn {
            background: #fff;
            color: #002D62;
            font-weight: bold;
            border: none;
            cursor: pointer;
            padding: 10px;
            border-radius: 8px;
            transition: background 0.3s ease;
            }

            .ace-submit-btn:hover {
            background: #ffe0c2;
            }

            #ace-popup-close {
            position: absolute;
            top: 8px;
            right: 12px;
            background: transparent;
            color: #fff;
            font-size: 24px;
            border: none;
            cursor: pointer;
            line-height: 1;
            transition: transform 0.2s ease;
            }

            #ace-popup-close:hover {
            transform: scale(1.2);
            }

            /* Terms checkbox styling */
            #ace-popup label {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 10px 0;
            text-align: left;
            }

            #ace-popup label input[type="checkbox"] {
            width: auto;
            margin: 0;
            }

            #ace-popup label span {
            font-size: 13px;
            }

            /* Success/Error Message Styling */
            .cef-success-message,
            .cef-error-message {
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            }

            .cef-success-message {
            background: #4CAF50;
            color: #fff;
            border: 1px solid #45a049;
            }

            .cef-error-message {
            background: #f44336;
            color: #fff;
            border: 1px solid #da190b;
            }

            /* Responsive */
            @media (max-width: 600px) {
            #ace-popup {
                width: 95%;
                padding: 20px;
            }
            
            #ace-popup h2 {
                font-size: 20px;
            }
            }
    /* End of style.css */
    </style>

    <div id="ace-popup-overlay">
        <div id="ace-popup">
            <button id="ace-popup-close">&times;</button>
            
            <?php
                // Display success or error messages
                if (isset($_GET['form_status'])) {
                    if ($_GET['form_status'] === 'success') {
                        echo '<div class="cef-success-message">✓ Thank you! Your inquiry has been submitted successfully.</div>';
                    } elseif ($_GET['form_status'] === 'error') {
                        echo '<div class="cef-error-message">⚠ There was an error submitting your form. Please try again.</div>';
                    } elseif ($_GET['form_status'] === 'terms_error') {
                        echo '<div class="cef-error-message">⚠ You must agree to the Terms & Conditions.</div>';
                    }
                }
            ?>
            
            <h2>Get in Touch</h2>
            
            <form id="ace-popup-form" method="post" action="">
                <?php wp_nonce_field('ace_popup_form_action', 'ace_popup_form_nonce'); ?>
                        
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input type="text" name="whatsapp" placeholder="WhatsApp Number" required>
                <select name="iam" required>
                    <option value="">I am...</option>
                    <option value="Student">A Student</option>
                    <option value="Parent">A Parent</option>
                    <option value="Other">Other</option>
                </select>
                <input type="text" name="subject" placeholder="Subject(s)" required>
                <input type="text" name="grade" placeholder="Grade" required>
                <input type="text" name="curriculum" placeholder="Curriculum" required>
                
                <label>
                    <input type="checkbox" name="terms" value="1" required>
                    <span>I agree to the Terms & Conditions</span>
                </label>
                
                <button type="submit" name="ace_popup_submit" class="ace-submit-btn">Submit</button>
            </form>

            <script>
                jQuery(document).ready(function ($) {
                    // Auto show after 3 seconds
                    setTimeout(() => {
                        if (!sessionStorage.getItem('acePopupClosed')) {
                            $('#ace-popup-overlay').fadeIn();
                        }
                    }, 3000);

                    // Close popup when clicking outside
                    $('#ace-popup-overlay').on('click', function (e) {
                        if ($(e.target).is('#ace-popup-overlay')) {
                            $('#ace-popup-overlay').fadeOut();
                            sessionStorage.setItem('acePopupClosed', 'true');
                        }
                    });

                    // Close popup on X button
                    $('#ace-popup-close').on('click', function () {
                        $('#ace-popup-overlay').fadeOut();
                        sessionStorage.setItem('acePopupClosed', 'true');
                    });

                    // Auto-hide success/error messages after 10 seconds
                    const successMsg = document.querySelector('.cef-success-message');
                    const errorMsg = document.querySelector('.cef-error-message');
                    
                    if (successMsg || errorMsg) {
                        setTimeout(function() {
                            const msg = successMsg || errorMsg;
                            msg.style.transition = 'opacity 0.5s ease';
                            msg.style.opacity = '0';
                            
                            setTimeout(function() {
                                msg.remove();
                                // Clean URL by removing query parameter
                                const url = new URL(window.location);
                                url.searchParams.delete('form_status');
                                window.history.replaceState({}, document.title, url);
                            }, 500);
                        }, 10000);
                    }
                });
            </script>
        </div>
    </div>

    <?php
    return ob_get_clean();
}

// Register the shortcode
add_shortcode('ace_popup', 'ace_popup_form');

// Handle form submission early
add_action('init', 'ace_popup_handle_form');

function ace_popup_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ace_popup_submit'])) {

        // Nonce Check
        if (!isset($_POST['ace_popup_form_nonce']) || !wp_verify_nonce($_POST['ace_popup_form_nonce'], 'ace_popup_form_action')) {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
            exit;
        }

        // Check terms checkbox
        if (empty($_POST['terms'])) {
            wp_redirect(add_query_arg('form_status', 'terms_error', wp_get_referer()));
            exit;
        }

        //$to = ['info@aceeducation.com.my', 'acekl2018@gmail.com', 'pervaizadina@gmail.com'];
        $to = ['info@aceeducation.com.my', 'acekl2018@gmail.com', 'adina.pervaiz@webace.com.my', 'pervaizadina@gmail.com'];
        $subject = 'New Enquiry Form Submission';

        $fields = [
            "Name" => sanitize_text_field($_POST['name']),
            "Email" => sanitize_email($_POST['email']),
            "WhatsApp" => sanitize_text_field($_POST['whatsapp']),
            "I am" => sanitize_text_field($_POST['iam']),
            "Subject" => sanitize_text_field($_POST['subject']),
            "Grade" => sanitize_text_field($_POST['grade']),
            "Curriculum" => sanitize_text_field($_POST['curriculum']),
            "Terms Accepted" => "Yes",
        ];

        // Create HTML email body
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #002D62;">New Enquiry from ACE Education Website</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%; max-width: 600px;">';
        foreach ($fields as $label => $value) {
            $message .= '<tr style="border-bottom: 1px solid #ddd;">';
            $message .= '<td style="padding: 10px; font-weight: bold; width: 200px; background: #f5f5f5;">' . esc_html($label) . ':</td>';
            $message .= '<td style="padding: 10px;">' . esc_html($value) . '</td>';
            $message .= '</tr>';
        }
        $message .= '</table>';
        $message .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
        $message .= '</body></html>';

        $headers = [
            'From: ACE Education Malaysia <info@aceeducation.com.my>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . sanitize_email($_POST['email'])
        ];
        
        // Send email
        $mail_sent = wp_mail($to, $subject, $message, $headers);

        // Redirect with success/error message
        if ($mail_sent) {
            wp_redirect(add_query_arg('form_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
        }
        exit;
    }
}