<?php
/*
Plugin Name: WP Popup Form Once
Description: Popup contact form that appears once on first visit and redirects after submit.
Version: 1.3
Author: Adina Pervaiz
*/

// Enqueue CSS and JS
function wp_pf_enqueue_assets() {
    wp_enqueue_style('wp-pf-css', plugin_dir_url(__FILE__) . 'assets/form.css');
    wp_enqueue_script('wp-pf-js', plugin_dir_url(__FILE__) . 'assets/form.js', array('jquery'), null, true);
    wp_localize_script('wp-pf-js', 'WP_PF', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('wp_pf_nonce'),
        'successMessage' => __('Thanks! Your message has been sent.', 'wp-pf'),
        'errorMessage'   => __('Sorry, something went wrong. Please try again.', 'wp-pf'),
        'redirectUrl'    => home_url('/thank-you/')
    ]);
}
add_action('wp_enqueue_scripts', 'wp_pf_enqueue_assets');

// Shortcode for popup button
function wp_pf_button_shortcode($atts) {
    $atts = shortcode_atts([
        'text' => 'Open Form',
        'class' => 'btn',
        'auto_open' => 'false'
    ], $atts);
    $auto_attr = $atts['auto_open'] === 'true' ? ' data-wp-pf-auto-open="1"' : '';
    return '<button class="' . esc_attr($atts['class']) . '" data-wp-pf-open' . $auto_attr . '>' . esc_html($atts['text']) . '</button>';
}
add_shortcode('popup_form_button', 'wp_pf_button_shortcode');

// Render popup HTML in footer
function wp_pf_render_popup() {
    ?>
    <div class="wp-pf-overlay" data-wp-pf-overlay aria-hidden="true">
        <div class="wp-pf-modal" role="dialog" aria-modal="true" aria-labelledby="wp-pf-title">
            <button class="wp-pf-close" data-wp-pf-close aria-label="Close">&times;</button>
            <h2 id="wp-pf-title"><?php _e('Contact Us', 'wp-pf'); ?></h2>
            <form class="wp-pf-form">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('wp_pf_nonce'); ?>">
                <p><label><?php _e('Name', 'wp-pf'); ?>*</label><input type="text" name="name" id="wp-pf-name" required></p>
                <p><label><?php _e('Email', 'wp-pf'); ?>*</label><input type="email" name="email" required></p>
                <p><label><?php _e('Phone', 'wp-pf'); ?></label><input type="text" name="phone"></p>
                <p><label><?php _e('Message', 'wp-pf'); ?>*</label><textarea name="message" required></textarea></p>
                <p><button type="submit" class="wp-pf-submit"><?php _e('Submit', 'wp-pf'); ?></button></p>
                <div class="wp-pf-status"></div>
            </form>
        </div>
    </div>
    <?php
}
add_action('wp_footer', 'wp_pf_render_popup');

// Handle AJAX submit
function wp_pf_handle_submit() {
    check_ajax_referer('wp_pf_nonce', 'nonce');

    $name    = sanitize_text_field($_POST['name'] ?? '');
    $email   = sanitize_email($_POST['email'] ?? '');
    $phone   = sanitize_text_field($_POST['phone'] ?? '');
    $message = sanitize_textarea_field($_POST['message'] ?? '');

    if (!$name || !$email || !$message) {
        wp_send_json_error(['message' => __('Please fill in required fields.', 'wp-pf')]);
    }

    if (!is_email($email)) {
        wp_send_json_error(['message' => __('Invalid email address.', 'wp-pf')]);
    }

    $to = get_option('admin_email');
    $subject = 'Popup Form Message from ' . $name;
    $body = "Name: $name\nEmail: $email\nPhone: $phone\nMessage:\n$message";
    $headers = ['Content-Type: text/plain; charset=UTF-8'];

    wp_mail($to, $subject, $body, $headers);

    wp_send_json_success();
}
add_action('wp_ajax_wp_pf_submit', 'wp_pf_handle_submit');
add_action('wp_ajax_nopriv_wp_pf_submit', 'wp_pf_handle_submit');
?>
