<?php
/*
Plugin Name: Custom Fixes
Plugin URI:  https://adinapervaiz.weebly.com
Description: Fixes missing CSS/JS, Slider Revolution errors, and defers render-blocking JS/CSS.
Version:     1.0
Author:      Adina Pervaiz

*/

// ----------------------------
// 1. Fix missing CSS files
// ----------------------------
add_action('wp_enqueue_scripts', function() {

    $styles_to_fix = array(
        'engitech-style' => array(
            'old_path' => '/css/style.css',
            'fallback_path' => '/style.css'
        ),
        // Add more theme/plugin CSS handles here if needed
    );

    foreach ($styles_to_fix as $handle => $paths) {
        $old_file = get_template_directory() . $paths['old_path'];
        if (!file_exists($old_file) && !empty($paths['fallback_path'])) {
            wp_dequeue_style($handle);
            wp_deregister_style($handle);

            wp_enqueue_style(
                $handle,
                get_template_directory_uri() . $paths['fallback_path'],
                array(),
                wp_get_theme()->get('Version')
            );
        }
    }

}, 20);

// ----------------------------
// 2. Protect Slider Revolution AJAX requests
// ----------------------------
add_filter('revslider_ajax_request', function($return, $request) {

    if (class_exists('RevSliderSlider')) {
        $sliders = new RevSliderSlider();
        $all_sliders = $sliders->getArrSliders();
        $valid_ids = array();

        foreach ($all_sliders as $slider) {
            if (isset($slider->id)) $valid_ids[] = (int)$slider->id;
        }

        if (isset($request['sliderid']) && !in_array((int)$request['sliderid'], $valid_ids)) {
            wp_send_json_error(array(
                'message' => 'Slider not found or disabled'
            ));
        }
    }

    return $return;

}, 10, 2);

// ----------------------------
// 3. Hide broken sliders on front-end
// ----------------------------
add_action('wp_footer', function() {
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const sliders = document.querySelectorAll('.rev_slider_wrapper');
        sliders.forEach(slider => {
            if (!slider.querySelectorAll('.tp-revslider-slidesli').length) {
                slider.style.display = 'none';
                console.warn('A broken or missing slider has been hidden.');
            }
        });
    });
    </script>
    <?php
});

// ----------------------------
// 4. Defer non-critical JS
// ----------------------------
add_filter('script_loader_tag', function($tag, $handle) {
    // List of JS handles to defer
    $defer_scripts = array(
        'swiper-js', 'frontend-modules', 'widget-carousel' // example handles
    );

    if (in_array($handle, $defer_scripts)) {
        return str_replace('<script ', '<script defer ', $tag);
    }

    return $tag;
}, 10, 2);

// ----------------------------
// 5. Preload important CSS
// ----------------------------
add_action('wp_head', function() {
    ?>
    <link rel="preload" href="<?php echo get_template_directory_uri(); ?>/style.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css"></noscript>
    <?php
});
