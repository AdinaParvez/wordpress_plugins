<?php
/**
* Plugin Name: Clean Tutor Registration & Profile
* Description: Front-end tutor registration, login, profile management with admin approval.
* Version: 1.2
* Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

/**
 * Force logout unapproved tutors
 */
add_action('init', function () {
    if (is_admin()) return;
    if (!is_user_logged_in()) return;
    if (is_user_logged_in()) {
        $user = wp_get_current_user();

        if (in_array('tutor', (array) $user->roles)) {
            if ((int) get_user_meta($user->ID, 'tutor_approved', true) !== 1) {
                wp_logout();
                wp_safe_redirect(home_url('/tutor-login-page?approval=pending'));
                exit;
            }
        }
    }
});

// -------------------- CREATE TUTOR ROLE --------------------
register_activation_hook(__FILE__, function() {
add_role('tutor', 'Tutor', [
'read' => true,
'edit_posts' => false,
'delete_posts' => false,
]);
});


// -------------------- ENQUEUE STYLES --------------------
add_action('wp_enqueue_scripts', function() {
wp_enqueue_style('tutor-registration-style', plugin_dir_url(__FILE__) . 'style.css');
});


// -------------------- REGISTRATION FORM --------------------
function ctutor_register_form_shortcode() {
if (is_user_logged_in()) return '<p>You are already logged in.</p>';


ob_start(); ?>
<form method="post" enctype="multipart/form-data" class="ctutor-register-form">
    <?php wp_nonce_field('ctutor_register', 'ctutor_nonce'); ?>
    <input type="text" name="tutor_name" placeholder="Full Name" required>

    <label>Designation</label>
    <select name="tutor_designation" required>
        <option value="">Select Designation</option>
        <option value="Senior Tutor">Senior Tutor</option>
        <option value="Junior Tutor">Junior Tutor</option>
        <option value="Subject Specialist">Subject Specialist</option>
    </select>
    
    <input type="text" placeholder="Contact" name="tutor_contact" required>

 
    <input type="email" placeholder="Email" name="tutor_email" required>

    <label>Teaching Subject</label>
    <input type="text" name="tutor_subject" required>

    <label>Previous Experience</label>
    <textarea name="tutor_experience" required></textarea>

    <label>Facebook Profile (optional)</label>
    <input type="url" name="tutor_facebook">

    <label>Instagram Profile (optional)</label>
    <input type="url" name="tutor_instagram">

    <label>LinkedIn Profile (optional)</label>
    <input type="url" name="tutor_linkedin">

    <label>Upload Supporting Document (PDF / DOC / DOCX)</label>
    <input type="file" name="tutor_document" accept=".pdf,.doc,.docx" required>
 
<br/>
    <label>Upload Profile Image</label>
    <input type="file" name="tutor_image" accept="image/*" required>

<br/>
    <label>Create Password</label>
    <input type="password" name="tutor_password" required>

    <input type="submit" name="tutor_register_submit" value="Register">
</form>

<?php
return ob_get_clean();
}
add_shortcode('ctutor_register_form', 'ctutor_register_form_shortcode');

// -------------------- HANDLE REGISTRATION --------------------
add_action('init', function() {
if (empty($_POST['tutor_register_submit'])) return;
if (empty($_POST['ctutor_nonce']) || !wp_verify_nonce($_POST['ctutor_nonce'], 'ctutor_register')) {
wp_die('Security check failed');
}


$name = sanitize_text_field($_POST['tutor_name']);
$designation = sanitize_text_field($_POST['tutor_designation']);
$contact = sanitize_text_field($_POST['tutor_contact']);
$email = sanitize_email($_POST['tutor_email']);
$subject = sanitize_text_field($_POST['tutor_subject']);
$experience = sanitize_textarea_field($_POST['tutor_experience']);
$facebook = esc_url_raw($_POST['tutor_facebook'] ?? '');
$instagram = esc_url_raw($_POST['tutor_instagram'] ?? '');
$linkedin = esc_url_raw($_POST['tutor_linkedin'] ?? '');
$password = $_POST['tutor_password'];



if (email_exists($email)) wp_die('Email already registered.');


// Create user
$user_id = wp_create_user($email, $password, $email);
if (is_wp_error($user_id)) {
    wp_die($user_id->get_error_message());
}
wp_update_user(['ID' => $user_id, 'display_name' => $name]);
$user = new WP_User($user_id);
$user->set_role('tutor');


// Save meta
update_user_meta($user_id, 'tutor_designation', $designation);
update_user_meta($user_id, 'tutor_contact', $contact);
update_user_meta($user_id, 'tutor_subject', $subject);
update_user_meta($user_id, 'tutor_experience', $experience);
update_user_meta($user_id, 'tutor_facebook', $facebook);
update_user_meta($user_id, 'tutor_instagram', $instagram);
update_user_meta($user_id, 'tutor_linkedin', $linkedin);
update_user_meta($user_id, 'tutor_approved', 0); // Admin approval pending


if (!function_exists('wp_handle_upload')) {
    require_once(ABSPATH.'wp-admin/includes/file.php');
}

$allowed_docs = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
];

if (!empty($_FILES['tutor_document']['name'])) {

    // ✅ MIME type validation (ADD HERE)
    $doc_type = mime_content_type($_FILES['tutor_document']['tmp_name']);

    if (!in_array($doc_type, $allowed_docs)) {
        wp_die('Invalid document type. Only PDF or Word files allowed.');
    }

    $doc = wp_handle_upload($_FILES['tutor_document'], ['test_form' => false]);

    if (!isset($doc['error'])) {
        update_user_meta($user_id, 'tutor_document', esc_url($doc['url']));
    }
}

if (!empty($_FILES['tutor_image']['name'])) {

    $img_type = mime_content_type($_FILES['tutor_image']['tmp_name']);

    if (strpos($img_type, 'image/') !== 0) {
        wp_die('Invalid image file. Please upload a valid image.');
    }

    $img = wp_handle_upload($_FILES['tutor_image'], ['test_form' => false]);

    if (!isset($img['error'])) {
        update_user_meta($user_id, 'tutor_image', esc_url($img['url']));
    }
}



wp_redirect(home_url('/tutor-login-page?registered=1'));
exit;
});


// -------------------- LOGIN FORM --------------------
function ctutor_login_form_shortcode() {
if (is_user_logged_in()) return '<p>You are already logged in.</p>';


ob_start(); ?>
<form method="post" class="ctutor-login-form">
<?php wp_nonce_field('ctutor_login', 'ctutor_login_nonce'); ?>
<input type="text" name="tutor_login_email" placeholder="Email" required>
<input type="password" name="tutor_login_password" placeholder="Password" required>
<input type="submit" name="tutor_login_submit" value="Login">
</form>
<?php
return ob_get_clean();
}
add_shortcode('ctutor_login_form', 'ctutor_login_form_shortcode');

// -------------------- HANDLE LOGIN --------------------
add_action('init', function() {
if (empty($_POST['tutor_login_submit'])) return;
if (empty($_POST['ctutor_login_nonce']) || !wp_verify_nonce($_POST['ctutor_login_nonce'], 'ctutor_login')) {
wp_die('Security check failed');
}

$user_login = sanitize_email($_POST['tutor_login_email']);

$creds = [
    'user_login'    => $user_login,
    'user_password' => $_POST['tutor_login_password'],
    'remember'      => true
];


$user = wp_signon($creds, false);


if (is_wp_error($user)) wp_die($user->get_error_message());


if (!in_array('tutor', (array)$user->roles)) wp_die('You are not allowed to log in here.');
if (get_user_meta($user->ID, 'tutor_approved', true) != 1) {
    wp_safe_redirect(home_url('/tutor-login-page?approval=pending'));
    exit;
}


wp_redirect(home_url('/tutor-profile'));
exit;
});

// -------------------- VIEW PROFILE --------------------
function ctutor_profile_shortcode() {

    if (!is_user_logged_in()) return '<p>Please log in to view your profile.</p>';

     // If a tutor ID is passed in URL, show that tutor
    $tutor_id = isset($_GET['tutor_id']) ? intval($_GET['tutor_id']) : get_current_user_id();


    $user = wp_get_current_user();
    if (!in_array('tutor', (array)$user->roles)) return '<p>Access denied.</p>';


    $meta = get_user_meta($user->ID);


    ob_start(); ?>
    <div class="ctutor-profile">
    <?php if (!empty($meta['tutor_image'][0])): ?>
    <img src="<?php echo esc_url($meta['tutor_image'][0]); ?>" class="ctutor-profile-image">
    <?php endif; ?>
    <p><strong>Name:</strong> <?php echo esc_html($user->display_name); ?></p>
    <p><strong>Designation:</strong> <?php echo esc_html($meta['tutor_designation'][0] ?? ''); ?></p>
    <p><strong>Contact:</strong> <?php echo esc_html($meta['tutor_contact'][0] ?? ''); ?></p>
    <p><strong>Email:</strong> <?php echo esc_html($user->user_email); ?></p>
    <p><strong>Teaching Subject:</strong> <?php echo esc_html($meta['tutor_subject'][0] ?? ''); ?></p>
    <p><strong>Experience:</strong> <?php echo esc_html($meta['tutor_experience'][0] ?? ''); ?></p>
    <?php foreach (['facebook','instagram','linkedin'] as $platform):
    if (!empty($meta['tutor_'.$platform][0])): ?>
    <p><strong><?php echo ucfirst($platform); ?>:</strong> <a href="<?php echo esc_url($meta['tutor_'.$platform][0]); ?>" target="_blank">View</a></p>
    <?php endif; endforeach; ?>
    <?php if (!empty($meta['tutor_document'][0])): ?>
    <p><strong>Document:</strong> <a href="<?php echo esc_url($meta['tutor_document'][0]); ?>" target="_blank">View</a></p>
    <?php endif; ?>
    <hr>

    <div class="ctutor-profile-actions">

        <a href="<?php echo esc_url(home_url('/edit-tutor-profile')); ?>" class="ctutor-btn-edit">
            ✏️ Edit Profile
        </a>

        <form method="post"
            onsubmit="return confirm('Are you sure you want to delete your profile? This action will permanently delete your account.');">

            <?php wp_nonce_field('ctutor_delete_profile', 'ctutor_delete_nonce'); ?>
            <input type="hidden" name="ctutor_delete_profile" value="1">

            <button type="submit" class="ctutor-btn-delete">
                🗑️ Delete Profile
            </button>
        </form>

    </div>

</div>
<?php
return ob_get_clean();
}
add_shortcode('ctutor_profile', 'ctutor_profile_shortcode');

// -------------------- DELETE TUTOR PROFILE --------------------
    add_action('init', function () {

        if (!is_user_logged_in()) return;

        if (!isset($_POST['ctutor_delete_profile'])) return;

        if (
            !isset($_POST['ctutor_delete_nonce']) ||
            !wp_verify_nonce($_POST['ctutor_delete_nonce'], 'ctutor_delete_profile')
        ) {
            wp_die('Security check failed.');
        }

        $user = wp_get_current_user();

        // Only tutors can delete themselves
        if (!in_array('tutor', (array)$user->roles)) {
            wp_die('Access denied.');
        }

        require_once ABSPATH . 'wp-admin/includes/user.php';

        $user_id = $user->ID;

        wp_logout();
        wp_delete_user($user_id);

        wp_safe_redirect(home_url('/tutor-register?account=deleted'));
        exit;
    });

// -------------------- EDIT PROFILE --------------------
function ctutor_profile_edit_shortcode() {
    if (!is_user_logged_in()) return '<p>Please log in to edit your profile.</p>';

    $user_id = get_current_user_id();
    if (!in_array('tutor', (array)wp_get_current_user()->roles)) return '<p>Access denied.</p>';

    // Handle form submission
    if (isset($_POST['ctutor_profile_update'])) {
        if (!isset($_POST['ctutor_profile_nonce']) || !wp_verify_nonce($_POST['ctutor_profile_nonce'], 'ctutor_profile_edit')) {
            wp_die('Security check failed.');
        }

        $name       = sanitize_text_field($_POST['tutor_name']);
        $designation= sanitize_text_field($_POST['tutor_designation']);
        $contact    = sanitize_text_field($_POST['tutor_contact']);
        $subject    = sanitize_text_field($_POST['tutor_subject']);
        $experience = sanitize_textarea_field($_POST['tutor_experience']);
        $facebook   = esc_url_raw($_POST['tutor_facebook'] ?? '');
        $instagram  = esc_url_raw($_POST['tutor_instagram'] ?? '');
        $linkedin   = esc_url_raw($_POST['tutor_linkedin'] ?? '');

        wp_update_user(['ID'=>$user_id, 'display_name'=>$name]);
        update_user_meta($user_id, 'tutor_designation', $designation);
        update_user_meta($user_id, 'tutor_contact', $contact);
        update_user_meta($user_id, 'tutor_subject', $subject);
        update_user_meta($user_id, 'tutor_experience', $experience);
        update_user_meta($user_id, 'tutor_facebook', $facebook);
        update_user_meta($user_id, 'tutor_instagram', $instagram);
        update_user_meta($user_id, 'tutor_linkedin', $linkedin);

        

        // Handle file uploads

        $allowed_docs = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ];


 //-------------------- HANDLE PROFILE EDIT --------------------

    if (!function_exists('wp_handle_upload')) {
        require_once(ABSPATH.'wp-admin/includes/file.php');
    }

    if (!empty($_FILES['tutor_document']['name'])) {

        // ✅ MIME validation
        $doc_type = mime_content_type($_FILES['tutor_document']['tmp_name']);

        if (!in_array($doc_type, $allowed_docs)) {
            wp_die('Invalid document type. Only PDF or Word files allowed.');
        }

        $doc = wp_handle_upload($_FILES['tutor_document'], ['test_form' => false]);

        if (!isset($doc['error'])) {
            update_user_meta($user_id, 'tutor_document', esc_url($doc['url']));
        }
    }


    if (!empty($_FILES['tutor_image']['name'])) {

    $img_type = mime_content_type($_FILES['tutor_image']['tmp_name']);

    if (strpos($img_type, 'image/') !== 0) {
        wp_die('Invalid image file.');
    }

    $img = wp_handle_upload($_FILES['tutor_image'], ['test_form' => false]);

    if (!isset($img['error'])) {
        update_user_meta($user_id, 'tutor_image', esc_url($img['url']));
    }
 }


        echo '<p style="color:green;">Profile updated successfully!</p>';
    }

    $user = get_userdata($user_id);
    $meta = get_user_meta($user_id);

    ob_start(); ?>
    <form method="post" enctype="multipart/form-data" class="ctutor-profile-edit">
        <?php wp_nonce_field('ctutor_profile_edit','ctutor_profile_nonce'); ?>
        <p><strong>Email:</strong> <?php echo esc_html($user->user_email); ?></p>

        <label>Name:</label>
        <input type="text" name="tutor_name" value="<?php echo esc_attr($user->display_name); ?>" required>

        <label>Designation:</label>
        <select name="tutor_designation" required>
            <option value="">Select Designation</option>
            <option value="Senior Tutor" <?php selected($meta['tutor_designation'][0]??'', 'Senior Tutor'); ?>>Senior Tutor</option>
            <option value="Junior Tutor" <?php selected($meta['tutor_designation'][0]??'', 'Junior Tutor'); ?>>Junior Tutor</option>
            <option value="Subject Specialist" <?php selected($meta['tutor_designation'][0]??'', 'Subject Specialist'); ?>>Subject Specialist</option>
        </select>

        <label>Contact:</label>
        <input type="text" name="tutor_contact" value="<?php echo esc_attr($meta['tutor_contact'][0]??''); ?>" required>

        <label>Teaching Subject:</label>
        <input type="text" name="tutor_subject" value="<?php echo esc_attr($meta['tutor_subject'][0]??''); ?>" required>

        <label>Experience:</label>
        <textarea name="tutor_experience" required><?php echo esc_textarea($meta['tutor_experience'][0]??''); ?></textarea>

        <label>Facebook:</label>
        <input type="url" name="tutor_facebook" value="<?php echo esc_attr($meta['tutor_facebook'][0]??''); ?>">

        <label>Instagram:</label>
        <input type="url" name="tutor_instagram" value="<?php echo esc_attr($meta['tutor_instagram'][0]??''); ?>">

        <label>LinkedIn:</label>
        <input type="url" name="tutor_linkedin" value="<?php echo esc_attr($meta['tutor_linkedin'][0]??''); ?>">

        <label>Profile Image:</label>
        <?php if(!empty($meta['tutor_image'][0])): ?>
            <img src="<?php echo esc_url($meta['tutor_image'][0]); ?>" style="max-width:150px;">
        <?php endif; ?>
        <input type="file" name="tutor_image" accept="image/*">

        <label>Document:</label>
        <?php if(!empty($meta['tutor_document'][0])): ?>
            <a href="<?php echo esc_url($meta['tutor_document'][0]); ?>" target="_blank">View Current Document</a>
        <?php endif; ?>
        <input type="file" name="tutor_document" accept=".pdf,.doc,.docx">

        <input type="submit" name="ctutor_profile_update" value="Update Profile">
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('ctutor_profile_edit','ctutor_profile_edit_shortcode');
// -------------------- FRONTEND TUTOR DIRECTORY --------------------
function ctutor_frontend_directory_shortcode() {
    $tutors = get_users([
        'role'=>'tutor',
        'meta_key'=>'tutor_approved',
        'meta_value'=>1
    ]);
    if(empty($tutors)) return '<p>No tutors available currently.</p>';

    ob_start();
    echo '<div class="ctutor-directory">';
    foreach($tutors as $tutor){
        $meta = get_user_meta($tutor->ID);
        $image = $meta['tutor_image'][0] ?? '';
        $subject = $meta['tutor_subject'][0] ?? '';
        $experience = $meta['tutor_experience'][0] ?? '';
        $facebook = $meta['tutor_facebook'][0] ?? '';
        $instagram = $meta['tutor_instagram'][0] ?? '';
        $linkedin = $meta['tutor_linkedin'][0] ?? '';

        echo '<div class="ctutor-card">';
        if($image) echo '<img src="'.esc_url($image).'" alt="'.esc_attr($tutor->display_name).'">';
        echo '<h3>'.esc_html($tutor->display_name).'</h3>';
        echo '<p><strong>Subject:</strong> '.esc_html($subject).'</p>';
        echo '<p><strong>Experience:</strong> '.esc_html($experience).'</p>';
        if($facebook) echo '<p><a href="'.esc_url($facebook).'" target="_blank">Facebook</a></p>';
        if($instagram) echo '<p><a href="'.esc_url($instagram).'" target="_blank">Instagram</a></p>';
        if($linkedin) echo '<p><a href="'.esc_url($linkedin).'" target="_blank">LinkedIn</a></p>';
        echo '</div>';
    }
    echo '</div>';
    return ob_get_clean();
}
add_shortcode('tutor_directory','ctutor_frontend_directory_shortcode');

// -------------------- EMAIL NOTIFICATION --------------------
function ctutor_notify_tutor($user_id,$status){
    $user = get_userdata($user_id);
    $to = $user->user_email;
    $subject = ($status=='approved')?'Tutor Registration Approved':'Tutor Registration Rejected';
    $message = ($status=='approved') ?
        "Hello {$user->display_name},\n\nYour tutor registration has been approved! You can now login and update your profile.\n\nThanks." :
        "Hello {$user->display_name},\n\nWe regret to inform you that your tutor registration has been rejected.\n\nThanks.";
    wp_mail($to,$subject,$message);
}

// -------------------- ADMIN MENU --------------------
add_action('admin_menu',function(){
    add_menu_page(
        'Tutor Management',
        'Tutor Management',
        'manage_options',
        'tutor-management',
        'ctutor_admin_management_page',
        'dashicons-welcome-learn-more',
        26
    );
});





// -------------------- ADMIN MANAGEMENT PAGE --------------------
function ctutor_admin_management_page(){
    if(!current_user_can('manage_options')) return;

    echo '<div class="wrap"><h1>Tutor Management</h1>';

    $tab = $_GET['tab'] ?? 'pending';
    echo '<h2 class="nav-tab-wrapper">';
    echo '<a href="'.admin_url('admin.php?page=tutor-management&tab=pending').'" class="nav-tab '.($tab=='pending'?'nav-tab-active':'').'">Pending Tutors</a>';
    echo '<a href="'.admin_url('admin.php?page=tutor-management&tab=approved').'" class="nav-tab '.($tab=='approved'?'nav-tab-active':'').'">Approved Tutors</a>';
    echo '</h2>';

    // Bulk actions
    if(isset($_POST['bulk_action']) && isset($_POST['tutor_ids'])){
        if(!isset($_POST['ctutor_bulk_action_nonce']) || !wp_verify_nonce($_POST['ctutor_bulk_action_nonce'],'ctutor_bulk_action')) wp_die('Security check failed.');
        $tutor_ids = array_map('intval',$_POST['tutor_ids']);
        if($_POST['bulk_action']=='approve'){
            foreach($tutor_ids as $id){
                update_user_meta($id,'tutor_approved',1);
                ctutor_notify_tutor($id,'approved');
            }
            echo '<div class="notice notice-success"><p>Selected tutors approved!</p></div>';
        }
        if($_POST['bulk_action']=='reject'){
            foreach($tutor_ids as $id){
                ctutor_notify_tutor($id,'rejected');
                wp_delete_user($id);
            }
            echo '<div class="notice notice-warning"><p>Selected tutors rejected and deleted!</p></div>';
        }
    }

    // Single approve/reject
    if(isset($_GET['approve_tutor'])){
        $tutor_id = intval($_GET['approve_tutor']);
        check_admin_referer('ctutor_single_action_'.$tutor_id);
        update_user_meta($tutor_id,'tutor_approved',1);
        ctutor_notify_tutor($tutor_id,'approved');
        echo '<div class="notice notice-success"><p>Tutor approved successfully!</p></div>';
    }
    if(isset($_GET['reject_tutor'])){
        $tutor_id = intval($_GET['reject_tutor']);
        check_admin_referer('ctutor_single_action_'.$tutor_id);
        ctutor_notify_tutor($tutor_id,'rejected');
        wp_delete_user($tutor_id);
        echo '<div class="notice notice-warning"><p>Tutor rejected and deleted successfully!</p></div>';
    }

    // Fetch tutors
    $meta_value = ($tab=='approved')?1:0;
    $tutors = get_users(['role'=>'tutor','meta_key'=>'tutor_approved','meta_value'=>$meta_value]);
    if(empty($tutors)){ echo '<p>No tutors in this list.</p></div>'; return; }

    echo '<form method="post">';
    wp_nonce_field('ctutor_bulk_action','ctutor_bulk_action_nonce');

    echo '<select name="bulk_action" required>
            <option value="">Bulk Actions</option>
            <option value="approve">Approve</option>
            <option value="reject">Reject</option>
          </select>
          <input type="submit" class="button" value="Apply">';

    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr>
            <th><input type="checkbox" id="bulk_select_all"></th>
            <th>Name</th><th>Email</th><th>Role</th><th>Document</th><th>Image</th><th>Actions</th>
          </tr></thead><tbody>';

    foreach($tutors as $tutor){
        $meta = get_user_meta($tutor->ID);
        $document = $meta['tutor_document'][0] ?? '';
        $image = $meta['tutor_image'][0] ?? '';
        $role = implode(', ',$tutor->roles);
        $approve_url = wp_nonce_url(admin_url('admin.php?page=tutor-management&approve_tutor='.$tutor->ID),'ctutor_single_action_'.$tutor->ID);
        $reject_url = wp_nonce_url(admin_url('admin.php?page=tutor-management&reject_tutor='.$tutor->ID),'ctutor_single_action_'.$tutor->ID);

        echo '<tr>
                <td><input type="checkbox" name="tutor_ids[]" value="'.esc_attr($tutor->ID).'"></td>
                <td>'.esc_html($tutor->display_name).'</td>
                <td>'.esc_html($tutor->user_email).'</td>
                <td>'.esc_html($role).'</td>
                <td>'.($document?'<a href="'.esc_url($document).'" target="_blank">View</a>':'').'</td>
                <td>'.($image?'<img src="'.esc_url($image).'" style="max-width:50px;">':'').'</td>
                <td>'.($tab=='pending'?'<a class="button button-primary" href="'.$approve_url.'">Approve</a> <a class="button button-secondary" href="'.$reject_url.'">Reject</a>':'<span style="color:green;">Approved</span>').'</td>
              </tr>';
    }
    echo '</tbody></table></form>';

    echo '<script>
        document.getElementById("bulk_select_all").addEventListener("click", function(e){
            document.querySelectorAll(\'input[name="tutor_ids[]"]\').forEach(function(cb){
                cb.checked = e.target.checked;
            });
        });
        </script>';


    echo '</div>';
}
