<?php
/**
 * Plugin Name: ACE Education Chat
 * Description: Smart chat widget for ACE Education
 * Version: 1.0
 * Author: Adina Pervaiz
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

function ace_education_chat() {
    // Only show on frontend
    if (is_admin()) {
        return;
    }
    
    // Output the chat HTML
    ?>
    <div id="ace-education-chat-widget">
        <div class="ace-chat-container">
            <div class="ace-chat-header">
                <div class="ace-header-info">
                    <h3>ACE Education Chat</h3>
                    <p>Click to restore</p>
                </div>
                <div class="ace-header-controls">
                    <button class="ace-control-btn ace-minimize-btn" title="Minimize">−</button>
                    <button class="ace-control-btn ace-close-btn" title="Close">×</button>
                </div>
            </div>
            
            <div class="ace-chat-content">
                <div class="ace-agent-selection">
                    <h4>Select an agent to chat with:</h4>
                    <div class="ace-agent-grid">
                        <button class="ace-agent-btn" data-agent="admissions">
                            <span class="ace-agent-icon">📚</span>
                            <span class="ace-agent-name">Admissions Officer</span>
                            <span class="ace-agent-desc">Course enrollment & registration</span>
                        </button>
                        <button class="ace-agent-btn" data-agent="tuition">
                            <span class="ace-agent-icon">👨‍🏫</span>
                            <span class="ace-agent-name">Tuition Advisor</span>
                            <span class="ace-agent-desc">Program details & tutoring</span>
                        </button>
                        <button class="ace-agent-btn" data-agent="support">
                            <span class="ace-agent-icon">💬</span>
                            <span class="ace-agent-name">Customer Support</span>
                            <span class="ace-agent-desc">General inquiries & help</span>
                        </button>
                        <button class="ace-agent-btn" data-agent="exams">
                            <span class="ace-agent-icon">📝</span>
                            <span class="ace-agent-name">Exam Specialist</span>
                            <span class="ace-agent-desc">Test prep & IGCSE guidance</span>
                        </button>
                    </div>
                </div>
                
                <div class="ace-chat-area">
                    <div class="ace-chat-agent-info">
                        <span class="ace-current-agent-icon">💬</span>
                        <span class="ace-current-agent-name">Select an agent to start chatting</span>
                        <button class="ace-change-agent-btn">Change Agent</button>
                    </div>
                    
                    <div class="ace-chat-messages">
                        <div class="ace-message ace-agent-message">
                            Welcome to ACE Education Malaysia! Please select an agent to start chatting. I'm here to help with admissions, tuition programs, exam preparation, and general inquiries.
                        </div>
                    </div>
                    
                    <div class="ace-suggested-questions">
                        <div class="ace-suggested-question" data-question="How do I enroll?">How do I enroll?</div>
                        <div class="ace-suggested-question" data-question="What subjects do you offer?">What subjects do you offer?</div>
                        <div class="ace-suggested-question" data-question="Do you have online classes?">Do you have online classes?</div>
                        <div class="ace-suggested-question" data-question="What are your locations?">What are your locations?</div>
                    </div>
                    
                    <div class="ace-chat-input-container">
                        <textarea class="ace-chat-input" placeholder="Type your message here..." rows="2"></textarea>
                        <button class="ace-send-btn">Send</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <style>
        #ace-education-chat-widget {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 99999;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            width: auto;
            height: auto;
        }

        .ace-chat-container {
            width: 380px;
            height: 600px;
            max-height: calc(100vh - 40px);
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            transition: all 0.3s ease;
        }

        .ace-chat-container.ace-minimized {
            height: 60px;
            width: 300px;
        }

        .ace-chat-container.ace-minimized .ace-chat-content {
            display: none;
        }

        .ace-chat-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            flex-shrink: 0;
        }

        .ace-chat-header h3 {
            font-size: 16px;
            margin: 0;
            font-weight: 600;
            line-height: 1.2;
        }

        .ace-chat-header p {
            opacity: 0.9;
            font-size: 11px;
            margin: 2px 0 0 0;
        }

        .ace-header-controls {
            display: flex;
            gap: 8px;
        }

        .ace-control-btn {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.2s;
            font-weight: bold;
        }

        .ace-control-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .ace-chat-content {
            display: flex;
            flex: 1;
            overflow: hidden;
        }

        .ace-agent-selection {
            width: 150px;
            background: #f8f9fa;
            padding: 15px;
            border-right: 1px solid #e9ecef;
            overflow-y: auto;
            flex-shrink: 0;
        }

        .ace-agent-selection h4 {
            font-size: 14px;
            margin-bottom: 12px;
            color: #333;
            font-weight: 600;
        }

        .ace-agent-btn {
            width: 100%;
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 8px;
            cursor: pointer;
            text-align: left;
            transition: all 0.2s;
        }

        .ace-agent-btn:hover {
            border-color: #667eea;
            box-shadow: 0 2px 8px rgba(102, 126, 234, 0.1);
        }

        .ace-agent-btn.active {
            border-color: #667eea;
            background: #f0f4ff;
        }

        .ace-agent-icon {
            font-size: 20px;
            margin-bottom: 6px;
            display: block;
        }

        .ace-agent-name {
            font-weight: 600;
            color: #333;
            font-size: 12px;
            display: block;
            line-height: 1.2;
        }

        .ace-agent-desc {
            font-size: 10px;
            color: #666;
            display: block;
            margin-top: 3px;
            line-height: 1.2;
        }

        .ace-chat-area {
            flex: 1;
            display: flex;
            flex-direction: column;
            min-width: 0;
        }

        .ace-chat-agent-info {
            background: #f8f9fa;
            padding: 10px 15px;
            display: flex;
            align-items: center;
            gap: 8px;
            border-bottom: 1px solid #e9ecef;
            flex-shrink: 0;
        }

        .ace-current-agent-icon {
            font-size: 18px;
        }

        .ace-current-agent-name {
            flex: 1;
            font-weight: 600;
            color: #333;
            font-size: 13px;
        }

        .ace-change-agent-btn {
            background: none;
            border: 1px solid #667eea;
            color: #667eea;
            padding: 4px 8px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 10px;
            font-weight: 500;
            transition: all 0.2s;
            white-space: nowrap;
        }

        .ace-change-agent-btn:hover {
            background: #667eea;
            color: white;
        }

        .ace-chat-messages {
            flex: 1;
            padding: 15px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
            background: #ffffff;
        }

        .ace-message {
            max-width: 85%;
            padding: 8px 12px;
            border-radius: 12px;
            line-height: 1.4;
            font-size: 12px;
            word-wrap: break-word;
            animation: aceFadeIn 0.3s ease-out;
            white-space: pre-line;
        }

        .ace-user-message {
            background: #667eea;
            color: white;
            align-self: flex-end;
            border-bottom-right-radius: 4px;
        }

        .ace-agent-message {
            background: #f1f3f5;
            color: #333;
            align-self: flex-start;
            border-bottom-left-radius: 4px;
        }

        .ace-typing-message {
            background: #f1f3f5;
            color: #666;
            align-self: flex-start;
            font-style: italic;
            animation: acePulse 1.5s infinite;
        }

        .ace-chat-input-container {
            padding: 12px;
            border-top: 1px solid #e9ecef;
            display: flex;
            gap: 8px;
            background: white;
            flex-shrink: 0;
        }

        .ace-chat-input {
            flex: 1;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 8px 12px;
            resize: none;
            font-size: 12px;
            min-height: 40px;
            max-height: 80px;
            transition: border-color 0.2s;
            font-family: inherit;
            line-height: 1.4;
        }

        .ace-chat-input:focus {
            outline: none;
            border-color: #667eea;
        }

        .ace-send-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 0 12px;
            cursor: pointer;
            font-weight: 600;
            font-size: 12px;
            transition: opacity 0.2s;
            align-self: flex-end;
            white-space: nowrap;
        }

        .ace-send-btn:hover {
            opacity: 0.9;
        }

        .ace-suggested-questions {
            padding: 0 12px 8px;
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            flex-shrink: 0;
        }

        .ace-suggested-question {
            background: #f0f4ff;
            border: 1px solid #d0d8ff;
            border-radius: 12px;
            padding: 4px 8px;
            font-size: 10px;
            cursor: pointer;
            transition: all 0.2s;
            line-height: 1.2;
        }

        .ace-suggested-question:hover {
            background: #667eea;
            color: white;
        }

        @keyframes aceFadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes acePulse {
            0%, 100% {
                opacity: 1;
            }
            50% {
                opacity: 0.6;
            }
        }

        /* Scrollbar styling */
        .ace-chat-messages::-webkit-scrollbar {
            width: 4px;
        }

        .ace-chat-messages::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        .ace-chat-messages::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 2px;
        }

        .ace-chat-messages::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            #ace-education-chat-widget {
                bottom: 10px;
                right: 10px;
                left: auto;
            }
            
            .ace-chat-container {
                width: 350px;
                height: 500px;
            }
            
            .ace-chat-container.ace-minimized {
                width: 250px;
                height: 50px;
            }
            
            .ace-agent-selection {
                width: 130px;
                padding: 12px;
            }
            
            .ace-agent-btn {
                padding: 10px;
                margin-bottom: 6px;
            }
            
            .ace-agent-icon {
                font-size: 18px;
            }
        }

        @media (max-width: 480px) {
            #ace-education-chat-widget {
                bottom: 5px;
                right: 5px;
            }
            
            .ace-chat-container {
                width: 320px;
                height: 450px;
            }
            
            .ace-chat-container.ace-minimized {
                width: 200px;
                height: 45px;
            }
            
            .ace-agent-selection {
                width: 120px;
            }
            
            .ace-agent-grid {
                display: flex;
                flex-direction: column;
            }
        }

        @media (max-width: 360px) {
            .ace-chat-container {
                width: 300px;
            }
            
            .ace-agent-selection {
                width: 110px;
            }
        }
    </style>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Knowledge base data
            const knowledgeBase = {
                admissions: {
                    name: 'Admissions Officer',
                    icon: '📚',
                    greeting: "Hello! I'm your Admissions Officer at ACE Education Malaysia. I can help you with enrollment, registration, and admission requirements. How can I assist you today?",
                    keywords: {
                        'enroll|enrollment|register|registration|join|admission|apply|application': [
                            "To enroll at ACE Education, simply contact us at +60164777167 (Mont Kiara) or +60162477738 (Subang Jaya). You can also email us at info@aceeducation.com.my",
                            "We offer enrollment for students from Grade 3 to Grade 12 across IGCSE, A-Level, IB, CBSE, and CIMP curricula. Contact us to discuss your needs!"
                        ],
                        'location|address|branch|center|centre|where|find': [
                            "We have 2 branches in Malaysia:\n📍 Mont Kiara: D-05-08 Plaza Mont Kiara, Jalan Kiara, 50480 Kuala Lumpur\n📍 Subang Jaya: C7, USJ10/1J, Taipan Business Centre, 47610 Selangor",
                            "Find us at Mont Kiara (Plaza Mont Kiara, +60164777167) or Subang Jaya (Taipan Business Centre, +60162477738)"
                        ],
                        'contact|phone|email|reach|call|number': [
                            "You can reach us at:\n📞 Mont Kiara: +60164777167\n📞 Subang Jaya: +60162477738\n📧 Email: info@aceeducation.com.my",
                            "Contact us at +60164777167 (Mont Kiara) or +60162477738 (Subang Jaya), or email info@aceeducation.com.my"
                        ]
                    },
                    default: "I can help you with enrollment, admission requirements, and registration at ACE Education. Contact us at +60164777167 (Mont Kiara), +60162477738 (Subang Jaya), or email info@aceeducation.com.my"
                },
                tuition: {
                    name: 'Tuition Advisor',
                    icon: '👨‍🏫',
                    greeting: "Hi! I'm your Tuition Advisor at ACE Education Malaysia. I can provide information about our tutoring programs, subjects, and teaching methods. What would you like to know?",
                    keywords: {
                        'subject|subjects|teach|course|courses|curriculum|what do you offer': [
                            "We offer tutoring in:\n📚 Mathematics\n🔬 Sciences (Physics, Chemistry, Biology)\n🌍 Languages (English, Bahasa Malaysia, Mandarin, French, German, Spanish)\n📖 Humanities (History, Geography, Psychology, Sociology)\n💼 Business Studies & Economics",
                            "ACE Education covers all major subjects across IGCSE, A-Level, IB, CBSE, and CIMP curricula - from Maths and Sciences to Languages and Humanities."
                        ],
                        'math|maths|mathematics|calculus|algebra|geometry': [
                            "Yes! We have expert Mathematics tutors covering all levels from basic arithmetic to advanced calculus for IGCSE, A-Level, and IB programs.",
                            "Our Maths tutors are highly qualified and have helped hundreds of students improve their grades significantly!"
                        ],
                        'online|remote|virtual|zoom|home': [
                            "Yes! We offer flexible online tutoring sessions. Our expert tutors deliver engaging one-on-one lessons through interactive virtual platforms.",
                            "ACE Education provides both online and in-person tutoring. Our online sessions are just as effective as face-to-face learning!"
                        ]
                    },
                    default: "We offer personalized one-on-one tutoring across all subjects for IGCSE, A-Level, IB, and more. Contact us at +60164777167 or info@aceeducation.com.my to learn more!"
                },
                support: {
                    name: 'Customer Support',
                    icon: '💬',
                    greeting: "Welcome to ACE Education Malaysia! I'm here to help with any general inquiries about our services, locations, and contact information. How can I assist you?",
                    keywords: {
                        'about|who|what is ace|tell me about|information': [
                            "ACE Education is a trusted tutoring provider in Kuala Lumpur since 2019. We offer personalized one-on-one support for IGCSE, A-Level, IB, and more, helping students achieve academic excellence.",
                            "Since 2019, ACE Education has helped thousands of students thrive through expert tutoring, test prep, language learning, and study abroad guidance!"
                        ],
                        'hours|time|schedule|timing|when|open|available': [
                            "We offer flexible scheduling for both online and in-person sessions. Contact us at +60164777167 to arrange lessons at times that suit your needs.",
                            "Our tutoring sessions are scheduled based on your availability - 7 days a week! Reach out to discuss timing."
                        ],
                        'location|address|branch|where|find|directions': [
                            "We have 2 convenient locations:\n📍 Mont Kiara: Plaza Mont Kiara, Jalan Kiara, 50480 KL\n📍 Subang Jaya: Taipan Business Centre, 47610 Selangor",
                            "Find us at Mont Kiara (Plaza Mont Kiara, +60164777167) or Subang Jaya (Taipan Business Centre, +60162477738)"
                        ]
                    },
                    default: "ACE Education offers tutoring, test prep, language learning, and study abroad support across Malaysia. Contact us at +60164777167 (Mont Kiara) or info@aceeducation.com.my for more information!"
                },
                exams: {
                    name: 'Exam Specialist',
                    icon: '📝',
                    greeting: "Hello! I'm your Exam Specialist at ACE Education. I can help you with test preparation for SAT, ACT, IELTS, TOEFL, IGCSE, A-Level, and IB exams. What exam are you preparing for?",
                    keywords: {
                        'sat|standardized test': [
                            "We offer comprehensive SAT preparation with personalized instruction, strategic test-taking techniques, and full-length mock exams to help you achieve top scores!",
                            "ACE Education provides expert SAT prep courses designed to boost your scores through targeted practice and proven strategies."
                        ],
                        'ielts|english test|language test': [
                            "We prepare students for IELTS with expert instruction, practice tests, and proven techniques to achieve your target band score!",
                            "Yes! Our IELTS prep courses include personalized coaching, mock tests, and strategic guidance from experienced instructors."
                        ],
                        'igcse|gcse|o level|cambridge': [
                            "We specialize in IGCSE/O-Level exam preparation across all subjects with experienced tutors who know Cambridge and Edexcel requirements!",
                            "Our IGCSE tutors have helped hundreds of students achieve A* grades through focused, results-driven preparation!"
                        ]
                    },
                    default: "We prepare students for SAT, ACT, IELTS, TOEFL, GRE, GMAT, IGCSE, A-Level, and IB exams with expert instruction and proven strategies. Contact +60164777167 or info@aceeducation.com.my to start your prep!"
                }
            };

            // DOM elements
            const chatContainer = document.querySelector('.ace-chat-container');
            const chatHeader = document.querySelector('.ace-chat-header');
            const minimizeBtn = document.querySelector('.ace-minimize-btn');
            const closeBtn = document.querySelector('.ace-close-btn');
            const agentButtons = document.querySelectorAll('.ace-agent-btn');
            const changeAgentBtn = document.querySelector('.ace-change-agent-btn');
            const currentAgentIcon = document.querySelector('.ace-current-agent-icon');
            const currentAgentName = document.querySelector('.ace-current-agent-name');
            const chatMessages = document.querySelector('.ace-chat-messages');
            const chatInput = document.querySelector('.ace-chat-input');
            const sendBtn = document.querySelector('.ace-send-btn');
            const suggestedQuestions = document.querySelectorAll('.ace-suggested-question');

            // State variables
            let currentAgent = null;
            let conversationHistory = [];
            let isMinimized = false;

            // Event listeners for minimize/close
            minimizeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                toggleMinimize();
            });

            closeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                closeChat();
            });

            chatHeader.addEventListener('click', function() {
                if (isMinimized) {
                    toggleMinimize();
                }
            });

            // Agent selection and chat functionality
            agentButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const agent = this.getAttribute('data-agent');
                    selectAgent(agent);
                });
            });

            changeAgentBtn.addEventListener('click', function() {
                resetChat();
            });

            sendBtn.addEventListener('click', sendMessage);

            chatInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                }
            });

            suggestedQuestions.forEach(question => {
                question.addEventListener('click', function() {
                    const questionText = this.getAttribute('data-question');
                    chatInput.value = questionText;
                    sendMessage();
                });
            });

            // Auto-resize textarea
            chatInput.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = Math.min(this.scrollHeight, 80) + 'px';
            });

            // Functions for minimize/close
            function toggleMinimize() {
                isMinimized = !isMinimized;
                chatContainer.classList.toggle('ace-minimized', isMinimized);
                
                if (isMinimized) {
                    minimizeBtn.innerHTML = '⤢';
                    minimizeBtn.title = 'Restore';
                } else {
                    minimizeBtn.innerHTML = '−';
                    minimizeBtn.title = 'Minimize';
                }
            }

            function closeChat() {
                if (confirm('Are you sure you want to close the chat? Your conversation will be lost.')) {
                    chatContainer.style.display = 'none';
                    showChatButton();
                }
            }

            function showChatButton() {
                const chatButton = document.createElement('div');
                chatButton.innerHTML = `
                    <div style="position: fixed; bottom: 20px; right: 20px; width: 60px; height: 60px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 99999;">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
                            <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/>
                        </svg>
                    </div>
                `;
                
                document.body.appendChild(chatButton);
                
                chatButton.addEventListener('click', function() {
                    chatContainer.style.display = 'flex';
                    chatButton.remove();
                    isMinimized = false;
                    chatContainer.classList.remove('ace-minimized');
                });
            }

            // Chat functions
            function selectAgent(agent) {
                currentAgent = agent;
                
                agentButtons.forEach(btn => {
                    if (btn.getAttribute('data-agent') === agent) {
                        btn.classList.add('active');
                    } else {
                        btn.classList.remove('active');
                    }
                });
                
                currentAgentIcon.textContent = knowledgeBase[agent].icon;
                currentAgentName.textContent = knowledgeBase[agent].name;
                
                chatMessages.innerHTML = '';
                addMessage(knowledgeBase[agent].greeting, 'agent');
            }

            function resetChat() {
                currentAgent = null;
                conversationHistory = [];
                
                agentButtons.forEach(btn => btn.classList.remove('active'));
                currentAgentIcon.textContent = '💬';
                currentAgentName.textContent = 'Select an agent to start chatting';
                chatMessages.innerHTML = '<div class="ace-message ace-agent-message">Welcome to ACE Education Malaysia! Please select an agent to start chatting. I\'m here to help with admissions, tuition programs, exam preparation, and general inquiries.</div>';
            }

            function sendMessage() {
                const message = chatInput.value.trim();
                
                if (message === '' || !currentAgent) {
                    if (!currentAgent) {
                        addMessage('Please select an agent first to start chatting.', 'agent');
                    }
                    return;
                }
                
                addMessage(message, 'user');
                chatInput.value = '';
                chatInput.style.height = 'auto';
                
                conversationHistory.push({
                    role: 'user',
                    content: message
                });
                
                const typingId = addMessage('Agent is typing...', 'typing');
                
                chatInput.disabled = true;
                sendBtn.disabled = true;
                
                setTimeout(() => {
                    const typingElement = document.getElementById(typingId);
                    if (typingElement) {
                        typingElement.remove();
                    }
                    
                    const response = getSmartResponse(message, currentAgent);
                    addMessage(response, 'agent');
                    
                    conversationHistory.push({
                        role: 'assistant',
                        content: response
                    });
                    
                    chatInput.disabled = false;
                    sendBtn.disabled = false;
                    chatInput.focus();
                }, 1000 + Math.random() * 1000);
            }

            function addMessage(text, type) {
                const messageId = 'ace-msg-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
                const messageClass = type === 'user' ? 'ace-message ace-user-message' : 
                                   type === 'typing' ? 'ace-message ace-typing-message' : 
                                   'ace-message ace-agent-message';
                
                const messageHtml = `<div class="${messageClass}" id="${messageId}">${escapeHtml(text)}</div>`;
                
                chatMessages.innerHTML += messageHtml;
                scrollToBottom();
                
                return messageId;
            }

            function scrollToBottom() {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }

            function escapeHtml(text) {
                const map = {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#039;'
                };
                return text.replace(/[&<>"']/g, function(m) { return map[m]; });
            }

            function getSmartResponse(message, agent) {
                const messageLower = message.toLowerCase();
                const agentKb = knowledgeBase[agent];
                
                if (/^(hi|hello|hey|good morning|good afternoon|good evening|greetings|salam)/i.test(message)) {
                    return agentKb.greeting;
                }
                
                if (/(thank|thanks|appreciate|tq)/i.test(message)) {
                    return "You're very welcome! Is there anything else I can help you with regarding ACE Education? 😊";
                }
                
                if (/(bye|goodbye|see you|thanks bye)/i.test(message)) {
                    return "Thank you for chatting with ACE Education! Feel free to reach out anytime. Have a great day! 👋";
                }
                
                let bestMatch = null;
                let bestMatchLength = 0;
                
                for (const pattern in agentKb.keywords) {
                    const regex = new RegExp('(' + pattern + ')', 'i');
                    const match = messageLower.match(regex);
                    
                    if (match && match[0].length > bestMatchLength) {
                        bestMatch = agentKb.keywords[pattern];
                        bestMatchLength = match[0].length;
                    }
                }
                
                if (bestMatch) {
                    return bestMatch[Math.floor(Math.random() * bestMatch.length)];
                }
                
                return agentKb.default;
            }
        });
    </script>
    <?php
}
                    
// Add to footer
add_action('wp_footer', 'ace_education_chat');