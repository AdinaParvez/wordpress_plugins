<?php
/*
Plugin Name: ALC Slider Manager
Description: Custom slider manager with per-page slider selection and fallback to theme slider.
Version: 1.1
Author: Adina Pervaiz
*/

// ========================
// Register Slider Post Types
// ========================
function alcsm_register_slider_post_type() {
    register_post_type('alc_slider', array(
        'labels' => array(
            'name' => __('Sliders', 'alc-slider-manager'),
            'singular_name' => __('Slider', 'alc-slider-manager'),
        ),
        'public' => true,
        'has_archive' => false,
        'supports' => array('title'),
    ));

    register_post_type('alc_slide', array(
        'labels' => array(
            'name' => __('Slides', 'alc-slider-manager'),
            'singular_name' => __('Slide', 'alc-slider-manager'),
        ),
        'public' => true,
        'has_archive' => false,
        'supports' => array('title', 'thumbnail'),
    ));
}
add_action('init', 'alcsm_register_slider_post_type');

// ========================
// Meta box for Slide details
// ========================
function alcsm_add_slide_meta_box() {
    add_meta_box('alcsm_slide_meta', __('Slide Details', 'alc-slider-manager'), 'alcsm_slide_meta_callback', 'alc_slide', 'normal', 'high');
}
add_action('add_meta_boxes', 'alcsm_add_slide_meta_box');

function alcsm_slide_meta_callback($post) {
    wp_nonce_field('alcsm_save_slide_meta', 'alcsm_slide_meta_nonce');
    $subtitle = get_post_meta($post->ID, '_alcsm_subtitle', true);
    $button = get_post_meta($post->ID, '_alcsm_button', true);
    $button_url = get_post_meta($post->ID, '_alcsm_button_url', true);

    echo '<p><label>' . __('Subtitle:', 'alc-slider-manager') . '</label>';
    echo '<input type="text" name="alcsm_subtitle" value="' . esc_attr($subtitle) . '" class="widefat" /></p>';

    echo '<p><label>' . __('Button Text:', 'alc-slider-manager') . '</label>';
    echo '<input type="text" name="alcsm_button" value="' . esc_attr($button) . '" class="widefat" /></p>';

    echo '<p><label>' . __('Button URL:', 'alc-slider-manager') . '</label>';
    echo '<input type="text" name="alcsm_button_url" value="' . esc_attr($button_url) . '" class="widefat" /></p>';
}

function alcsm_save_slide_meta($post_id) {
    if (!isset($_POST['alcsm_slide_meta_nonce']) || !wp_verify_nonce($_POST['alcsm_slide_meta_nonce'], 'alcsm_save_slide_meta')) {
        return;
    }
    update_post_meta($post_id, '_alcsm_subtitle', sanitize_text_field($_POST['alcsm_subtitle']));
    update_post_meta($post_id, '_alcsm_button', sanitize_text_field($_POST['alcsm_button']));
    update_post_meta($post_id, '_alcsm_button_url', esc_url_raw($_POST['alcsm_button_url']));
}
add_action('save_post_alc_slide', 'alcsm_save_slide_meta');

// ========================
// Add Parent Slider Meta to Slides
// ========================
function alcsm_add_slide_parent_meta_box() {
    add_meta_box('alcsm_slide_parent', __('Assign to Slider', 'alc-slider-manager'), 'alcsm_slide_parent_callback', 'alc_slide', 'side');
}
add_action('add_meta_boxes', 'alcsm_add_slide_parent_meta_box');

function alcsm_slide_parent_callback($post) {
    $sliders = get_posts(array('post_type' => 'alc_slider', 'numberposts' => -1));
    $selected = get_post_meta($post->ID, '_alcsm_parent_slider', true);
    echo '<select name="alcsm_parent_slider" class="widefat">';
    echo '<option value="">' . __('Select Slider', 'alc-slider-manager') . '</option>';
    foreach ($sliders as $slider) {
        echo '<option value="' . $slider->ID . '" ' . selected($selected, $slider->ID, false) . '>' . esc_html($slider->post_title) . '</option>';
    }
    echo '</select>';
}

function alcsm_save_slide_parent_meta($post_id) {
    if (isset($_POST['alcsm_parent_slider'])) {
        update_post_meta($post_id, '_alcsm_parent_slider', intval($_POST['alcsm_parent_slider']));
    }
}
add_action('save_post_alc_slide', 'alcsm_save_slide_parent_meta');

// ========================
// Slider Shortcode
// ========================
function alcsm_slider_shortcode($atts) {
    $atts = shortcode_atts(array('id' => ''), $atts, 'alc_slider');
    $slider_id = intval($atts['id']);
    if (!$slider_id) return '';

    $slides = get_posts(array(
        'post_type' => 'alc_slide',
        'meta_key' => '_alcsm_parent_slider',
        'meta_value' => $slider_id,
        'posts_per_page' => -1,
    ));

    if (!$slides) return '';

    ob_start();
    echo '<div class="alc-slider">';
    foreach ($slides as $slide) {
        $subtitle = get_post_meta($slide->ID, '_alcsm_subtitle', true);
        $button = get_post_meta($slide->ID, '_alcsm_button', true);
        $button_url = get_post_meta($slide->ID, '_alcsm_button_url', true);
        $image = get_the_post_thumbnail($slide->ID, 'full');
        echo '<div class="alc-slide">';
        echo $image;
        echo '<h2>' . esc_html($slide->post_title) . '</h2>';
        if ($subtitle) echo '<p>' . esc_html($subtitle) . '</p>';
        if ($button && $button_url) echo '<a href="' . esc_url($button_url) . '" class="alc-button">' . esc_html($button) . '</a>';
        echo '</div>';
    }
    echo '</div>';
    return ob_get_clean();
}
add_shortcode('alc_slider', 'alcsm_slider_shortcode');

// ========================
// Page Slider Meta Box
// ========================
function alcsm_add_slider_meta_box() {
    add_meta_box(
        'alcsm_page_slider',
        __('Page Slider', 'alc-slider-manager'),
        'alcsm_page_slider_callback',
        'page',
        'side'
    );
}
add_action('add_meta_boxes', 'alcsm_add_slider_meta_box');

function alcsm_page_slider_callback($post) {
    wp_nonce_field('alcsm_save_page_slider', 'alcsm_page_slider_nonce');
    $selected = get_post_meta($post->ID, '_alcsm_page_slider', true);
    $sliders = get_posts(array(
        'post_type' => 'alc_slider',
        'posts_per_page' => -1,
        'post_status' => 'publish',
    ));

    echo '<select name="alcsm_page_slider" class="widefat">';
    echo '<option value="">' . __('Default (theme slider)', 'alc-slider-manager') . '</option>';
    foreach ($sliders as $slider) {
        printf('<option value="%d" %s>%s</option>', $slider->ID, selected($selected, $slider->ID, false), esc_html($slider->post_title));
    }
    echo '</select>';
}

function alcsm_save_page_slider($post_id) {
    if (!isset($_POST['alcsm_page_slider_nonce']) || !wp_verify_nonce($_POST['alcsm_page_slider_nonce'], 'alcsm_save_page_slider')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (isset($_POST['alcsm_page_slider'])) {
        update_post_meta($post_id, '_alcsm_page_slider', absint($_POST['alcsm_page_slider']));
    }
}
add_action('save_post_page', 'alcsm_save_page_slider');

// ========================
// Display Slider with Fallback
// ========================
function alcsm_display_page_slider() {
    if (is_page()) {
        $slider_id = get_post_meta(get_the_ID(), '_alcsm_page_slider', true);
        if ($slider_id) {
            echo do_shortcode('[alc_slider id="' . $slider_id . '"]');
            return;
        }
    }
    // Fallback to theme slider
    if (function_exists('the_custom_header_markup')) {
        the_custom_header_markup();
    } else {
        echo '<!-- Default theme slider -->';
    }
}
add_action('wp_head', 'alcsm_display_page_slider');