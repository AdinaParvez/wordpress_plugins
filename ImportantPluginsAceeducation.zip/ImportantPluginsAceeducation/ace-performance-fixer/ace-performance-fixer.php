<?php
/*
Plugin Name: ACE Performance Fixer
Description: Defers non-critical JS and delays heavy third-party scripts (GTM/GA, Facebook, reCAPTCHA) until user interaction to reduce TBT and improve Core Web Vitals.
Version: 1.0
Author: GSTech / Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

// --------------------- Defaults ---------------------
function apf_defaults() {
    return [
        'defer_js' => 1,
        'delay_gtm' => 1,
        'delay_fb' => 1,
        'delay_recaptcha' => 1,
        'delay_after_interaction_ms' => 0, // 0 = immediate on interaction
        'script_allowlist' => 'jquery,wp-emoji-release,wp-polyfill,elementor-frontend,swiper',
        'delay_url_patterns' => 'googletagmanager,gtag/js,connect.facebook.net,recaptcha,google-analytics.com,analytics.js',
    ];
}
function apf_get($k) {
    $opts = get_option('apf_options', []);
    $defaults = apf_defaults();
    return isset($opts[$k]) ? $opts[$k] : $defaults[$k];
}

// --------------------- Admin UI ---------------------
add_action('admin_menu', function() {
    add_options_page('ACE Performance Fixer', 'ACE Performance Fixer', 'manage_options', 'apf-settings', 'apf_settings_page');
});
function apf_settings_page() {
    if (!current_user_can('manage_options')) return;
    $defaults = apf_defaults();
    $opts = get_option('apf_options', $defaults);
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('apf_save','apf_nonce')) {
        foreach ($defaults as $k => $v) {
            if (isset($_POST[$k])) $opts[$k] = is_numeric($v) ? intval($_POST[$k]) : sanitize_text_field($_POST[$k]);
            else if (is_numeric($v)) $opts[$k] = 0;
        }
        update_option('apf_options', $opts);
        echo '<div class="updated"><p>Settings saved.</p></div>';
    }
    $opts = wp_parse_args($opts, $defaults);
    ?>
    <div class="wrap">
      <h1>ACE Performance Fixer</h1>
      <form method="post">
        <?php wp_nonce_field('apf_save','apf_nonce'); ?>
        <table class="form-table">
          <tr><th>Defer non-critical JS</th>
              <td><input type="checkbox" name="defer_js" value="1" <?php checked(1, $opts['defer_js']); ?>></td></tr>
          <tr><th>Delay Google Tag Manager / GA</th>
              <td><input type="checkbox" name="delay_gtm" value="1" <?php checked(1, $opts['delay_gtm']); ?>></td></tr>
          <tr><th>Delay Facebook Pixel</th>
              <td><input type="checkbox" name="delay_fb" value="1" <?php checked(1, $opts['delay_fb']); ?>></td></tr>
          <tr><th>Delay reCAPTCHA</th>
              <td><input type="checkbox" name="delay_recaptcha" value="1" <?php checked(1, $opts['delay_recaptcha']); ?>></td></tr>
          <tr><th>Delay after interaction (ms)</th>
              <td><input type="number" name="delay_after_interaction_ms" value="<?php echo intval($opts['delay_after_interaction_ms']); ?>" min="0"></td></tr>
          <tr><th>Script allowlist (comma separated handles)</th>
              <td><input type="text" name="script_allowlist" value="<?php echo esc_attr($opts['script_allowlist']); ?>" style="width:100%"></td></tr>
          <tr><th>Delay URL patterns (comma separated)</th>
              <td><input type="text" name="delay_url_patterns" value="<?php echo esc_attr($opts['delay_url_patterns']); ?>" style="width:100%"><p class="description">Scripts whose src contains any of these substrings will be delayed (GTM/GA/FB/recaptcha by default).</p></td></tr>
        </table>
        <p><input type="submit" class="button button-primary" value="Save Settings"></p>
      </form>
      <p><strong>Notes:</strong> If some functionality breaks (sliders, forms), add the script handle to the allowlist above.</p>
    </div>
    <?php
}

// --------------------- Helper ---------------------
function apf_allowlist_array() {
    $raw = apf_get('script_allowlist');
    $arr = array();
    foreach (explode(',', $raw) as $s) { $s = trim($s); if ($s) $arr[] = $s; }
    return $arr;
}
function apf_delay_patterns() {
    $raw = apf_get('delay_url_patterns');
    $arr = array();
    foreach (explode(',', $raw) as $s) { $s = trim($s); if ($s) $arr[] = $s; }
    return $arr;
}

// --------------------- Defer non-critical JS ---------------------
if (apf_get('defer_js')) {
    add_filter('script_loader_tag', function($tag, $handle, $src) {
        if (is_admin()) return $tag;
        if (empty($src)) return $tag;

        // allowlist by handle
        foreach (apf_allowlist_array() as $a) {
            if (stripos($handle, $a) !== false) return $tag;
        }

        // don't touch inline scripts or already deferred/async
        if (stripos($tag, ' defer') !== false || stripos($tag, ' async') !== false) return $tag;

        // don't defer admin or critical WP scripts (very conservative)
        if (stripos($src, '/wp-admin/') !== false) return $tag;

        // safely add defer
        return str_replace(' src', ' defer src', $tag);
    }, 10, 3);
}

// --------------------- Delay third-party scripts client-side ---------------------
add_action('wp_head', function() {
    // build list of patterns to delay depending on settings
    $patterns = apf_delay_patterns();
    // but remove patterns that users toggled off
    if (!apf_get('delay_gtm')) {
        // remove common GTM pattern(s)
        foreach (['googletagmanager','gtag/js','google-analytics'] as $p) {
            $idx = array_search($p, $patterns);
            if ($idx !== false) unset($patterns[$idx]);
        }
    }
    if (!apf_get('delay_fb')) {
        foreach (['connect.facebook.net','fbq','fbevents'] as $p) {
            $idx = array_search($p, $patterns);
            if ($idx !== false) unset($patterns[$idx]);
        }
    }
    if (!apf_get('delay_recaptcha')) {
        foreach (['recaptcha','www.google.com/recaptcha'] as $p) {
            $idx = array_search($p, $patterns);
            if ($idx !== false) unset($patterns[$idx]);
        }
    }

    // If no patterns, bail
    if (empty($patterns)) return;

    // produce JSON for JS
    $json_patterns = wp_json_encode(array_values($patterns));
    $delay_ms = intval(apf_get('delay_after_interaction_ms'));

    // This inline script does:
    // 1) on DOMContentLoaded, finds <script src="..."> whose src contains any pattern and removes it (so browser won't fetch).
    // 2) stores those srcs in window.__apf_delayedScripts
    // 3) attaches an interaction listener; on first interaction it will inject those scripts back (optionally after delay_ms)
    echo "<script id='apf-delay-scripts'>\n";
    echo "(function(){\n";
    echo "var patterns = {$json_patterns};\n";
    echo "var delay_ms = {$delay_ms};\n";
    echo "window.__apf_delayedScripts = window.__apf_delayedScripts || [];\n";
    echo "function matchesPattern(src){ if(!src) return false; src = src.toLowerCase(); for(var i=0;i<patterns.length;i++){ if(src.indexOf(patterns[i].toLowerCase())!==-1) return true; } return false; }\n";
    echo "document.addEventListener('DOMContentLoaded', function(){\n";
    echo "  var scripts = Array.prototype.slice.call(document.querySelectorAll('script[src]'));\n";
    echo "  for(var i=0;i<scripts.length;i++){ var s = scripts[i]; var src = s.getAttribute('src'); if(matchesPattern(src)){\n";
    // store any inline attributes or special content too (data attributes used by some trackers)
    echo "      window.__apf_delayedScripts.push({ src: src, attrs: Array.prototype.slice.call(s.attributes).map(function(a){return {name:a.name,value:a.value};}) });\n";
    echo "      s.parentNode && s.parentNode.removeChild(s);\n";
    echo "  } }\n";
    echo "}, false);\n";

    // interaction handler
    echo "function loadDelayed(){ if(!window.__apf_delayedScripts || !window.__apf_delayedScripts.length) return; function inject(){ window.__apf_delayedScripts.forEach(function(o){ try{ var s = document.createElement('script'); s.src = o.src; s.async = false; // maintain execution order; do not set defer\n";
    // reapply attributes if any
    echo "    if(o.attrs && o.attrs.length){ o.attrs.forEach(function(a){ try{ if(a.name !== 'src') s.setAttribute(a.name,a.value); }catch(e){} }); }\n";
    echo "    document.body.appendChild(s);\n";
    echo "  }catch(e){} }); window.__apf_delayedScripts = []; }\n";
    echo "  if(delay_ms && delay_ms>0){ setTimeout(inject, delay_ms); } else { inject(); } \n";
    echo "  removeInteractionListeners(); }\n";
    echo "function addInteractionListeners(){ ['scroll','keydown','pointerdown','touchstart'].forEach(function(ev){ document.addEventListener(ev, loadDelayed, {once:true, passive:true}); }); }\n";
    echo "function removeInteractionListeners(){ ['scroll','keydown','pointerdown','touchstart'].forEach(function(ev){ document.removeEventListener(ev, loadDelayed); }); }\n";
    echo "addInteractionListeners();\n";
    echo "})();\n";
    echo "</script>\n";
}, 1);

// --------------------- Small admin hint --------------
add_action('admin_notices', function() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="notice notice-info is-dismissible"><p><strong>ACE Performance Fixer:</strong> active. Check settings at Settings → ACE Performance Fixer. If any UI breaks, add the script handle to the allowlist.</p></div>';
});
