<?php
/**
 * Plugin Name: AceWeb Forced Reflow Fix
 * Plugin URI:  https://aceweb.bh/
 * Description: Reduces forced reflows by providing runtime protections: caches getBoundingClientRect calls per frame, exposes a batched write helper, dispatches throttled scroll/resize events, an admin settings page, debug overlay and automatic sticky-header handling.
 * Version:     1.1.0
 * Author:      Adina Pervaiz
 * License:     GPLv2+
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class AceFR_Plugin {
    const OPT_KEY = 'acefr_settings';

    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_notices', array($this, 'admin_notice'));
    }

    public function add_admin_menu() {
        add_options_page('AceFR Fix', 'AceFR Fix', 'manage_options', 'acefr-fix', array($this, 'settings_page'));
    }

    public function register_settings() {
        register_setting(self::OPT_KEY, self::OPT_KEY, array($this, 'sanitize_options'));
        add_settings_section('acefr_main', 'Runtime Protections', null, 'acefr-fix');
        add_settings_field('enable_gbr', 'Cache getBoundingClientRect', array($this, 'field_checkbox'), 'acefr-fix', 'acefr_main', array('key'=>'enable_gbr'));
        add_settings_field('enable_cs', 'Cache getComputedStyle', array($this, 'field_checkbox'), 'acefr-fix', 'acefr_main', array('key'=>'enable_cs'));
        add_settings_field('enable_throttle', 'Throttled scroll/resize events', array($this, 'field_checkbox'), 'acefr-fix', 'acefr_main', array('key'=>'enable_throttle'));
        add_settings_field('enable_sticky', 'Sticky header CSS fallback', array($this, 'field_checkbox'), 'acefr-fix', 'acefr_main', array('key'=>'enable_sticky'));
        add_settings_field('enable_debug', 'Enable debug overlay', array($this, 'field_checkbox'), 'acefr-fix', 'acefr_main', array('key'=>'enable_debug'));
        add_settings_field('sticky_selectors', 'Sticky selectors', array($this, 'field_text'), 'acefr-fix', 'acefr_main', array('key'=>'sticky_selectors'));
    }

    public function sanitize_options($in) {
        $out = get_option(self::OPT_KEY, array());
        $out['enable_gbr'] = isset($in['enable_gbr']) ? 1 : 0;
        $out['enable_cs'] = isset($in['enable_cs']) ? 1 : 0;
        $out['enable_throttle'] = isset($in['enable_throttle']) ? 1 : 0;
        $out['enable_sticky'] = isset($in['enable_sticky']) ? 1 : 0;
        $out['enable_debug'] = isset($in['enable_debug']) ? 1 : 0;
        $out['sticky_selectors'] = sanitize_text_field($in['sticky_selectors']);
        return $out;
    }

    public function field_checkbox($args) {
        $opts = get_option(self::OPT_KEY, array());
        $key = $args['key'];
        $val = !empty($opts[$key]) ? 1 : 0;
        printf('<input type="checkbox" name="%s[%s]" value="1" %s />', esc_attr(self::OPT_KEY), esc_attr($key), checked(1, $val, false));
    }

    public function field_text($args) {
        $opts = get_option(self::OPT_KEY, array());
        $key = $args['key'];
        $val = isset($opts[$key]) ? esc_attr($opts[$key]) : 'header,.site-header,.elementor-sticky,.sticky-header';
        printf('<input style="width:100%%" type="text" name="%s[%s]" value="%s" />', esc_attr(self::OPT_KEY), esc_attr($key), $val);
        echo '<p class="description">Comma-separated CSS selectors the plugin will try to convert to CSS-sticky when sticky fallback is enabled.</p>';
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) return;
        ?>
        <div class="wrap">
            <h1>AceFR Forced Reflow Fix</h1>
            <form method="post" action="options.php">
                <?php settings_fields(self::OPT_KEY); do_settings_sections('acefr-fix'); submit_button(); ?>
            </form>
            <h2>Usage</h2>
            <ul>
                <li>Use <code>window.acefr.batchedWrite(fn)</code> to schedule DOM writes.</li>
                <li>Listen to <code>acefr:scroll</code> and <code>acefr:resize</code> events instead of raw scroll/resize for rAF-throttled callbacks.</li>
                <li>Add <code>data-acefr-sticky</code> to a header element or list selectors in settings to apply the CSS sticky fallback.</li>
            </ul>
        </div>
        <?php
    }

    public function enqueue_assets() {
        // Read options
        $opts = get_option(self::OPT_KEY, array(
            'enable_gbr' => 1,
            'enable_cs' => 1,
            'enable_throttle' => 1,
            'enable_sticky' => 1,
            'enable_debug' => 0,
            'sticky_selectors' => 'header,.site-header,.elementor-sticky,.sticky-header'
        ));

        wp_register_style('acefr-inline-handle', false);
        wp_enqueue_style('acefr-inline-handle');

        wp_register_script('acefr-inline-handle', '', array(), '1.1', true);
        wp_enqueue_script('acefr-inline-handle');

        $inline = $this->get_inline_js($opts);
        wp_add_inline_script('acefr-inline-handle', $inline);

        // Minimal CSS used by the plugin
        $css = ".acefr-sticky-fallback{position:sticky !important;top:0;z-index:9999;}
.acefr-debug-overlay{position:fixed;right:12px;bottom:12px;background:rgba(0,0,0,0.7);color:#fff;padding:8px 10px;border-radius:6px;font-family:monospace;font-size:12px;z-index:999999;pointer-events:none;opacity:0.9;}";
        if ($opts['enable_debug']) {
            $css .= '
.acefr-debug-overlay .acefr-row{margin-bottom:4px;}';
        }
        wp_add_inline_style('acefr-inline-handle', $css);
    }

    private function get_inline_js($opts) {
        $enable_gbr = !empty($opts['enable_gbr']) ? 'true' : 'false';
        $enable_cs = !empty($opts['enable_cs']) ? 'true' : 'false';
        $enable_throttle = !empty($opts['enable_throttle']) ? 'true' : 'false';
        $enable_sticky = !empty($opts['enable_sticky']) ? 'true' : 'false';
        $enable_debug = !empty($opts['enable_debug']) ? 'true' : 'false';
        $sticky_selectors = isset($opts['sticky_selectors']) ? esc_js($opts['sticky_selectors']) : 'header,.site-header,.elementor-sticky,.sticky-header';

$js = "(function(){'use strict';if(typeof window==='undefined'||!window.requestAnimationFrame)return;window.acefr=window.acefr||{};window.acefr._config={gbr:$enable_gbr,cs:$enable_cs,throttle:$enable_throttle,sticky:$enable_sticky,debug:$enable_debug,selectors:'$sticky_selectors'};var debugCounters={gbr:0,cs:0,writes:0,frames:0};if(window.acefr._config.gbr)(function(){var orig=Element.prototype.getBoundingClientRect;if(!orig)return;var cache=new WeakMap();var frameId=null;function clearCache(){cache=new WeakMap();frameId=null;}Element.prototype.getBoundingClientRect=function(){var entry=cache.get(this);if(entry){debugCounters.gbr++;return entry.rect;}var rect=orig.call(this);cache.set(this,{rect:rect});if(!frameId)frameId=requestAnimationFrame(clearCache);return rect;};})();if(window.acefr._config.cs)(function(){if(!window.getComputedStyle)return;var origCS=window.getComputedStyle.bind(window);var csCache=new Map();var csFrame=null;function clearCS(){csCache.clear();csFrame=null;}window.getComputedStyle=function(el){try{var key=el&&(el.__acefr_cs_id||(el.__acefr_cs_id=Math.random().toString(36).slice(2)));var cached=csCache.get(key);if(cached){debugCounters.cs++;return cached;}var style=origCS(el);csCache.set(key,style);if(!csFrame)csFrame=requestAnimationFrame(clearCS);return style;}catch(e){return origCS(el);}};})();(function(){var writeQueue=[];var scheduled=false;function runWrites(){scheduled=false;var q=writeQueue.splice(0);for(var i=0;i<q.length;i++){try{q[i]();debugCounters.writes++;}catch(e){console.error('acefr write error',e);}}}window.acefr.batchedWrite=function(fn){if(typeof fn!=='function')return;writeQueue.push(fn);if(!scheduled){scheduled=true;requestAnimationFrame(runWrites);}};})();if(window.acefr._config.throttle)(function(){var scrolling=false;var resizing=false;window.addEventListener('scroll',function(){if(scrolling)return;scrolling=true;requestAnimationFrame(function(){scrolling=false;window.dispatchEvent(new CustomEvent('acefr:scroll',{detail:{time:Date.now()}}));});},{passive:true});window.addEventListener('resize',function(){if(resizing)return;resizing=true;requestAnimationFrame(function(){resizing=false;window.dispatchEvent(new CustomEvent('acefr:resize',{detail:{time:Date.now()}}));});},{passive:true});})();if(window.acefr._config.sticky)(function(){function applySticky(nodes){for(var i=0;i<nodes.length;i++){try{nodes[i].classList.add('acefr-sticky-fallback');nodes[i].setAttribute('data-acefr-sticky','1');}catch(e){}}}try{var attrNodes=document.querySelectorAll('[data-acefr-sticky]');if(attrNodes&&attrNodes.length)applySticky(attrNodes);var selectors=window.acefr._config.selectors.split(',').map(function(s){return s.trim();}).filter(Boolean);if(selectors.length){var sel=selectors.join(',');var nodes=document.querySelectorAll(sel);if(nodes&&nodes.length)applySticky(nodes);}}catch(e){}})();if(window.acefr._config.debug)(function(){var ov=document.createElement('div');ov.className='acefr-debug-overlay';ov.innerHTML='<div class=\"acefr-row\">gbr:<span id=\"acefr-gbr\">0</span></div><div class=\"acefr-row\">cs:<span id=\"acefr-cs\">0</span></div><div class=\"acefr-row\">writes:<span id=\"acefr-writes\">0</span></div><div class=\"acefr-row\">fps:<span id=\"acefr-fps\">0</span></div>';document.body.appendChild(ov);var last=performance.now();var frames=0;function tick(){frames++;debugCounters.frames++;var now=performance.now();if(now-last>=1000){var g=document.getElementById('acefr-gbr');if(g)g.textContent=debugCounters.gbr;var c=document.getElementById('acefr-cs');if(c)c.textContent=debugCounters.cs;var w=document.getElementById('acefr-writes');if(w)w.textContent=debugCounters.writes;var f=document.getElementById('acefr-fps');if(f)f.textContent=frames;frames=0;last=now;debugCounters.gbr=0;debugCounters.cs=0;debugCounters.writes=0;}requestAnimationFrame(tick);}requestAnimationFrame(tick);})();window.acefr._debugGet=function(){return Object.assign({},debugCounters);};})();";

        return $js;
    }

    public function admin_notice() {
        if (!current_user_can('activate_plugins')) return;
        echo '<div class="notice notice-success is-dismissible"><p>AceWeb Forced Reflow Fix plugin is active. Go to <a href="options-general.php?page=acefr-fix">Settings → AceFR Fix</a> to configure runtime protections, debug overlay, and sticky header selectors.</p></div>';
    }

}

new AceFR_Plugin();

// End of file
