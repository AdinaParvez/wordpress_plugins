jQuery(document).ready(function($) {

    // ✅ Prevent duplicate binding by using .off().on()
    $(document).off('submit', '#aceReviewForm').on('submit', '#aceReviewForm', function(e) {
        e.preventDefault();

        let formData = new FormData(this);
        formData.append('action', 'submit_ace_review');
        formData.append('security', aceReviewsAjax.nonce);

        $.ajax({
            url: aceReviewsAjax.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    // ✅ Close review form modal
                    $('#googleReviewModal').fadeOut();

                    // ✅ Show thank you modal
                    $('#thankYouModal').fadeIn();

                    // ✅ Auto close after 3s + refresh
                    setTimeout(function() {
                        $('#thankYouModal').fadeOut();
                        location.reload();
                    }, 3000);
                } else {
                    alert(response.data.message || "Something went wrong.");
                }
            },
            error: function() {
                alert("Server error. Please try again.");
            }
        });
    });

    // ✅ Open Review Modal
    $(document).off('click', '#openReviewModal').on('click', '#openReviewModal', function(e) {
        e.preventDefault();
        $('#googleReviewModal').fadeIn();
    });

    // ✅ Close on [X] button
    $(document).off('click', '.ace-close').on('click', '.ace-close', function(e) {
        e.preventDefault();
        $(this).closest('.ace-modal').fadeOut();
    });

    // ✅ Close when clicking outside modal content
    $(window).on('click', function(e) {
        if ($(e.target).hasClass('ace-modal')) {
            $(e.target).fadeOut();
        }
    });

    // ✅ File upload preview
    $(document).off('change', '#profile_pic').on('change', '#profile_pic', function() {
        const fileName = this.files[0] ? this.files[0].name : 'No file chosen';
        $(this).siblings('.file-upload-label').find('.file-name').text(fileName);
    });

});
