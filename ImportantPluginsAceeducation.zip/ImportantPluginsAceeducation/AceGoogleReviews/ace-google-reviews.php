<?php
/*
Plugin Name: ACE Google Reviews
Description: Display student reviews with profile picture upload, ratings, and carousel. Use shortcode [ace_google_reviews].
Version: 2.0
Author: Adina Pervaiz
*/

if (!defined('ABSPATH')) exit;

class ACE_Google_Reviews {

    public function __construct() {
        add_action('init', [$this, 'register_review_cpt']);
        add_shortcode('ace_google_reviews', [$this, 'render_reviews']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_submit_ace_review', [$this, 'handle_form_submission']);
        add_action('wp_ajax_nopriv_submit_ace_review', [$this, 'handle_form_submission']);
    }

    // ✅ Register custom post type
    public function register_review_cpt() {
        register_post_type('ace_review', [
            'labels' => [
                'name' => __('ACE Reviews', 'ace'),
                'singular_name' => __('ACE Review', 'ace')
            ],
            'public' => false,
            'show_ui' => true,
            'supports' => ['title', 'editor'],
            'menu_icon' => 'dashicons-format-status', // nicer admin icon
        ]);
    }

    // ✅ Enqueue CSS + JS
    public function enqueue_assets() {
        wp_enqueue_style(
            'ace-reviews-css',
            plugin_dir_url(__FILE__) . 'style.css',
            [],
            filemtime(plugin_dir_path(__FILE__) . 'style.css')
        );

        wp_enqueue_script(
            'ace-reviews-js',
            plugin_dir_url(__FILE__) . 'script.js',
            ['jquery'],
            filemtime(plugin_dir_path(__FILE__) . 'script.js'),
            true
        );

        wp_localize_script('ace-reviews-js', 'aceReviewsAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('ace_reviews_nonce'),
        ]);
    }

    // ✅ Handle form submission securely
    public function handle_form_submission() {
        check_ajax_referer('ace_reviews_nonce', 'security');

        $name    = sanitize_text_field($_POST['name'] ?? '');
        $email   = sanitize_email($_POST['email'] ?? '');
        $course  = sanitize_text_field($_POST['course'] ?? '');
        $rating  = intval($_POST['rating'] ?? 0);
        $content = sanitize_textarea_field($_POST['content'] ?? '');
        $date    = current_time('Y-m-d');

        if (empty($name) || empty($email) || empty($rating) || empty($content)) {
            wp_send_json_error(['message' => 'Please fill all required fields.']);
        }

        // ✅ Handle image upload
        $image_url = '';
        if (!empty($_FILES['profile_pic']['name'])) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            $upload = wp_handle_upload($_FILES['profile_pic'], ['test_form' => false]);

            if (!isset($upload['error']) && isset($upload['url'])) {
                $image_url = esc_url_raw($upload['url']);
            }
        }

        // ✅ Save review in custom post type
        $post_id = wp_insert_post([
            'post_title'   => $name,
            'post_content' => $content,
            'post_type'    => 'ace_review',
            'post_status'  => 'publish',
        ]);

        if ($post_id) {
            update_post_meta($post_id, 'ace_email', $email);
            update_post_meta($post_id, 'ace_course', $course);
            update_post_meta($post_id, 'ace_rating', $rating);
            update_post_meta($post_id, 'ace_date', $date);
            update_post_meta($post_id, 'ace_image', $image_url);

            wp_send_json_success(['message' => 'Review submitted successfully!']);
        } else {
            wp_send_json_error(['message' => 'Failed to submit review.']);
        }
    }

    // ✅ Render reviews shortcode
    public function render_reviews() {
        ob_start();

        $reviews = get_posts([
            'post_type'   => 'ace_review',
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby'     => 'date',
            'order'       => 'DESC'
        ]);
        ?>

        <div class="ace-reviews-wrapper">
            <h3><i class="fab fa-google"></i> <?php _e('Student Google Reviews', 'ace'); ?></h3>
            
            <div class="ace-reviews-grid">
                <?php foreach ($reviews as $review): 
                    $course = get_post_meta($review->ID, 'ace_course', true);
                    $rating = intval(get_post_meta($review->ID, 'ace_rating', true));
                    $date   = get_post_meta($review->ID, 'ace_date', true);
                    $image  = get_post_meta($review->ID, 'ace_image', true);
                    $stars  = str_repeat('★', $rating) . str_repeat('☆', max(0, 5 - $rating));
                ?>
                <div class="ace-review-card">
                    <div class="ace-review-header">
                        <?php if ($image): ?>
                            <img src="<?php echo esc_url($image); ?>" class="ace-review-avatar" alt="<?php echo esc_attr($review->post_title); ?>">
                        <?php else: 
                            $initials = strtoupper(substr($review->post_title, 0, 1)); ?>
                            <div class="ace-review-avatar initials"><?php echo esc_html($initials); ?></div>
                        <?php endif; ?>
                        <div>
                            <h5><?php echo esc_html($review->post_title); ?></h5>
                            <div class="ace-stars"><?php echo esc_html($stars); ?></div>
                            <span><?php echo esc_html($course); ?></span>
                        </div>
                    </div>
                    <p><?php echo esc_html($review->post_content); ?></p>
                    <div class="ace-review-date"><?php echo esc_html($date); ?></div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Write Review Button -->
            <div class="ace-review-button">
                <button type="button" id="openReviewModal"><?php _e('Write a Review', 'ace'); ?></button>
            </div>
        </div>

        <!-- Review Modal -->
        <div id="googleReviewModal" class="ace-modal">
            <div class="ace-modal-content">
                <span class="ace-close">&times;</span>
                <h4><?php _e('Write a Review', 'ace'); ?></h4>
                <form id="aceReviewForm" enctype="multipart/form-data">
                    <input type="text" name="name" placeholder="<?php esc_attr_e('Your Name *', 'ace'); ?>" required>
                    <input type="email" name="email" placeholder="<?php esc_attr_e('Your Email *', 'ace'); ?>" required>
                    <input type="text" name="course" placeholder="<?php esc_attr_e('Course Taken', 'ace'); ?>">
                    <input type="number" name="rating" placeholder="<?php esc_attr_e('Rating (1-5)', 'ace'); ?>" min="1" max="5" required>
                    <textarea name="content" placeholder="<?php esc_attr_e('Your Review *', 'ace'); ?>" required></textarea>
                    
                    <!-- ✅ Better styled file upload -->
                    <div class="file-upload-wrapper">
                        <label for="profile_pic" class="file-upload-label">
                            <span class="upload-icon">📷</span>
                            <span class="upload-text"><?php _e('Upload Profile Picture (Optional)', 'ace'); ?></span>
                            <span class="file-name"><?php _e('No file chosen', 'ace'); ?></span>
                        </label>
                        <input type="file" name="profile_pic" id="profile_pic" accept="image/*">
                    </div>
                    
                    <button type="submit"><?php _e('Submit Review', 'ace'); ?></button>
                </form>
            </div>
        </div>

        <!-- Thank You Modal -->
        <div id="thankYouModal" class="ace-modal">
            <div class="ace-modal-content">
                <span class="ace-close">&times;</span>
                <h4>🎉 <?php _e('Thank You!', 'ace'); ?></h4>
                <p><?php _e('Your review has been submitted successfully.', 'ace'); ?></p>
            </div>
        </div>

        <?php
        return ob_get_clean();
    }
}

// ✅ Elementor widget compatibility
add_action('elementor/widgets/register', function($widgets_manager) {
    if ( class_exists('\Elementor\Widget_Base') ) {
        class ACE_Google_Reviews_Widget extends \Elementor\Widget_Base {
            public function get_name() { return 'ace_google_reviews_widget'; }
            public function get_title() { return __('ACE Google Reviews', 'ace'); }
            public function get_icon() { return 'eicon-comments'; }
            public function get_categories() { return ['general']; }
            public function render() {
                echo do_shortcode('[ace_google_reviews]');
            }
        }
        $widgets_manager->register(new ACE_Google_Reviews_Widget());
    }
});

// ✅ Boot the plugin
new ACE_Google_Reviews();
