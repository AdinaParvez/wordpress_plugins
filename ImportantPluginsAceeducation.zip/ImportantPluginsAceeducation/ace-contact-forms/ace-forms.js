/**
 * ACE Contact Forms JavaScript
 * Handles form submissions for WordPress
 */

(function($) {
    'use strict';
    
    // Form handler class
    class ACEWordPressFormHandler {
        constructor() {
            this.init();
        }
        
        init() {
            // Wait for DOM to be ready
            $(document).ready(() => {
                this.bindEvents();
            });
        }
        
        bindEvents() {
            // Handle all forms with class 'ace-contact-form' or common IDs
            const formSelectors = [
                '#contactForm',
                '#enrollForm', 
                '#trialForm',
                '.ace-contact-form',
                'form[data-ace-form]'
            ].join(',');
            
            $(document).on('submit', formSelectors, (e) => {
                this.handleSubmit(e);
            });
        }
        
        async handleSubmit(e) {
            e.preventDefault();
            
            const $form = $(e.target);
            const $submitBtn = $form.find('button[type="submit"], input[type="submit"]');
            const $messageDiv = $form.find('[id*="Msg"], .form-message, .message, [id*="formMsg"]').first();
            
            // Get form data
            const formData = new FormData($form[0]);
            
            // Add WordPress-specific data
            formData.append('action', 'ace_submit_form');
            formData.append('nonce', ace_ajax.nonce);
            
            // Auto-detect form type if not specified
            if (!formData.get('form_type')) {
                formData.append('form_type', this.detectFormType());
            }
            
            // Show loading state
            const originalBtnText = $submitBtn.text();
            $submitBtn.prop('disabled', true).text('Sending...');
            $messageDiv.hide();
            
            try {
                const response = await $.ajax({
                    url: ace_ajax.ajax_url,
                    method: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false
                });
                
                if (response.success) {
                    this.showMessage($messageDiv, response.data, 'success');
                    $form[0].reset();
                } else {
                    this.showMessage($messageDiv, response.data || 'An error occurred', 'error');
                }
                
            } catch (error) {
                console.error('Form submission error:', error);
                this.showMessage($messageDiv, 'Network error. Please try again.', 'error');
            } finally {
                // Reset button
                $submitBtn.prop('disabled', false).text(originalBtnText);
            }
        }
        
        showMessage($messageDiv, message, type) {
            if (!$messageDiv.length) return;
            
            $messageDiv
                .text(message)
                .css('color', type === 'success' ? 'green' : 'red')
                .show();
            
            // Auto-hide success messages
            if (type === 'success') {
                setTimeout(() => {
                    $messageDiv.fadeOut();
                }, 5000);
            }
        }
        
        detectFormType() {
            const url = window.location.href.toLowerCase();
            
            if (url.includes('corporate-english')) return 'corporate-english';
            if (url.includes('general-english')) return 'general-english';
            if (url.includes('ielts')) return 'ielts-preparation';
            if (url.includes('business-english')) return 'business-english';
            
            return 'default';
        }
    }
    
    // Initialize when WordPress AJAX is available
    if (typeof ace_ajax !== 'undefined') {
        new ACEWordPressFormHandler();
    }
    
})(jQuery);

// Vanilla JavaScript fallback for non-jQuery themes
if (typeof jQuery === 'undefined') {
    document.addEventListener('DOMContentLoaded', function() {
        class VanillaACEFormHandler {
            constructor() {
                this.bindEvents();
            }
            
            bindEvents() {
                const forms = document.querySelectorAll('#contactForm, #enrollForm, #trialForm, .ace-contact-form, [data-ace-form]');
                forms.forEach(form => {
                    form.addEventListener('submit', (e) => this.handleSubmit(e));
                });
            }
            
            async handleSubmit(e) {
                e.preventDefault();
                
                const form = e.target;
                const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
                const messageDiv = form.querySelector('[id*="Msg"], .form-message, .message, [id*="formMsg"]');
                
                const formData = new FormData(form);
                formData.append('action', 'ace_submit_form');
                formData.append('nonce', window.ace_ajax_nonce || '');
                
                if (!formData.get('form_type')) {
                    formData.append('form_type', this.detectFormType());
                }
                
                const originalText = submitBtn.textContent;
                submitBtn.disabled = true;
                submitBtn.textContent = 'Sending...';
                
                if (messageDiv) messageDiv.style.display = 'none';
                
                try {
                    const response = await fetch(window.ace_ajax_url || '/wp-admin/admin-ajax.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        this.showMessage(messageDiv, result.data, 'success');
                        form.reset();
                    } else {
                        this.showMessage(messageDiv, result.data || 'An error occurred', 'error');
                    }
                    
                } catch (error) {
                    console.error('Form submission error:', error);
                    this.showMessage(messageDiv, 'Network error. Please try again.', 'error');
                } finally {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            }
            
            showMessage(messageDiv, message, type) {
                if (!messageDiv) return;
                
                messageDiv.textContent = message;
                messageDiv.style.color = type === 'success' ? 'green' : 'red';
                messageDiv.style.display = 'block';
                
                if (type === 'success') {
                    setTimeout(() => {
                        messageDiv.style.display = 'none';
                    }, 5000);
                }
            }
            
            detectFormType() {
                const url = window.location.href.toLowerCase();
                
                if (url.includes('corporate-english')) return 'corporate-english';
                if (url.includes('general-english')) return 'general-english';
                if (url.includes('ielts')) return 'ielts-preparation';
                if (url.includes('business-english')) return 'business-english';
                
                return 'default';
            }
        }
        
        new VanillaACEFormHandler();
    });
}