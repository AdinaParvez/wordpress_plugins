<?php
/**
 * Plugin Name: ACE Contact Forms
 * Description: Universal contact form handler for ACE Language Centre
 * Version: 1.0
 * Author: Adina Pervaiz, ACE Language Centre
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ACE_Contact_Forms {
    
    public function __construct() {
        add_action('wp_ajax_ace_submit_form', array($this, 'handle_form_submission'));
        add_action('wp_ajax_nopriv_ace_submit_form', array($this, 'handle_form_submission'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_head', array($this, 'add_ajax_url'));
    }
    
    /**
     * Enqueue JavaScript for form handling
     */
    public function enqueue_scripts() {
        wp_enqueue_script('ace-forms', plugin_dir_url(__FILE__) . 'ace-forms.js', array('jquery'), '1.0', true);
        wp_localize_script('ace-forms', 'ace_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ace_form_nonce')
        ));
    }
    
    /**
     * Add AJAX URL to head for non-jQuery implementations
     */
    public function add_ajax_url() {
        echo '<script>window.ace_ajax_url = "' . admin_url('admin-ajax.php') . '";</script>';
    }
    
    /**
     * Handle form submission
     */
    public function handle_form_submission() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'ace_form_nonce')) {
            wp_die('Security check failed');
        }
        
        // Sanitize input data
        $fullname = sanitize_text_field($_POST['fullname'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $company = sanitize_text_field($_POST['company'] ?? '');
        $preferred = sanitize_text_field($_POST['preferred'] ?? '');
        $message = sanitize_textarea_field($_POST['message'] ?? '');
        $form_type = sanitize_text_field($_POST['form_type'] ?? '');
        
        // Validate required fields
        if (empty($fullname) || empty($email)) {
            wp_send_json_error('Name and email are required');
            return;
        }
        
        if (!is_email($email)) {
            wp_send_json_error('Invalid email format');
            return;
        }
        
        // Determine form type
        $form_type = $this->detect_form_type($form_type);
        $form_config = $this->get_form_config($form_type);
        
        // Prepare email
        $to = get_option('ace_contact_email', 'info@acelanguagecentre.my');
        $subject = $form_config['subject_prefix'] . ' - ' . $fullname;
        $email_body = $this->generate_email_template(array(
            'form_name' => $form_config['name'],
            'fullname' => $fullname,
            'email' => $email,
            'phone' => $phone,
            'company' => $company,
            'preferred' => $preferred,
            'message' => $message,
            'site_url' => get_site_url(),
            'page_url' => wp_get_referer()
        ));
        
        // Email headers
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <info@' . parse_url(get_site_url(), PHP_URL_HOST) . '>',
            'Reply-To: ' . $email
        );
        
        // Send email
        $sent = wp_mail($to, $subject, $email_body, $headers);
        
        if ($sent) {
            // Log successful submission
            error_log("ACE Language Centre Form Submission Success: {$form_type} - {$email}");
            wp_send_json_success('Thank you for your inquiry! We will contact you soon.');
        } else {
            // Log failed submission
            error_log("ACE Language Centre Form Submission Failed: {$form_type} - {$email}");
            wp_send_json_error('Sorry, there was an error sending your message. Please try again.');
        }
    }
    
    /**
     * Detect form type from various sources
     */
    private function detect_form_type($form_type) {
        if (!empty($form_type)) {
            return $form_type;
        }
        
        $referer = wp_get_referer();
        if (!$referer) {
            return 'default';
        }
        
        $url = strtolower($referer);
        
        if (strpos($url, 'corporate-english') !== false) {
            return 'corporate-english';
        } elseif (strpos($url, 'general-english') !== false) {
            return 'general-english';
        } elseif (strpos($url, 'ielts') !== false) {
            return 'ielts-preparation';
        } elseif (strpos($url, 'business-english') !== false) {
            return 'business-english';
        }
        
        return 'default';
    }
    
    /**
     * Get form configuration
     */
    private function get_form_config($form_type) {
        $configs = array(
            'corporate-english' => array(
                'name' => 'Corporate English Training',
                'subject_prefix' => 'Corporate English Training Inquiry'
            ),
            'general-english' => array(
                'name' => 'General English Programme', 
                'subject_prefix' => 'General English Programme Inquiry'
            ),
            'ielts-preparation' => array(
                'name' => 'IELTS Preparation Course',
                'subject_prefix' => 'IELTS Course Inquiry'
            ),
            'business-english' => array(
                'name' => 'Business English Programme',
                'subject_prefix' => 'Business English Inquiry'
            ),
            'default' => array(
                'name' => 'Course Inquiry',
                'subject_prefix' => 'General Inquiry'
            )
        );
        
        return $configs[$form_type] ?? $configs['default'];
    }
    
    /**
     * Generate email template
     */
    private function generate_email_template($data) {
        ob_start();
        ?>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(90deg, #002D62, #FDB913); color: white; padding: 20px; border-radius: 8px 8px 0 0; }
                .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 8px 8px; }
                .field { margin-bottom: 15px; padding: 10px; background: white; border-radius: 5px; }
                .field strong { color: #002D62; }
                .footer { margin-top: 20px; font-size: 12px; color: #666; text-align: center; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2 style="margin: 0;">New <?php echo esc_html($data['form_name']); ?> Inquiry</h2>
                </div>
                <div class="content">
                    <?php if (!empty($data['fullname'])): ?>
                        <div class="field"><strong>Full Name:</strong> <?php echo esc_html($data['fullname']); ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($data['email'])): ?>
                        <div class="field"><strong>Email:</strong> <?php echo esc_html($data['email']); ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($data['phone'])): ?>
                        <div class="field"><strong>Phone:</strong> <?php echo esc_html($data['phone']); ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($data['company'])): ?>
                        <div class="field"><strong>Company:</strong> <?php echo esc_html($data['company']); ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($data['preferred'])): ?>
                        <div class="field"><strong>Preferred Intake:</strong> <?php echo esc_html($data['preferred']); ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($data['message'])): ?>
                        <div class="field"><strong>Message:</strong><br><?php echo nl2br(esc_html($data['message'])); ?></div>
                    <?php endif; ?>
                    
                    <div class="field"><strong>Submitted From:</strong> <?php echo esc_url($data['page_url']); ?></div>
                </div>
                <div class="footer">
                    <p>This inquiry was submitted from <?php echo esc_html(get_bloginfo('name')); ?> on <?php echo date('Y-m-d H:i:s'); ?></p>
                </div>
            </div>
        </body>
        </html>
        <?php
        return ob_get_clean();
    }
}

// Initialize the plugin
new ACE_Contact_Forms();

// Add admin menu for settings
add_action('admin_menu', 'ace_contact_admin_menu');

function ace_contact_admin_menu() {
    add_options_page(
        'ACE Contact Forms',
        'ACE Contact Forms', 
        'manage_options',
        'ace-contact-forms',
        'ace_contact_admin_page'
    );
}

function ace_contact_admin_page() {
    if (isset($_POST['submit'])) {
        update_option('ace_contact_email', sanitize_email($_POST['ace_contact_email']));
        echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
    }
    
    $email = get_option('ace_contact_email', 'info@acelanguagecentre.my');
    ?>
    <div class="wrap">
        <h1>ACE Contact Forms Settings</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr>
                    <th scope="row">Contact Email</th>
                    <td>
                        <input type="email" name="ace_contact_email" value="<?php echo esc_attr($email); ?>" class="regular-text" />
                        <p class="description">All form submissions will be sent to this email address.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
?>