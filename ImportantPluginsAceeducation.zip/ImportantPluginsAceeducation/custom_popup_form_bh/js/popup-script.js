document.addEventListener('DOMContentLoaded', function() {
    const popup = document.getElementById('atpf-popup-modal');
    const closeBtn = document.getElementById('atpf-close-popup');

    function getCookie(name) {
        const value = "; " + document.cookie;
        const parts = value.split("; " + name + "=");
        if(parts.length === 2) return parts.pop().split(";").shift();
    }

    if(!getCookie('atpf_popup_seen')){
        popup.classList.add('active');
    }

    closeBtn.addEventListener('click', function(){
        popup.classList.remove('active');
        const d = new Date();
        d.setTime(d.getTime() + (7*24*60*60*1000));
        document.cookie = "atpf_popup_seen=true; expires=" + d.toUTCString() + "; path=/";
    });

    const phoneInput = document.querySelector("#atpf-phone");
    if(phoneInput){
        window.aptfTel = window.intlTelInput(phoneInput, {
            initialCountry: "bh",
            separateDialCode: true,
            nationalMode: false,
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js"
        });
        if(phoneInput.value.trim() === "") phoneInput.value = "+973 ";
    }

    const form = document.getElementById('atpf-popup-form');
    form.addEventListener('submit', function() {
        if(window.aptfTel) document.getElementById('atpf-phone-full').value = window.aptfTel.getNumber();
    });
});
