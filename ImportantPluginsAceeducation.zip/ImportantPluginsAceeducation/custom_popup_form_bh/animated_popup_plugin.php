<?php
/*
Plugin Name: Auto Popup Tutor Form Bahrain
Description: Popup tutor form on page load (Name, Email, Phone, Message). Bahrain code fixed.
Version: 2.1
Author: Adina Pervaiz
*/

// Enqueue CSS and JS
function aptf_enqueue_assets() {
    wp_enqueue_style('intl-tel-input-css', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/css/intlTelInput.min.css');
    wp_enqueue_script('intl-tel-input-js', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/intlTelInput.min.js', [], null, true);
    wp_enqueue_script('aptf-popup-js', plugin_dir_url(__FILE__).'popup-script.js', ['intl-tel-input-js'], null, true);
    wp_enqueue_style('aptf-popup-css', plugin_dir_url(__FILE__).'popup-style.css');
}
add_action('wp_enqueue_scripts', 'aptf_enqueue_assets');

// Print popup HTML in footer
function aptf_print_popup_html() { ?>
    <div id="aptf-popup-modal">
        <div id="aptf-popup-content">
            <span id="aptf-close-popup">&times;</span>
            <h2>Enquire About Tutor Services</h2>
            <form method="post" id="aptf-popup-form">
                <?php wp_nonce_field('aptf_form_action', 'aptf_form_nonce'); ?>
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input id="aptf-phone" type="tel" name="phone" placeholder="Phone Number" required>
                <input type="hidden" name="phone_full" id="aptf-phone-full">
                <textarea name="message" rows="4" placeholder="Your Message" required></textarea>
                <input type="submit" name="aptf_submit" value="Send Inquiry">
            </form>
        </div>
    </div>
<?php }
add_action('wp_footer', 'aptf_print_popup_html');

// Handle form submission
function aptf_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aptf_submit'])) {
        if (!isset($_POST['aptf_form_nonce']) || !wp_verify_nonce($_POST['aptf_form_nonce'], 'aptf_form_action')) return;

        $to = ['info@aceeducation.bh','acekl2018@gmail.com'];
        $subject = 'New Tutor Inquiry via Popup Form';

        $fields = [
            "Name" => sanitize_text_field($_POST['name']),
            "Email" => sanitize_email($_POST['email']),
            "Phone" => sanitize_text_field($_POST['phone_full'] ?? ''),
            "Message" => sanitize_textarea_field($_POST['message'])
        ];

        $message = '<html><body><h2>New Tutor Inquiry</h2><table>';
        foreach($fields as $label => $value){
            $message .= "<tr><td><strong>{$label}:</strong></td><td>{$value}</td></tr>";
        }
        $message .= '</table></body></html>';

        $headers = [
            'From: ACE Education Bahrain <no-reply@aceeducation.bh>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: '.sanitize_email($_POST['email'])
        ];

        wp_mail($to, $subject, $message, $headers);

        echo '<script>alert("Thank you! Your inquiry has been submitted.");</script>';
    }
}
add_action('init','aptf_handle_form');
