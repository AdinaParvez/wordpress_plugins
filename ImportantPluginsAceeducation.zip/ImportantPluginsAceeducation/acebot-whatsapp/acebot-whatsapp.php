<?php
/**
 * Plugin Name: AceBot WhatsApp — Single-file (Multi-agent)
 * Plugin URI:  https://example.com/
 * Description: Chat widget that routes to multiple WhatsApp agents, collects leads, stores them in DB, emails leads, and provides admin UI.
 * Version:     1.0.0
 * Author:      Adina Pervaiz
 * Text Domain: acebot-whatsapp
 */

if (!defined('ABSPATH')) exit;

class AceBot_WhatsApp_Single {
    private $option_name = 'acebot_whatsapp_options';
    private $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'acebot_leads';
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('wp_footer', array($this, 'maybe_print_widget'));
        add_action('wp_ajax_acebot_save_lead', array($this, 'ajax_save_lead'));
        add_action('wp_ajax_nopriv_acebot_save_lead', array($this, 'ajax_save_lead'));
        add_action('wp_ajax_acebot_track', array($this, 'ajax_track'));
        add_action('wp_ajax_nopriv_acebot_track', array($this, 'ajax_track'));
        add_action('wp_ajax_acebot_delete_lead', array($this, 'ajax_delete_lead'));

        register_activation_hook(__FILE__, array($this, 'on_activate'));
        register_deactivation_hook(__FILE__, array($this, 'on_deactivate'));
    }

    public function on_activate() {
        $this->create_table();
        // defaults
        $defaults = array(
            'phone_default' => '+60164777167',
            'button_text' => 'Chat on WhatsApp',
            'brand_color' => '#25D366',
            'logo_url' => '',
            'position' => 'bottom-right',
            'show_on_homepage' => 1,
            'open_on_load' => 0,
            'notify_email' => get_option('admin_email'),
            'agents' => array(
                array('label'=>'Admissions','phone'=>'+60164777167'),
                array('label'=>'Support','phone'=>'+60164777167')
            ),
            'i18n' => array(
                'title' => 'Chat with us',
                'placeholder_name' => 'Your name',
                'placeholder_email' => 'Email (optional)',
                'placeholder_phone' => 'Phone (optional)',
                'placeholder_message' => 'Your message',
                'send_button' => 'Send & Open WhatsApp'
            )
        );
        if (get_option($this->option_name) === false) {
            add_option($this->option_name, $defaults);
        } else {
            // ensure agents exist (backwards compat)
            $opts = get_option($this->option_name);
            if (empty($opts['agents'])) {
                $opts['agents'] = $defaults['agents'];
                update_option($this->option_name, $opts);
            }
        }
    }

    public function on_deactivate() {
        // keep data; uninstall will remove
    }

    private function create_table() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(191) NOT NULL,
            email varchar(191) NOT NULL,
            phone varchar(60) NOT NULL,
            message text NOT NULL,
            agent varchar(100) NOT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function register_settings() {
        register_setting($this->option_name, $this->option_name, array($this, 'sanitize_options'));
        add_settings_section('acebot_main', 'AceBot Settings', null, 'acebot-whatsapp');

        add_settings_field('phone_default', 'Default WhatsApp phone', array($this, 'field_phone_default'), 'acebot-whatsapp', 'acebot_main');
        add_settings_field('button_text', 'Button text', array($this, 'field_button_text'), 'acebot-whatsapp', 'acebot_main');
        add_settings_field('brand_color', 'Brand color', array($this, 'field_brand_color'), 'acebot-whatsapp', 'acebot_main');
        add_settings_field('logo_url', 'Logo URL', array($this, 'field_logo_url'), 'acebot-whatsapp', 'acebot_main');
        add_settings_field('position', 'Position', array($this, 'field_position'), 'acebot-whatsapp', 'acebot_main');
        add_settings_field('show_on_homepage', 'Show only on homepage', array($this, 'field_show_homepage'), 'acebot-whatsapp', 'acebot_main');
        add_settings_field('open_on_load', 'Open on page load', array($this, 'field_open_on_load'), 'acebot-whatsapp', 'acebot_main');
        add_settings_field('agents', 'Agents (one per line: Label | +60123456789)', array($this, 'field_agents'), 'acebot-whatsapp', 'acebot_main');
        add_settings_field('notify_email', 'Notification email', array($this, 'field_notify_email'), 'acebot-whatsapp', 'acebot_main');
        add_settings_field('i18n', 'Translations & placeholders', array($this, 'field_i18n'), 'acebot-whatsapp', 'acebot_main');
    }

    public function sanitize_options($input) {
        $out = array();
        $out['phone_default'] = preg_replace('/[^0-9+]/', '', $input['phone_default'] ?? '+60164777167');
        $out['button_text'] = sanitize_text_field($input['button_text'] ?? 'Chat on WhatsApp');
        $out['brand_color'] = sanitize_text_field($input['brand_color'] ?? '#25D366');
        $out['logo_url'] = esc_url_raw($input['logo_url'] ?? '');
        $out['position'] = in_array($input['position'] ?? 'bottom-right', array('bottom-right','bottom-left')) ? $input['position'] : 'bottom-right';
        $out['show_on_homepage'] = !empty($input['show_on_homepage']) ? 1 : 0;
        $out['open_on_load'] = !empty($input['open_on_load']) ? 1 : 0;
        $out['notify_email'] = sanitize_email($input['notify_email'] ?? get_option('admin_email'));

        // parse agents from textarea (agents_raw)
        $agents = array();
        if (!empty($input['agents_raw'])) {
            $lines = preg_split("/\r\n|\n|\r/", $input['agents_raw']);
            foreach ($lines as $ln) {
                $ln = trim($ln);
                if (empty($ln)) continue;
                if (strpos($ln, '|') !== false) list($label, $phone) = array_map('trim', explode('|', $ln, 2));
                else list($label, $phone) = array_map('trim', explode(',', $ln) + array('',''));
                $phone = preg_replace('/[^0-9+]/', '', $phone);
                if ($label && $phone) $agents[] = array('label' => sanitize_text_field($label), 'phone' => $phone);
            }
        }
        if (empty($agents)) {
            // fallback to previous stored agents or default
            $prev = get_option($this->option_name);
            $out['agents'] = $prev['agents'] ?? array(array('label'=>'Admissions','phone'=>'+60164777167'));
        } else {
            $out['agents'] = $agents;
        }

        // i18n
        $i = $input['i18n'] ?? array();
        $out['i18n'] = array(
            'title' => sanitize_text_field($i['title'] ?? 'Chat with us'),
            'placeholder_name' => sanitize_text_field($i['placeholder_name'] ?? 'Your name'),
            'placeholder_email' => sanitize_text_field($i['placeholder_email'] ?? 'Email (optional)'),
            'placeholder_phone' => sanitize_text_field($i['placeholder_phone'] ?? 'Phone (optional)'),
            'placeholder_message' => sanitize_text_field($i['placeholder_message'] ?? 'Your message'),
            'send_button' => sanitize_text_field($i['send_button'] ?? 'Send & Open WhatsApp')
        );

        return $out;
    }

    // Fields callbacks
    public function field_phone_default() {
        $opts = get_option($this->option_name);
        echo '<input name="' . esc_attr($this->option_name) . '[phone_default]" value="' . esc_attr($opts['phone_default'] ?? '+60164777167') . '" class="regular-text" />';
        echo '<p class="description">International format required, e.g. +60164777167</p>';
    }
    public function field_button_text() {
        $opts = get_option($this->option_name);
        echo '<input name="' . esc_attr($this->option_name) . '[button_text]" value="' . esc_attr($opts['button_text'] ?? 'Chat on WhatsApp') . '" class="regular-text" />';
    }
    public function field_brand_color() {
        $opts = get_option($this->option_name);
        echo '<input name="' . esc_attr($this->option_name) . '[brand_color]" value="' . esc_attr($opts['brand_color'] ?? '#25D366') . '" class="regular-text" />';
    }
    public function field_logo_url() {
        $opts = get_option($this->option_name);
        echo '<input name="' . esc_attr($this->option_name) . '[logo_url]" value="' . esc_attr($opts['logo_url'] ?? '') . '" class="regular-text" />';
        echo '<p class="description">Small logo image URL (optional)</p>';
    }
    public function field_position() {
        $opts = get_option($this->option_name);
        $pos = $opts['position'] ?? 'bottom-right';
        echo '<select name="' . esc_attr($this->option_name) . '[position]">';
        echo '<option value="bottom-right" ' . selected($pos,'bottom-right',false) . '>Bottom right</option>';
        echo '<option value="bottom-left" ' . selected($pos,'bottom-left',false) . '>Bottom left</option>';
        echo '</select>';
    }
    public function field_show_homepage() {
        $opts = get_option($this->option_name);
        $val = !empty($opts['show_on_homepage']);
        echo '<input type="checkbox" name="' . esc_attr($this->option_name) . '[show_on_homepage]" value="1" ' . checked($val,true,false) . ' /> Show only on homepage';
    }
    public function field_open_on_load() {
        $opts = get_option($this->option_name);
        $val = !empty($opts['open_on_load']);
        echo '<input type="checkbox" name="' . esc_attr($this->option_name) . '[open_on_load]" value="1" ' . checked($val,true,false) . ' /> Open chat automatically on page load';
    }
    public function field_agents() {
        $opts = get_option($this->option_name);
        $raw = '';
        if (!empty($opts['agents']) && is_array($opts['agents'])) {
            foreach ($opts['agents'] as $a) $raw .= ($a['label'] ?? '') . ' | ' . ($a['phone'] ?? '') . "\n";
        }
        echo '<textarea rows="6" cols="60" name="' . esc_attr($this->option_name) . '[agents_raw]" placeholder="One per line: Label | +60123456789">' . esc_textarea($raw) . '</textarea>';
    }
    public function field_notify_email() {
        $opts = get_option($this->option_name);
        echo '<input type="email" name="' . esc_attr($this->option_name) . '[notify_email]" value="' . esc_attr($opts['notify_email'] ?? get_option('admin_email')) . '" class="regular-text" />';
        echo '<p class="description">Email which will receive copies of leads (defaults to admin email)</p>';
    }
    public function field_i18n() {
        $opts = get_option($this->option_name);
        $i = $opts['i18n'] ?? array();
        echo '<p><strong>Widget title</strong>: <input name="' . esc_attr($this->option_name) . '[i18n][title]" value="' . esc_attr($i['title'] ?? 'Chat with us') . '" /></p>';
        echo '<p><strong>Name placeholder</strong>: <input name="' . esc_attr($this->option_name) . '[i18n][placeholder_name]" value="' . esc_attr($i['placeholder_name'] ?? 'Your name') . '" /></p>';
        echo '<p><strong>Email placeholder</strong>: <input name="' . esc_attr($this->option_name) . '[i18n][placeholder_email]" value="' . esc_attr($i['placeholder_email'] ?? 'Email (optional)') . '" /></p>';
        echo '<p><strong>Phone placeholder</strong>: <input name="' . esc_attr($this->option_name) . '[i18n][placeholder_phone]" value="' . esc_attr($i['placeholder_phone'] ?? 'Phone (optional)') . '" /></p>';
        echo '<p><strong>Message placeholder</strong>: <input name="' . esc_attr($this->option_name) . '[i18n][placeholder_message]" value="' . esc_attr($i['placeholder_message'] ?? 'Your message') . '" /></p>';
        echo '<p><strong>Send button</strong>: <input name="' . esc_attr($this->option_name) . '[i18n][send_button]" value="' . esc_attr($i['send_button'] ?? 'Send & Open WhatsApp') . '" /></p>';
    }

    public function admin_menu() {
        add_options_page('AceBot WhatsApp', 'AceBot WhatsApp', 'manage_options', 'acebot-whatsapp', array($this, 'settings_page'));
        add_menu_page('AceBot', 'AceBot', 'manage_options', 'acebot-main', array($this, 'leads_page'), 'dashicons-format-chat', 60);
        add_submenu_page('acebot-main', 'Leads & Analytics', 'Leads & Analytics', 'manage_options', 'acebot-leads', array($this, 'leads_page'));
    }

    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>AceBot WhatsApp — Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields($this->option_name);
                do_settings_sections('acebot-whatsapp');
                submit_button();
                ?>
            </form>
            <h2>Shortcode</h2>
            <p>Use <code>[ace_whatsapp_bot]</code> to place the widget manually in your theme.</p>
        </div>
        <?php
    }

    // Admin leads UI
    public function leads_page() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->table} ORDER BY created_at DESC LIMIT 200");

        echo '<div class="wrap"><h1>AceBot Leads & Analytics</h1>';
        echo '<p><a class="button" href="' . esc_url(add_query_arg('acebot_export','1')) . '">Export CSV (all)</a></p>';

        if (isset($_GET['acebot_export']) && $_GET['acebot_export'] == '1') {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="acebot-leads-' . date('Ymd') . '.csv"');
            $out = fopen('php://output','w');
            fputcsv($out, array('id','name','email','phone','message','agent','created_at'));
            foreach($wpdb->get_results("SELECT * FROM {$this->table} ORDER BY created_at DESC") as $r) {
                fputcsv($out, array($r->id,$r->name,$r->email,$r->phone,$r->message,$r->agent,$r->created_at));
            }
            exit;
        }

        echo '<table class="widefat fixed"><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Message</th><th>Agent</th><th>Created</th><th>Action</th></tr></thead><tbody>';
        foreach($rows as $r) {
            echo '<tr>';
            echo '<td>' . esc_html($r->id) . '</td>';
            echo '<td>' . esc_html($r->name) . '</td>';
            echo '<td>' . esc_html($r->email) . '</td>';
            echo '<td>' . esc_html($r->phone) . '</td>';
            echo '<td>' . esc_html(wp_trim_words($r->message, 12)) . '</td>';
            echo '<td>' . esc_html($r->agent) . '</td>';
            echo '<td>' . esc_html($r->created_at) . '</td>';
            echo '<td><a href="#" class="button acebot-delete" data-id="' . esc_attr($r->id) . '">Delete</a></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';

        // Show today analytics
        $key = 'acebot_analytics_' . date('Ymd');
        $data = get_option($key, array());
        echo '<h2>Analytics (today)</h2>';
        echo '<pre>' . esc_html(print_r($data, true)) . '</pre>';

        echo '</div>';
        // delete JS
        echo '<script>
        (function(){
            var els = document.querySelectorAll(".acebot-delete");
            els.forEach(function(el){
                el.addEventListener("click", function(e){
                    e.preventDefault();
                    if (!confirm("Delete this lead?")) return;
                    var id = this.getAttribute("data-id");
                    var xhr = new XMLHttpRequest();
                    xhr.open("POST", "' . admin_url('admin-ajax.php') . '");
                    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                    xhr.onload = function(){ if (xhr.status==200) location.reload(); };
                    xhr.send("action=acebot_delete_lead&id=" + encodeURIComponent(id) + "&nonce=' . wp_create_nonce('acebot_nonce') . '");
                });
            });
        })();
        </script>';
    }

    public function enqueue_assets() {
        if (is_admin()) return;
        // register inline styles & script
        $opts = get_option($this->option_name);

        $css = $this->frontend_css();
        wp_register_style('acebot-inline', false);
        wp_enqueue_style('acebot-inline');
        wp_add_inline_style('acebot-inline', $css);

        $js = $this->frontend_js();
        wp_register_script('acebot-inline-js', false, array('jquery'), null, true);
        wp_enqueue_script('acebot-inline-js');

        $localized = array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('acebot_nonce'),
            'phone_default' => $opts['phone_default'] ?? '+60164777167',
            'button_text' => $opts['button_text'] ?? 'Chat on WhatsApp',
            'brand_color' => $opts['brand_color'] ?? '#25D366',
            'logo_url' => $opts['logo_url'] ?? '',
            'position' => $opts['position'] ?? 'bottom-right',
            'show_on_homepage' => !empty($opts['show_on_homepage']) ? 1 : 0,
            'open_on_load' => !empty($opts['open_on_load']) ? 1 : 0,
            'agents' => $opts['agents'] ?? array(array('label'=>'Default','phone'=>($opts['phone_default'] ?? '+60164777167'))),
            'notify_email' => $opts['notify_email'] ?? get_option('admin_email'),
            'i18n' => $opts['i18n'] ?? array()
        );
        wp_localize_script('acebot-inline-js', 'AceBotOpts', $localized);
        wp_add_inline_script('acebot-inline-js', $js);
    }

    private function frontend_css() {
        return "
            #acebot-root{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial;}
            .acebot-widget{position:fixed;z-index:99999}
            .acebot-widget.bottom-right{right:20px;bottom:20px}
            .acebot-widget.bottom-left{left:20px;bottom:20px}
            .acebot-button{display:flex;align-items:center;gap:10px;background:var(--acebot-brand,#25D366);color:#fff;border-radius:999px;padding:12px 16px;box-shadow:0 6px 18px rgba(0,0,0,.12);border:none;cursor:pointer}
            .acebot-icon{width:22px;height:22px;background-size:contain;display:inline-block}
            .acebot-chat{width:320px;max-width:calc(100vw-40px);background:#fff;border-radius:12px;overflow:hidden;margin-bottom:8px;box-shadow:0 12px 40px rgba(0,0,0,.16)}
            .acebot-chat header{background:linear-gradient(90deg,#06b26b,#00a884);color:#fff;padding:12px;display:flex;justify-content:space-between;align-items:center}
            .acebot-messages{padding:12px;max-height:200px;overflow:auto;font-size:13px;color:#333}
            .acebot-quick{padding:12px;border-top:1px solid #eee;display:flex;gap:8px;flex-wrap:wrap}
            .acebot-quick button{padding:8px 10px;border-radius:999px;border:1px solid #eee;background:#fafafa;cursor:pointer}
            .acebot-form{padding:12px}
            .acebot-form .field{margin-bottom:8px}
            .acebot-form input,.acebot-form textarea,.acebot-form select{width:100%;padding:8px;box-sizing:border-box;border:1px solid #ddd;border-radius:6px}
            .acebot-form .submit{background:#0b8f54;color:#fff;padding:10px;border-radius:8px;border:none;cursor:pointer;width:100%}
            @media(max-width:600px){.acebot-chat{width:92%}}
";
    }

    private function frontend_js() {
        // Note: uses jQuery (WP default) for AJAX convenience
        return "(function($){
        var opts = window.AceBotOpts || {};
        function create(tag, attrs, html){ var el = document.createElement(tag); if(attrs) for(var k in attrs) el.setAttribute(k, attrs[k]); if(html) el.innerHTML = html; return el; }

        function render(){
            var root = document.getElementById('acebot-root');
            if(!root) {
                // fallback - create container in body
                root = document.createElement('div'); root.id = 'acebot-root'; document.body.appendChild(root);
            }
            root.innerHTML = '';
            var widget = create('div', {class: 'acebot-widget ' + (opts.position || 'bottom-right')});
            var chat = create('div', {class: 'acebot-chat', style: 'display:none'});
            var headerHtml = '<div style=\"display:flex;align-items:center;gap:8px\">' + (opts.logo_url ? '<img src=\"'+opts.logo_url+'\" style=\"height:28px;border-radius:4px\" />' : '') + '<strong>' + (opts.i18n && opts.i18n.title ? opts.i18n.title : 'Chat with us') + '</strong></div>' + '<button class=\"acebot-close\" style=\"background:transparent;border:0;color:rgba(255,255,255,.95);cursor:pointer\">✕</button>';
            var header = create('header',{}, headerHtml);
            var messages = create('div',{class:'acebot-messages'}, '<div>Hi! I\\'m AceBot. Choose an option below, fill the form, or open WhatsApp.</div>');
            var quick = create('div',{class:'acebot-quick'});
            var quickReplies = ['I want to enroll','Pricing','Course schedule','Support'];
            quickReplies.forEach(function(q){ var b = create('button',{}, q); b.addEventListener('click', function(){ openWhatsApp(q); track('quick_reply'); }); quick.appendChild(b); });

            // form
            var form = create('form', {class:'acebot-form', id:'acebot-form'});
            var i18n = opts.i18n || {};
            var agentSel = create('select', {name:'agent', id:'acebot-agent'});
            (opts.agents || []).forEach(function(a){ var o = document.createElement('option'); o.value = a.phone || a.label || ''; o.text = (a.label || 'Agent') + (a.phone ? ' ('+a.phone+')' : ''); agentSel.appendChild(o); });
            form.appendChild(create('div', {class:'field'}, '<input name=\"name\" placeholder=\"'+(i18n.placeholder_name||'Your name')+'\" required />'));
            form.appendChild(create('div', {class:'field'}, '<input type=\"email\" name=\"email\" placeholder=\"'+(i18n.placeholder_email||'Email (optional)')+'\" />'));
            form.appendChild(create('div', {class:'field'}, '<input name=\"phone\" placeholder=\"'+(i18n.placeholder_phone||'Phone (optional)')+'\" />'));
            form.appendChild(create('div', {class:'field'}, '<textarea name=\"message\" placeholder=\"'+(i18n.placeholder_message||'Your message')+'\"></textarea>'));
            var wrap = create('div', {class:'field'}); wrap.appendChild(agentSel); form.appendChild(wrap);
            form.appendChild(create('div', {class:'field'}, '<button class=\"submit\" type=\"submit\">'+(i18n.send_button||'Send & Open WhatsApp')+'</button>'));

            form.addEventListener('submit', function(e){ e.preventDefault();
                var data = {
                    action:'acebot_save_lead',
                    nonce: opts.nonce,
                    name: this.querySelector('[name=name]').value || '',
                    email: this.querySelector('[name=email]').value || '',
                    phone: this.querySelector('[name=phone]').value || '',
                    message: this.querySelector('[name=message]').value || '',
                    agent: this.querySelector('[name=agent]').value || (opts.phone_default || '')
                };
                // AJAX save lead
                $.post(opts.ajax_url, data, function(resp){
                    var parts = [];
                    if (data.name) parts.push('Name: ' + data.name);
                    if (data.email) parts.push('Email: ' + data.email);
                    if (data.phone) parts.push('Phone: ' + data.phone);
                    if (data.message) parts.push('Message: ' + data.message);
                    var text = parts.join('\\n');
                    openWhatsApp(text, data.agent);
                    track('lead_submit', data.agent);
                });
            });

            var openBtn = create('button', {class:'acebot-button'}, '<span class=\"acebot-icon\"></span>' + (opts.button_text || 'Chat on WhatsApp'));
            openBtn.addEventListener('click', function(){ chat.style.display = chat.style.display === 'none' ? 'block' : 'none'; track('open_toggle'); });

            header.querySelector('.acebot-close').addEventListener('click', function(){ chat.style.display = 'none'; track('close'); });

            chat.appendChild(header);
            chat.appendChild(messages);
            chat.appendChild(quick);
            chat.appendChild(form);

            widget.appendChild(chat);
            widget.appendChild(openBtn);
            root.appendChild(widget);

            if (opts.open_on_load && +opts.open_on_load === 1) {
                chat.style.display = 'block';
                track('open_on_load');
            }

            // set brand color CSS variable
            try {
                var rootEl = document.querySelector('.acebot-button');
                if (rootEl) rootEl.style.setProperty('--acebot-brand', opts.brand_color || '#25D366');
            } catch(e){}
        }

        function openWhatsApp(text, phone){
            phone = (phone || (opts.phone_default || '')).replace(/[^0-9]/g,'');
            var msg = encodeURIComponent(text || opts.button_text || 'Hello');
            if (!phone) { alert('WhatsApp phone not configured'); return; }
            var url = 'https://wa.me/' + phone + '?text=' + msg;
            // GTM dataLayer push
            try { if (window.dataLayer && typeof window.dataLayer.push === 'function') window.dataLayer.push({event:'acebot_whatsapp_open', phone: phone, message: text || ''}); } catch(e){}
            window.open(url, '_blank');
        }

        function track(action, agent){
            try {
                $.post(opts.ajax_url, {action:'acebot_track', nonce: opts.nonce, action_type: action, agent: agent || ''}, function(){});
                if (window.dataLayer && typeof window.dataLayer.push === 'function') window.dataLayer.push({event:'acebot_event', acebot_action:action, acebot_agent: agent || ''});
            } catch(e){}
        }

        $(function(){ render(); });
    })(jQuery);";
    }

    // Print widget root in footer unless only show on homepage & not front
    public function maybe_print_widget() {
        $opts = get_option($this->option_name);
        if (!empty($opts['show_on_homepage']) && !is_front_page()) return;
        echo '<div id="acebot-root"></div>';
    }

    // AJAX: save lead
    public function ajax_save_lead() {
        check_ajax_referer('acebot_nonce', 'nonce');
        $name = sanitize_text_field($_POST['name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $message = sanitize_textarea_field($_POST['message'] ?? '');
        $agent = sanitize_text_field($_POST['agent'] ?? '');
        global $wpdb;
        $wpdb->insert($this->table, array(
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'message' => $message,
            'agent' => $agent
        ), array('%s','%s','%s','%s','%s'));

        // email notifications
        $opts = get_option($this->option_name);
        $admin = get_option('admin_email');
        $notify = $opts['notify_email'] ?? $admin;
        $subject = 'New AceBot lead';
        $body = "Name: $name\nEmail: $email\nPhone: $phone\nAgent: $agent\nMessage:\n$message\n";
        wp_mail($admin, $subject, $body);
        if ($notify && $notify !== $admin) wp_mail($notify, $subject, $body);

        wp_send_json_success(array('saved' => true));
    }

    // AJAX: track simple analytics (stored as daily option)
    public function ajax_track() {
        check_ajax_referer('acebot_nonce', 'nonce');
        $action = sanitize_text_field($_POST['action_type'] ?? 'click');
        $agent = sanitize_text_field($_POST['agent'] ?? '');
        $key = 'acebot_analytics_' . date('Ymd');
        $data = get_option($key, array());
        if (!isset($data[$action])) $data[$action] = 0;
        $data[$action]++;
        if ($agent) {
            if (!isset($data['agent'])) $data['agent'] = array();
            if (!isset($data['agent'][$agent])) $data['agent'][$agent] = 0;
            $data['agent'][$agent]++;
        }
        update_option($key, $data);
        wp_send_json_success($data);
    }

    public function ajax_delete_lead() {
        check_ajax_referer('acebot_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('unauthorized');
        $id = intval($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error('invalid');
        global $wpdb;
        $wpdb->delete($this->table, array('id'=>$id), array('%d'));
        wp_send_json_success();
    }
}

new AceBot_WhatsApp_Single();

// Shortcode for manual placement
function ace_whatsapp_bot_shortcode() {
    return '<div id=\"acebot-root\"></div>';
}
add_shortcode('ace_whatsapp_bot', 'ace_whatsapp_bot_shortcode');

// Uninstall handler (when plugin removed via WP admin uninstall)
if (defined('WP_UNINSTALL_PLUGIN')) {
    global $wpdb;
    $table = $wpdb->prefix . 'acebot_leads';
    $wpdb->query("DROP TABLE IF EXISTS {$table}");
    delete_option('acebot_whatsapp_options');
}
?>
