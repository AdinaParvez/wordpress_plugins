<?php
/*
Plugin Name: Custom Language Form Bahrain
Description: A responsive language form that sends email and saves data to the database.
Version: 2.0
Author: Adina Pervaiz
*/

// Create database table on plugin activation
register_activation_hook(__FILE__, 'cef_language_create_table');
function cef_language_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'language_form_submissions_bh';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        parent_name varchar(255) NOT NULL,
        student_name varchar(255) NOT NULL,
        dob date NOT NULL,
        phone varchar(50) NOT NULL,
        email varchar(255) NOT NULL,
        category varchar(50) NOT NULL,
        language varchar(50) NOT NULL,
        level varchar(50) NOT NULL,
        session_duration varchar(50) NOT NULL,
        preferred_days text NOT NULL,
        preferred_timing varchar(50) NOT NULL,
        message text NOT NULL,
        terms varchar(50) NOT NULL,
        email_sent tinyint(1) DEFAULT 0,
        submitted_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Add admin menu to view submissions
add_action('admin_menu', 'cef_language_add_admin_menu');
function cef_language_add_admin_menu() {
    add_menu_page(
        'Language Form Submissions',
        'Language Forms',
        'manage_options',
        'language-form-submissions',
        'cef_language_display_submissions',
        'dashicons-translation',
        32
    );
}

// Display submissions in admin
function cef_language_display_submissions() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'language_form_submissions_bh';
    
    // Handle delete action
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $wpdb->delete($table_name, ['id' => $id]);
        echo '<div class="notice notice-success"><p>Submission deleted successfully.</p></div>';
    }
    
    // Handle export action
    if (isset($_GET['action']) && $_GET['action'] === 'export') {
        cef_language_export_to_csv();
        exit;
    }
    
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submitted_at DESC");
    
    ?>
    <div class="wrap">
        <h1>Language Learning Form Submissions</h1>
        <p>
            <a href="<?php echo admin_url('admin.php?page=language-form-submissions&action=export'); ?>" class="button button-primary">Export to CSV</a>
        </p>
        
        <?php if (empty($submissions)): ?>
            <p>No submissions found.</p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Parent Name</th>
                        <th>Student Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Language</th>
                        <th>Level</th>
                        <th>Email Sent</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $submission): ?>
                        <tr>
                            <td><?php echo $submission->id; ?></td>
                            <td><?php echo esc_html($submission->parent_name); ?></td>
                            <td><?php echo esc_html($submission->student_name); ?></td>
                            <td><?php echo esc_html($submission->email); ?></td>
                            <td><?php echo esc_html($submission->phone); ?></td>
                            <td><?php echo esc_html($submission->language); ?></td>
                            <td><?php echo esc_html($submission->level); ?></td>
                            <td><?php echo $submission->email_sent ? '✓ Yes' : '✗ No'; ?></td>
                            <td><?php echo date('M j, Y g:i a', strtotime($submission->submitted_at)); ?></td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=language-form-submissions&action=view&id=' . $submission->id); ?>" class="button button-small">View</a>
                                <a href="<?php echo admin_url('admin.php?page=language-form-submissions&action=delete&id=' . $submission->id); ?>" class="button button-small" onclick="return confirm('Are you sure you want to delete this submission?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
        <?php
        // Display full details if viewing a specific submission
        if (isset($_GET['action']) && $_GET['action'] === 'view' && isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $submission = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
            
            if ($submission) {
                ?>
                <div style="margin-top: 30px; padding: 20px; background: #fff; border: 1px solid #ccc;">
                    <h2>Submission Details - #<?php echo $submission->id; ?></h2>
                    <table class="form-table">
                        <tr><th>Parent's Name:</th><td><?php echo esc_html($submission->parent_name); ?></td></tr>
                        <tr><th>Student's Name:</th><td><?php echo esc_html($submission->student_name); ?></td></tr>
                        <tr><th>Date of Birth:</th><td><?php echo esc_html($submission->dob); ?></td></tr>
                        <tr><th>Phone:</th><td><?php echo esc_html($submission->phone); ?></td></tr>
                        <tr><th>Email:</th><td><?php echo esc_html($submission->email); ?></td></tr>
                        <tr><th>Tutoring Category:</th><td><?php echo esc_html($submission->category); ?></td></tr>
                        <tr><th>Language:</th><td><?php echo esc_html($submission->language); ?></td></tr>
                        <tr><th>Level:</th><td><?php echo esc_html($submission->level); ?></td></tr>
                        <tr><th>Session Duration:</th><td><?php echo esc_html($submission->session_duration); ?></td></tr>
                        <tr><th>Preferred Days:</th><td><?php echo esc_html($submission->preferred_days); ?></td></tr>
                        <tr><th>Preferred Timing:</th><td><?php echo esc_html($submission->preferred_timing); ?></td></tr>
                        <tr><th>Message:</th><td><?php echo nl2br(esc_html($submission->message)); ?></td></tr>
                        <tr><th>Terms Agreed:</th><td><?php echo esc_html($submission->terms); ?></td></tr>
                        <tr><th>Email Sent:</th><td><?php echo $submission->email_sent ? 'Yes' : 'No'; ?></td></tr>
                        <tr><th>Submitted:</th><td><?php echo date('F j, Y, g:i a', strtotime($submission->submitted_at)); ?></td></tr>
                    </table>
                    <p><a href="<?php echo admin_url('admin.php?page=language-form-submissions'); ?>" class="button">Back to List</a></p>
                </div>
                <?php
            }
        }
        ?>
    </div>
    <?php
}


function cef_language_export_to_csv() {
    global $wpdb;

    // Clear any previous output to avoid header errors
    if (ob_get_length()) ob_clean();

    $table_name = $wpdb->prefix . 'language_form_submissions_bh';
    $submissions = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    // If no records found, stop
    if (empty($submissions)) {
        wp_die(__('No data available to export.', 'cef'));
    }

    // Set headers for CSV file download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=language_form_submissions_bh-' . date('Y-m-d') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Open output stream
    $output = fopen('php://output', 'w');

    // Add UTF-8 BOM (for Excel compatibility)
    fputs($output, "\xEF\xBB\xBF");

    // Output CSV header (column names)
    fputcsv($output, array_keys($submissions[0]));

    // Output CSV rows
    foreach ($submissions as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
    exit;

}


// Shortcode to display form
function cef_language_form_shortcode() {
    ob_start(); ?>
    
<style>
    .cef-form-wrapper {
        max-width: 100%; /* Full width like Elementor */
        margin: 0 auto;
        padding: 20px 0;
        background: #fff; /* White background */
        font-family: Arial, sans-serif;
    }

    .cef-form-wrapper form {
        display: grid;
        grid-template-columns: repeat(2, 1fr); /* Two columns by default */
        gap: 20px;
        align-items: start;
    }

    .cef-form-wrapper p {
        margin: 0;
    }

    .cef-form-wrapper label {
        font-weight: 600;
        font-size: 14px;
        display: block;
        margin-bottom: 6px;
        color: #333;
    }

    .cef-form-wrapper input[type="text"],
    .cef-form-wrapper input[type="number"],
    .cef-form-wrapper input[type="date"],
    .cef-form-wrapper input[type="tel"],
    .cef-form-wrapper input[type="email"],
    .cef-form-wrapper textarea,
    .cef-form-wrapper select {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        background: #fff;
        box-sizing: border-box;
    }

    /* Full-width fields */
    .cef-form-wrapper .full {
        grid-column: span 2;
        width: 100%;
    }

    /* Submit Button */
    .cef-form-wrapper input[type="submit"] {
        grid-column: span 2;
        background-color: #f9b000; /* Match ACE yellow button */
        width: 100%;
        color: #000;
        border: none;
        padding: 12px;
        cursor: pointer;
        border-radius: 4px;
        font-size: 16px;
        font-weight: bold;
        transition: background 0.3s ease;
    }

    .cef-form-wrapper input[type="submit"]:hover {
        background-color: #005177;
        color: #fff;
    }

    /* Checkbox label alignment */
    .cef-form-wrapper label input[type="checkbox"] {
        display: inline-block;
        width: auto;
        margin-right: 8px;
    }

    /* 🔹 Responsive Styles */
    @media (max-width: 768px) {
        .cef-form-wrapper form {
            grid-template-columns: 1fr; /* Single column on tablets/mobiles */
        }

        .cef-form-wrapper .full {
            grid-column: span 1; /* Reset full width inside 1-col layout */
        }

        .cef-form-wrapper input,
        .cef-form-wrapper select,
        .cef-form-wrapper textarea {
            font-size: 16px; /* Slightly bigger for touch screens */
        }

        .cef-form-wrapper input[type="submit"] {
            font-size: 18px;
            padding: 14px;
        }
    }
</style>



    <div class="cef-form-wrapper">
        <!--The code to check if emails are succeeding or failing-->
        <?php
        // Display success or error messages
        if (isset($_GET['form_status'])) {
            if ($_GET['form_status'] === 'success') {
                echo '<div class="cef-success-message">✓ Thank you! Your inquiry has been submitted successfully.</div>';
            } elseif ($_GET['form_status'] === 'error') {
                echo '<div class="cef-error-message">⚠ There was an error submitting your form. Please try again.</div>';
            } elseif ($_GET['form_status'] === 'terms_error') {
                echo '<div class="cef-error-message">⚠ You must agree to the Terms & Conditions.</div>';
            }
        }
        ?>
        <form method="post" action="">
           <?php wp_nonce_field('cef_language_form_action', 'cef_language_form_nonce'); ?>
            <p>
                <label>Parent's Name</label>
                <input type="text" placeholder="Please write your full name" name="parent_name" required>
            </p>
            <p>
                <label>Student's Name</label>
                <input type="text" placeholder="Please write Student's full name" name="student_name" required>
            </p>
       
            <p>
                <label>Date of Birth</label>
                <input type="date" placeholder="Please select your Date of Birth" name="dob" required>
            </p>
            <p>
                <label>Phone Number</label>
                <input type="tel" placeholder="Please write phone number" name="phone" required>
            </p>
             <!-- FULL WIDTH -->
            <p class="full">
                <label>Email</label>
                <input type="email" placeholder="Please write your Email"  name="email" required>
            </p>
            <p>
                <label>Tutoring Category</label>
                <select name="category" required>
                    <option value="">Please Choose</option>
                    <option value="Online">Online Tutoring</option>
                    <option value="Home">Home Tutoring</option>
                </select>
            </p>
            <p>
                <label>Choose Language</label>
                <select name="language" required>
                    <option value="">Please Choose</option>
                    <option value="English">English</option>
                    <option value="French">French</option>
                    <option value="German">German</option>
                    <option value="Italian">Italian</option>
                    <option value="Korean">Korean</option>
                    <option value="Chinese">Chinese</option>
                    <option value="Japanese">Japanese</option>
                </select>
            </p>
                <!-- FULL WIDTH -->
            <p class="full">
                <label>Choose Level</label>
                <select name="level" required>
                    <option value="">Please Choose</option>
                    <option value="Beginner">Beginner</option>
                    <option value="Elementary">Elementary</option>
                    <option value="Pre-Intermediate">Pre-Intermediate</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Upper-Intermediate">Upper-Intermediate</option> 
                    <option value="Advanced">Advanced</option>
                    <option value="Proficient">Proficient</option>
                </select>
            </p>
            <p>
                <label>Session Duration</label>
                   <select name="session_duration" required>
                    <option value="">Please Choose</option>
                    <option value="1 Hour">1 Hour</option>
                    <option value="1.5 Hour">1.5 Hours</option>
                    <option value="2 Hours">2 Hours</option>
                    <option value="3 Hours">3 Hours</option>
                </select>
            </p>
            <p>
                <label>Preferred Days</label>
                <select name="preferred_days[]" multiple required>
                    <option value="">Please Choose</option>
                    <option value="Monday">Monday</option>
                    <option value="Tuesday">Tuesday</option>
                    <option value="Wednesday">Wednesday</option>
                    <option value="Thursday">Thursday</option>
                    <option value="Friday">Friday</option>
                     <option value="Saturday">Saturday</option>
                     <option value="Sunday">Sunday</option>
                </select>
            </p>
            <p>
                <label>Preferred Timing(s)</label>
                <select name="preferred_timing" required>
                    <option value="">Please Choose</option>
                    <option value="Pre12PM">Pre 12 PM</option>
                    <option value="12-5PM">12 - 5 PM</option>
                    <option value="After5PM">After 5 PM</option>
                </select>
            </p>
                <!-- FULL WIDTH -->
            <p class="full">
                <label>Message</label>
                <textarea name="message" placeholder="message" rows="5" required></textarea>
            </p>
                <!-- FULL WIDTH -->
            <p class="full">
                <label>
                    <input type="checkbox" name="terms" value="Agreed" required>
                    Terms & Conditions - I agree to the Terms & Conditions of ACE WEB SERVICES W.L.L. (ACE Education Bahrain) </label>
            </p>
                <!-- FULL WIDTH -->
            <p class="full">
                <input type="submit" name="cef_language_submit" value="Send Enquiry">
            </p>
        </form>
        <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Auto-hide success/error messages after 5 seconds
            const successMsg = document.querySelector('.cef-success-message');
            const errorMsg = document.querySelector('.cef-error-message');
            
            if (successMsg || errorMsg) {
                setTimeout(function() {
                    // Remove message with fade effect
                    const msg = successMsg || errorMsg;
                    msg.style.transition = 'opacity 0.5s ease';
                    msg.style.opacity = '0';
                    
                    setTimeout(function() {
                        msg.remove();
                        // Clean URL by removing query parameter
                        const url = new URL(window.location);
                        url.searchParams.delete('form_status');
                        window.history.replaceState({}, document.title, url);
                    }, 500);
                }, 10000); // 10 seconds
            }
        });
        </script>
    </div>

    <?php
    return ob_get_clean();
}
add_shortcode('custom_language_form_bh', 'cef_language_form_shortcode');


// Handle form submission early (Fixed Hook!)
add_action('init', 'cef_handle_language_form');

function cef_handle_language_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cef_language_submit']) ) {

         // Verify nonce
        if (!isset($_POST['cef_language_form_nonce']) || !wp_verify_nonce($_POST['cef_language_form_nonce'], 'cef_language_form_action')) {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
            exit;
        }

        // Terms & Conditions check
        if ( empty($_POST['terms']) ) {
            wp_redirect(add_query_arg('form_status', 'terms_error', wp_get_referer()));
            exit;
        }

        $to = ['info@aceeducation.bh', 'acekl2018@gmail.com']; // Change this to your email
        $subject = 'New Language Learning Form Submission';

        $fields = [
                "Parent's Name" => sanitize_text_field($_POST['parent_name']),
                "Student's Name: " => sanitize_text_field($_POST['student_name']),
                "Date of Birth: " => sanitize_text_field($_POST['dob']),
                "Phone: " => sanitize_text_field($_POST['phone']),
                "Email: " => sanitize_email($_POST['email']),
                "Tutoring Category: " => sanitize_text_field($_POST['category']),
                "Language: " => sanitize_text_field($_POST['language']),
                "Level: " => sanitize_text_field($_POST['level']),
                "Session Duration: " => sanitize_text_field($_POST['session_duration']),
                "Preferred Days: " => implode(', ', array_map('sanitize_text_field', $_POST['preferred_days'])), 
                "Preferred Timing: " => sanitize_text_field($_POST['preferred_timing']),
                "Message: " => sanitize_textarea_field($_POST['message']),
                "Terms & Conditions: " => sanitize_text_field($_POST['terms']),

        ];


        // Create HTML email body
        $message = '<html><body style="font-family: Arial, sans-serif;">';
        $message .= '<h2 style="color: #f9b000;">New Language Request</h2>';
        $message .= '<table style="border-collapse: collapse; width: 100%;">';
        
        foreach ($fields as $label => $value) {
            $message .= '<tr style="border-bottom: 1px solid #ddd;">';
            $message .= '<td style="padding: 10px; font-weight: bold; width: 200px;">' . $label . ':</td>';
            $message .= '<td style="padding: 10px;">' . $value . '</td>';
            $message .= '</tr>';
        }
        
        $message .= '</table>';
        $message .= '<p style="margin-top: 20px; color: #666;">Submitted on: ' . date('F j, Y, g:i a') . '</p>';
        $message .= '</body></html>';


        $headers = [
            'From: ACE Education Bahrain<info@aceeducation.bh>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . sanitize_email($_POST['email'])
        ];

        
        // Send email
        $mail_sent = wp_mail($to, $subject, $message, $headers);

        // Save to database (always save, mark if email was sent)
        global $wpdb;
        $table_name = $wpdb->prefix . 'language_form_submissions_bh';
        
        $data['email_sent'] = $mail_sent ? 1 : 0;
        
        $inserted = $wpdb->insert($table_name, $data);

        // Redirect with success message (form is saved regardless of email status)
        if ($inserted) {
            wp_redirect(add_query_arg('form_status', 'success', wp_get_referer()));
        } else {
            wp_redirect(add_query_arg('form_status', 'error', wp_get_referer()));
        }
        exit;
    }
}
?>
