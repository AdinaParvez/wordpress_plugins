<?php
/**
 * Plugin Name: LCP Optimizer (Hero Image)
 * Description: Preload and prioritize the LCP hero image without editing functions.php
 * Version: 1.0
 * Author: ACE Web Team
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * 1️⃣ Preload LCP image in HEAD
 */
add_action('wp_head', function () {
    if (!is_front_page()) return;

    ?>
    <link rel="preload"
          as="image"
          href="https://aceeducation.com.my/wp-content/uploads/2025/06/ace_edu_pic3.webp"
          fetchpriority="high">
    <?php
});

/**
 * 2️⃣ Force fetchpriority=high on LCP image
 */
add_filter('wp_get_attachment_image_attributes', function ($attr, $attachment) {
    if (is_front_page() && isset($attr['class']) && str_contains($attr['class'], 'hero')) {
        $attr['fetchpriority'] = 'high';
        unset($attr['loading']); // remove lazy load
    }
    return $attr;
}, 10, 2);
