<?php
/**
 * Plugin Name: Category Elementor Template
 * Plugin URI: https://acelanguagecentre.edu.my
 * Description: Adds Elementor template field to WooCommerce product categories. Each category can have its own custom Elementor template.
 * Version: 1.0.1
 * Author: ACE Language Centre
 * Author URI: https://acelanguagecentre.edu.my
 * License: GPL v2 or later
 * Text Domain: category-elementor-template
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Category_Elementor_Template {

    public function __construct() {
        // Add field to category edit page
        add_action('product_cat_edit_form_fields', [$this, 'add_template_field'], 10, 1);
        add_action('product_cat_add_form_fields', [$this, 'add_template_field_create'], 10, 1);
        
        // Save field value
        add_action('edited_product_cat', [$this, 'save_template_field'], 10, 1);
        add_action('created_product_cat', [$this, 'save_template_field'], 10, 1);
        
        // Display template on category page - HIGHER PRIORITY
        add_action('woocommerce_before_main_content', [$this, 'display_template'], 25);
        
        // Remove default category description if template exists
        add_action('woocommerce_archive_description', [$this, 'maybe_remove_description'], 5);
        
        // Add admin column
        add_filter('manage_edit-product_cat_columns', [$this, 'add_template_column']);
        add_filter('manage_product_cat_custom_column', [$this, 'add_template_column_content'], 10, 3);
        
        // Enable shortcode processing
        add_filter('woocommerce_taxonomy_archive_description_raw', 'do_shortcode', 99);
        add_filter('term_description', 'do_shortcode', 99);
    }

    /**
     * Maybe remove default description if template exists
     */
    public function maybe_remove_description() {
        if (!is_product_category()) {
            return;
        }

        $term_id = get_queried_object_id();
        $template_id = get_term_meta($term_id, 'elementor_template_id', true);

        // If template exists, remove the description that shows shortcode
        if ($template_id && !empty($template_id)) {
            remove_action('woocommerce_archive_description', 'woocommerce_taxonomy_archive_description', 10);
        }
    }

    /**
     * Add template field to category edit page
     */
    public function add_template_field($term) {
        $template_id = get_term_meta($term->term_id, 'elementor_template_id', true);
        $templates = $this->get_elementor_templates();
        ?>
        <tr class="form-field">
            <th scope="row">
                <label for="elementor_template_id">Elementor Template</label>
            </th>
            <td>
                <select name="elementor_template_id" id="elementor_template_id" class="postform">
                    <option value="">— Select Template —</option>
                    <?php foreach ($templates as $template) : ?>
                        <option value="<?php echo esc_attr($template->ID); ?>" <?php selected($template_id, $template->ID); ?>>
                            <?php echo esc_html($template->post_title); ?> (ID: <?php echo esc_html($template->ID); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <p class="description">Select an Elementor template to display at the top of this category page.</p>
                <p class="description"><strong>Or enter Template ID manually:</strong></p>
                <input type="number" name="elementor_template_id_manual" id="elementor_template_id_manual" value="<?php echo esc_attr($template_id); ?>" style="width: 100px;">
                <p class="description">Find template ID in: <strong>Elementor → Saved Templates</strong></p>
                <p class="description" style="color: #d63638;"><strong>IMPORTANT:</strong> Remove the [elementor-template] shortcode from the category description field above. This plugin will handle the template display automatically.</p>
            </td>
        </tr>
        <?php
    }

    /**
     * Add template field to category create page
     */
    public function add_template_field_create() {
        $templates = $this->get_elementor_templates();
        ?>
        <div class="form-field">
            <label for="elementor_template_id">Elementor Template</label>
            <select name="elementor_template_id" id="elementor_template_id" class="postform">
                <option value="">— Select Template —</option>
                <?php foreach ($templates as $template) : ?>
                    <option value="<?php echo esc_attr($template->ID); ?>">
                        <?php echo esc_html($template->post_title); ?> (ID: <?php echo esc_html($template->ID); ?>)
                    </option>
                <?php endforeach; ?>
            </select>
            <p class="description">Select an Elementor template to display at the top of this category page.</p>
            <p class="description"><strong>Or enter Template ID manually:</strong></p>
            <input type="number" name="elementor_template_id_manual" id="elementor_template_id_manual" style="width: 100px;">
        </div>
        <?php
    }

    /**
     * Save template field value
     */
    public function save_template_field($term_id) {
        // Use manual ID if provided, otherwise use dropdown
        if (isset($_POST['elementor_template_id_manual']) && !empty($_POST['elementor_template_id_manual'])) {
            $template_id = absint($_POST['elementor_template_id_manual']);
        } elseif (isset($_POST['elementor_template_id'])) {
            $template_id = absint($_POST['elementor_template_id']);
        } else {
            $template_id = 0;
        }

        if ($template_id > 0) {
            update_term_meta($term_id, 'elementor_template_id', $template_id);
        } else {
            delete_term_meta($term_id, 'elementor_template_id');
        }
    }

    /**
     * Display template on category page
     */
    public function display_template() {
        if (!is_product_category()) {
            return;
        }

        $term_id = get_queried_object_id();
        $template_id = get_term_meta($term_id, 'elementor_template_id', true);

        if ($template_id && !empty($template_id)) {
            // Check if Elementor plugin is active
            if (!did_action('elementor/loaded')) {
                echo '<!-- Elementor not loaded -->';
                return;
            }

            echo '<div class="category-elementor-template" style="width: 100%; margin: 20px 0;">';
            
            // Use Elementor's frontend class to render
            if (class_exists('\Elementor\Plugin')) {
                $elementor_instance = \Elementor\Plugin::instance();
                echo $elementor_instance->frontend->get_builder_content_for_display($template_id);
            } else {
                // Fallback to shortcode
                echo do_shortcode('[elementor-template id="' . absint($template_id) . '"]');
            }
            
            echo '</div>';
        }
    }

    /**
     * Get all Elementor templates
     */
    private function get_elementor_templates() {
        $args = [
            'post_type'      => 'elementor_library',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
            'post_status'    => 'publish'
        ];

        return get_posts($args);
    }

    /**
     * Add template column to category list
     */
    public function add_template_column($columns) {
        $columns['elementor_template'] = 'Elementor Template';
        return $columns;
    }

    /**
     * Display template in column
     */
    public function add_template_column_content($content, $column_name, $term_id) {
        if ($column_name === 'elementor_template') {
            $template_id = get_term_meta($term_id, 'elementor_template_id', true);
            if ($template_id) {
                $template = get_post($template_id);
                if ($template) {
                    $content = esc_html($template->post_title) . ' <span style="color: #999;">(ID: ' . $template_id . ')</span>';
                } else {
                    $content = '<span style="color: #d63638;">Template not found (ID: ' . $template_id . ')</span>';
                }
            } else {
                $content = '—';
            }
        }
        return $content;
    }
}

// Initialize the plugin
new Category_Elementor_Template();

// Activation hook
register_activation_hook(__FILE__, function() {
    // Clear any caches
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
    }
});